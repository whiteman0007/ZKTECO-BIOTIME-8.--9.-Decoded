# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\backends\\email_smtp.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

"""SMTP email backend class."""
import json
import smtplib
import socket
import ssl
import threading
from django.conf import settings
from django.core.mail.backends.base import BaseEmailBackend
from django.core.mail.message import sanitize_address
from django.core.mail.utils import DNS_NAME
from django.utils.encoding import force_str
from mysite.base import db_const
from mysite.tools.encryption_utils import aes_decrypt
class EmailBackend(BaseEmailBackend):
    """\n    A wrapper that manages the SMTP network connection.\n    """
    def __init__(self, host=None, port=None, username=None, password=None, use_tls=None, fail_silently=False, use_ssl=None, timeout=None, ssl_keyfile=None, ssl_certfile=None, **kwargs):
        super(EmailBackend, self).__init__(fail_silently=fail_silently)
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.use_tls = use_tls
        self.use_ssl = use_ssl
        self.timeout = timeout
        self.ssl_keyfile = ssl_keyfile
        self.ssl_certfile = ssl_certfile
        self._verbose = kwargs.get('verbose', False)
        if not isinstance(self._verbose, bool):
            self._verbose = False
        self._get_email_setting()
        self.connection = None
        self._lock = threading.RLock()
    def _get_email_setting(self):
        # irreducible cflow, using cdg fallback
        from mysite.base.models import SystemSetting
        es = SystemSetting.objects.filter(name='email_setting').first()
        if es is not None:
            es = json.loads(es.value)
            if 'email_password' in es:
                try:
                    es['email_password'] = aes_decrypt(es['email_password'])
                except Exception as e:
                    print(e)
        else:
            es = {}
        necessary = db_const.SMTP_NECESSARY_FIELD
        for field in necessary:
            value_from_args = getattr(self, field, None)
            if value_from_args is not None:
                continue
            mapping = necessary.get(field)
            db_field, default_value, sentry = (mapping.field, mapping.default, mapping.sentry)
            if len(db_field) > 0:
                db_value = es.get(db_field, None)
                if db_field is not None:
                    if sentry and callable(sentry):
                            db_value = sentry(db_value)
                    setattr(self, field, db_value)
                    setattr(self, field, default_value)
                    if self._verbose and settings.DEBUG:
                            print((field, '=', getattr(self, field)))
        self.use_ssl = False if self.use_tls else True
        if self.use_ssl and self.use_tls:
                raise ValueError('EMAIL_USE_TLS/EMAIL_USE_SSL are mutually exclusive, so only set one of those settings to True.')
    @property
    def connection_class(self):
        return smtplib.SMTP_SSL if self.use_ssl else smtplib.SMTP
    def get_connection(self, *args, **kwargs):
        self.connection = self.connection_class(*args, **kwargs)
    def open(self):
        """\n        Ensure an open connection to the email server. Return whether or not a\n        new connection was required (True or False) or None if an exception\n        passed silently.\n        """
        if self.connection:
            return False
        else:
            connection_params = {'local_hostname': DNS_NAME.get_fqdn()}
            if self.timeout is not None:
                connection_params['timeout'] = self.timeout
            if self.use_ssl:
                connection_params.update({'keyfile': self.ssl_keyfile, 'certfile': self.ssl_certfile})
        try:
            self.get_connection(self.host, self.port, **connection_params)
            if not self.use_ssl and self.use_tls:
                    self.connection.starttls(keyfile=self.ssl_keyfile, certfile=self.ssl_certfile)
            if self.username and self.password:
                    self.connection.login(force_str(self.username), force_str(self.password))
        except (smtplib.SMTPException, socket.error):
            if not self.fail_silently:
                raise
        else:
            return True
    def close(self):
        # irreducible cflow, using cdg fallback
        """Closes the connection to the email server."""
        if self.connection is None:
            return
        else:
            if False:
                pass
        self.connection.quit()
            except (ssl.SSLError, smtplib.SMTPServerDisconnected):
                self.connection.close()
                except smtplib.SMTPException:
                    if self.fail_silently:
                        return
                            self.connection = None
                        raise
    def send_messages(self, email_messages):
        # irreducible cflow, using cdg fallback
        """\n        Sends one or more EmailMessage objects and returns the number of email\n        messages sent.\n        """
        if not email_messages:
            return
        else:
            with self._lock:
                pass
        new_conn_created = self.open()
        if not self.connection or new_conn_created is None:
            return
            num_sent = 0
            for message in email_messages:
                sent = self._send(message)
                if sent:
                    num_sent += 1
            if new_conn_created:
                self.close()
                        return num_sent
    def _send(self, email_message):
        """A helper method that does the actual sending."""
        if not email_message.recipients():
            return False
        else:
            encoding = email_message.encoding or settings.DEFAULT_CHARSET
            from_email = sanitize_address(email_message.from_email, encoding)
            recipients = [sanitize_address(addr, encoding) for addr in email_message.recipients()]
            message = email_message.message()
        try:
            self.connection.sendmail(from_email, recipients, message.as_bytes(linesep='\r\n'))
        except smtplib.SMTPException:
            if not self.fail_silently:
                raise
            return False
        return True