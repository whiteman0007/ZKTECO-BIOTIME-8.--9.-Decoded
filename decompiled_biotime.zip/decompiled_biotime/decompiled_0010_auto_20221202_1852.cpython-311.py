# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0010_auto_20221202_1852.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from __future__ import unicode_literals
from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('personnel', '0009_auto_20220419_1516')]
    operations = [migrations.AlterModelOptions(name='employeecertification', options={'default_permissions': ('delete', 'change', 'view'), 'ordering': ['id']}), migrations.AlterModelOptions(name='resign', options={'default_permissions': ('delete', 'change', 'view'), 'ordering': ['id'], 'verbose_name': 'psnl_model_resign', 'verbose_name_plural': 'psnl_model_resign'})]