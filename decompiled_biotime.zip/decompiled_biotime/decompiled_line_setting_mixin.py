# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\line_setting_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
class LineSettingViewMixin:
    @action(methods=['get'], url_path='line_setting', detail=False)
    def line_setting(self, request, *args, **kwargs):
        instance = SystemSetting.objects.filter(name='line_notify_service').first()
        data = json.loads(instance.value) if instance else {}
        return Response(data)