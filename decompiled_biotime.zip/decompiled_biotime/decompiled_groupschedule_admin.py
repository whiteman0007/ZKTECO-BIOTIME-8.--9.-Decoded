# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\groupschedule_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from django.forms import ModelForm
from mysite import admin, config
from mysite.att.models import GroupSchedule
from mysite.att.actions import AddGroupSchedule
class GroupScheduleChangeForm(ModelForm):
    class Meta:
        model = GroupSchedule
        fields = ('group', 'start_date', 'end_date', 'shift')
@admin.register(GroupSchedule)
class GroupScheduleAdmin(admin.ZKModelAdmin):
    list_display = ('group_code', 'group_alias', 'employee_quantity', 'start_date', 'end_date', 'shift')
    form = GroupScheduleChangeForm
    list_filter = ('group__code', 'group__name', 'shift__alias')
    actions = (AddGroupSchedule,)
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def group_code(self, obj):
        return obj.group.code
    group_code.short_description = _('attGroup.fields.code')
    def group_alias(self, obj):
        return obj.group.name
    group_alias.short_description = _('attGroup.fields.name')
    def employee_quantity(self, obj):
        return obj.group.attemployee_set.count()
    employee_quantity.short_description = _('attGroup.fields.employeeQuantity')
    def get_queryset(self, request):
        queryset = super(GroupScheduleAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.assign_company:
                queryset = queryset.filter(group__company=request.user.assign_company)
        queryset = queryset.select_related()
        return queryset