# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\iclock\\devview_ex.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:36 UTC (1750673016)

import base64
import datetime
import functools
import os
import six
import socket
import json
import re
import logging
from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist
from django.core.cache import cache
from mysite._utils import getattr_ex
from mysite.core.zktools import getSQL_insert_new, getSQL_update_new, zk_get_VerifyStyles
from mysite.core.zkcmdproc import DevIdentity
from mysite.iclock import const as mconst, tasks
from mysite.iclock.const import bioFinger
from mysite.iclock.models import BioData, TerminalParameter
from mysite.iclock.utils import cache_key, getBiophoto, get_personnel_photo
from mysite.iclock.comm import const
from mysite.iclock.comm.utils import get_comm_setting
from mysite.personnel.models import Employee
from mysite.utils import customSql, customSql2, trimTemp, setValueDic, VersionInfo, getNormalCard, DevIdentity_ex, getUploadFileName, store_path
from mysite.visitor.models import Visitor, VisitorBioData
BIO_EMP_TABLE = BioData._meta.db_table
BIO_VISITOR_TABLE = VisitorBioData._meta.db_table
DATA_USER_INFO_DESC = 'User'
DATA_USER_PHOTO_DESC = 'User Photo'
BIO_DATA_FP_DESC = 'Fingerprint'
BIO_DATA_FACE_DESC = 'Face'
BIO_DATA_FINGER_VEIN_DESC = 'Finger Vein'
BIO_DATA_DESC = 'BioData'
BIO_DATA_PHOTO_DESC = 'BioPhoto'
logger = logging.getLogger('mysite.iclock.comm')
def format_pin(pin):
    if not settings.PIN_WIDTH:
        return pin
    else:
        return pin.rstrip().zfill(settings.PIN_WIDTH)
def get_employee(pin, device=None):
    """\n    If exists return else create and return\n    :param pin: Employee Code\n    :param device: Uploading device\n    :return: Instance of employee\n    """
    pin = format_pin(pin)
    emp, created = Employee.get_or_create(pin, device)
    return emp
def get_employee_via_pin(pin, device=None):
    if device and device.area:
            company_id = getattr(device.area, 'company_id', None)
    emp = Employee.get_emp_via_code(pin, company_id)
    return emp
def is_ipv4(ip):
    # irreducible cflow, using cdg fallback
    socket.inet_pton(socket.AF_INET, ip)
        return False if ip == '0.0.0.0' else True
        except AttributeError:
                socket.inet_aton(ip)
                    return ip.count('.') == 3
                    except socket.error:
                            return False
            except socket.error:
                    return False
def is_ipv6(ip):
    try:
        socket.inet_pton(socket.AF_INET6, ip)
    except socket.error:
        return False
    return True
def is_ip_address(ip):
    if is_ipv4(ip) or is_ipv6(ip):
        return True
    else:
        return False
def get_real_ip(request):
    forwards_str = request.META.get('HTTP_X_FORWARDED_FOR', '')
    if not forwards_str:
        forwards_str = request.META.get('HTTP_X_REAL_IP', '')
    if not forwards_str:
        forwards_str = request.META.get('REMOTE_ADDR', '')
    forwards = list(filter(None, forwards_str.split(',')))
    if forwards:
        ip = forwards[0].split(':')[0]
        return ip
    else:
        return ''
def save_device_upload_log(terminal, success_count, error_count, obj, op):
    if settings.ASYN_SAVE_DEVICE_UPLOAD_LOG:
        tasks.save_device_upload_log.delay(terminal, success_count, error_count, obj, op)
    else:
        tasks.save_device_upload_log(terminal, success_count, error_count, obj, op)
def update_command_error_result(cmd_id, cmd_result, update_time):
    if settings.ASYN_CMD_RESULT:
        tasks.update_command_error_result.delay(cmd_id, cmd_result, update_time)
    else:
        tasks.update_command_error_result(cmd_id, cmd_result, update_time)
def update_command_result(success_cmds, update_time):
    if settings.ASYN_CMD_RESULT:
        tasks.update_command_result.delay(success_cmds, update_time)
    else:
        tasks.update_command_result(success_cmds, update_time)
def valid_employee_pre_save(desc):
    """\n    Decorator for employee checking\n    :param desc: Data type description\n    :return:\n    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(device, payload, *args, **kwargs):
            data = body_data_format(payload)
            pin = data.get('PIN', None)
            if not pin:
                return (desc, '', False)
            else:
                try:
                    pin = format_pin(pin)
                except Exception as e:
                    return (desc, str(e))
                emp = get_employee(pin, device)
                if emp and emp.emp_code!= format_pin(pin):
                    return (desc, '', False)
                else:
                    if not emp:
                        if pin.startswith('V'):
                            emp = Visitor.objects.filter(visitor_code=pin).first()
                        else:
                            return (desc, '', False)
                    return func(device, pin, emp, data, *args, **kwargs)
        return wrapper
    return decorator
def punch_period_validator(punch_time):
    valid_days = get_comm_setting('transaction_retention', 9999, int)
    nt = datetime.datetime.now()
    if valid_days < 9999 and punch_time < nt - datetime.timedelta(days=valid_days):
            return False
    return True
def body_data_format(payload):
    data = {}
    for item in payload.split('\t'):
        kv = item.split('=', 1)
        if len(kv) > 1:
            k, v = kv
            data[k.replace('Pin', 'PIN')] = v
    return data
def card2number(card):
    if card in ['0']:
        return ''
    else:
        if card and len(card) == 12 and card.startswith('[') and (card[(-3):] in ['00]', '01]']):
                        card = str(int(card[1:3], 16) + int(card[3:5], 16) * 256 + int(card[5:7], 16) * 65536 + int(card[7:9], 16) * 16777216)
        return card
def save_bio_data_via_sql(payload, visitor=False):
    BIO_TABLE = BIO_EMP_TABLE
    if visitor:
        BIO_TABLE = BIO_VISITOR_TABLE
    sql, params = getSQL_insert_new(BIO_TABLE, payload)
    customSql(sql, params)
def update_bio_data_via_sql(payload, visitor=False):
    BIO_TABLE = BIO_EMP_TABLE
    if visitor:
        BIO_TABLE = BIO_VISITOR_TABLE
    sql, params = getSQL_update_new(BIO_TABLE, payload)
    customSql(sql, params)
def process_bio_data_update(device, emp, bio_type, bio_id, bio_tmp, bio_index, alg_ver, json_format=True, extra=None):
    if extra is None:
        extra = {}
    alg_ver = str(alg_ver)
    now = datetime.datetime.now()
    minor_ver = extra.get('minor_ver', None)
    visitor = False
    if isinstance(emp, Visitor):
        visitor = True
        id_dict = {'visitor_id': emp.id}
        update_id_dict = {'whereevisitor_id': emp.id}
        bios = VisitorBioData.objects.filter(visitor=emp, bio_no=bio_id, major_ver=alg_ver, bio_type=bio_type)
    else:
        bios = BioData.objects.filter(employee=emp, bio_no=bio_id, major_ver=alg_ver, bio_type=bio_type)
        id_dict = {'employee_id': emp.id}
        update_id_dict = {'whereemployee_id': emp.id}
    if minor_ver is not None:
        bios = bios.filter(minor_ver=minor_ver)
    bio_data = bios.values('id', 'sn', 'bio_tmp').first()
    _bio_tmp = bio_tmp
    if not bio_data:
        if json_format:
            bio_tmp = json.dumps({bio_index: bio_tmp}).replace('\n', '').replace('\r', '')
        payload = {'bio_no': bio_id, 'bio_index': bio_index, 'bio_format': 0, 'minor_ver': str(minor_ver) if minor_ver is not None else '0', 'duress': 0, 'major_ver': alg_ver, 'bio_tmp': bio_tmp, 'bio_type': bio_type, 'sn': device.sn, 'valid': 1, 'update_time': now, 'status': 0, 'change_time': now}
        payload.update(id_dict)
        if extra:
            payload.update(extra)
        save_bio_data_via_sql(payload, visitor=visitor)
        device.upload_time = now
        return 'Create'
    else:
        payload = {'wherebio_no': bio_id, 'wheremajor_ver': alg_ver, 'wherebio_type': bio_type, 'sn': device.sn, 'status': 0, 'update_time': now, 'change_time': now}
        payload.update(update_id_dict)
        if minor_ver:
            payload.update({'whereminor_ver': minor_ver})
        tmp_changed = new_tmp = False
        if json_format:
            json_tmp = json.loads(bio_data['bio_tmp'])
            if bio_index not in json_tmp.keys():
                new_tmp = True
            if new_tmp or json_tmp[bio_index]!= bio_tmp:
                json_tmp[bio_index] = bio_tmp
                bio_tmp = json.dumps(json_tmp).replace('\n', '').replace('\r', '')
                tmp_changed = True
        else:
            if bio_data['bio_tmp']!= bio_tmp:
                tmp_changed = True
        if bio_type == bioFinger:
            c_key = cache_key.BIODATA_TEMPLATE % (settings.UNIT, bio_data['id'], bio_id)
        else:
            c_key = cache_key.BIODATA_TEMPLATE % (settings.UNIT, bio_data['id'], bio_index)
        if tmp_changed:
            payload.update({'bio_tmp': bio_tmp})
            update_bio_data_via_sql(payload, visitor=visitor)
            cache.set(c_key, _bio_tmp.replace('\n', '').replace('\r', ''))
            if new_tmp:
                return 'Create'
            else:
                return 'Update'
        else:
            if bio_data['sn']!= device.sn and const.SYNC_WHEN_NO_CHANGED:
                update_bio_data_via_sql(payload, visitor=visitor)
                cache.set(c_key, _bio_tmp.replace('\n', '').replace('\r', ''))
                return 'Update'
            else:
                return 'No Changed'
@valid_employee_pre_save(DATA_USER_INFO_DESC)
def save_user(device, pin, emp, flds, **kwargs):
    """\n    Saving user from device\n    """
    try:
        ename = flds['Name'].strip()
        if ename and six.PY2:
                if hasattr(device, 'language') and device.language not in ['83']:
                    ename = unicode(flds['Name'].decode('utf-8')).strip()
                else:
                    ename = unicode(flds['Name'].decode('gb18030')).strip()
    except Exception:
        logger.exception('Employee Name:%s error' % flds['Name'])
        ename = ''
    passwd = flds['Passwd']
    if passwd == '0':
        passwd = ''
    card = flds.get('Card', '')
    acc_group = str(flds.get('Grp', ''))
    tz = flds['TZ']
    priv = int(flds.get('Pri', 0))
    params = []
    upload_name = get_comm_setting('enable_name_upload', 1)
    if upload_name and ename and (ename not in ('0', emp.first_name)):
                emp.first_name = ename
                params.append({'field': 'first_name', 'value': ename})
    emp_pwd = emp.password if isinstance(emp, Visitor) else emp.device_password
    if passwd!= emp_pwd or not emp_pwd or emp_pwd == '0':
        if isinstance(emp, Visitor):
            params.append({'field': 'password', 'value': passwd})
        else:
            params.append({'field': 'device_password', 'value': passwd})
    if not isinstance(emp, Visitor):
        if (emp.dev_privilege is None or emp.dev_privilege!= priv) and emp.device_privilege_verify(priv):
                emp.dev_privilege = priv
                params.append({'field': 'dev_privilege', 'value': priv})
        if acc_group!= emp.acc_group:
            emp.acc_group = acc_group
            params.append({'field': 'acc_group', 'value': acc_group})
        if tz!= emp.acc_timezone and device.is_access:
                emp.acc_timezone = tz
                params.append({'field': 'acc_timezone', 'value': tz})
        try:
            verify = int(flds['Verify'])
            if verify == (-1):
                verify = 0
        except:
            verify = 0
        if 'Verify' in flds.keys() and emp.verify_mode!= verify:
                emp.verify_mode = verify
                params.append({'field': 'verify_mode', 'value': verify})
    upload_card = get_comm_setting('enable_card_upload', 1)
    formatted_card = card2number(card)
    if upload_card and card and (formatted_card!= emp.card_no) and (card not in ('[0000000000]', '[]')):
                    emp.card_no = formatted_card
                    params.append({'field': 'card_no', 'value': formatted_card})
    event = DATA_USER_INFO_DESC
    if len(params) > 0:
        if isinstance(emp, Visitor):
            emp.update_time = datetime.datetime.now()
            params.append({'field': 'update_time', 'value': datetime.datetime.now()})
            sql = 'update visitor_visitor set %s where id='%s\'' % (','.join(['{field}=%s'.format(**param) for param in params]), emp.id)
            customSql(sql, [param['value'] for param in params])
        else:
            emp.enroll_sn = device.sn
            params.append({'field': 'enroll_sn', 'value': device.sn})
            emp.update_time = datetime.datetime.now()
            params.append({'field': 'update_time', 'value': datetime.datetime.now()})
            sql = 'update personnel_employee set %s where id='%s\'' % (','.join(['{field}=%s'.format(**param) for param in params]), emp.id)
            res, exception = customSql2(sql, [param['value'] for param in params])
    else:
        event = '%s No Changed' % event
    device.upload_time = datetime.datetime.now()
    if get_comm_setting('enable_resigned_filter') and (not isinstance(emp, Visitor)):
            tasks.employee_filter.delay(pin, device)
    return (event, pin, True)
def get_algorithm_version_of_device(device, bio_type):
    from mysite.core.zkcmdproc import get_bio_version, get_bio_major_and_minor_ver
    alg_ver = get_bio_version(device, bio_type)
    major_ver, minor_ver = get_bio_major_and_minor_ver(device, bio_type)
    return (alg_ver, major_ver, minor_ver)
@valid_employee_pre_save(BIO_DATA_FP_DESC)
def save_user_fingerprint(device, pin, emp, data, **kwargs):
    bio_tmp = trimTemp(data.get('TMP', None))
    bio_id = data.get('FID', None)
    bio_index = 0
    if not bio_tmp or not bio_id:
        return (BIO_DATA_FP_DESC, '[{pin}]{error}'.format(pin=pin, error='Parameter Error'), False)
    else:
        if not device.fp_alg_ver:
            return (BIO_DATA_FP_DESC, '[{pin}]{error}'.format(pin=pin, error='Algorithm Version Not Found'), False)
        else:
            alg_ver, major_ver, minor_ver = get_algorithm_version_of_device(device, mconst.bioFinger)
            if not major_ver:
                return (BIO_DATA_FP_DESC, '[{pin}]{error}:{ver}'.format(pin=pin, error='Invalid Algorithm Version', ver=alg_ver), False)
            else:
                extra = {'minor_ver': minor_ver}
                status = process_bio_data_update(device, emp, mconst.bioFinger, bio_id, bio_tmp, bio_index, major_ver, json_format=False, extra=extra)
                return ('{event} {status}'.format(event=BIO_DATA_FP_DESC, status=status), pin, True)
@valid_employee_pre_save(BIO_DATA_FACE_DESC)
def save_user_face(device, pin, emp, data, **kwargs):
    bio_tmp = trimTemp(data.get('TMP', None))
    bio_index = data.get('FID', None)
    bio_id = 0
    if not bio_tmp or not bio_index:
        return (BIO_DATA_FACE_DESC, '[{pin}]{error}'.format(pin=pin, error='Parameter Error'), False)
    else:
        alg_ver, major_ver, minor_ver = get_algorithm_version_of_device(device, mconst.bioFace)
        if not major_ver:
            return (BIO_DATA_FACE_DESC, '[{pin}]{error}:{ver}'.format(pin=pin, error='Invalid Algorithm Version', ver=alg_ver), False)
        else:
            extra = {'minor_ver': minor_ver, 'valid': data.get('Valid', 1)}
            status = process_bio_data_update(device, emp, mconst.bioFace, bio_id, bio_tmp, bio_index, major_ver, extra=extra)
            return ('{event} {status}'.format(event=BIO_DATA_FACE_DESC, status=status), pin, True)
@valid_employee_pre_save(BIO_DATA_FINGER_VEIN_DESC)
def save_user_finger_vein(device, pin, emp, data, **kwargs):
    bio_id = data.get('FID', None)
    bio_index = data.get('Index', None)
    bio_tmp = trimTemp(data.get('TMP', None))
    if not all((bio_id, bio_tmp, bio_index)):
        return (BIO_DATA_FINGER_VEIN_DESC, '[{pin}]{error}'.format(pin=pin, error='Parameter Error'), False)
    else:
        alg_ver, major_ver, minor_ver = get_algorithm_version_of_device(device, mconst.bioVein)
        if not major_ver:
            return (BIO_DATA_FINGER_VEIN_DESC, '[{pin}]{error}:{ver}'.format(pin=pin, error='Invalid Algorithm Version', ver=alg_ver), False)
        else:
            extra = {'minor_ver': minor_ver, 'valid': data.get('Valid', 1)}
            status = process_bio_data_update(device, emp, mconst.bioVein, bio_id, bio_tmp, bio_index, major_ver, extra=extra)
            return ('{event} {status}'.format(event=BIO_DATA_FINGER_VEIN_DESC, status=status), pin, True)
@valid_employee_pre_save(BIO_DATA_DESC)
def save_user_bio_data(device, pin, emp, data, **kwargs):
    bio_type = data.get('Type', None)
    bio_id = data.get('No', None)
    bio_index = data.get('Index', None)
    bio_tmp = data.get('Tmp', None)
    alg_ver = data.get('MajorVer', None)
    bio_type = int(bio_type)
    type_desc = mconst.BIO_TYPE.get(bio_type, bio_type)
    if not all((bio_type, bio_id, bio_index, bio_tmp, alg_ver)):
        return (BIO_DATA_DESC, '[{bio}][{pin}]{error}'.format(pin=pin, bio=type_desc, error='Parameter Error'), False)
    else:
        extra = {'minor_ver': data.get('MinorVer') if data.get('MinorVer') else 0, 'duress': data.get('Duress') if data.get('Duress') else 0, 'bio_format': data.get('format') if data.get('format') else 0, 'valid': data.get('Valid') if data.get('Valid') else 1}
        if bio_type in [mconst.bioFinger]:
            status = process_bio_data_update(device, emp, bio_type, bio_id, bio_tmp, bio_index, alg_ver, json_format=False, extra=extra)
        else:
            status = process_bio_data_update(device, emp, bio_type, bio_id, bio_tmp, bio_index, alg_ver, extra=extra)
        return ('{desc}[{bio}] {status}'.format(desc=BIO_DATA_DESC, bio=type_desc, status=status), pin, True)
def save_att_capture(request, device):
    d = request.body
    dList = []
    if b'CMD=uploadphoto' in d:
        dList = d.split(b'CMD=uploadphoto')
    if b'CMD=realupload' in d:
        dList = d.split(b'CMD=realupload')
    if not dList:
        return
    else:
        hlist = dList[0].decode('utf-8')
        pd = setValueDic(hlist)
        try:
            pin = pd['PIN']
        except:
            try:
                pin = request.POST.get('PIN', '')
                if not pin:
                    pin = request.GET.get('PIN', '')
            except:
                pin = request.GET.get('PIN', '')
        if settings.ASYN_SAVE_DEVICE_PHOTO:
            tasks.save_device_capture.delay(pin, dList, device.sn, pd)
        else:
            tasks.save_device_capture(pin, dList, device.sn, pd)
        return pin[:14]
@valid_employee_pre_save(DATA_USER_PHOTO_DESC)
def save_user_photo(device, pin, emp, data, **kwargs):
    if settings.ASYN_SAVE_DEVICE_PHOTO:
        tasks.save_employee_photo.delay(device, data)
    else:
        tasks.save_employee_photo(device, data)
    return (DATA_USER_PHOTO_DESC, pin, True)
@valid_employee_pre_save(BIO_DATA_PHOTO_DESC)
def save_bio_photo(device, pin, emp, flds, **kwargs):
    # irreducible cflow, using cdg fallback
    """\n    :param device:\n    :param flds: BIOPHOTO PIN=${XXX}\tFileName=${XXX}\tType=${XXX}\tSize=${XXX}\tContent=${XXX}\n    :return:\n    """
    import uuid
    import datetime
    import shutil
    from mysite.utils import get_or_create_photo_folder
    from mysite.iclock import const
    from mysite.iclock.comm.utils import get_comm_setting
    from mysite.tools.image_utils import encrypt_image
    from mysite.personnel.utils import get_default_company_id
    from mysite.core.zkcmdproc import bioPalmVL, bioFaceVL
    photo_path = get_or_create_photo_folder('photo')
    is_new = True
    visitor = False
    bio_type = int(flds.get('Type', bioFaceVL))
    bio_no = int(flds.get('No', 0))
    bio_index = int(flds.get('Index', 0))
    type_desc = mconst.BIO_TYPE.get(bio_type, bio_type)
    event_desc = '{desc}[{bio}]'.format(desc=BIO_DATA_PHOTO_DESC, bio=type_desc)
    if len(flds['Content']) == int(flds['Size']):
        cur = base64.decodebytes(flds['Content'].encode('utf-8'))
        approval_photo = '{pin}.jpg'.format(pin=flds['PIN'])
        if bio_type == bioPalmVL:
            approval_photo = '{pin}_{no}_{index}.jpg'.format(pin=flds['PIN'], no=bio_no, index=bio_index)
            store_dir = get_or_create_photo_folder('biophoto/palm')
        else:
            store_dir = get_or_create_photo_folder('biophoto')
        approval_state = get_comm_setting('device_policy')
        if isinstance(emp, Visitor):
            visitor = True
            if bio_type == bioPalmVL:
                store_dir = get_or_create_photo_folder('visitor/biophoto/palm')
            else:
                store_dir = get_or_create_photo_folder('visitor/biophoto')
        if settings.ENABLE_ENCRYPT_PHOTO:
            cur = encrypt_image(cur)
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            company_id = getattr(device.area, 'company_id', get_default_company_id())
            approval_photo = '{company}/{pin}.jpg'.format(company=company_id, pin=flds['PIN'])
            if bio_type == bioPalmVL:
                approval_photo = '{company}/{pin}_{no}_{index}.jpg'.format(company=company_id, pin=flds['PIN'], no=bio_no, index=bio_index)
                get_or_create_photo_folder('biophoto/palm', company_id)
            else:
                get_or_create_photo_folder('biophoto', company_id)
        approval_photo_path = os.path.join(store_dir, approval_photo)
        if bio_type == bioPalmVL:
            with open(approval_photo_path, 'wb') as rf:
                rf.write(cur)
            if visitor:
                objs = emp.visitorbiophoto_set.filter(approval_state__in=(const.APPROVAL_PASSED, const.APPROVAL_AUTO_APPROVED))
            else:
                objs = emp.biophoto_set.filter(approval_state__in=(const.APPROVAL_PASSED, const.APPROVAL_AUTO_APPROVED))
            if objs.count() and os.path.isfile(approval_photo_path):
                    with open(approval_photo_path, 'rb') as af:
                        pre = af.read()
                    if pre and pre == cur:
                            is_new = False
            nt = datetime.datetime.now()
            if is_new:
                cls = emp.visitorbiophoto_set.model if visitor else emp.biophoto_set.model
                if approval_state == const.APPROVAL_AUTO_APPROVED:
                    with open(approval_photo_path, 'wb') as rf:
                        rf.write(cur)
                    if not objs.count():
                        rp = get_or_create_photo_folder('visitor/register') if visitor else get_or_create_photo_folder('register')
                        register_photo = '{uuid}.jpg'.format(uuid=uuid.uuid4())
                        with open(os.path.join(rp, register_photo), 'wb') as rf:
                            rf.write(cur)
                        if visitor:
                            try:
                                cls(visitor=emp, first_name=emp.first_name, last_name=emp.last_name, enroll_sn=device.sn, register_photo=register_photo, register_time=nt, approval_photo=approval_photo, approval_time=nt, approval_state=const.APPROVAL_AUTO_APPROVED).save(force_insert=True)
                            except Exception as e:
                                import traceback
                                print('>>>>exception:', traceback.print_exc())
                        else:
                            cls(employee=emp, first_name=emp.first_name, last_name=emp.last_name, enroll_sn=device.sn, register_photo=register_photo, register_time=nt, approval_photo=approval_photo, approval_time=nt, approval_state=const.APPROVAL_AUTO_APPROVED).save(force_insert=True)
                    else:
                        objs.update(approval_time=nt, enroll_sn=device.sn)
                    if not visitor and (not emp.photo) and (bio_type == 9):
                                photo_name = '{0}.jpg'.format(emp.pin())
                                if getattr_ex(settings, 'MULTI_COMPANY', False):
                                    company_id = getattr(device.area, 'company_id', get_default_company_id())
                                    photo_name = '{0}/{1}.jpg'.format(company_id, emp.pin())
                                emp_photo_path = os.path.join(photo_path, photo_name)
                                shutil.copy(approval_photo_path, emp_photo_path)
                                emp.photo = 'photo/' + photo_name
                                emp.save(update_fields=['photo'])
                    rp = get_or_create_photo_folder('visitor/register') if visitor else get_or_create_photo_folder('register')
                    register_photo = '{uuid}.jpg'.format(uuid=uuid.uuid4())
                    if visitor:
                        cls(visitor=emp, first_name=emp.first_name, last_name=emp.last_name, enroll_sn=device.sn, register_photo=register_photo, register_time=nt).save(force_insert=True)
                    else:
                        cls(employee=emp, first_name=emp.first_name, last_name=emp.last_name, enroll_sn=device.sn, register_photo=register_photo, register_time=nt).save(force_insert=True)
                    with open(os.path.join(rp, register_photo), 'wb') as rf:
                        rf.write(cur)
        return (event_desc, 'Error Size {content}:{size}'.format(content=len(flds['Content']), size=int(flds['Size'])), False)
                if not is_new:
                    return (event_desc + ' No Changed', pin, True)
                else:
                    return (event_desc, pin, True)
            except Exception as e:
                    logger.exception('save_bio_photo:%s error' % emp.visitor_code if visitor else emp.emp_code)
                    return (event_desc, str(e), False)
def line2operation_log(device, params):
    """\n    :param device: Current device\n    :param params: Post data\n    :return:\n    """
    if settings.ASYN_SAVE_DEVICE_UPLOAD_LOG:
        tasks.save_device_log.delay(device, params)
        tasks.device_log_upload.delay(device, params)
    else:
        tasks.save_device_log(device, params)
        tasks.device_log_upload(device, params)
    return ('Operation Log', '', True)
def line2error_log(device, line):
    """\n    :param device:\n    :param line:ERRORLOG ErrCode=${XXX}$(HT)ErrMsg=${XXX}$(HT)DataOrigin=${XXX}$(HT)CmdId=${XXX}$(HT)Additiona l=${XXX}\n    :return:\n    """
    if not line:
        return
    else:
        opts = line.split(' ', 1)
        if len(opts)!= 2:
            logger.exception('line2error_log:%s error' % line)
            return
        else:
            tag, data = (opts[0], opts[1])
            if tag not in ['ERRORLOG']:
                return
            else:
                fields = {}
                for item in data.split('\t'):
                    kv = item.split('=', 1)
                    if len(kv) > 0:
                        fields[kv[0]] = kv[1]
                nt = datetime.datetime.now()
                if settings.ASYN_SAVE_DEVICE_UPLOAD_LOG:
                    tasks.save_error_log.delay(device, fields, nt)
                else:
                    tasks.save_error_log(device, fields, nt)
def line2transaction(device, line):
    # irreducible cflow, using cdg fallback
    """\n    :param device:\n    :param line: 1\t2020-09-09 13:51:00\t0\t1\t\t0\t0\t\t\t7\n\n    FORMAT-01[Normal]: Pin\tPunchTime\tPunchState\tVerify\tWorkCode\tReserved\tReserved\n    FORMAT-02[MTD]: Pin\tPunchTime\tPunchState\tVerify\tWorkCode\tReserved\tReserved\tMaskFlag\tTemperature\n    :return:\n    """
    from mysite.zkauth import encryption
    from mysite.iclock.utils import punch_time_replace_ar
    from mysite.personnel.utils import get_default_company
    cols = line.split('\t')
    transaction = dict(zip(const.DATA_FIELDS_OF_TRANSACTION, cols))
    lon, lat = (None, None)
    try:
        punch_time = transaction.get('punch_time', '')
        params = punch_time.split(',')
        if len(params) > 1:
            try:
                punch_time, lon, lat = params
            except Exception:
                logger.exception('line2transaction:%s error' % params)
                punch_time = params[0]
        punch_time = punch_time_replace_ar(punch_time)
        punch_time = datetime.datetime.strptime(punch_time, const.PUNCH_TIME_FORMAT)
    except Exception as e:
        logger.exception('line2transaction:%s error' % line)
        return (None, str(e))
    if not punch_period_validator(punch_time):
        return (None, '')
    else:
        pin = transaction.get('pin', '')
        company = get_default_company()
    emp = get_employee_via_pin(pin, device)
    if emp:
        company = emp.company
    if emp and emp.emp_code!= format_pin(pin):
            return (None, '')
            except ObjectDoesNotExist:
                emp = None
                    company_code = company.company_code if company else ''
                    if device.product_type in [mconst.INS_TERMINAL]:
                        purpose = 0
                    else:
                        purpose = device.product_type
                    if False:
                        pass
                    crc_code = encryption(punch_time.strftime('%Y%m%d%H%M%S'))
                    data = {'company_code': company_code, 'emp_code': pin, 'punch_time': punch_time, 'punch_state': transaction.get('punch_state', 255), 'verify_type': transaction.get('verify', 0), 'terminal_sn': device.sn, 'terminal_alias': device.alias, 'area_alias': device.area.area_name, 'work_code': crc_code, 'purpose': purpose, 'terminal_id': device.pk, 'source': mconst.DATA_SOURCE_TERMINAL, 'is_mask': 255, 'temperature': 255, 'upload_time': datetime.datetime.now(), 'is_attendance': 0, 'sync_status': 0}
                    if emp:
                        data['emp_id'] = emp.pk
                    if lon and lat:
                            data['longitude'] = lon
                            data['latitude'] = lat
                    if transaction.get('mask_flag', '').strip() and transaction.get('temperature', '').strip():
                            data['is_mask'] = transaction['mask_flag']
                            data['temperature'] = transaction['temperature']
                    if device.is_attendance:
                        data['is_attendance'] = device.is_attendance
                    tasks.real_time_transaction.delay(device, emp, line, data.copy())
                    return (data, '')
def line2user(device, line):
    """\n    :param device: Init from cache with extra parameters\n    :param line: Row data, Pls check form push protocol\n    :return:\n    """
    if get_comm_setting('enable_registration') and (not device.is_registration):
            return ('Not Registration Device', '', False)
    opts = line.split(' ', 1)
    if not len(opts) > 1:
        return ('Data', 'Invalid Data', False)
    else:
        data_type, payload = (opts[0], opts[1])
        if data_type in [const.DATA_DEVICE_OPERATION_LOG]:
            return line2operation_log(device, payload)
        else:
            if data_type in [const.DATA_USER_INFO]:
                return save_user(device, payload)
            else:
                if data_type in [const.DATA_USER_FINGERPRINT]:
                    return save_user_fingerprint(device, payload)
                else:
                    if data_type in [const.DATA_USER_FACE]:
                        return save_user_face(device, payload)
                    else:
                        if data_type in [const.DATA_USER_FINGER_VEIN]:
                            return save_user_finger_vein(device, payload)
                        else:
                            if data_type in [const.DATA_USER_BIO_DATA]:
                                return save_user_bio_data(device, payload)
                            else:
                                if data_type in [const.DATA_USER_PHOTO]:
                                    return save_user_photo(device, payload)
                                else:
                                    if data_type in [const.DATA_USER_BIO_PHOTO]:
                                        return save_bio_photo(device, payload)
                                    else:
                                        return ('UNKNOWN DATA', '', False)
def is_changed(device, field, val):
    v = getattr(device, field, None)
    if v and v not in [val]:
            return True
    return False
def update_dev_alg(dev_alg, new_alg):
    if not dev_alg:
        return True
    else:
        if dev_alg > 0 or new_alg <= 0:
            return False
        else:
            return True
def update_device_info(device, data, source=None):
    # irreducible cflow, using cdg fallback
    from mysite.iclock.comm.utils import get_data_sync_mode
    from mysite.iclock import choices
    from mysite.core.zkcmdproc import verify_bio_feature, multi_biodata_count, verify_multi_bio_feature
    sync_mode = get_data_sync_mode()
    payload = setValueDic(data)
    changed = False
    re_sync = False
    for k, v in payload.items():
        pass
    if k in const.ALL_FUNCS:
        pass
    v = int(v) if v.isnumeric() else 0
    setattr(device, const.FIELD_MAPPING.get(k, k), v)
    if k in const.FIELD_MAPPING:
        pass
    if k in ['~Platform']:
        pass
    changed = is_changed(device, 'platform', v)
    device.platform = v
    if '_TFT' in v:
        changed = is_changed(device, 'is_tft', '1')
        device.is_tft = '1'
    if k in ['AccSupportFunList']:
        pass
    changed = is_changed(device, 'AccSupportFunList', v)
    device.AccSupportFunList = v
    if v[7:8] == '1':
        changed = is_changed(device, 'MulCardUser', 1)
        device.MulCardUser = 1
    if k in ['~IsOnlyRFMachine']:
        pass
    if v in ['1']:
        changed = is_changed(device, 'FingerFunOn', 0)
        device.FingerFunOn = 0
    if k in ['IPAddress']:
        pass
    if not is_ip_address(v):
        continue
    else:
        if device.ip_address not in [v]:
            device.ip_address = v
            changed = True
    if k in ['PvCount']:
        pass
    if verify_bio_feature(device, mconst.bioPalmVL):
        continue
    else:
        setattr(device, const.FIELD_MAPPING.get(k, k), v)
    if k in ['MultiBioDataCount']:
        pass
    if verify_bio_feature(device, mconst.bioPalmVL):
        pv_count = multi_biodata_count(mconst.bioPalmVL, v)
        setattr(device, const.FIELD_MAPPING.get('PvCount', 'palm_count'), pv_count)
    if verify_multi_bio_feature(device, mconst.bioFaceVL):
        face_count = multi_biodata_count(mconst.bioFaceVL, v)
        setattr(device, const.FIELD_MAPPING.get('FaceCount', 'face_count'), face_count)
    if k in ['FaceCount']:
        pass
    if not device.face_alg_ver:
        continue
    if verify_multi_bio_feature(device, mconst.bioFaceVL):
        continue
    if source in ['INFO'] and VersionInfo(device.face_alg_ver).Major_Version > 7:
        pass
    continue
    v = v if int(v) > 0 else 0
    setattr(device, const.FIELD_MAPPING.get(k, k), v)
    except Exception:
        pass
    logger.exception('FaceCount:%s error' % device.face_alg_ver)
    if k in const.BIO_ALGORITHM:
        try:
            if not v:
                v = '0'
            matches = re.search('VX(\\w+)', v)
            if matches:
                if k in ['~AlgVer']:
                    setattr(device, 'FingerFunOn', 1)
                v = matches.group(1)
            alg = VersionInfo(v.strip() or 0).Major_Minor
            if not alg:
                continue
            else:
                dev_field = const.FIELD_MAPPING.get(k, k)
                dev_alg_str = six.text_type(getattr(device, dev_field, None) or '').strip()
                dev_alg = VersionInfo(dev_alg_str or 0).Major_Minor
                if update_dev_alg(dev_alg, alg):
                    setattr(device, dev_field, alg)
                    changed = True
                    re_sync = True
                    msg = '[*]{alg} update from {pre} -> {cur}\n'.format(alg=k, pre=dev_alg, cur=alg)
                    logger.info(msg)
        except Exception:
            logger.exception('BioAlgorithm:%s=%s error' % (k, v))
    else:
        if k in ['Identifier']:
            funcs_set = zip(const.BIO_FUNCS, v)
            for func, val in funcs_set:
                val = int(val) if val.isnumeric() else 0
                setattr(device, func, val)
        else:
            setattr(device, const.FIELD_MAPPING.get(k, k), v)
    if k in ['VerifyStyles']:
        if not v:
            continue
        else:
            val = zk_get_VerifyStyles(v)
            changed = is_changed(device, 'VerifyStyles', val)
            device.VerifyStyles = val
    else:
        continue
    if device.product_type in [mconst.INS_TERMINAL]:
        device.FaceFunOn = 0
    if changed or device.state not in [mconst.TERMINAL_DISABLE]:
        if settings.ASYN_DEV_PARAMETER:
            tasks.update_terminal_parameter.delay(device, payload)
        else:
            tasks.update_terminal_parameter(device, payload)
    if re_sync and sync_mode not in [choices.MANUAL]:
            device.set_push_time(datetime.datetime.now())
            tasks.data_sync.delay(device, process_all=True)
            msg = '[*]Device {0} Move from default area re-sync...\n'.format(device.sn)
            logger.info(msg)
    return payload
def remote_attendance(pin, device):
    # irreducible cflow, using cdg fallback
    """\n    异地考勤\n    :param pin:\n    :param device:\n    :return:\n    """
    if not pin:
        return
    emp = Employee.objects.filter(emp_code=format_pin(pin)).first()
    if not emp:
        return
    if False:
        pass
    card = ''
    if emp.card_no:
        if str(getattr(device, 'CardProtFormat', '0')) in ['1']:
            card = emp.card_no
        else:
            if len(emp.card_no) < 11:
                card = getNormalCard(emp.card_no) or ''
    pwd = emp.device_password or ''
    dev_privilege = emp.dev_privilege or 0
    verify_mode = emp.verify_mode
    if DevIdentity_ex(device.push_protocol, const.PUSH_V2214):
        cmd = 'DATA UPDATE USERINFO PIN=%s	Name=%s	Passwd=%s	Card=%s	Pri=%s	Verify=%s\n' % (pin, emp.first_name, pwd, card, dev_privilege, verify_mode)
    else:
        cmd = 'DATA USER PIN=%s	Name=%s	Passwd=%s	Card=%s	Pri=%s	Verify=%s\n' % (pin, emp.first_name, pwd, card, dev_privilege, verify_mode)
    if False:
        pass
    if DevIdentity(device, 'pic'):
        cmd += '%s\n' % (get_personnel_photo(pin) or '')
    if False:
        pass
    if DevIdentity(device, 'fp') and device.fp_alg_ver:
        alg_ver = VersionInfo(device.fp_alg_ver or 0).Major_Version
        fps = BioData.objects.filter(employee=emp, bio_type=mconst.bioFinger).values('bio_no', 'bio_tmp', 'major_ver', 'minor_ver')
        for fp in fps:
            major_ver = VersionInfo(fp['major_ver'] or 0).Major_Version
            if alg_ver > 10 and major_ver >= 10:
                cmd += 'DATA UPDATE BIODATA Pin=%s\tNo=%s\tIndex=%s\tValid=%d\tDuress=%d\tType=%d\tMajorVer=%s\tMinorVer=%s\tTmp=%s\n' % (pin, fp['bio_no'], 0, 1, 0, mconst.bioFinger, fp['major_ver'], fp['minor_ver'], fp['bio_tmp'])
                if major_ver in [alg_ver]:
                    if DevIdentity_ex(device.push_protocol, const.PUSH_V2214):
                        cmd += 'DATA UPDATE FINGERTMP PIN=%s\tFID=%d\tSize=%d\tTMP=%s\tValid=1\n' % (pin, fp['bio_no'], len(fp['bio_tmp']), fp['bio_tmp'])
                        cmd += 'DATA FP PIN=%s\tFID=%d\tTMP=%s\tValid=1\n' % (pin, fp['bio_no'], fp['bio_tmp'])
    if DevIdentity(device, 'face') and device.face_alg_ver:
            alg_ver = str(device.face_alg_ver)
            bio_datas = BioData.objects.filter(employee=emp, bio_type=mconst.bioFace, major_ver=alg_ver).values('bio_no', 'bio_tmp', 'major_ver', 'minor_ver')
            if bio_datas:
                for bio_data in bio_datas:
                    bio_data_tmp = json.loads(bio_data['bio_tmp'])
                    for tid, tmp in bio_data_tmp:
                        if VersionInfo(alg_ver or 0).Major_Version >= 9:
                            cmd += 'DATA UPDATE BIODATA Pin=%s\tNo=%s\tIndex=%s\tValid=%d\tDuress=%d\tType=%d\tMajorVer=%s\tMinorVer=%s\tTmp=%s\n' % (pin, bio_data['bio_no'], tid, 1, 0, mconst.bioFace, alg_ver, bio_data['minor_ver'], tmp)
                        else:
                            cmd += 'DATA UPDATE FACE PIN=%s\tFID=%s\tSize=%d\tValid=%d\tTMP=%s' % (pin, tid, len(tmp), 1, tmp)
    if DevIdentity(device, 'palm') and device.palm_alg_ver:
            alg_ver = str(device.palm_alg_ver)
            bio_datas = BioData.objects.filter(employee=emp, bio_type=mconst.bioFace, major_ver=alg_ver).values('bio_no', 'bio_tmp', 'major_ver', 'minor_ver')
            if bio_datas:
                for bio_data in bio_datas:
                    bio_data_tmp = json.loads(bio_data['bio_tmp'])
                    for tid, tmp in bio_data_tmp:
                        cmd += 'DATA UPDATE BIODATA Pin=%s\tNo=%s\tIndex=%s\tValid=%d\tDuress=%d\tType=%d\tMajorVer=%s\tMinorVer=%s\tTmp=%s\n' % (pin, bio_data['bio_no'], tid, 1, 0, mconst.bioHand, alg_ver, bio_data['minor_ver'], tmp)
    if DevIdentity(device, 'vein'):
        pass
    if DevIdentity(device, 'bio_photo'):
        cmd += '%s\n' % (getBiophoto(pin) or '')
    return cmd