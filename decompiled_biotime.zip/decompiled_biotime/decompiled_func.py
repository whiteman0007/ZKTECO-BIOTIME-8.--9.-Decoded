# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\_utils\\db_functions\\func.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.db.models.functions import ConcatPair, Concat, Extract
class ConcatWithConverse(Concat):
    """\n    Concatenates text fields together. Backends that result in an entire\n    null expression when any arguments are null will wrap each argument in\n    coalesce functions to ensure we always get a non-null result.\n    """
    def _converse(self, value):
        return value
    def _paired(self, expressions):
        if len(expressions) == 2:
            return ConcatPair(*expressions)
        else:
            return ConcatPair(self._converse(expressions[0]), self._paired(expressions[1:]))
class ConcatPadZero(ConcatWithConverse):
    """\n    Concatenates text fields together. Backends that result in an entire\n    null expression when any arguments are null will wrap each argument in\n    coalesce functions to ensure we always get a non-null result.\n    """
    def _converse(self, value):
        return '{:02}'.format(value)
class ExtractDate(Extract):
    lookup_name = 'date'