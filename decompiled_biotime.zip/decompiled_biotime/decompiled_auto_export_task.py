# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\auto_export_task.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

from django.utils.translation import gettext_lazy as _
from rest_framework import status
from rest_framework.response import Response
from mysite.base.api import serializers, filters
from mysite.base.api.utils_class import BasicUserModelViewSet
from mysite.base.models import AutoExportTask
class AutoExportTaskViewSet(BasicUserModelViewSet):
    queryset = AutoExportTask.objects.all()
    serializer_class = serializers.AutoExportTaskSerializer
    filterset_class = filters.AutoExportTaskFilter
    ordering_fields = ('id',)
    def create(self, request, *args, **kwargs):
        put_id = request.query_params.get('put_id')
        del_id = request.query_params.get('del_id')
        error_msg = {}
        error_list = []
        if not put_id and (not del_id):
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        else:
            if put_id:
                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                headers = self.get_success_headers(serializer.data)
                if put_id!= 'null':
                    put_task = AutoExportTask.objects.get(id=put_id)
                    data = request.data['params'].encode('utf-8')
                    put_task.params = data
                    put_task.save()
                    return Response(serializer.data, status=status.HTTP_200_OK, headers=headers)
                else:
                    error_list.append(_('please create a task first'))
                    error_msg['params'] = error_list
                    return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)
            else:
                try:
                    instance = AutoExportTask.objects.get(id=del_id)
                except Exception:
                    return Response(status=status.HTTP_400_BAD_REQUEST)
                self.perform_destroy(instance)
                return Response(status=status.HTTP_204_NO_CONTENT)