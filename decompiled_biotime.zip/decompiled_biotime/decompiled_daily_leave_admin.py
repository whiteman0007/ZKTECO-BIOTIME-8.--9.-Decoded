# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\daily_leave_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att import const
from mysite.att.api.report_views import DailyLeaveViewSet
from mysite.att.api.report_views.daily_leave import DailyLeaveSerializer
from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
@report_register()
class DailyLeaveAdmin(ReportAdminBase):
    model_name = 'dailyLeaveReport'
    view_name = 'daily_leave'
    template = 'att/report_new/daily_leave.html'
    api_view = DailyLeaveViewSet
    serializer = DailyLeaveSerializer
    data_source = '/att/api/dailyLeaveReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday')
    hidden_fields = ('company_code', 'last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = ('emp_code', 'att_date')
    add_paycode_column = True
    paycode_type = const.LEAVE