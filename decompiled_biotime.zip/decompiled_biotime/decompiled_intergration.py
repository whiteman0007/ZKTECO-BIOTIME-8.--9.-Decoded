# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\views\\intergration.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

global mProgrammingError
global pyDB
global mInternalError
global mOperationalError
global _dbManager
global conn_args
import json
from mysite._utils import getattr_ex
ONLY_ATT = False
pyDB = None
mOperationalError = None
mInternalError = None
mProgrammingError = None
conn_args = {}
_dbManager = None
DJANGO = False
from django.conf import settings
def get_connection(params, test=False):
    """\n    make a connection for database.\n    """
    from django.db.utils import load_backend
    db = {'ENGINE': 'django.db.backends.dummy', 'NAME': '', 'USER': '', 'PASSWORD': '', 'HOST': '', 'PORT': '', 'CONN_MAX_AGE': 0, 'AUTOCOMMIT': True, 'OPTIONS': {}, 'TIME_ZONE': None, 'ATOMIC_REQUESTS': False, 'CONN_HEALTH_CHECKS': False}
    conn = None
    alias = 'migrate'
    if params:
        engine = params.get('migrate_database_type', None)
        user = params.get('migrate_database_user', '')
        name = params.get('migrate_database_name', '')
        password = params.get('migrate_database_password', '')
        host = params.get('migrate_database_address', '')
        port = params.get('migrate_database_port', '')
        if engine.lower() in 'sqlite':
            import sqlite3
            db_addr = params.get('migrate_sqlite_database', None)
            conn = sqlite3.connect(db_addr)
        else:
            db.update({'NAME': name, 'USER': user, 'PASSWORD': password, 'HOST': host, 'PORT': port})
            if engine.lower() in ['mysql', 'oracle', 'postgresql']:
                db['ENGINE'] = 'django.db.backends.{engine}'.format(engine=engine)
                if engine.lower() in ['oracle']:
                    db['OPTIONS'] = {'threaded': True}
            else:
                if engine.lower() in ['sqlserver_ado']:
                    db['ENGINE'] = 'mssql'
                    db['OPTIONS'] = {'use_legacy_datetime': True, 'connection_timeout': 10, 'connection_retries': 1, 'driver': 'ODBC Driver 17 for SQL Server', 'MARS_Connection': True}
                    from mssql.base import DatabaseWrapper
                    return DatabaseWrapper(db, alias)
            backend = load_backend(db['ENGINE'])
            conn = backend.DatabaseWrapper(db, alias)
    return conn
def test_conn(params=None, test=False):
    # irreducible cflow, using cdg fallback
    """\n    测试连接池连接是否正常\n    return:\n    res: True:正常,False:不正常\n    msg: 如果不正常,为异常信息\n    """
    conn = None
    cur = None
    msg = ''
    try:
        conn = get_connection(params, test)
        cur = conn.cursor()
    except Exception as e:
        import traceback
        traceback.print_exc()
        msg = e
        if cur:
            cur.close()
        if conn:
            conn.close()
        return msg
def get_insert_sql():
    from mysite.sql_utils import get_curr_db_engine_name
    insert_sql = ''
    db_engine = get_curr_db_engine_name()
    if db_engine == 'sqlserver':
        insert_sql = 'if not exists(select id from iclock_transaction where emp_code=\'%(emp_code)s\' and punch_time=\'%(punch_time)s\' and company_code=\'%(company_code)s\')\n        insert into iclock_transaction (emp_code, emp_id, punch_time, punch_state, verify_type, work_code, terminal_sn, terminal_id, is_mask, temperature, is_attendance,company_code) values \n                (\'%(emp_code)s\',%(emp_id)s,\'%(punch_time)s\',%(punch_state)s,%(verify_type)s,\'%(work_code)s\',\'%(terminal_sn)s\',%(terminal_id)s,%(is_mask)s,%(temperature)s, %(is_attendance)s,\'%(company_code)s\');'
    else:
        if db_engine == 'mysql':
            insert_sql = 'insert into iclock_transaction (emp_code, emp_id, punch_time, punch_state, verify_type, work_code, terminal_sn, terminal_id, source, is_mask, temperature, is_attendance,company_code)\n        select \'%(emp_code)s\',%(emp_id)s,\'%(punch_time)s\',%(punch_state)s,%(verify_type)s,\'%(work_code)s\',\'%(terminal_sn)s\',%(terminal_id)s,1,%(is_mask)s,%(temperature)s,%(is_attendance)s,\'%(company_code)s\'\n        from dual where not exists (select id from iclock_transaction where emp_code=\'%(emp_code)s\' and punch_time=\'%(punch_time)s\' and company_code=\'%(company_code)s\')\n        '
        else:
            if db_engine == 'oracle':
                insert_sql = 'insert into iclock_transaction (emp_code, emp_id, punch_time, punch_state, verify_type, work_code,\n        terminal_sn, terminal_id, is_mask, temperature,is_attendance,company_code)\n        select \'%(emp_code)s\',%(emp_id)s,to_date(\'%(punch_time)s\', \'yyyy-mm-dd hh24:mi:ss\'),%(punch_state)s,%(verify_type)s,\n        \'%(work_code)s\',\'%(terminal_sn)s\',%(terminal_id)s, %(is_mask)s, %(temperature)s, %(is_attendance)s,\'%(company_code)s\'\n        from dual where not exists (select id from iclock_transaction where emp_code = \'%(emp_code)s\' and \n        punch_time = to_date(\'%(punch_time)s\', \'yyyy-mm-dd hh24:mi:ss\') and company_code=\'%(company_code)s\')\n        '
            else:
                if db_engine == 'postgresql':
                    insert_sql = '\n        insert into iclock_transaction (emp_code, emp_id, punch_time, punch_state, verify_type, work_code, terminal_sn, \n        terminal_id, is_mask, temperature, is_attendance,company_code) values \n                (\'%(emp_code)s\',%(emp_id)s,\'%(punch_time)s\',%(punch_state)s,%(verify_type)s,\'%(work_code)s\',\'%(terminal_sn)s\',%(terminal_id)s, %(is_mask)s, %(temperature)s, %(is_attendance)s,\'%(company_code)s\')\n                ON CONFLICT (emp_code, punch_time,company_code) DO NOTHING;\n        '
    return insert_sql
def get_select_trans_sql(migrate_software, dbtype):
    from .db_migrate import WDMS5, WDMS6, ZKTIMEWEB2, ZKTIMENET, BIOTIME_8, BIOTIME7
    sql_ex = ' order by c.id'
    if dbtype == 'postgresql':
        sql_ex = ' order by c.id limit %(end)s offset %(start)s'
    else:
        if dbtype == 'mysql':
            sql_ex = ' order by c.id limit %(start)s,%(end)s'
    where = ''
    table = 'checkinout'
    if migrate_software in [WDMS6]:
        table = 'transaction_'
    else:
        if migrate_software in [ZKTIMENET]:
            table = 'att_punches'
        else:
            if migrate_software in BIOTIME_8:
                table = 'iclock_transaction'
    if dbtype == 'sqlserver_ado':
        where = ' and c.id not in (select top %(start)s id from {table} where %(and)s)'.format(table=table)
    else:
        if dbtype == 'oracle':
            where = ' and c.id >= %(start)s and c.id < %(end)s '
    if migrate_software in [ZKTIMEWEB2]:
        if dbtype == 'sqlserver_ado':
            sql = '\n                        select top 5000 u.badgenumber, c.checktime, c.checktype, c.verifycode, c.sn_name, c.workcode, c.id from checkinout c \n                        inner join userinfo u on u.badgenumber = c.pin \n                        where %(and)s\n                        '
        else:
            sql = '\n                        select u.badgenumber, c.checktime, c.checktype, c.verifycode, c.sn_name, c.workcode, c.id from checkinout c \n                        inner join userinfo u on u.badgenumber = c.pin \n                        where %(and)s\n                        '
    else:
        if migrate_software in [BIOTIME7]:
            if dbtype == 'sqlserver_ado':
                sql = '\n                        select top 5000 u.badgenumber, c.checktime, c.checktype, c.verifycode, c.sn_name, c.WorkCode, c.id from checkinout c \n                        inner join userinfo u on u.badgenumber = c.pin \n                        where %(and)s\n                        '
            else:
                if dbtype!= 'postgresql':
                    sql = '\n                        select u.badgenumber, c.checktime, c.checktype, c.verifycode, c.sn_name, c.WorkCode, c.id from checkinout c \n                        inner join userinfo u on u.badgenumber = c.pin \n                        where %(and)s\n                        '
                else:
                    sql = '\n                        select u.badgenumber, c.checktime, c.checktype, c.verifycode, c.sn_name, c.\"WorkCode\", c.id from checkinout c \n                        inner join userinfo u on u.badgenumber = c.pin \n                        where %(and)s\n                        '
        else:
            if migrate_software in [WDMS5] and getattr_ex(settings, 'MULTI_COMPANY', False):
                if dbtype == 'sqlserver_ado':
                    sql = '\n                        select top 5000 u.badgenumber, c.checktime, c.checktype, c.verifycode, c.SN,c.WorkCode, c.id, com.companyid\n                        from checkinout c \n                        inner join company com on c.company_id = com.companyid\n                        inner join userinfo u on c.userid = u.userid where %(and)s \n                        '
                else:
                    sql = '\n                        select u.badgenumber, c.checktime, c.checktype, c.verifycode, c.SN,c.WorkCode, c.id, com.companyid\n                        from checkinout c \n                        inner join company com on c.company_id = com.companyid\n                        inner join userinfo u on c.userid = u.userid where %(and)s \n                        '
            else:
                if migrate_software in [WDMS5]:
                    if dbtype == 'sqlserver_ado':
                        sql = '\n                        select top 5000 u.badgenumber, c.checktime, c.checktype, c.verifycode, c.SN,c.WorkCode, c.id\n                        from checkinout c \n                        inner join userinfo u on c.userid = u.userid where %(and)s \n                        '
                    else:
                        sql = '\n                        select u.badgenumber, c.checktime, c.checktype, c.verifycode, c.SN,c.WorkCode, c.id\n                        from checkinout c \n                        inner join userinfo u on c.userid = u.userid where %(and)s \n                        '
                else:
                    if migrate_software in [WDMS6]:
                        if dbtype == 'sqlserver_ado':
                            sql = '\n                        select top 5000 u.pin, c.time, c.status, c.verify, i.sn, c.workcode, c.id from transaction_  c \n                        inner join employee u on u.id = c.employee_id \n                        inner join iclock i on  i.id = c.iclock_id where %(and)s \n                        '
                        else:
                            sql = '\n                        select u.pin, c.time, c.status, c.verify, i.sn, c.workcode, c.id from transaction_  c \n                        inner join employee u on u.id = c.employee_id \n                        inner join iclock i on  i.id = c.iclock_id where %(and)s \n                        '
                    else:
                        if migrate_software in [ZKTIMENET]:
                            if dbtype == 'sqlserver_ado':
                                sql = '\n                        select top 5000 u.emp_pin, c.punch_time, c.workstate, c.verifycode, \'\' as sn, c.workcode, c.id from att_punches c \n                        inner join hr_employee u on u.id = c.employee_id \n                        where %(and)s\n                        '
                            else:
                                sql = '\n                        select u.emp_pin, c.punch_time, c.workstate, c.verifycode, \'\' as sn, c.workcode, c.id from att_punches c \n                        inner join hr_employee u on u.id = c.employee_id \n                        where %(and)s\n                        '
                        else:
                            if dbtype == 'sqlserver_ado':
                                sql = '\n                    select top 5000 u.emp_code, c.punch_time, c.punch_state, c.verify_type, c.terminal_sn, c.work_code, c.id,com.company_code\n                    from iclock_transaction c \n                    inner join personnel_employee u on c.emp_id = u.id\n                    left join personnel_company com on com.id=u.company_id\n                    where %(and)s\n                  '
                            else:
                                sql = '\n                    select u.emp_code, c.punch_time, c.punch_state, c.verify_type, c.terminal_sn, c.work_code, c.id,com.company_code\n                    from iclock_transaction c \n                    inner join personnel_employee u on c.emp_id = u.id\n                    left join personnel_company com on com.id=u.company_id \n                    where %(and)s\n                  '
    sql += where
    sql += sql_ex
    return sql