# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\admin\\increasement_formula_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:11 UTC (1750673051)

from mysite import admin
from mysite.payroll.models import IncreasementFormula
from mysite.admin.kernel import ZKModelAdmin
from mysite.settings.components.secretes import THAILAND
@admin.register(IncreasementFormula)
class IncreasementFormulaAdmin(ZKModelAdmin):
    actions = []
    if THAILAND.fget():
        list_display = ('id', 'name', 'formula', 'special_type_name', 'remark')
    else:
        list_display = ('id', 'name', 'formula', 'remark')
    list_filter = ('name', 'formula', 'remark')
    sort_fields = ()
    cache_keys = ()