# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\forms\\leave_formula_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:13 UTC (1750673053)

from django.forms import ModelForm
from django.forms import ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite.att.models.model_paycode import PayCode, LEAVE
from mysite.payroll.models import LeaveFormula
class AddLeaveFormulaForm(ModelForm):
    pay_code = ModelChoiceField(label=_('leave.fields.payCode'), queryset=PayCode.objects.filter(code_type=LEAVE))
    class Meta:
        model = LeaveFormula
        fields = '__all__'