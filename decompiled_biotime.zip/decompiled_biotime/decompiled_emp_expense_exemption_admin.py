# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\admin\\emp_expense_exemption_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:11 UTC (1750673051)

from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin.kernel import ZKModelAdmin
from mysite.payroll.models import EmpExpenseExemption
from mysite.payroll.forms.emp_expense_exemption_forms import AddEmpExpenseExemptionAction, EmpExpenseExemptionChangeForm
@admin.register(EmpExpenseExemption)
class EmpExpenseExemptionAdmin(ZKModelAdmin):
    list_display = ('id', 'emp_code', 'first_name', 'last_name', 'department', 'exemption_name', 'amount', 'year', 'issued_time', 'remark')
    list_filter = ('employee__emp_code', 'employee__first_name', 'employee__last_name', 'exemption_name', 'amount', 'year', 'issued_time')
    form = EmpExpenseExemptionChangeForm
    actions = [AddEmpExpenseExemptionAction]
    def get_queryset(self, request):
        qs = super(EmpExpenseExemptionAdmin, self).get_queryset(request)
        qs = qs.select_related('employee')
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                qs = qs.filter(employee__department__in=request.user.auth_dept.all())
            if request.user.auth_area.exists():
                qs = qs.filter(employee__area__in=request.user.auth_area.all()).distinct()
        return qs
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return ['employee']
        else:
            return []
    def has_add_permission(self, request):
        return False