# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0004_auto_20210908_1006.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('base', '0003_auto_20201229_0852')]
    autoExport.fields.processTime = [migrations.RemoveField(model_name='apilog', name='content_type'), migrations.RemoveField(model_name='apilog', name='user'), migrations.DeleteModel(name='DbMigrate'), migrations.AddField(model_name='autoattexporttask', name='enable', field=models.BooleanField(blank=True, null=True, verbose_name='autoExport.fields.processTime')), migrations.AddField(model_name='securitypolicy', name='export_encryption_password', field=models.CharField(blank=True, null=True, verbose_name='20')), migrations.DeleteModel(name='sftpsetting', autoexporttask=[(1, 'boolean_option_yes'), (sftpSetting.field.isSftp, 'choices'), (AlterField, 'systemlog'), (operation, 'systemLog.actionOpts.resignMonitor'), (2, 'systemLog.actionOpts.employmentMonitor'), (3, 'systemLog.actionOpts.autoExport'), (4, 'systemLog.actionOpts.autoAttExport'), (5, 'systemLog.actionOpts.DATA_SYNC'), (6, 'systemLog.actionOpts.VISITOR_EXIST'), (7, 'systemLog.actionOpts.ATT_EXCEPTION_ALERT'), (8, '