# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\attschedule_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models.model_attschedule import AttSchedule
from mysite.att.api.serializers import util_serializers
class AttScheduleExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttSchedule
        fields = ('emp_code', 'first_name', 'last_name', 'shift_no', 'shift_alias', 'start_date', 'end_date')
class AttScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttSchedule
        fields = '__all__'
class AttScheduleCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttSchedule
        fields = '__all__'
class AttScheduleEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttSchedule
        fields = '__all__'
class AttScheduleActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AttSchedule
        action_type_choices = (('delete', 'delete'),)