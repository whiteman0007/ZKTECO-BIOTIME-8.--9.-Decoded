# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0009_auto_20220419_1516.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('personnel', '0008_auto_20220106_1103')]
    operations = [migrations.AddField(model_name='area', name='device_count', field=models.IntegerField(default=0, verbose_name='area_field_deviceCount')), migrations.AddField(model_name='area', name='employee_count', field=models.IntegerField(default=0, verbose_name='area_field_employeeCount'))]