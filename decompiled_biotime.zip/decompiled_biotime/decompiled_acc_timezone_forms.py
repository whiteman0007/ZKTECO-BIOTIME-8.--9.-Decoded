# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\forms\\acc_timezone_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:49 UTC (1750672969)

from django.core.cache import cache
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.acc.models import AccTimezone
from mysite.admin import forms
from mysite.personnel.models import Area
class AccTimezoneForm(ModelForm):
    area = forms.ModelChoiceField(label=_('accPrivilege_field_area'), queryset=Area.objects.all(), disabled=True)
    class Meta:
        model = AccTimezone
        fields = '__all__'
    def __init__(self, *args, **kwargs):
        super(AccTimezoneForm, self).__init__(*args, **kwargs)
        try:
            request = kwargs.get('initial', None)
            current_area = 1
            if request:
                current_area = request['request'].GET.get('current_area', 1)
            if args and args[0]['area']:
                    current_area = args[0]['area']
            self.fields['area'].initial = current_area
        except Exception:
            return None
class AccTimezoneEditForm(ModelForm):
    current_area = forms.CharField(required=False, max_length=20)
    area = forms.ModelChoiceField(label=_('accPrivilege_field_area'), queryset=Area.objects.all(), disabled=True)
    timezone_no = forms.IntegerField(label=_('accTimezone_field_no'), disabled=True)
    class Meta:
        model = AccTimezone
        fields = '__all__'