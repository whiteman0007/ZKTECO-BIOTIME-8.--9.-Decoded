# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\group_overtime_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import GroupOvertimeViewSet
from mysite.att.api.report_views.group_overtime import GroupOvertimeSerializer
from mysite.att import const
@report_register()
class GroupOvertimeAdmin(ReportAdminBase):
    model_name = 'groupOvertimeReport'
    view_name = 'group_overtime'
    template = 'att/report_new/group_overtime.html'
    api_view = GroupOvertimeViewSet
    serializer = GroupOvertimeSerializer
    data_source = '/att/api/groupOvertimeReport/'
    required_group_wise = True
    list_display = ('group_code', 'group_name', 'total_emp')
    hidden_fields = ()
    sort_fields = ('group_name',)
    paycode_type = const.OVERTIME
    add_paycode_column = True