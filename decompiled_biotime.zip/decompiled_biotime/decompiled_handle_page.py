# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\views\\handle_page.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from django.shortcuts import render
def page_not_found(request, exception):
    return render(request, '404.html')
def page_error(request):
    return render(request, '500.html')