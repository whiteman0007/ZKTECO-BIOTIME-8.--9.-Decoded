# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\emitters.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

import decimal
import re
import inspect
import copy
try:
    import yaml
except ImportError:
    yaml = None
try:
    any
except NameError:
    def any(iterable):
        for element in iterable:
            if element:
                return True
        return False
from django.db.models.query import QuerySet
from django.db.models import Model, permalink
from django.utils.encoding import smart_str
from django.core.urlresolvers import reverse, NoReverseMatch
from django.http import HttpResponse
try:
    import io as StringIO
except ImportError:
    from io import StringIO
try:
    import pickle
except ImportError:
    import pickle
import django.template as template
def do_filter(value, filter):
    try:
        p = template.Parser('')
        fe = template.FilterExpression('value|' + filter, p)
        return fe.resolve({'value': value})
    except:
        return value
reverser = permalink
class Emitter(object):
    """\n    Super emitter. All other emitters should subclass\n    this one. It has the `construct` method which\n    conveniently returns a serialized `dict`. This is\n    usually the only method you want to use in your\n    emitter. See below for examples.\n\n    `RESERVED_FIELDS` was introduced when better resource\n    method detection came, and we accidentially caught these\n    as the methods on the handler. Issue58 says that\'s no good.\n    """
    EMITTERS = {}
    RESERVED_FIELDS = {'anonymous', 'model', 'create', 'fields', 'read', 'delete', 'allowed_methods', 'update', 'exclude'}
    def __init__(self, admin, payload, typemapper, handler, fields=(), head=(), anonymous=True):
        self.admin = admin
        self.typemapper = typemapper
        self.data = payload
        self.handler = handler
        self.fields = fields
        self.head = head
        self.anonymous = anonymous
        if isinstance(self.data, Exception):
            raise
    def method_fields(self, handler, fields):
        if not handler:
            return {}
    def construct(self):
        """\n        Recursively serialize a lot of types, and\n        in cases where it doesn\'t recognize the type,\n        it will fall back to Django\'s `smart_str`.\n\n        Returns `dict`.\n        """
        def _any(thing, fields=()):
            """\n            Dispatch, all types are routed through here.\n            """
            ret = None
            if isinstance(thing, QuerySet):
                ret = _qs(thing, fields=fields)
            else:
                if isinstance(thing, (tuple, list)):
                    ret = _list(thing)
                else:
                    if isinstance(thing, dict):
                        ret = _dict(thing)
                    else:
                        if isinstance(thing, decimal.Decimal):
                            ret = str(thing)
                        else:
                            if isinstance(thing, Model):
                                ret = _model(thing, fields=fields)
                            else:
                                if inspect.isfunction(thing):
                                    if not inspect.getargspec(thing)[0]:
                                        ret = _any(thing())
                                else:
                                    if hasattr(thing, '__emittable__'):
                                        f = thing.__emittable__
                                        if inspect.ismethod(f) and len(inspect.getargspec(f)[0]) == 1:
                                                ret = _any(f())
                                    else:
                                        if repr(thing).startswith('<django.db.models.fields.related.RelatedManager'):
                                            ret = _any(thing.all())
                                        else:
                                            ret = smart_str(thing, strings_only=True)
            return ret
        def _fk(data, field):
            """\n            Foreign keys.\n            """
            id = getattr(data, field.name + '_id')
            id_key = '%s_%s' % (field.name, id)
            if not hasattr(self, '_fk_cache'):
                self._fk_cache = {}
            value = self._fk_cache.get(id_key, None)
            if value is None:
                value = smart_str(getattr(data, field.name))
                self._fk_cache[id_key] = value
            return _any({'id': id, 'verbose': value})
        def _related(data, fields=()):
            """\n            Foreign keys.\n            """
            return [_model(m, fields) for m in data.iterator()]
        def _m2m(data, field, fields=()):
            """\n            Many to many (re-route to `_model`.)\n            """
            return [_model(m, fields) for m in getattr(data, field.name).iterator()]
        def _model(data, fields=()):
            # irreducible cflow, using cdg fallback
            """\n            Models. Will respect the `fields` and/or\n            `exclude` on the handler (see `typemapper`.)\n            """
            ret = {}
            handler = self.in_typemapper(type(data), self.anonymous)
            get_absolute_uri = False
            if handler or fields:
                v = lambda f: getattr(data, f.attname)
                if not fields:
                    mapped = self.in_typemapper(type(data), self.anonymous)
                    get_fields = set(mapped.fields)
                    exclude_fields = set(mapped.exclude).difference(get_fields)
                    if 'absolute_uri' in get_fields:
                        get_absolute_uri = True
                    if not get_fields:
                        get_fields = {f.attname.replace('_id', '', 1) for f in data._meta.fields}
                    for exclude in exclude_fields:
                        if isinstance(exclude, str):
                            get_fields.discard(exclude)
                        else:
                            if isinstance(exclude, re._pattern_type):
                                for field in get_fields.copy():
                                    if exclude.match(field):
                                        get_fields.discard(field)
                else:
                    get_fields = fields
                get_fields_with_filter = dict(['|' in f and (f[:f.index('|')], f[f.index('|') + 1:]) or (f, '') for f in list(get_fields)])
                get_fields = list(get_fields_with_filter.keys())
                met_fields = self.method_fields(handler, get_fields)
                for f in data._meta.local_fields:
                    if f.serialize and (not any([p in met_fields for p in (f.attname, f.name)])):
                        if not f.rel:
                            if f.attname in get_fields:
                                if get_fields_with_filter.get(f.attname, None):
                                    ret[f.attname] = _any(do_filter(v(f), get_fields_with_filter[f.attname]))
                                else:
                                    get_disp = 'get_%s_display' % f.attname
                                    if hasattr(data, get_disp):
                                        ret[f.attname] = _any(getattr(data, get_disp)())
                                    else:
                                        ret[f.attname] = _any(v(f))
                                get_fields.remove(f.attname)
                            if f.attname[:(-3)] in get_fields:
                                ret[f.name] = _fk(data, f)
                                get_fields.remove(f.name)
                for mf in data._meta.many_to_many:
                    if mf.serialize and mf.attname not in met_fields and (mf.attname in get_fields):
                                ret[mf.name] = _m2m(data, mf)
                                get_fields.remove(mf.name)
                for maybe_field in get_fields:
                    if '.' in maybe_field:
                        model, field = maybe_field.split('.', 1)
                        obj = getattr(data, model, None)
                        if obj:
                            ret[maybe_field] = _model(obj, (field,))[field]
                        else:
                            ret[maybe_field] = ''
                        if isinstance(maybe_field, (list, tuple)):
                            model, fields = maybe_field
                            inst = getattr(data, model, None)
                            if inst:
                                if hasattr(inst, 'all'):
                                    ret[model] = _related(inst, fields)
                                    if callable(inst):
                                        if len(inspect.getargspec(inst)[0]) == 1:
                                            ret[model] = _any(inst(), fields)
                                        ret[model] = _model(inst, fields)
                            if maybe_field in met_fields:
                                ret[maybe_field] = _any(met_fields[maybe_field](data))
                            else:
                                maybe = getattr(data, maybe_field, None)
                                if maybe:
                                    if callable(maybe):
                                        if len(inspect.getargspec(maybe)[0]) == 1:
                                            ret[maybe_field] = _any(maybe())
                                    else:
                                        ret[maybe_field] = _any(maybe)
                                else:
                                    handler_f = getattr(handler or self.handler, maybe_field, None)
                                    if handler_f:
                                        ret[maybe_field] = _any(handler_f(data))
                for f in data._meta.fields:
                    ret[f.attname] = _any(getattr(data, f.attname))
                fields = dir(data.__class__) + list(ret.keys())
                add_ons = [k for k in dir(data) if k not in fields]
                for k in add_ons:
                    ret[k] = _any(getattr(data, k))
            if self.in_typemapper(type(data), self.anonymous):
                handler = self.in_typemapper(type(data), self.anonymous)
                if hasattr(handler, 'resource_uri'):
                    url_id, fields = handler.resource_uri(data)
                    try:
                        ret['resource_uri'] = reverser(lambda: (url_id, fields))()
                    except NoReverseMatch as e:
                        pass
            if hasattr(data, 'get_api_url') and 'resource_uri' not in ret:
                    try:
                        ret['resource_uri'] = data.get_api_url()
                    except:
                        pass
            if hasattr(data, 'get_absolute_url') and get_absolute_uri:
                    try:
                        ret['absolute_uri'] = data.get_absolute_url()
                    except:
                        pass
            return ret
        def _qs(data, fields=()):
            """\n            Querysets.\n            """
            return [_any(v, fields) for v in data]
        def _list(data):
            """\n            Lists.\n            """
            return [_any(v) for v in data]
        def _dict(data):
            """\n            Dictionaries.\n            """
            return dict([(k, _any(v)) for k, v in list(data.items())])
        return _any(self.data, self.fields)
    def in_typemapper(self, model, anonymous):
        for klass, (km, is_anon) in list(self.typemapper.items()):
            if model is km and is_anon is anonymous:
                return klass
    def render(self):
        """\n        This super emitter does not implement `render`,\n        this is a job for the specific emitter below.\n        """
        raise NotImplementedError('Please implement render.')
    def stream_render(self, request, stream=True):
        """\n        Tells our patched middleware not to look\n        at the contents, and returns a generator\n        rather than the buffered string. Should be\n        more memory friendly for large datasets.\n        """
        yield self.render(request)
    @classmethod
    def get(cls, format):
        """\n        Gets an emitter, returns the class and a content-type.\n        """
        if format in cls.EMITTERS:
            return cls.EMITTERS.get(format)
        else:
            raise ValueError('No emitters found for type %s' % format)
    @classmethod
    def register(cls, name, klass, content_type='text/plain'):
        """\n        Register an emitter.\n\n        Parameters::\n         - `name`: The name of the emitter (\'json\', \'xml\', \'yaml\', ...)\n         - `klass`: The emitter class.\n         - `content_type`: The content type to serve response as.\n        """
        cls.EMITTERS[name] = (klass, content_type)
    @classmethod
    def unregister(cls, name):
        """\n        Remove an emitter from the registry. Useful if you don\'t\n        want to provide output in one of the built-in emitters.\n        """
        return cls.EMITTERS.pop(name, None)