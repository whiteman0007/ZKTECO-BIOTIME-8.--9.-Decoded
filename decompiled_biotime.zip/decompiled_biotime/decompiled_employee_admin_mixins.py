# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\employee_admin_mixins.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

import copy
import json
from collections import OrderedDict
import six
from celery_progress.backend import AbstractProgressRecorder
from django.contrib.admin.utils import label_for_field
from django.db.models.constants import LOOKUP_SEP
from django.http.response import HttpResponse
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views.decorators.csrf import csrf_protect
from urllib.parse import quote
from mysite import config
from mysite._utils import getattr_ex
from mysite.personnel.models import Employee, EmployeeCustomAttribute
from mysite.utils import progress_record
csrf_protect_m = method_decorator(csrf_protect)
class EmployeeAttrField(object):
    def __init__(self, field):
        self.field = field
        self.name = 'user_defined_{0}'.format(field.id)
        self.verbose_name = field.attr_name
        self.call = self.wrapper()
        self.unique = field.is_unique
    def wrapper(self):
        def wrap(obj):
            if not isinstance(obj, Employee):
                obj = getattr(obj, 'employee', None)
            ext = getattr(obj, 'employeeextrainfo', None)
            if not ext:
                return ''
            else:
                value = json.loads(ext.value)
                return value.get(str(self.field.id), '')
        wrap.short_description = self.verbose_name
        return wrap
class EmployeeAttribute(object):
    @property
    def field_map(self):
        field_map = OrderedDict()
        ext_fields = EmployeeCustomAttribute.cache_data()
        for field in ext_fields:
            f = EmployeeAttrField(field)
            field_map[f.name] = f
        return field_map
    @property
    def fields(self):
        return self.field_map.values()
    def get_field(self, name):
        return self.field_map.get(name, None)
class EmployeeExtMixin(object):
    list_display_fixed = ['id', 'emp_code', 'first_name', 'nickname', 'last_name', 'superior', 'card_no'] + list(config.WDMS_LIST_DISPLAY) + ['department', 'dept_code', 'position', 'emp_type', 'hire_date', 'gender', 'email'] + list(config.WDMS_FILTER_APP_STATUS) + ['employee_area_code', 'employee_area', 'update_time']
    hidden_fields_fixed = ['nickname', 'last_name', 'dept_code', 'superior', 'gender', 'email', 'card_no', 'employee_area_code', 'update_time'] + list(config.WDMS_HIDDEN)
    def get_extend_field(self, name):
        ext_attrs = EmployeeAttribute()
        return ext_attrs.get_field(name)
    def get_extend_fields(self):
        try:
            ext_attrs = EmployeeAttribute()
            return ext_attrs.fields
        except Exception as e:
            return None
    def get_ext_list_display(self):
        list_display = copy.deepcopy(self.list_display_fixed)
        ext_fields = self.get_extend_fields()
        if ext_fields:
            for f in ext_fields:
                list_display.append(f.name)
                setattr(self, f.name, getattr(f, 'call', lambda x: ''))
        return list_display
    def get_ext_hidden_fields(self):
        hidden_fields = copy.deepcopy(self.hidden_fields_fixed)
        ex_fields = self.get_extend_fields()
        for f in ex_fields:
            hidden_fields.append(f.name)
        return hidden_fields
class EmployeeDataImportMixin(object):
    list_import = ('emp_code', 'first_name', 'last_name', 'nickname', 'department__dept_code', 'department__dept_name', 'position__position_code', 'position__position_name', 'area__area_code', 'area__area_name', 'card_no', 'hire_date', 'gender', 'email', 'dev_privilege')
    must_import = ('emp_code',)
    defaults = ()
    def get_must_import_field(self):
        from django.conf import settings
        from mysite.authorized import auth_settings
        must_import_field = list(self.must_import)
        if getattr_ex(settings, 'MULTI_COMPANY_EXT') and auth_settings.AUTHORIZED_FIRM > 1 or settings.ENABLE_WDMS:
            must_import_field.append('email')
        return must_import_field
    def get_list_import(self, request):
        columns = []
        must_import_field = self.get_must_import_field()
        employee_fields = []
        if request.user and (not request.user.is_employee):
                employee_fields = request.user.userprofile.employee_fields.split(',')
        for f in self.list_import:
            if LOOKUP_SEP in f:
                fk, attr = f.split(LOOKUP_SEP, 1)
                fk = self.opts.get_field(fk)
                name = label_for_field(attr, model=fk.related_model)
            else:
                name = label_for_field(f, model=self.model, model_admin=self)
            selected = disabled = bool(f in must_import_field)
            selected = selected | bool(f in self.defaults)
            selected = selected | bool(f in employee_fields)
            columns.append({'name': six.text_type(name), 'value': f, 'disabled': disabled, 'selected': selected})
        ext_fields = self.get_extend_fields()
        for f in ext_fields:
            name = f.verbose_name
            columns.append({'name': six.text_type(name), 'value': f.name, 'disabled': False, 'selected': False})
        return HttpResponse(json.dumps(columns))
    def get_import_template(self, request):
        """\n        Response for \'Download Template\' in import page\'\n        :param request:\n        :return: return import template\n        """
        import xlsxwriter
        from io import BytesIO
        from django.http.response import HttpResponse
        from django.contrib.admin.utils import label_for_field
        columns = request.GET.get('fields', '')
        columns = json.loads(columns)
        if request.user and (not request.user.is_employee):
                request.user.userprofile.employee_fields = ','.join(columns.keys())
                request.user.userprofile.save()
        ext_fields = self.get_extend_fields()
        useless = set(columns.keys()) - set(self.list_import) - set([f.name for f in ext_fields])
        for key in useless:
            columns.pop(key)
        ordered = sorted(columns.items(), key=lambda x: int(x[1]))
        output = BytesIO()
        wb = xlsxwriter.Workbook(output)
        sheet = wb.add_worksheet('Template')
        for index, item in enumerate(ordered):
            column, i = item
            field = self.get_extend_field(column)
            attrs = column.split('__')
            if field:
                head = field.verbose_name
            else:
                if len(attrs) > 1:
                    fk, attr = attrs
                    fk = self.opts.get_field(fk)
                    head = label_for_field(attr, model=fk.related_model)
                else:
                    head = label_for_field(column, model=self.model, model_admin=self)
            head = str(head)
            sheet.write(0, index, head)
            sheet.set_column(0, index, len(head))
        wb.close()
        output.seek(0)
        response = HttpResponse(output.read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename={0}.xls'.format(quote(str(self.opts.verbose_name)))
        return response
    @csrf_protect_m
    def import_template(self, request):
        """\n        Response for \'Download Template\' in import page\'\n        :param request:\n        :return: return import template\n        """
        import xlsxwriter
        from io import BytesIO
        from django.http.response import HttpResponse
        from mysite.personnel.config import PERSONNEL_EMPLOYEE_MUST_FIELDS
        verbose_name = PERSONNEL_EMPLOYEE_MUST_FIELDS.copy()
        custom_fields = request.GET['fields'].split(',')
        if custom_fields[0]:
            verbose_name.extend(custom_fields)
        output = BytesIO()
        wb = xlsxwriter.Workbook(output)
        sheet = wb.add_worksheet('Template')
        for i, v in enumerate(verbose_name):
            head = '{0}'.format(v)
            sheet.write(0, i, head)
            sheet.set_column(0, i, len(head) * 3)
        wb.close()
        output.seek(0)
        response = HttpResponse(output.read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename={0}.xls'.format(quote(self.opts.verbose_name))
        return response
    def data_import(self, request, **kwargs):
        from .employee_import import ImportEmployeeData
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ImportEmployeeData(app_label=self.opts.app_label, model_name=self.opts.model_name, model_admin=self, **kwargs)
        process.save()
        employee_fields = process.columns.keys()
        if request.user and (not request.user.is_employee):
                request.user.userprofile.employee_fields = ','.join(employee_fields)
                request.user.userprofile.save()
        if process.errors:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.errors[0]
class EmployeePhotoImportMixin(object):
    def photo_import(self, request, **kwargs):
        import os
        from django.conf import settings
        from mysite.personnel.utils import devicePIN
        from mysite.utils import get_or_create_photo_folder
        from mysite.tools.image_utils import encrypt_image
        photos = request.FILES.getlist('user_photo')
        if not photos:
            return _('empPhotoImport_error_noPhoto')
        else:
            progress_recorder = kwargs.pop('progress_recorder', None)
            company = kwargs.pop('company')
            total = len(photos)
            current = 0
            progress_record(progress_recorder, current, total, _('importProgress.status.dataVerification'))
            pins = [devicePIN(photo.name.rsplit('.', 1)[0]) for photo in photos]
            exists_pins = Employee.objects.filter(emp_code__in=pins, company_id=company).values_list('emp_code', flat=True)
            extra_pins = set(pins) - set(list(exists_pins))
            ignore_error = int(kwargs.pop('ignore_error', '0'))
            if not ignore_error and extra_pins:
                return _('empPhotoImport_error_{pin}NotFound').format(pin=','.join(extra_pins))
            else:
                store_dir = get_or_create_photo_folder('photo', company.id)
                overwrite = int(kwargs.pop('overwrite', '0'))
                for index, photo in enumerate(photos):
                    current = index
                    progress_record(progress_recorder, current, total, _('importProgress.status.uploading'))
                    pin = devicePIN(photo.name.rsplit('.', 1)[0])
                    if pin in extra_pins:
                        continue
                    else:
                        file_path = os.path.join(store_dir, '{pin}.jpg'.format(pin=pin))
                        if getattr_ex(settings, 'MULTI_COMPANY', False):
                            file_path = os.path.join(store_dir, '{company}/{pin}.jpg'.format(company=company.id, pin=pin))
                        if not overwrite and os.path.exists(file_path):
                                continue
                        with open(file_path, 'wb') as f:
                            if settings.ENABLE_ENCRYPT_PHOTO:
                                f.write(encrypt_image(photo.read()))
                            else:
                                f.write(photo.read())
                progress_record(progress_recorder, total, total, _('importProgress.status.uploading'))
class EmployeeCertificateImportMixin(object):
    def cert_import(self, request, **kwargs):
        from mysite.personnel.admin.employeecertification_admin import ImportEmployeeCertificationData
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ImportEmployeeCertificationData(request, app_label=self.opts.app_label, model_name='EmployeeCertification', **kwargs)
        process.exe_import_data()
        if process.error_info:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.error_info[0]
class EmployeeUSBDataImportMixin(object):
    def usb_data_import(self, request, **kwargs):
        from mysite.personnel.import_usb_data import ImportUSBData
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ImportUSBData(request, **kwargs)
        process.usb_data_import()
        if process.error_info:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.error_info[0]
class EmployeeUSBDataExportMixin(object):
    def usb_data_export(self, request, **kwargs):
        from mysite.personnel.export_usb_data import ExportUSBData
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ExportUSBData(request, **kwargs)
        process.usb_data_export()
        if process.error_info:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.error_info[0]