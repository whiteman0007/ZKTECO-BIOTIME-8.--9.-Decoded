# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\global_date_setting.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from rest_framework import serializers
class GlobalDateSettingUpdateSerializer(serializers.Serializer):
    short_date = serializers.CharField(required=False, allow_blank=True, default='1')
    short_time = serializers.CharField(required=False, allow_blank=True, default='1')