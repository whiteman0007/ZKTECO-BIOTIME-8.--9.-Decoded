# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\meeting\\api\\serializers\\attender_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:05 UTC (1750673045)

from rest_framework import serializers
from mysite.personnel.models import Employee
class MeetingAttenderSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source='department.dept_name', allow_null=True)
    position_name = serializers.CharField(source='position.position_name', allow_null=True)
    class Meta:
        model = Employee
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'nickname', 'department_name', 'position_name')