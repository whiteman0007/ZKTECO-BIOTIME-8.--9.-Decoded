# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\visitor\\migrations\\0011_pro_903_2024090900.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:28 UTC (1750702768)

from django.db import migrations, models
import django.db.models.deletion
dict_code_id = {}
def migrate_certification(*args, **kwargs):
    sql = 'insert into visitor_visitorcertification(cert_code,cert_name)\n    select distinct c.cert_code,c.cert_name from personnel_certification c \n    where c.id in (select r.cert_type_id from visitor_reservation r) \n    or c.id in (select v.cert_type_id from visitor_visitor v)'
    from mysite.sql_utils import p_execute
    p_execute(sql)
    from mysite.visitor.models.model_certification import VisitorCertification
    certs = VisitorCertification.objects.all()
    if certs:
        for c in certs:
            dict_code_id[c.cert_code] = c.id
dict_visitor_cert = {}
def get_visitor_certification(*args, **kwargs):
    from mysite.sql_utils import p_query
    sql = 'select distinct v.id,c.cert_code \n    from visitor_visitor v,personnel_certification c \n    where v.cert_type_id=c.id'
    try:
        res = p_query(sql)
        for v in res:
            dict_visitor_cert[v[0]] = v[1]
    except Exception as e0:
        print('get_visitor_certification - ' + str(e0))
def update_visitor_certification(*args, **kwargs):
    if dict_visitor_cert:
        for v_id, code in dict_visitor_cert.items():
            c_id = dict_code_id.get(code, 0)
            sql = f'update visitor_visitor set cert_type_id={c_id} where id={v_id}'
            migrations.RunSQL(sql)
dict_reservation_cert = {}
def get_reservation_certification(*args, **kwargs):
    from mysite.sql_utils import p_query
    sql = 'select distinct r.workflowinstance_ptr_id,c.cert_code \n    from visitor_reservation r,personnel_certification c \n    where r.cert_type_id=c.id'
    try:
        res = p_query(sql)
        for r in res:
            dict_reservation_cert[r[0]] = r[1]
    except Exception as e0:
        print('get_visitor_certification - ' + str(e0))
def update_reservation_certification(*args, **kwargs):
    if dict_reservation_cert:
        for r_id, code in dict_reservation_cert.items():
            c_id = dict_code_id.get(code, 0)
            sql = f'update visitor_reservation set cert_type_id={c_id} where workflowinstance_ptr_id={r_id}'
            migrations.RunSQL(sql)
class Migration(migrations.Migration):
    dependencies = [('visitor', '0010_alter_bio_type_903')]
    operations = [migrations.CreateModel(name='VisitorCertification', fields=[('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('cert_code', models.CharField(max_length=20, unique=True, verbose_name='certification_field_code')), ('cert_name', models.CharField(max_length=100, unique=True, verbose_name='certification_field_name')), migrations.RunPython(migrate_certification, reverse_code=migrations.RunPython.noop), migrations.RunPython(update_reservation_certification, reverse_code=migrations.RunPython.noop), migrations.RunPython(get_visitor_certification, reverse_code=migrations.RunPython.noop), migrations.RunPython(update_visitor_certification, reverse_code=migrations.RunPython.noop)]