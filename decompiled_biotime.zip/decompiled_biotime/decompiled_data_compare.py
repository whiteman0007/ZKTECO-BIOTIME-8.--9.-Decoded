# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\iclock\\data_compare.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:36 UTC (1750673016)

import functools
import re
from mysite.core.zkcmdproc import verify_bio_feature, zk_set_data, zk_set_fingerprint, zk_set_face, DevIdentity, zk_delete_data
from mysite.iclock import const
from mysite.iclock.devview_ex import save_device_upload_log
from mysite.iclock.models import BioPhoto, BioData
from mysite.iclock.utils import getDevice
from mysite.personnel.models import Employee
from mysite.utils import DevIdentity_ex, saveCmd
def generate_shell_out_file_name(file_name, cmd_content):
    flags = ['biodata_query', 'fp10_query', 'face7_query', 'biophoto', 'user_query']
    tag = 'shell'
    for flag in flags:
        if flag not in cmd_content:
            continue
        else:
            tag = flag
            break
    file_name = '_'.join([tag, file_name])
    return file_name
def push_version_verify(func):
    @functools.wraps(func)
    def wrapper(device):
        device = getDevice(device.sn)
        if DevIdentity_ex(device.push_ver, 'Ver 2.0.33S-20210419') and device.is_android:
            return None
        else:
            return func(device)
    return wrapper
def device_db_query(sql):
    db_service = '/mnt/mtdblock/service/sqlite3'
    db = '/mnt/mtdblock/data/ZKDB.db'
    db_query_cmd = 'shell %s %s "%s\"' % (db_service, db, sql)
    return db_query_cmd
@push_version_verify
def query_user_from_device(device):
    """\n    Query user list form device\n    """
    sql = 'SELECT user_query.user_pin FROM user_info user_query'
    cmd = device_db_query(sql)
    saveCmd(device.pk, cmd, active_async=False)
@push_version_verify
def query_fingerprint_from_device(device):
    if not verify_bio_feature(device, const.bioFinger):
        return
    else:
        query_field = 'u.user_pin, fp10_query.fingerid'
        query_table = 'fptemplate10 fp10_query'
        query_join = 'user_info u on u.id = fp10_query.pin'
        query_params = 'trim(fp10_query.template) != \'\''
        group_by = 'u.user_pin, fp10_query.fingerid'
        sql = 'SELECT %s FROM %s INNER JOIN %s WHERE %s GROUP BY %s' % (query_field, query_table, query_join, query_params, group_by)
        cmd = device_db_query(sql)
        saveCmd(device.pk, cmd, active_async=False)
@push_version_verify
def query_face_from_device(device):
    if not verify_bio_feature(device, const.bioFace):
        return
    else:
        query_field = 'u.user_pin'
        query_table = 'face_template_7 face7_query'
        query_join = 'user_info u on u.user_pin = face7_query.user_pin'
        query_params = 'trim(face7_query.template) != \'\''
        group_by = 'u.user_pin'
        sql = 'SELECT %s FROM %s INNER JOIN %s WHERE %s GROUP BY %s' % (query_field, query_table, query_join, query_params, group_by)
        cmd = device_db_query(sql)
        saveCmd(device.pk, cmd, active_async=False)
@push_version_verify
def query_bio_template_from_device(device):
    query_field = 'biodata_query.user_pin, biodata_query.bio_type, biodata_query.template_no'
    query_table = 'pers_biotemplate biodata_query'
    query_join_data = 'pers_biotemplatedata pbd on biodata_query.template_id = pbd.ID'
    query_join_user = 'user_info u on u.user_pin = biodata_query.user_pin'
    query_params = 'trim(pbd.template_data) != \'\''
    group_by = 'biodata_query.user_pin, biodata_query.bio_type, biodata_query.template_no'
    sql = 'SELECT %s FROM %s INNER JOIN %s INNER JOIN %s where %s group by %s' % (query_field, query_table, query_join_data, query_join_user, query_params, group_by)
    cmd = device_db_query(sql)
    saveCmd(device.pk, cmd, active_async=False)
@push_version_verify
def query_bio_photo_from_device(device):
    if not verify_bio_feature(device, const.bioFaceVL):
        return
    else:
        store_path = '/mnt/mmcblock/data/biophoto/face'
        cmd = 'shell ls %s' % store_path
        saveCmd(device.pk, cmd)
def clear_shell_out(device):
    import datetime
    import os
    import shutil
    from django.conf import settings
    now = datetime.datetime.now()
    expired = (now - datetime.timedelta(days=7)).strftime('%Y%m%d')
    storage = os.path.join(settings.ADDITION_FILE_ROOT, *('upload', device.sn, 'data'))
    if not os.path.exists(storage):
        return
    else:
        for daily in os.listdir(storage):
            if not daily.isdigit():
                return
            else:
                if int(daily) > int(expired):
                    return
                else:
                    daily_storage = os.path.join(storage, daily)
                    if not os.path.isdir(daily_storage):
                        continue
                    else:
                        shutil.rmtree(daily_storage)
def data_compare_cmd(device):
    from mysite.core.zkcmdproc import verify_bio_feature, verify_bio_photo
    device = getDevice(device.sn)
    if device.is_android:
        return
    else:
        saveCmd(device.pk, 'shell cp /mnt/mtdblock/data/sqlite3* /mnt/mtdblock/service/sqlite3')
        query_user_from_device(device)
        bio_types = const.BIO_TYPE.keys()
        if DevIdentity(device, 'bio_data'):
            if any([verify_bio_feature(device, bio_type) for bio_type in bio_types]):
                query_bio_template_from_device(device)
        else:
            if verify_bio_feature(device, const.bioFace):
                query_face_from_device(device)
        if verify_bio_feature(device, const.bioFinger):
            query_fingerprint_from_device(device)
        clear_shell_out(device)
def data_compare_pre_check(title):
    def title_wrapper(func):
        @functools.wraps(func)
        def wrapper(device, shell_out, return_value):
            if not shell_out:
                save_device_upload_log(device.pk, 0, 0, 'No file found', title)
                return
            else:
                with open(shell_out, 'r') as f:
                    content = f.read()
                if int(return_value)!= 0:
                    save_device_upload_log(device.pk, 0, 0, content[60:], title)
                else:
                    device_rows = content.strip().split('\n')
                    device_rows = set(filter(None, device_rows))
                    func(device, device_rows, return_value)
        return wrapper
    return title_wrapper
def data_compare_bio_data_by_type(device, bio_type, device_rows, server_rows):
    from mysite.iclock.const import BIO_TYPE
    device_missing = list(server_rows - device_rows)
    employee_wise = {}
    for item in device_missing:
        emp_code, bio = item.split('|', 1)
        if emp_code not in employee_wise:
            employee_wise[emp_code] = []
        employee_wise[emp_code].append(bio)
    emp_codes = list(employee_wise.keys())
    for i in range(int(len(emp_codes) / 1000) + 1):
        codes = emp_codes[i * 1000:(i + 1) * 1000]
        employees = Employee.objects.filter(company=device.area.company, emp_code__in=codes, is_active=True)
        for employee in employees:
            kwargs = {'active_async': False}
            if bio_type == const.bioFinger:
                kwargs['is_finger'] = 1
            else:
                if bio_type == const.bioFace:
                    kwargs['is_face'] = 1
                else:
                    if bio_type == const.bioVein:
                        kwargs['is_fv'] = 1
                    else:
                        if bio_type == const.bioHand:
                            kwargs['is_pv'] = 1
                            kwargs['is_vpv'] = 1
                        else:
                            if bio_type == const.bioFaceVL:
                                kwargs['is_biophoto'] = 1
                            else:
                                continue
            kwargs['is_employee'] = 0
            zk_set_data(device, 'userinfo', [employee], **kwargs)
    desc = 'Device missing %s' % len(device_missing)
    save_device_upload_log(device.pk, 0, 0, desc, '%s Compare' % BIO_TYPE.get(bio_type, bio_type))
    server_missing = device_rows - server_rows
    return server_missing
@data_compare_pre_check('BioData Compare')
def data_compare_bio_data(device, device_rows, return_value):
    from mysite.iclock.const import BIO_TYPE
    from mysite.core.zkcmdproc import get_bio_major_and_minor_ver
    server_missing = set()
    employees = Employee.objects.filter(area=device.area, is_active=True)
    for bio_type in list(BIO_TYPE.keys()):
        device_rows_filtered = set(filter(lambda x: re.search('.+\\|%s\\|.+' % bio_type, x), device_rows))
        if not device_rows_filtered:
            continue
        else:
            major_ver, minor_ver = get_bio_major_and_minor_ver(device, bio_type)
            if not major_ver:
                continue
            else:
                rows = BioData.objects.filter(employee__in=employees, employee__is_active=True, bio_type=bio_type, major_ver=major_ver, minor_ver=minor_ver).values_list('employee__emp_code', 'bio_type', 'bio_no')
                server_rows = set(['%s|%s|%s' % (r[0], r[1], r[2]) for r in rows])
                missing = data_compare_bio_data_by_type(device, bio_type, device_rows_filtered, server_rows)
                server_missing.union(missing)
    emp_codes = set([value.split('|')[0] for value in server_missing])
    for emp_code in emp_codes:
        cmd = 'DATA QUERY USERINFO PIN={pin}'.format(pin=emp_code)
        saveCmd(device.pk, cmd)
    desc = 'Server missing %s' % len(server_missing)
    save_device_upload_log(device.pk, 0, 0, desc, 'BioData Compare')
@data_compare_pre_check('BioPhoto Compare')
def data_compare_bio_photo(device, device_rows, return_value):
    employees = Employee.objects.filter(area=device.area, is_active=True)
    device_rows = set([r.split('.')[0] for r in device_rows])
    server_rows = set(BioPhoto.objects.filter(employee__in=employees, approval_state__in=(1, 3)).values_list('employee__emp_code', flat=True))
    device_missing = list(server_rows - device_rows)
    for i in range(int(len(device_missing) / 1000) + 1):
        emp_codes = device_missing[i * 1000:(i + 1) * 1000]
        employees = Employee.objects.filter(company=device.area.company, emp_code__in=emp_codes)
        if not employees.exists():
            continue
        else:
            zk_set_data(device, 'userinfo', employees, is_biophoto=1, is_employee=0, active_async=False)
    server_missing = list(device_rows - server_rows)
    for emp_code in set(server_missing):
        cmd = 'DATA QUERY USERINFO PIN={pin}'.format(pin=emp_code)
        saveCmd(device.pk, cmd)
    desc = 'Device missing %s, service missing %s' % (len(device_missing), len(server_missing))
    save_device_upload_log(device.pk, 0, 0, desc, 'BioPhoto Compare')
@data_compare_pre_check('Fingerprint Compare')
def data_compare_fp10(device, device_rows, return_value):
    employees = Employee.objects.filter(area=device.area, is_active=True)
    rows = BioData.objects.filter(employee__in=employees, employee__is_active=True, bio_type=const.bioFinger, major_ver='10').values('employee__emp_code', 'bio_no')
    server_rows = set(['%s|%s' % (r['employee__emp_code'], r['bio_no']) for r in rows])
    device_missing = list(server_rows - device_rows)
    kwargs = {'notify': False, 'active_async': False}
    for value in device_missing:
        emp_code, finger_id = value.split('|')
        biodata = BioData.objects.filter(employee__company=device.area.company, employee__emp_code=emp_code, bio_type=const.bioFinger, major_ver='10', bio_no=finger_id).first()
        if not biodata:
            continue
        else:
            zk_set_fingerprint(emp_code, device, biodata, **kwargs)
    server_missing = list(device_rows - server_rows)
    emp_codes = [value.split('|')[0] for value in server_missing]
    for emp_code in set(emp_codes):
        cmd = 'DATA QUERY USERINFO PIN={pin}'.format(pin=emp_code)
        saveCmd(device.pk, cmd)
    desc = 'Device missing %s, service missing %s' % (len(device_missing), len(server_missing))
    save_device_upload_log(device.pk, 0, 0, desc, 'Fingerprint Compare')
@data_compare_pre_check('Face Compare')
def data_compare_face7(device, device_rows, return_value):
    employees = Employee.objects.filter(area=device.area, is_active=True)
    rows = BioData.objects.filter(employee__in=employees, employee__is_active=True, bio_type=const.bioFace, major_ver__in=('7', '7.0')).values_list('employee__emp_code', flat=True)
    server_rows = set(rows)
    device_missing = list(server_rows - device_rows)
    kwargs = {'notify': False, 'active_async': False}
    for emp_code in device_missing:
        biodata = BioData.objects.filter(employee__emp_code=emp_code, bio_type=const.bioFace, major_ver__in=('7', '7.0')).first()
        if not biodata:
            continue
        else:
            zk_set_face(emp_code, device, biodata, **kwargs)
    server_missing = list(device_rows - server_rows)
    for emp_code in set(server_missing):
        cmd = 'DATA QUERY USERINFO PIN={pin}'.format(pin=emp_code)
        saveCmd(device.pk, cmd)
    desc = 'Device missing %s, service missing %s' % (len(device_missing), len(server_missing))
    save_device_upload_log(device.pk, 0, 0, desc, 'Face 7 Compare')
@data_compare_pre_check('User Compare')
def data_compare_user(device, device_rows, return_value):
    from django.conf import settings
    server_rows = set(Employee.objects.filter(area=device.area, is_active=True).values_list('emp_code', flat=True))
    device_missing = list(server_rows - device_rows)
    for i in range(int(len(device_missing) / 1000) + 1):
        emp_codes = device_missing[i * 1000:(i + 1) * 1000]
        employees = Employee.objects.filter(company=device.area.company, emp_code__in=emp_codes, is_active=True)
        zk_set_data(device, 'userinfo', employees, is_pic=1, active_async=False)
    server_missing = list(device_rows - server_rows)
    if settings.DATA_COMPARE_TYPE == 1:
        for emp_code in set(server_missing):
            zk_delete_data(device, emp_code, 'user')
    else:
        for emp_code in set(server_missing):
            cmd = 'DATA QUERY USERINFO PIN={pin}'.format(pin=emp_code)
            saveCmd(device.pk, cmd)
    desc = 'Device missing %s, service missing %s' % (len(device_missing), len(server_missing))
    save_device_upload_log(device.pk, 0, 0, desc, 'User Compare')
def data_compare(sn, cmd, shell_out, return_value):
    device = getDevice(sn)
    if 'biodata_query' in cmd:
        data_compare_bio_data(device, shell_out, return_value)
    else:
        if 'fp10_query' in cmd:
            data_compare_fp10(device, shell_out, return_value)
        else:
            if 'face7_query' in cmd:
                data_compare_face7(device, shell_out, return_value)
            else:
                if 'biophoto' in cmd:
                    data_compare_bio_photo(device, shell_out, return_value)
                else:
                    if 'user_query' in cmd:
                        data_compare_user(device, shell_out, return_value)