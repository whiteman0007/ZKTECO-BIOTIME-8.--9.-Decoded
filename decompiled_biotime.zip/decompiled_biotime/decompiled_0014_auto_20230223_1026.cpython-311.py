# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0014_auto_20230223_1026.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

import datetime
from django.db import migrations, models
import django.db.models.deletion
import mysite.base.models.modelless
import mysite.personnel.fields
from mysite.sql_utils import p_query, p_execute
def update_work_code_of_manuallog(apps, schema_editor):
    sql = 'select distinct work_code from att_manuallog'
    res = p_query(sql)
    for r in res:
        old_code = r[0]
        if old_code:
            code = old_code[:8]
            twc_sql = 'select * from iclock_terminalworkcode where code=\'{code}\''.format(code=code)
            twc_res = p_query(twc_sql)
            if not twc_res:
                twc_insert_sql = 'insert into iclock_terminalworkcode(status, code, alias) values(0, \'{code}\', \'{alias}\')'.format(code=code, alias=code)
                twc_id = p_execute(twc_insert_sql)
            else:
                twc_id = twc_res[0][0]
            update_sql = 'update att_manuallog set work_code={work_code_id} where work_code=\'{work_code}\''
            update_sql = update_sql.format(work_code_id=twc_id, work_code=old_code)
            p_execute(update_sql)
class Migration(migrations.Migration):
    dependencies = [('personnel', '0011_auto_20230223_1026'), ('base', '0007_auto_20221202_1852'), ('att', '0013_auto_20221202_1852')]
    AddField = [migrations.CreateModel('AttUserGuidePermission', name=[], fields='att.menus.userGuid', options=True, bases=[], managers=['verbose_name', 'base.abstractpermission', 'objects']), migrations.AddField('attgroup', name='id', field=['att.models.attGroup', 'ordering', 'AddField', 'company', 'AddField', 'company', 'personnel', 'CompanyForeignKey', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django', '1', 'django