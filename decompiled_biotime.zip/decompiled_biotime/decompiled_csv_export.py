# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\tools\\export_utils\\csv_export.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import time
import datetime
import os
import codecs
import csv
from celery_progress.backend import AbstractProgressRecorder
from django.http.response import HttpResponse
from urllib.parse import quote
from django.utils.encoding import smart_str
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from mysite.tools.export_utils.export_interface import ExportInterface
from mysite.tools.export_utils.utils import encrypt_zip
from mysite.utils import progress_record
class BaseCsvExport(ExportInterface):
    pass
    def __init__(self, datas, fields='__all__', headers=None, filename=None, progress_recorder=None, password=None, filename_model=None, **kwargs):
        self.datas = datas
        self.fields = fields
        self.headers = headers
        self.filename = filename
        self.progress_recorder = progress_recorder
        self.total = kwargs.get('total', 0)
        self.counter = 0
        self.password = password
        self.filename_model = filename_model
        if not isinstance(self.filename, str):
            self.filename = '%s_export.csv' % time.strftime('%Y%m%d_%H%M%S')
    def get_response(self):
        response = HttpResponse(content_type='text/csv;charset=UTF-8')
        response.write(codecs.BOM_UTF8)
        response['Content-Disposition'] = 'attachment;filename=%s' % quote(self.filename)
        writer = csv.writer(response, dialect='excel')
        if self.headers:
            writer.writerow(self.headers)
        for data in self.datas:
            writer.writerow([data.get(field, '') for field in self.fields])
        return response
    def save_file(self, basedir=None):
        raise NotImplementedError('Subclasses of BaseCsvExport must provide a save_file() method.')
    def append_space_before_equal(self, val: str):
        val = ' ' + val if val.startswith('=') else val
        return val
class CsvExport(BaseCsvExport):
    """"""
    def save_file(self, basedir=None):
        from mysite.tools.export_utils.utils import get_field_value
        if not basedir:
            basedir = os.path.join(settings.ADDITION_FILE_ROOT, 'reports')
        if not os.path.exists(basedir):
            os.makedirs(basedir)
        basedir = os.path.join(basedir, datetime.datetime.now().strftime('%Y%m%d'))
        if not os.path.exists(basedir):
            os.makedirs(basedir)
        if self.password:
            filepath = os.path.abspath(os.path.join(basedir, smart_str(self.filename_model)))
        else:
            filepath = os.path.abspath(os.path.join(basedir, smart_str(self.filename)))
        with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f, dialect='excel')
            if self.headers:
                writer.writerow(self.headers)
            for data in self.datas:
                writer.writerow([get_field_value(data, field).replace(',', ';') for field in self.fields])
                self.counter += 1
                progress_record(self.progress_recorder, self.counter, self.total, _('exportProgress.status.generateDoc'))
        return encrypt_zip(filepath, self.password)