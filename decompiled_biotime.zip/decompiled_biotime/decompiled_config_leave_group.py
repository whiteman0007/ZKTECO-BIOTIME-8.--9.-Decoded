# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\config_leave_group.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
import json
from dateutil import parser
from dateutil.relativedelta import relativedelta
from django.utils.translation import gettext_lazy as _
from mysite.att.models import LeaveGroupDetail, LeaveYearBalance, PayCode
from mysite.att.models_choices import BASED_ON_SERVICE, FIXED_QUOTA, ONE_TIME_LEAVE, UNLIMITED_LEAVE, MIN_LEAVE_DAY, COMPENSATORY_LEAVE
from mysite.personnel.models import Employee
from mysite.workflow.models_choices import APPROVED, REVOKE
from mysite.utils import get_dt4mssql
class ConfigLeaveGroup(object):
    def __init__(self, employee, pay_code, leavegroupdetail):
        self.employee = employee
        self.hire_date = get_dt4mssql(employee.hire_date, 1)
        self.leave_group = employee.leave_group
        self.pay_code = pay_code
        self.leavegroupdetail = leavegroupdetail
        self.leave_type = self.leavegroupdetail.leave_type
        self.config_startDay = parser.parse('{0}-{1}'.format(2000, leavegroupdetail.start_day)) if leavegroupdetail.leave_type in (FIXED_QUOTA, BASED_ON_SERVICE) else datetime.datetime.now().date()
        self.leave_distribution_time = self.leavegroupdetail.leave_distribution_time
        self.leave_entitlement = self.leavegroupdetail.leave_entitlement
        self.allow_leave_day = self.leavegroupdetail.allow_leave_day
        self.min_leave_day = self.leavegroupdetail.min_leave_day
        self.allow_exceed_limit = self.leavegroupdetail.allow_exceed_limit
        self.entitlement_detail = self.leavegroupdetail.entitlement_detail
        self.used_leave_day = 0
        self.left_leave_day = 0
        self.set_hire_day = self.leavegroupdetail.set_hire_day
        self.allow_balance = self.leavegroupdetail.allow_balance
        self.curr_pre_balance = 0
        self.pre_balance = 0
        self.exceed_leave_days = 0
    def get_leaveyearbalance_obj(self, year=None):
        return LeaveYearBalance.objects.filter(year=year, employee=self.employee, pay_code=self.pay_code).first()
    def get_leave_entitlement(self, service_y):
        entitlement_detail = json.loads(self.entitlement_detail.replace('\'', '\"'))
        for detail_i in entitlement_detail:
            if service_y in range(detail_i['seniority_start'], detail_i['seniority_end'] + 1):
                self.leave_entitlement = int(detail_i['entitlement_days']) if detail_i['entitlement_days'] else 0
                return
        self.leave_entitlement = 0
    def leave_used_data(self):
        data = {'code': 0, 'all_leave_day': self.leave_entitlement, 'used_leave_day': self.used_leave_day, 'left_leave_day': self.left_leave_day, 'allow_exceed_limit': self.allow_exceed_limit, 'pre_balance': self.pre_balance, 'curr_pre_balance': self.curr_pre_balance, 'exceed_leave_days': self.exceed_leave_days, 'leave_type': self.leave_type}
        return data
    def config_compensatory_time(self, year):
        from mysite.att.models import Overtime, PayloadPayCode
        from mysite.att import const
        compensatory_hours = sum(PayloadPayCode.objects.filter(pay_code__fixed_code=const.CP, att_date__year=int(year), emp=self.employee).values_list('hours', flat=True))
        leaveyearbalance_obj = self.get_leaveyearbalance_obj(year)
        if not leaveyearbalance_obj:
            pre_balance = 0
            if self.allow_balance:
                compensatory_leave_hours = sum(PayloadPayCode.objects.filter(pay_code__fixed_code=const.CPL, att_date__year=int(year - 1), emp=self.employee).values_list('hours', flat=True))
                pre_compensatory_hours = sum(PayloadPayCode.objects.filter(pay_code__fixed_code=const.CP, att_date__year=int(year - 1), emp=self.employee).values_list('hours', flat=True))
                pre_balance = min(self.leavegroupdetail.max_balance, max(pre_compensatory_hours - compensatory_leave_hours, 0))
            leaveyearbalance_obj = LeaveYearBalance(employee=self.employee, pre_balance=pre_balance, year=year, entitlement_days=compensatory_hours, pay_code=self.pay_code, leave_type=self.leave_type)
        else:
            leaveyearbalance_obj.entitlement_days = compensatory_hours
        leaveyearbalance_obj.save()
    def config_type_distributed(self, leave_range_end_date=None):
        if self.leave_type == UNLIMITED_LEAVE:
            self.config_unlimit_leave(leave_range_end_date)
        else:
            if self.leave_type == ONE_TIME_LEAVE:
                self.config_one_time_leave(leave_range_end_date)
            else:
                if self.leave_type == BASED_ON_SERVICE:
                    self.config_based_on_service(leave_range_end_date)
                else:
                    if self.leave_type == FIXED_QUOTA:
                        self.config_fixed_quota(leave_range_end_date)
                    else:
                        if self.leave_type == COMPENSATORY_LEAVE:
                            self.config_compensatory_leave()
    def config_one_time_leave(self, leave_range_end_date=None):
        if not leave_range_end_date:
            leave_range_end_date = datetime.datetime.now()
        leaveyearbalance_obj = self.get_leaveyearbalance_obj(leave_range_end_date.year)
        if not leaveyearbalance_obj:
            leaveyearbalance_obj = LeaveYearBalance(employee=self.employee, pre_balance=0, year=leave_range_end_date.year, entitlement_days=self.leave_entitlement, pay_code=self.pay_code, leave_type=self.leave_type)
            leaveyearbalance_obj.save()
        self.used_leave_day = leaveyearbalance_obj.leave_day
        self.left_leave_day = self.leave_entitlement - self.used_leave_day
    def config_unlimit_leave(self, leave_range_end_date=None):
        if not leave_range_end_date:
            leave_range_end_date = datetime.datetime.now()
        leaveyearbalance_obj = self.get_leaveyearbalance_obj(leave_range_end_date.year)
        if not leaveyearbalance_obj:
            LeaveYearBalance(employee=self.employee, pre_balance=0, year=leave_range_end_date.year, entitlement_days=9999, pay_code=self.pay_code, leave_type=self.leave_type).save()
        else:
            self.used_leave_day = leaveyearbalance_obj.leave_day
    def config_based_on_service(self, leave_start_date=None):
        if self.set_hire_day == 1:
            self.config_startDay = datetime.datetime(2000, self.hire_date.month, self.hire_date.day)
        if not leave_start_date:
            leave_start_date = datetime.datetime.now()
        _range_start_date = to_datetime(leave_start_date.year, self.config_startDay.month, self.config_startDay.day)
        service_start_date = to_datetime(self.hire_date.year, self.config_startDay.month, self.config_startDay.day)
        year = leave_start_date.year + self.leave_distribution_time
        year = year - 1 if leave_start_date < _range_start_date else year
        lb_obj = self.get_leaveyearbalance_obj(year)
        pre_lb_obj = self.get_leaveyearbalance_obj(year - 1)
        if lb_obj:
            self.pre_balance = lb_obj.pre_balance
            self.used_leave_day = lb_obj.leave_day
            self.exceed_leave_days = lb_obj.exceed_leave_day
            self.leave_entitlement = lb_obj.entitlement_days
        else:
            service_y = self.get_service_year(str(leave_start_date), str(service_start_date))
            if service_y < 0:
                return
            else:
                proportion = False
                if self.leave_distribution_time:
                    if service_y == 0:
                        service_y = 1 if _range_start_date.date() >= self.hire_date else 0
                    if service_y == 1:
                        proportion = True
                else:
                    if self.hire_date < _range_start_date.date():
                        service_y += 1
                    if leave_start_date.year == _range_start_date.year and _range_start_date.date() <= self.hire_date:
                            service_y = 1
                    if service_y == 1:
                        proportion = True
                if service_y:
                    self.get_leave_entitlement(service_y)
                    if proportion and (not self.set_hire_day) and (not self.leave_distribution_time):
                                distribution_date = to_datetime(year, self.config_startDay.month, self.config_startDay.day) + relativedelta(days=(-1))
                                distribution_day = (self.leave_entitlement * ((distribution_date - parser.parse(str(self.hire_date)) + datetime.timedelta(days=1)) / 365)).days
                                pre_lb_obj = LeaveYearBalance.objects.filter(employee=self.employee, year=year - 1, pay_code=self.pay_code).first()
                                if not pre_lb_obj:
                                    pre_lb_obj = LeaveYearBalance(employee=self.employee, year=year - 1, pre_balance=0, entitlement_days=max(distribution_day, 0), pay_code=self.pay_code, leave_type=self.leave_type)
                                    pre_lb_obj.save()
                                self.leave_entitlement += distribution_day if distribution_day < 0 else 0
                else:
                    self.leave_entitlement = 0
                self.used_leave_day = 0
                self.exceed_leave_days = 0
                if self.allow_balance and pre_lb_obj:
                    pre_pre_lb_obj = self.get_leaveyearbalance_obj(leave_start_date.year - 2)
                    discount_balance = pre_lb_obj.entitlement_days - pre_lb_obj.leave_day + pre_lb_obj.pre_balance - (pre_pre_lb_obj.exceed_leave_day if pre_pre_lb_obj else 0)
                    self.pre_balance = max(min(self.leavegroupdetail.max_balance, discount_balance), 0)
                else:
                    self.pre_balance = 0
                LeaveYearBalance(employee=self.employee, year=year, pre_balance=self.pre_balance, entitlement_days=self.leave_entitlement, pay_code=self.pay_code, leave_type=self.leave_type).save()
        previous_exceed_leave_days = pre_lb_obj.exceed_leave_day if pre_lb_obj else 0
        self.used_leave_day = self.used_leave_day + previous_exceed_leave_days
        self.left_leave_day = max(self.leave_entitlement - self.used_leave_day + self.pre_balance, 0)
        self.curr_pre_balance = max(self.pre_balance - self.used_leave_day, 0)
    def config_compensatory_leave(self):
        year = datetime.datetime.now().year
        lb_obj = self.get_leaveyearbalance_obj(year)
        pre_lb_obj = self.get_leaveyearbalance_obj(year - 1)
        if not lb_obj:
            lb_obj = LeaveYearBalance(employee=self.employee, year=year, pre_balance=self.pre_balance, entitlement_days=0, pay_code=self.pay_code, leave_type=self.leave_type)
            lb_obj.save()
        else:
            self.pre_balance = lb_obj.pre_balance
            self.used_leave_day = lb_obj.leave_day
            self.leave_entitlement = lb_obj.entitlement_days
        if self.allow_balance and pre_lb_obj:
                discount_balance = pre_lb_obj.entitlement_days - pre_lb_obj.leave_day + pre_lb_obj.pre_balance
                self.pre_balance = max(min(self.leavegroupdetail.max_balance, discount_balance), 0)
        self.used_leave_day = lb_obj.leave_day
        self.left_leave_day = max(self.leave_entitlement - self.used_leave_day + self.pre_balance, 0)
        self.curr_pre_balance = max(self.pre_balance - self.used_leave_day, 0)
    def config_fixed_quota(self, leave_start_date=None):
        now = datetime.datetime.now()
        if not leave_start_date:
            leave_start_date = now
        _range_start_date = to_datetime(leave_start_date.year, self.config_startDay.month, self.config_startDay.day)
        year = leave_start_date.year + self.leave_distribution_time
        year = year - 1 if leave_start_date < _range_start_date else year
        lb_obj = self.get_leaveyearbalance_obj(year)
        pre_lb_obj = self.get_leaveyearbalance_obj(year - 1)
        if not lb_obj:
            self.used_leave_day = 0
            self.exceed_leave_days = 0
            leave_entitlement = self.leave_entitlement
            if self.leave_distribution_time:
                _range_end_date = to_datetime(year, self.config_startDay.month, self.config_startDay.day) + datetime.timedelta(days=(-1))
                if self.hire_date > _range_end_date.date():
                    leave_entitlement = 0
            else:
                if self.hire_date.year == _range_start_date.year and leave_start_date < _range_start_date:
                        leave_entitlement = 0
            LeaveYearBalance(employee=self.employee, year=year, pre_balance=self.pre_balance, entitlement_days=leave_entitlement, pay_code=self.pay_code, leave_type=self.leave_type).save()
        else:
            self.pre_balance = lb_obj.pre_balance
            self.used_leave_day = lb_obj.leave_day
            self.exceed_leave_days = lb_obj.exceed_leave_day
            self.leave_entitlement = lb_obj.entitlement_days
        self.left_leave_day = max(self.leave_entitlement - self.used_leave_day - (pre_lb_obj.exceed_leave_day if pre_lb_obj else 0), 0)
    def get_service_year(self, str1, str2):
        year1 = datetime.datetime.strptime(str1[0:10], '%Y-%m-%d').year
        year2 = datetime.datetime.strptime(str2[0:10], '%Y-%m-%d').year
        month1 = datetime.datetime.strptime(str1[0:10], '%Y-%m-%d').month
        month2 = datetime.datetime.strptime(str2[0:10], '%Y-%m-%d').month
        num = (year1 - year2) * 12 + (month1 - month2)
        return num // 12
    def update_leaveyearbalance_year(self, current_year, approval_status, leave_day, delete=False):
        leaveyearbalance = self.get_leaveyearbalance_obj(current_year)
        if not leaveyearbalance:
            LeaveYearBalance(employee=self.employee, year=current_year, pre_balance=self.pre_balance, entitlement_days=self.leave_entitlement, pay_code=self.pay_code, leave_type=self.leave_type).save()
            leaveyearbalance = self.get_leaveyearbalance_obj(current_year)
        if approval_status == APPROVED and (not delete):
            if self.leave_type == ONE_TIME_LEAVE:
                leaveyearbalance.leave_day = self.leave_entitlement
            else:
                leaveyearbalance.leave_day += leave_day
        else:
            if approval_status == REVOKE or (approval_status == APPROVED and delete):
                if self.leave_type == ONE_TIME_LEAVE:
                    leaveyearbalance.leave_day = 0
                else:
                    leaveyearbalance.leave_day = max(leaveyearbalance.leave_day - leave_day, 0)
        leaveyearbalance.save()
    def update_leaveyearbalance(self, leave_obj, delete=False):
        # irreducible cflow, using cdg fallback
        start_day = to_datetime(leave_obj.start_time.year, self.config_startDay.month, self.config_startDay.day)
        if leave_obj.start_time < start_day < leave_obj.end_time:
                leave_day_cur = default_leave_days(leave_obj.start_time, start_day, self.employee, self.pay_code)
                leave_day_next = default_leave_days(start_day, leave_obj.end_time, self.employee, self.pay_code)
                leave_time_range = [[leave_obj.start_time, start_day], [start_day, leave_obj.end_time]]
                leave_day_cur = default_leave_days(leave_obj.start_time, leave_obj.end_time, self.employee, self.pay_code)
                leave_day_next = None
                leave_time_range = [[leave_obj.start_time, leave_obj.end_time]]
        leave_day = [leave_day_cur, leave_day_next]
        for i, range_i in enumerate(leave_time_range):
            year = range_i[0].year - self.leave_distribution_time
            year = year - 1 if range_i[0] < start_day else year
            self.update_leaveyearbalance_year(year, leave_obj.approval_status, leave_day[i], delete)
    def check_leave_day_vaild(self, leave_obj):
        # irreducible cflow, using cdg fallback
        if leave_obj.leave_day % MIN_LEAVE_DAY > 0:
            return str(_('leaveGroup.alert.invalidLeaveDay'))
        if self.allow_leave_day and self.hire_date + datetime.timedelta(days=self.allow_leave_day) > leave_obj.start_time.date():
            return str(_('leaveGroup.alert.noReachAllowLeaveDay')) % self.employee.emp_code
        if leave_obj.leave_day < self.min_leave_day:
            return str(_('leaveGroup.alert.noReachMinLeaveDay')) % self.employee.emp_code
        if self.leave_type == UNLIMITED_LEAVE:
            return
        start_day = to_datetime(leave_obj.start_time.year, self.config_startDay.month, self.config_startDay.day)
        if leave_obj.start_time < start_day < leave_obj.end_time:
                leave_day_cur = default_leave_days(leave_obj.start_time, start_day, self.employee, self.pay_code)
                leave_day_next = default_leave_days(start_day, leave_obj.end_time, self.employee, self.pay_code)
                leave_time_range = [[leave_obj.start_time, start_day], [start_day, leave_obj.end_time]]
                leave_day_cur = leave_obj.leave_day
                leave_day_next = None
                leave_time_range = [[leave_obj.start_time, leave_obj.end_time]]
        leave_day = [leave_day_cur, leave_day_next]
        pre_exceed = 0
        for i, range_i in enumerate(leave_time_range):
            self.config_type_distributed(range_i[0])
            left_leave_day = self.left_leave_day - pre_exceed
            if left_leave_day < leave_day[i]:
                if self.leave_type == ONE_TIME_LEAVE:
                    return _('leaveGroup.alert.leftBalanceCannotCover')
                else:
                    if self.leave_type == BASED_ON_SERVICE:
                        if self.allow_exceed_limit:
                            leave_range_end_date = range_i[0] + relativedelta(years=1)
                            leave_range_start_date = to_datetime(self.hire_date.year, self.config_startDay.month, self.config_startDay.day)
                            service_y = self.get_service_year(str(leave_range_end_date), str(leave_range_start_date))
                            self.get_leave_entitlement(service_y + 1)
                            if self.exceed_leave_days + leave_day[i] - self.left_leave_day <= self.leave_entitlement:
                                continue
                        return _('leaveGroup.alert.leftBalanceCannotCover')
                    else:
                        if self.leave_type == FIXED_QUOTA:
                            pre_exceed = leave_day[i] - self.left_leave_day
                            if self.allow_exceed_limit:
                                leave_range_end_date = range_i[0] + relativedelta(years=1)
                                self.config_fixed_quota(leave_range_end_date)
                                forward_left_leave_day = self.left_leave_day
                            else:
                                forward_left_leave_day = 0
                            if left_leave_day + forward_left_leave_day < leave_day[i]:
                                return _('leaveGroup.alert.leftBalanceCannotCover')
                        else:
                            if self.leave_type == COMPENSATORY_LEAVE:
                                return _('leaveGroup.alert.leftBalanceCannotCoverCompensatory')
            else:
                pre_exceed = leave_obj.leave_day - self.left_leave_day
def check_leave_balance(leave_obj):
    employee = leave_obj.employee
    pay_code = leave_obj.pay_code
    leavegroupdetail = get_leavegroupdetail_obj(employee, pay_code)
    if leavegroupdetail:
        configlg = ConfigLeaveGroup(employee, pay_code, leavegroupdetail)
        return configlg.check_leave_day_vaild(leave_obj)
def save_leaveyearbalance(leave_obj, delete=False):
    from mysite.att.models import PayCode
    employee = leave_obj.employee
    pay_code = leave_obj.pay_code
    if pay_code.is_cp():
        pay_code = PayCode.cpl()
    leavegroupdetail = get_leavegroupdetail_obj(employee, pay_code)
    if leavegroupdetail:
        configlg = ConfigLeaveGroup(employee, pay_code, leavegroupdetail)
        year = leave_obj.start_time.year
        if not configlg.set_hire_day and leave_obj.start_time < to_datetime(year, configlg.config_startDay.month, configlg.config_startDay.day):
                year -= 1
        lb_list = LeaveYearBalance.objects.filter(employee=employee, pay_code=pay_code, year__gte=year)
        if lb_list.exists():
            from mysite.att import tasks
            for lb_i in lb_list:
                tasks.restore_leaveyearbalance.delay(employee, leave_type=[configlg.leave_type], year=lb_i.year, pay_code=pay_code)
def get_leavegroupdetail_obj(employee, pay_code):
    if employee.leave_group and pay_code:
        return LeaveGroupDetail.objects.filter(leave_group_id=employee.leave_group, pay_code=pay_code).first()
    else:
        return None
def default_leave_days(start_date, end_date, employee, pay_code):
    from mysite.att.calc_new import time_range_to_work_day
    from mysite.att import const
    if not pay_code:
        return 0
    else:
        if not isinstance(pay_code, PayCode):
            if pay_code.isdigit():
                pay_code = PayCode.objects.filter(pk=int(pay_code)).first()
            else:
                return 0
        if not pay_code:
            return 0
        else:
            if not isinstance(employee, Employee):
                employee = Employee.get_emp_by_pk(int(employee))
            if type(start_date) == datetime.date:
                start_date = datetime.datetime.combine(start_date, datetime.time.min)
            if type(end_date) == datetime.date:
                end_date = datetime.datetime.combine(end_date, datetime.time.max)
            leavegroupdetail = get_leavegroupdetail_obj(employee, pay_code)
            if not leavegroupdetail:
                if pay_code.fixed_code == const.CPL:
                    leave_day = round(float((end_date - start_date).total_seconds() / 3600), 2)
                else:
                    leave_day = time_range_to_work_day(employee, start_date, end_date)
                return leave_day
            else:
                leave_day = 0
                if leavegroupdetail.leave_type == ONE_TIME_LEAVE:
                    leave_day = (end_date - start_date).days
                    leave_second = (end_date - start_date).total_seconds()
                    if leave_second > leave_day * 24 * 3600:
                        leave_day += 1
                    return leave_day
                else:
                    if leavegroupdetail.leave_type == COMPENSATORY_LEAVE:
                        leave_day = time_range_to_work_day(employee, start_date, end_date, return_hours=True, deduct_holiday_day=leavegroupdetail.deduct_holiday_day)
                    else:
                        leave_day = time_range_to_work_day(employee, start_date, end_date, deduct_holiday_day=leavegroupdetail.deduct_holiday_day)
                    min_leave_day = leavegroupdetail.min_leave_day if leavegroupdetail else 0.0
                    if min_leave_day > 0:
                        if leavegroupdetail.leave_type == COMPENSATORY_LEAVE:
                            if leave_day < min_leave_day:
                                leave_day = min_leave_day
                        else:
                            d = leave_day // min_leave_day
                            mod = leave_day % min_leave_day
                            if mod > 0:
                                d += 1
                            leave_day = d * min_leave_day
                    return leave_day
def to_datetime(year: int, month: int, day: int) -> datetime.datetime:
    try:
        return datetime.datetime(year, month, day)
    except Exception as e:
        if month == 2 and day == 29:
            return datetime.datetime(year, 2, 28)
        else:
            raise e