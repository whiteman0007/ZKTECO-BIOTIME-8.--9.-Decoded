# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\tools\\celery_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import datetime
import functools
import json
import logging
from decimal import Decimal
from celery_progress.backend import ProgressRecorder, PROGRESS_STATE
from kombu.utils.uuid import uuid
from mysite.tools.redis_utils import celery_result_redis
class VirtualTask:
    def __init__(self):
        self.id = uuid()
    def update_state(self, task_id=None, state=None, meta=None, **kwargs):
        status = ('FAILURE' if kwargs.get('error_message', None) else 'SUCCESS',)
        task_result = {'status': status, 'result': str(meta) if meta else meta, 'task_id': self.id}
        key = 'celery-task-meta-' + self.id
        celery_result_redis.set(key, json.dumps(task_result), ex=3600)
    def save_result(self, result, success=True):
        if success:
            status = 'SUCCESS'
            result = str(result) if result else result
        else:
            status = 'FAILURE'
            result = {'exc_type': '', 'exc_message': [str(result) if result else result], 'exc_module': ''}
        task_result = {'status': status, 'result': result, 'traceback': None, 'children': [], 'task_id': self.id, 'date_done': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        key = 'celery-task-meta-' + self.id
        celery_result_redis.set(key, json.dumps(task_result), ex=3600)
    def is_aborted(self, **kwargs):
        return False
class ProgressRecorderExtend(ProgressRecorder):
    def set_progress(self, current, total, description='', **kwargs):
        percent = 0
        if total > 0:
            percent = Decimal(current) / Decimal(total) * Decimal(100)
            percent = float(round(percent, 2))
        self.task.update_state(state=PROGRESS_STATE, meta={'current': current, 'total': total, 'percent': percent, 'description': description, 'error_message': kwargs.get('error_message', '')}, **kwargs)
    def stop_task(self, current, total, exc):
        self.task.update_state(state='FAILURE', meta={'current': current, 'total': total, 'percent': 100.0, 'exc_message': str(exc), 'exc_type': str(type(exc))})
def progress_recorder_adder(method):
    """\n    用于给进度条celery task添加一个progress_recorder参数，用于记录进度\n    添加功能：将异步任务改成同步任务运行，将.delay()删除后依然可以正常运行，方便调试\n    add \"progress_recorder\" parameter to progress celery task, which is used to record progress\n    Feature: change asynchronous task to synchronous task, delete \'.delay()\'\' can still run normally, easy to debug\n    """
    @functools.wraps(method)
    def wapper(*args, **kw):
        task = args[0]
        vt_flag = False
        exception_flag = False
        if not task.request.id:
            vt_flag = True
            task = VirtualTask()
        progress_recorder = ProgressRecorderExtend(task)
        kw['progress_recorder'] = progress_recorder
        result = None
        try:
            result = method(*args, **kw)
        except Exception as e:
            exception_flag = True
            if vt_flag:
                logging.getLogger('task').exception('progress_recorder_adder error')
                task.save_result(str(e), success=False)
                task._is_aborted = True
            else:
                raise e
        if vt_flag:
            if exception_flag is False:
                task.save_result(result)
            result = task
        return result
    return wapper