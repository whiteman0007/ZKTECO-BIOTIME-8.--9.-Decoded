# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\dept_summary_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import DepartmentSummaryViewSet
from mysite.att.api.report_views.department_summary import DepartmentSummarySerializer
@report_register()
class DeptSummaryAdmin(ReportAdminBase):
    model_name = 'departmentSummaryReport'
    view_name = 'dept_summary_report'
    template = 'att/report_new/departmentsummaryreport.html'
    api_view = DepartmentSummaryViewSet
    serializer = DepartmentSummarySerializer
    data_source = '/att/api/departmentSummaryReport/'
    required_dept_wise = True
    list_display = ('company_code', 'company_name', 'dept_code', 'dept_name', 'total_emp', 'total_late_times', 'total_early_leave_times', 'total_absent_times')
    hidden_fields = ('company_code', 'dept_code')
    sort_fields = 'dept_name'
    add_paycode_column = True