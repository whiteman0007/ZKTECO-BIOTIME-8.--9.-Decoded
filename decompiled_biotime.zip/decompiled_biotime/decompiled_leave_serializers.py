# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\leave_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.personnel.api.serializers import EmployeeWithPhotoSerializer
from mysite.att.models.model_leave import Leave
from mysite.att.api.serializers import util_serializers
from django.utils.translation import gettext_lazy as _
import datetime
from mysite.workflow.api.serializers import AdministratorSerializer
class LeaveSerializer(serializers.ModelSerializer):
    pay_code_name = serializers.CharField(source='pay_code.name', allow_null=True)
    approval_status_display = serializers.CharField(source='get_approval_status_display', allow_null=True)
    attachment = serializers.SerializerMethodField()
    def get_attachment(self, obj):
        if obj.attachment:
            return '/files/' + str(obj.attachment)
        else:
            return ''
    class Meta:
        model = Leave
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'department', 'position', 'workflow_engine', 'workflow_name', 'start_time', 'end_time', 'apply_reason', 'apply_time', 'pay_code', 'pay_code_name', 'attachment', 'approval_status', 'approval_status_display', 'approval_remark', 'approval_time', 'last_approver', 'approver']
class LeaveCreateSerializer(serializers.ModelSerializer):
    def validate(self, attrs):
        from mysite.att.config_leave_group import default_leave_days
        user = self.context['request'].user
        if self.context['request'].POST.get('auto_approved', None):
            if not user.is_superuser:
                for group in user.groups.all():
                    if group.permissions.all().filter(codename='approve_leave'):
                        attrs['approval_status'] = 2
                        attrs['approval_time'] = datetime.datetime.now()
                        attrs['approver_instance'] = AdministratorSerializer(instance=user).data
                        attrs['approver'] = user.first_name or user.username
                        break
            else:
                attrs['approval_status'] = 2
                attrs['approval_time'] = datetime.datetime.now()
                attrs['approver_instance'] = AdministratorSerializer(instance=user).data
                attrs['approver'] = user.first_name or user.username
        attrs['leave_day'] = default_leave_days(attrs['start_time'], attrs['end_time'], attrs['employee'], attrs['pay_code'])
        return attrs
    class Meta:
        model = Leave
        fields = ['employee', 'pay_code', 'start_time', 'end_time', 'apply_reason', 'apply_time', 'attachment', 'leave_day']
class LeaveEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = Leave
        fields = ['pay_code', 'start_time', 'end_time', 'apply_reason', 'apply_time', 'attachment']
class LeaveActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = Leave
        action_type_choices = (('delete', 'delete'),)
class LeaveForEmailSerializer(serializers.ModelSerializer):
    pay_code = serializers.CharField(source='pay_code.name', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = Leave
        exclude = ('employee', 'approver_instance')
class LeaveForNotificationSerializer(serializers.ModelSerializer):
    employee = EmployeeWithPhotoSerializer()
    pay_code = serializers.CharField(source='pay_code.name', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = Leave
        fields = ('id', 'employee', 'pay_code', 'start_time', 'end_time', 'apply_reason', 'apply_time', 'approval_status', 'approver', 'approval_time', 'approval_remark')