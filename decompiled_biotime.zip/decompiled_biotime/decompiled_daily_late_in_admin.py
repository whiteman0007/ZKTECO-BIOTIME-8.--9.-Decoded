# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\daily_late_in_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att import const
from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import DailyLateInViewSet
from mysite.att.api.report_views.daily_late_in import DailyLateInSerializer
@report_register()
class DailyLateInAdmin(ReportAdminBase):
    model_name = 'dailyLateInReport'
    view_name = 'daily_late_in'
    template = 'att/report_new/daily_late_in.html'
    api_view = DailyLateInViewSet
    serializer = DailyLateInSerializer
    data_source = '/att/api/dailyLateInReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday', 'time_table_alias', 'check_in', 'check_out', 'clock_in', 'clock_out', 'total_hrs')
    hidden_fields = ('company_code', 'last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = ('emp_code', 'att_date')
    add_paycode_column = True
    fixed_code = (const.LATE_IN,)