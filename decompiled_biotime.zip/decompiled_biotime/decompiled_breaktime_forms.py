# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\forms\\breaktime_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
from django.forms import ModelForm, ValidationError, ModelChoiceField
from mysite.att.models import BreakTime
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att.models.model_paycode import PayCode, NORMAL, OVERTIME, EXCEPTION
from mysite.att.fields import PayCodeModelChoiceField
from mysite.att.company_form import CompanyField4ModelForm
from mysite.utils import get_dt4mssql
class BreakTimeForm(CompanyField4ModelForm):
    duration = forms.IntegerField(label=_('breakTime_field_duration'), initial=60, unit=_('time.units.minute'))
    available_interval = forms.IntegerField(label=_('breakTime_field_duplicatePunchPeriod'), initial=1, unit=_('time.units.minute'))
    minimum_duration = forms.IntegerField(label=_('breakTime_field_minimumBreakTime'), min_value=0, initial=0, unit=_('time.units.minute'))
    profit_code = PayCodeModelChoiceField(label=_('breakTime.fields.payCode'), required=False)
    min_early_in = forms.IntegerField(label=_('breakTime.fields.minEarlyIn'), initial=0, min_value=0, unit=_('time.units.minute'))
    loss_code = ModelChoiceField(label=_('breakTime.fields.payCode'), queryset=PayCode.objects.filter(code_type=EXCEPTION).order_by('display_order'), required=False)
    min_late_in = forms.IntegerField(label=_('breakTime.fields.minLateIn'), initial=0, min_value=0, unit=_('time.units.minute'))
    period_end = forms.TimeField(label=_('breakTime_field_endTime'), initial=datetime.time(13, 0, 0))
    def __init__(self, *args, **kwargs):
        super(BreakTimeForm, self).__init__(*args, **kwargs)
        if self.instance:
            cur = datetime.datetime(2019, 1, 1).date()
            period_start = datetime.datetime.combine(cur, get_dt4mssql(self.instance.period_start, 2))
            period_end = period_start + datetime.timedelta(minutes=self.instance.end_margin)
            self.fields['period_end'].initial = period_end.strftime('%H:%M:%S')
    def clean_end_margin(self):
        period_start = self.cleaned_data.get('period_start', None)
        period_end = self.cleaned_data.pop('period_end', None)
        if period_start and period_end:
            _period_start = datetime.datetime.combine(datetime.datetime(2019, 1, 1).date(), period_start)
            _period_end = datetime.datetime.combine(datetime.datetime(2019, 1, 1).date(), period_end)
            if _period_end < _period_start:
                _period_end += datetime.timedelta(days=1)
            margin = (_period_end - _period_start).total_seconds() / 60
            return margin
        else:
            return 0
    def clean(self):
        cleaned_data = super(BreakTimeForm, self).clean()
        cleaned_data['id'] = self.instance.id
        if self.changed_data:
            data_pre_check(cleaned_data)
        return cleaned_data
    class Meta:
        model = BreakTime
        fields = ('period_start', 'period_end', 'duration', 'end_margin', 'func_key', 'available_interval_type', 'available_interval', 'calc_type', 'min_early_in', 'min_late_in', 'minimum_duration', 'multiple_punch', 'alias', 'id', 'profit_rule', 'profit_code', 'loss_rule', 'loss_code')
def data_pre_check(cleaned_data):
    bk_id = cleaned_data.get('id', None)
    if bk_id:
        obj = BreakTime.objects.filter(pk=bk_id).first()
        if obj:
            using = obj.timeinterval_set.count()
            if using:
                raise ValidationError(_('breakTime_validationError_breakTimeUsing'))
    duration = cleaned_data.get('duration', 0)
    period_duration = cleaned_data.get('end_margin', 0)
    min_early_in = cleaned_data.get('min_early_in', 0)
    min_late_in = cleaned_data.get('min_late_in', 0)
    available_interval = cleaned_data.get('available_interval', 0)
    minimum_duration = cleaned_data.get('minimum_duration', 0)
    if duration < 0 or period_duration < 0 or min_early_in < 0 or (min_late_in < 0) or (available_interval < 0) or (minimum_duration < 0):
        raise ValidationError(_('breakTime_validationError_invalidNumber'), code='-1')
    else:
        if duration > period_duration:
            raise ValidationError(_('breakTime_validationError_durationGreatThanPeriod'), code='-1')
        else:
            if min_early_in > duration:
                raise ValidationError(_('breakTime_validationError_earlyGreatThanDuration'), code='-1')
            else:
                if min_late_in > duration:
                    raise ValidationError(_('breakTime_validationError_overGreatThanRangeDuration'), code='-1')
                else:
                    if minimum_duration > duration:
                        raise ValidationError(_('breakTime.validationError.minimumDurationGreatThanDuration'), code='-1')