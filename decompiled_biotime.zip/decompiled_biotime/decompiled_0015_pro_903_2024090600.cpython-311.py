# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0015_pro_903_2024090600.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('base', '0015_auto_20241212_20114')]
    operations = [migrations.CreateModel(name='ReportOutputSetting', fields=[('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('agreement_message_id', models.CharField(max_length=200, verbose_name='reportOutputSetting_agreementMessageId')), ('report_name', models.CharField(choices=[('transaction_report', 'menu_att_transactionReport'), ('time_card_report', 'menu_att_timeCardReport'), ('first_last_report', 'menu_att_firstLastReport'), ('first_in_last_out_report', 'menu_att_firstInLastOutReport'), ('total_time_card_report', 'att.menus.reports.totalTimeCard'), ('daily_activity_report', 'att.menus.reports.dailyWorkedHours'), ('daily_overtime_report', 'att.menus.reports.dailyOvertime'), ('daily_leave_report', 'att.menus.reports.dailyLeave'), ('daily_late_in_report', 'att.menus.reports.dailyLateIn'), ('daily_early_out_report', 'att.menus.reports.dailyEarlyOut'), ('daily_absent_report', 'att.menus.reports.dailyAbsence'), ('daily_exception_report', 'att.menus.reports.dailyException'), ('scheduled_punch_report', 'att.menus.reports.scheduledLog'), ('punch_paring_report', 'att.menus.reports.pairedPunch'), (