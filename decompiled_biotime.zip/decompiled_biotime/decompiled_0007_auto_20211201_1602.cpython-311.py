# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0007_auto_20211201_1602.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from __future__ import unicode_literals
from django.db import migrations
import django.db.models.deletion
import mysite.personnel.fields
class Migration(migrations.Migration):
    dependencies = [('personnel', '0006_auto_20211201_1516')]
    operations = [migrations.AddField(model_name='area', name='company', field=mysite.personnel.fields.CompanyForeignKey(default=1, on_delete=django.db.models.deletion.CASCADE, to='personnel.Company', verbose_name='area.field.company')), migrations.AddField(model_name='department', name='company', field=mysite.personnel.fields.CompanyForeignKey(default=1, on_delete=django.db.models.deletion.CASCADE, to='personnel.Company', verbose_name='department.field.company')), migrations.AlterUniqueTogether(model_name='area', name=set([('company', 'area_code')])), migrations.AlterUniqueTogether(model_name='department', name=set([('company', 'emp_code')])), migrations.AlterUniqueTogether(model_name='position', name=set([('company', 'position_code')]))]