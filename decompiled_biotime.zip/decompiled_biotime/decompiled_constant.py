# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\constant.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

__author__ = 'Arvin'
LENGTH_E_PIN = 20
LENGTH_E_FIRST_NAME = 24
LENGTH_E_LAST_NAME = 20
LENGTH_E_ARABIC_NAME = 100
LENGTH_NICKNAME = 100
LENGTH_D_CODE = 20
LENGTH_D_NAME = 50
LENGTH_P_CODE = 20
LENGTH_P_NAME = 50
LENGTH_A_CODE = 20
LENGTH_A_NAME = 30
LENGTH_CARD_NO = 20