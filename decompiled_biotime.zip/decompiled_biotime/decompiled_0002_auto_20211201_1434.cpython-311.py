# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\workflow\\migrations\\0002_auto_20211201_1434.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:30 UTC (1750702770)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('workflow', '0001_initial')]
    operations = [migrations.AlterField(model_name='workflowinstance', name='workflow_engine', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='workflow.WorkflowEngine', verbose_name='workflowInstance.fields.engine'))]