# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\company_stamp_setting.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import os
import json
import base64
import re
from django.conf import settings
from rest_framework import serializers
from mysite.tools.image_utils import base64_to_image, crop_image, image_to_base64
class CompanyStampSettingUpdateSerializer(serializers.Serializer):
    description = serializers.CharField(required=False, allow_blank=True, default='')
    stamp_pos = serializers.CharField(required=False, allow_blank=True, default='0')
    stamp_img = serializers.CharField(required=False, allow_blank=True, default='')
    stamp_crop_info = serializers.CharField(required=False, allow_blank=True, default='')
    def validate(self, data):
        stamp_img = data.get('stamp_img')
        prefix_search = re.search('^data:image/.+;base64,', stamp_img)
        prefix = ''
        img_format = 'png'
        if prefix_search:
            prefix = prefix_search.group()
            img_format = prefix.split('/')[(-1)].split(';')[0]
        stamp_crop_info = data.get('stamp_crop_info')
        if stamp_crop_info:
            crop_info = json.loads(stamp_crop_info)
            stamp_img = base64_to_image(stamp_img)
            stamp_img = crop_image(stamp_img, crop_info)
            stamp_img = stamp_img.resize((400, 150))
            stamp_img = image_to_base64(stamp_img, img_format)
            stamp_img = prefix + stamp_img
            data['stamp_img'] = stamp_img
            data['stamp_crop_info'] = ''
        if stamp_img:
            if not os.path.exists(settings.COMPANY_STAMP_STORE_PATH):
                os.mkdir(settings.COMPANY_STAMP_STORE_PATH)
            img_info, img_code = stamp_img.split(',')
            f_name = os.path.join(settings.COMPANY_STAMP_STORE_PATH, 'stamp.{0}'.format(img_format))
            with open(f_name, 'wb') as f:
                f.write(base64.b64decode(img_code))
        return data