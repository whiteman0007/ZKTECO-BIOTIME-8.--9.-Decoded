# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\dashboard_absent_list.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import datetime
from django.utils.translation import gettext_lazy as _
from django.db.models import Count, Max
from rest_framework import mixins, serializers
from mysite.att.api.serializers import NoneSerializer
from mysite.base.api.filters import EmployeeFilter
from mysite.base.api.utils_class import UserLayUIGenericViewSet
from mysite.personnel.models import Employee
class DailyAbsentSerializer(serializers.ModelSerializer):
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='department__dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='department__dept_name', allow_null=True)
    position_code = serializers.CharField(label=_('report_column_positionCode'), source='position__position_code', allow_null=True)
    position_name = serializers.CharField(label=_('report_column_positionName'), source='position__position_name', allow_null=True)
    last_punch = serializers.CharField(label=_('report_column_positionName'), source='last', allow_null=True)
    class Meta:
        model = Employee
        fields = ('emp_code', 'first_name', 'last_name', 'nickname', 'dept_code', 'dept_name', 'position_code', 'position_name', 'last_punch')
class DailyAbsentViewSet(mixins.ListModelMixin, UserLayUIGenericViewSet):
    model = Employee
    queryset = Employee.objects.select_related().order_by('emp_code')
    filterset_class = EmployeeFilter
    serializer_dict = {'list': DailyAbsentSerializer}
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)
    def get_queryset(self):
        from django.db.models import Q
        from django.contrib.auth import get_user_model
        queryset = super(DailyAbsentViewSet, self).get_queryset()
        now = datetime.datetime.now()
        tmw = now + datetime.timedelta(days=1)
        if isinstance(self.request.user, get_user_model()):
            if not self.request.user.is_superuser:
                filters = {}
                distinct = False
                if self.request.user.auth_dept.exists():
                    filters['department__in'] = self.request.user.auth_dept.all()
                if self.request.user.auth_area.exists():
                    distinct = True
                    filters['area__in'] = self.request.user.auth_area.all()
                if self.request.user.assign_company:
                    filters['company'] = self.request.user.assign_company
                if filters:
                    queryset = queryset.filter(**filters)
                if distinct:
                    queryset = queryset.distinct()
        else:
            queryset = queryset.filter(emp_code=self.request.user.emp_code)
        queryset = queryset.values('emp_code', 'first_name', 'last_name', 'nickname', 'department__dept_code', 'department__dept_name', 'position__position_code', 'position__position_name')
        queryset = queryset.annotate(last=Max('transaction__punch_time'))
        queryset = queryset.filter(Q(last__lt=now.date()) | Q(last__gt=tmw.date()) | Q(last__isnull=True))
        return queryset