# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\meeting\\actions\\meetingmanuallog_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:04 UTC (1750673044)

from django.forms import ModelMultipleChoiceField, ModelChoiceField
from django.forms.widgets import HiddenInput
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.admin.action import ZKModelAction
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.meeting.models import MeetingEntity
from mysite.meeting.models import MeetingManualLog
from mysite.meeting.widgets import MeetingRadioSelect
from mysite.personnel.models import Employee
from mysite.personnel.widgets import EmployeeManyToManyMiddleWidget
class AddMeetingManualLogForm(forms.ZKActionForm):
    employee = ModelMultipleChoiceField(label=_('model_employee'), required=False, queryset=Employee.objects.get_queryset(), widget=EmployeeManyToManyMiddleWidget())
    meeting = ModelChoiceField(queryset=MeetingEntity.objects.get_queryset(), label=_('meetingManualLog.fields.meeting'), widget=MeetingRadioSelect, required=True)
    punch_time = forms.DateTimeField(label=_('meetingManualLog.fields.punchTime'))
    punch_state = forms.ChoiceField(label=_('meetingManualLog.fields.punchState'), choices=((0, 'Check In'), (1, 'Check Out')))
    apply_reason = forms.TextField(label=_('meetingManualLog.fields.applyReason'), required=False)
    auto_approve = forms.BooleanField(label=_('common.fields.autoApproved'), initial=True, required=False)
    def __init__(self, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        self.permission = APPROVAL_APPROVE_PERMISSION.get('meetingmanuallog')
        super(AddMeetingManualLogForm, self).__init__(*args, **kwargs)
        if not self.request or not self.request.user.has_perm(self.permission):
                self.fields['auto_approve'].widget = HiddenInput()
                self.fields['auto_approve'].initial = False
class AddMeetingManualLog(ZKModelAction):
    verbose_name = _('meetingManualLog.actions.add')
    short_description = _('meetingManualLog.actions.add.description')
    help_txt = _('meetingManualLog.actions.add.helpTxt')
    action_form = AddMeetingManualLogForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        if data.get('employee', None):
            for emp in data['employee']:
                obj = MeetingManualLog(employee=emp, punch_time=data['punch_time'], punch_state=data['punch_state'], apply_reason=data['apply_reason'], meeting=data['meeting'])
                obj.save(force_insert=True)
                user = self.request.user
                if data.get('auto_approve', None) and user.has_perm(self.valid_form.permission):
                        obj.do_approve(user, _('common.fields.autoApproved'))
        else:
            raise AdminRuntimeWarning(_('meetingManualLog.errors.add.employeeNoSelected'))