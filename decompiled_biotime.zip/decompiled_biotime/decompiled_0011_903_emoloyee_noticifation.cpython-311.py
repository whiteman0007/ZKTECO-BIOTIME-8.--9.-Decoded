# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0011_903_emoloyee_noticifation.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:14 UTC (1750702694)

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('personnel', '0013_alter_area_area_name_alter_certification_cert_name_and_more'), ('accounts', '0010_901_notification_category')]
    operations = [migrations.AddField(model_name='usernotification', name='employee', field=models.ForeignKey(null=True, on_delete=django.db.models.deletion.CASCADE, to='personnel.employee', verbose_name='Employee')), migrations.AlterField(model_name='usernotification', name='user', field=models.ForeignKey(null=True, on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL, verbose_name='userNotification.fields.user'))]