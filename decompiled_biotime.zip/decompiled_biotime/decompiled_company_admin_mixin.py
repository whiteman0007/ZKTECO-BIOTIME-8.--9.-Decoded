# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\company_admin_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

import copy
from django.conf import settings
from mysite._utils import getattr_ex
class CompanyAdminMixin(object):
    list_display_fixed = ['id', 'company_code', 'company_name']
    hidden_fields_fixed = []
    def get_extend_fields(self):
        if getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
            return ['country', 'city', 'fax', 'state', 'email', 'phone', 'website', 'postal_code', 'address', 'address2']
        else:
            return []
    def get_extend_hidden_fields(self):
        if getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
            return ['website', 'address2']
        else:
            return []
    def get_ext_list_display(self):
        list_display = copy.deepcopy(self.list_display_fixed)
        ext_fields = self.get_extend_fields()
        for field_name in ext_fields:
            list_display.append(field_name)
        list_display.extend(['employee_count', 'resigned_count', 'department_count', 'position_count', 'area_count'])
        return list_display
    def get_ext_hidden_fields(self):
        hidden_fields = copy.deepcopy(self.hidden_fields_fixed)
        ex_fields = self.get_extend_hidden_fields()
        for field_name in ex_fields:
            hidden_fields.append(field_name)
        return hidden_fields