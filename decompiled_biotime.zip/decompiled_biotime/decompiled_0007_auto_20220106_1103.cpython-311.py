# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0007_auto_20220106_1103.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:12 UTC (1750702692)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('accounts', '0006_myuser_assign_company')]
    operations = [migrations.AlterField(model_name='usernotification', name='event', field=models.IntegerField(blank=True, choices=[(101, 'userNotification.events.deviceOffline'), (102, 'userNotification.events.deviceOnline'), (6, 'userNotification.events.lateIn'), (7, 'userNotification.events.earlyOut'), (8, 'userNotification.events.absence'), (1, 'userNotification.events.attManualLog'), (2, 'userNotification.events.attLeave'), (3, 'userNotification.events.attOvertime'), (4, 'userNotification.events.attTraining'), (5, 'userNotification.events.schedule'), (10, 'userNotification.events.meeting'), (11, 'userNotification.events.mtgManualLog'), (9, 'userNotification.events.visitorReservation')], null=True, verbose_name='userNotification.fields.event'))]