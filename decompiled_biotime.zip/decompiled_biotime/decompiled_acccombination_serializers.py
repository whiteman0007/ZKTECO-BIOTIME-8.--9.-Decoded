# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\acc\\api\\serializers\\acccombination_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from rest_framework import serializers
from mysite.acc.models.model_acc_combination import AccCombination
from mysite.att.api.serializers import util_serializers
class AccCombinationSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccCombination
        fields = ['id', 'combination_no', 'combination_name', 'group1', 'group2', 'group3', 'group4', 'group5']
class AccCombinationCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccCombination
        fields = '__all__'
class AccCombinationEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccCombination
        fields = '__all__'
class AccCombinationActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AccCombination
        action_type_choices = (('delete', 'delete'),)