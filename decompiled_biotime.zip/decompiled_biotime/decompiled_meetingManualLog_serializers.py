# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\staff_meeting\\api\\serializers\\meetingManualLog_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:34 UTC (1750673074)

from rest_framework import serializers
from mysite.meeting.models import MeetingManualLog
from mysite.personnel.models import Employee
from django.utils.translation import gettext_lazy as _
class MeetingManualLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = MeetingManualLog
        fields = '__all__'
class MeetingManualLogRequestSerializer(serializers.ModelSerializer):
    approval_status_display = serializers.CharField(source='get_approval_status_display', allow_null=True)
    punch_state_display = serializers.CharField(source='get_punch_state_display', allow_null=True)
    meeting_alias = serializers.CharField(source='meeting.alias', allow_null=True)
    class Meta:
        model = MeetingManualLog
        fields = ('id', 'employee', 'emp_code', 'first_name', 'last_name', 'punch_time', 'punch_state', 'apply_reason', 'apply_time', 'approval_status_display', 'punch_state_display', 'meeting_alias', 'approver', 'emp_photo', 'approval_status')
class MeetingManualLogCreateSerializer(serializers.ModelSerializer):
    def validate(self, attrs):
        user = self.context['request'].user
        if not isinstance(user, Employee):
            raise serializers.ValidationError({'detail': 'User not a Employee'})
        else:
            if not attrs['meeting']:
                raise serializers.ValidationError({'detail': _('meetingEntity.save.error.missRoom')})
            else:
                attrs['employee'] = user
                return attrs
    class Meta:
        model = MeetingManualLog
        fields = ('punch_time', 'punch_state', 'meeting')
class MeetingManualLogRetrieveSerializer(serializers.ModelSerializer):
    approval_status_display = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = MeetingManualLog
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'department', 'position', 'workflow_engine', 'workflow_name', 'punch_time', 'punch_state', 'apply_reason', 'apply_time', 'approval_status', 'approval_status_display', 'approval_remark', 'approval_time', 'last_approver')
class MeetingManualLogApproveSerializer(MeetingManualLogRequestSerializer):
    approval_permission = serializers.SerializerMethodField()
    punch_state_display = serializers.CharField(source='get_punch_state_display', allow_null=True)
    meeting_alias = serializers.CharField(source='meeting.alias')
    def get_approval_permission(self, obj):
        if obj.approval_status!= 1:
            return False
        else:
            pending_node = obj.get_first_pending_node()
            if pending_node is None:
                return False
            else:
                perm = pending_node.has_approval_permission(self.context['request'].user)
                return True if perm else False
    class Meta:
        model = MeetingManualLog
        fields = ('id', 'employee', 'emp_code', 'first_name', 'last_name', 'punch_time', 'punch_state', 'apply_reason', 'apply_time', 'meeting_alias', 'emp_photo', 'approval_status', 'approval_status_display', 'approver', 'approval_permission', 'punch_state_display')