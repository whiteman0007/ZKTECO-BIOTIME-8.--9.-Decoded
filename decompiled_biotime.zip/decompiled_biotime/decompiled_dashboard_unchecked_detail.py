# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\ep\\api\\serializers\\dashboard_unchecked_detail.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

from rest_framework import serializers
from mysite.personnel.models import Employee
class UncheckSerializer(serializers.ModelSerializer):
    dept_name = serializers.CharField(source='department.dept_name', allow_null=True)
    position_name = serializers.CharField(source='position.position_name', allow_null=True)
    class Meta:
        model = Employee
        fields = ('emp_code', 'first_name', 'last_name', 'dept_name', 'position_name')