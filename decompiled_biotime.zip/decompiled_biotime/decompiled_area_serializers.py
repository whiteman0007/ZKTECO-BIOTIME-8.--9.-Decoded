# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\api\\serializers\\area_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

from rest_framework import serializers
from mysite.personnel.models.model_area import Area
from mysite.personnel.models.model_company import Company
from mysite.personnel.utils import get_default_company
class ParentAreaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area']
class AreaSerializer(serializers.ModelSerializer):
    parent_area = ParentAreaSerializer()
    parent_area_name = serializers.SerializerMethodField()
    def get_parent_area_name(self, obj):
        if obj.parent_area:
            return obj.parent_area.area_name
        else:
            return None
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area', 'parent_area_name']
class AreaListDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area', 'device_count', 'employee_count', 'finger_count', 'face', 'palm', 'vl_face']
class AreaExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area']
class AreaCreateSerializer(serializers.ModelSerializer):
    company = serializers.CharField(default=get_default_company(), write_only=True)
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area', 'company']
class AreaEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area']
        extra_kwargs = {'area_code': {'required': False, 'allow_null': False}, 'area_name': {'required': False, 'allow_null': False}}
class AreaDataSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()
    pId = serializers.SerializerMethodField()
    def get_name(self, obj):
        return '{code} {name}'.format(code=obj.area_code, name=obj.area_name or '')
    def get_pId(self, obj):
        return getattr(obj, 'parent_area_id', 0)
    class Meta:
        model = Area
        fields = ('id', 'name', 'pId')
class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'company_code', 'company_name']
class WDMSAreaSerializer(AreaSerializer):
    company = CompanySerializer()
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area', 'company']
class WDMSAreaCreateSerializer(AreaCreateSerializer):
    company = serializers.CharField()
    def validate_company(self, company):
        if isinstance(company, str):
            return Company.objects.filter(id=company).first()
        else:
            return company
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area', 'company']
class WDMSAreaEditSerializer(AreaEditSerializer):
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name', 'parent_area', 'company']
        extra_kwargs = {'area_code': {'required': False, 'read_only': True}, 'area_name': {'required': False, 'allow_null': False}, 'company': {'required': False, 'read_only': True}}