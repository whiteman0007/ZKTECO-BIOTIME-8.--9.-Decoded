# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\changeschedule_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.models.model_changeschedule import ChangeSchedule
from mysite.personnel.api.serializers import EmployeeWithPhotoSerializer
class ChangeScheduleSerializer(serializers.ModelSerializer):
    approval_status_display = serializers.CharField(label=_('common_field_approvalStatus'), source='get_approval_status_display', allow_null=True)
    attachment = serializers.SerializerMethodField(label=_('common_field_attachment'))
    def get_attachment(self, obj):
        if obj.attachment:
            return '/files/' + str(obj.attachment)
        else:
            return ''
    class Meta:
        model = ChangeSchedule
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'department', 'position', 'workflow_engine', 'workflow_name', 'attachment', 'previous_timeinterval', 'timeinterval', 'approval_status', 'approval_status_display', 'approval_remark', 'approval_time', 'last_approver']
class ChangeScheduleForEmailSerializer(serializers.ModelSerializer):
    timeinterval = serializers.CharField(source='timeinterval.alias', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = ChangeSchedule
        exclude = ('employee', 'approver_instance')
class ChangeScheduleForNotificationSerializer(serializers.ModelSerializer):
    employee = EmployeeWithPhotoSerializer()
    timetable = serializers.CharField(source='timeinterval.alias', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = ChangeSchedule
        fields = ('id', 'employee', 'att_date', 'previous_timeinterval', 'timetable', 'apply_reason', 'apply_time', 'approval_status', 'approver', 'approval_time', 'approval_remark')