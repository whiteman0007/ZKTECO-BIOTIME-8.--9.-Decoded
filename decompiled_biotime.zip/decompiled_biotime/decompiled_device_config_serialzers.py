# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\iclock\\api\\serializers\\device_config_serialzers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:35 UTC (1750673015)

from rest_framework import serializers
from mysite.iclock.models import DeviceModuleConfig
class DeviceConfigSerializer(serializers.ModelSerializer):
    enable_registration = serializers.IntegerField()
    enable_name_upload = serializers.IntegerField()
    enable_card_upload = serializers.IntegerField()
    enable_name_download = serializers.IntegerField()
    encryption = serializers.IntegerField()
    global_setup = serializers.IntegerField()
    class Meta:
        model = DeviceModuleConfig
        fields = ('id', 'enable_registration', 'enable_resigned_filter', 'enable_auto_add', 'enable_name_upload', 'enable_name_download', 'encryption', 'enable_card_upload', 'transaction_retention', 'command_retention', 'timezone', 'global_setup', 'heartbeat', 'transfer_mode', 'transfer_interval', 'transfer_time', 'dev_log_retention', 'upload_log_retention', 'edit_policy', 'import_policy', 'mobile_policy', 'device_policy', 'sync_mode', 'sync_time', 'visitor_policy', 'api_policy')
class DeviceConfigUpdateSerializer(serializers.ModelSerializer):
    enable_auto_add = serializers.IntegerField(required=False, allow_null=True, default=1)
    enable_resigned_filter = serializers.IntegerField(required=False, allow_null=True, default=0)
    enable_registration = serializers.IntegerField(required=False, allow_null=True, default=0)
    enable_name_upload = serializers.IntegerField(required=False, allow_null=True, default=1)
    enable_card_upload = serializers.IntegerField(required=False, allow_null=True, default=1)
    enable_name_download = serializers.IntegerField(required=False, allow_null=True, default=1)
    encryption = serializers.IntegerField(required=False, allow_null=True, default=0)
    global_setup = serializers.IntegerField(required=False, allow_null=True, default=0)
    class Meta:
        model = DeviceModuleConfig
        fields = ('id', 'enable_registration', 'enable_resigned_filter', 'enable_auto_add', 'enable_name_upload', 'enable_name_download', 'encryption', 'enable_card_upload', 'transaction_retention', 'command_retention', 'timezone', 'global_setup', 'heartbeat', 'transfer_mode', 'transfer_interval', 'transfer_time', 'dev_log_retention', 'upload_log_retention', 'edit_policy', 'import_policy', 'mobile_policy', 'device_policy', 'api_policy', 'sync_mode', 'sync_time', 'visitor_policy')