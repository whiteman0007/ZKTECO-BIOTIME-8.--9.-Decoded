# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0017_pro_903_2024090600.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0016_903_calculate_workcode')]
    operations = [migrations.AlterField(model_name='paycode', name='code_type', field=models.SmallIntegerField(choices=[(1, 'payCode.codeType.normal'), (2, 'payCode.codeType.overtime'), (3, 'payCode.codeType.leave'), (4, 'payCode.codeType.exception'), (5, 'payCode.codeType.training')], default=1, verbose_name='payCode.fields.codeType'))]