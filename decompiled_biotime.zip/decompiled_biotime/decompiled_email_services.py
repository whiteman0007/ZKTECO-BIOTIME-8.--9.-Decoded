# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\admin\\services\\email\\email_services.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:53 UTC (1750672973)

import os
import json
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.header import Header
from email.utils import formataddr
import six
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.base.models import SystemSetting
def _check_email_address(address_dict):
    for addr_type, addresses in six.iteritems(address_dict):
        if isinstance(addresses, six.string_types):
            raise TypeError('`email address` argument must be a list or tuple')
        else:
            if addresses is None:
                continue
            else:
                try:
                    for addr in addresses:
                        if not addr:
                            continue
                        else:
                            validate_email(addr)
                except ValidationError:
                    raise ValidationError('Illegal email address', code='invalid')
def send_one_mail_with_attachments(subject, body, to, context=None, to_cc=None, to_bcc=None, subject_template_name=None, content_template_name=None, attachments=None):
    """\n    attachments: must be value file path list\n    """
    new_attachments = []
    attachments = attachments if attachments else []
    for attachment in attachments:
        with open(attachment, 'rb') as f:
            name = os.path.split(attachment)[1]
            mime = MIMEBase('text', 'txt', filename=attachment)
            mime.add_header('Content-Disposition', 'attachment', filename=name)
            mime.set_payload(f.read())
            encoders.encode_base64(mime)
            new_attachments.append(mime)
    send_one_mail(subject, body, to, context=None, to_cc=None, to_bcc=None, subject_template_name=None, content_template_name=None, attachments=new_attachments)
def send_one_mail(subject, body, to, context=None, to_cc=None, to_bcc=None, subject_template_name=None, content_template_name=None, attachments=None):
    """\n    attachments: must be email.MIMEBase.MIMEBase obj list\n    """
    from django.template import loader
    from django.core.mail import EmailMultiAlternatives
    from django.conf import settings
    es = SystemSetting.cache_data(name='email_setting')
    if es is None:
        raise AdminRuntimeWarning('Please setup email setting first.')
    else:
        es = json.loads(es.value)
        if not es.get('email_enable'):
            raise AdminRuntimeWarning('Please setup email setting first.')
        else:
            from_account = es.get('email_account')
            from_name = es.get('email_account_name') if es.get('email_account_name') else str(settings.PROJECT_NAME)
            from_email = formataddr((str(Header(from_name, 'utf-8')), from_account))
            _check_email_address({'to': to, 'to_cc': to_cc, 'to_bcc': to_bcc})
            if context is None:
                context = dict()
            if subject_template_name is not None:
                subject = loader.render_to_string(subject_template_name, context)
            subject = ''.join(subject.splitlines())
            attachments = attachments if attachments else []
            attachments = [i for i in attachments if isinstance(i, MIMEBase)]
            email_message = EmailMultiAlternatives(subject, 'body', from_email, to=to, cc=to_cc, bcc=to_bcc, attachments=attachments)
            if content_template_name is not None:
                html_content = loader.render_to_string(content_template_name, context)
            else:
                html_content = body
            email_message.attach_alternative(html_content, 'text/html')
            try:
                email_message.send()
            except smtplib.SMTPException as e:
                raise AdminRuntimeWarning({'type': type(e), 'repr': str(e)})
def send_one_mail_to_self():
    """\n    test email setting correct\n    :return:\n    """
    own_mail = SystemSetting.objects.filter(name='email_setting')
    if own_mail:
        to = [json.loads(own_mail[0].value).get('email_account')]
        subject = 'Test Email'
        body = 'Test Email Body'
        print((to, subject, body))
        send_one_mail(subject, body, to)
        return True
    else:
        print('email setting error')
        return False
def send_feedback_mail(subject, body, to, email_account, context=None, to_cc=None, to_bcc=None, subject_template_name=None, content_template_name=None, attachments=None, connection=None):
    """\n    attachments: must be email.MIMEBase.MIMEBase obj list\n    """
    from mysite.admin.feedback_sender import send_email
    return send_email(subject, body, to, email_account, context=context, to_cc=to_cc, to_bcc=to_bcc, subject_template_name=subject_template_name, content_template_name=content_template_name, attachments=attachments, connection=connection)