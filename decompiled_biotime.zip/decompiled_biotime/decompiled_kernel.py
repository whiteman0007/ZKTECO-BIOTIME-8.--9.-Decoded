# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\admin\\kernel.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:53 UTC (1750672973)

import copy
import json
from collections import OrderedDict
from functools import update_wrapper
from django import get_version
from django.contrib.admin.options import ModelAdmin, csrf_protect_m
from django.contrib.admin.utils import unquote
from django.core.cache import cache
from django.core.exceptions import ImproperlyConfigured, PermissionDenied
from django.db import models, router, transaction, DatabaseError
from django.forms.formsets import all_valid
from django.http import Http404, HttpResponseForbidden, JsonResponse
from django.utils.encoding import force_str
from django.utils.translation import gettext as _
from mysite.accounts.models import MyUser
from mysite import config
from mysite.admin import fields as admin_fields
from mysite.admin import helpers as defined_helpers
from mysite.admin import widgets as admin_widgets
from mysite.admin.action import GeneralActionDelete, ActionHandleError, GeneralActionNew
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.admin.forms import widgets
from mysite.admin.mixins import ModelMixinEssential, ModelMixinAction, ModelMixinExtend, ModelMixinExport
from mysite.admin.utils import effective_user_required
from mysite.admin.utils import log_operation, export_error_dict, get_error_message
from mysite.utils import is_xss_in_dict
IS_POPUP_VAR = '_popup'
TO_FIELD_VAR = '_to_field'
FORMFIELD_FOR_DBFIELD_DEFAULTS = {models.DateTimeField: {'widget': widgets.ZKDateTimeInput}, models.DateField: {'widget': widgets.ZKDateInput}, models.TimeField: {'widget': widgets.ZKTimeInput}, models.TextField: {'widget': widgets.ZKTextArea}, models.URLField: {'widget': widgets.ZKURLInput}, models.FloatField: {'widget': widgets.ZKNumberInput}, models.IntegerField: {'widget': widgets.ZKDecimalFieldInput}, models.DecimalField: {'widget': widgets.ZKTextInput}, models.GenericIPAddressField: {'widget': widgets.ZKFileInput}, models.ImageField: {'widget': widgets.ZKFileInput}, models.BooleanField: {'widget': widgets.ZKCheckboxInput}, models.OneToOneField: {'widget': widgets.ZKTypeSelect}, admin_fields.PasswordField: {'widget': widgets.ZKPasswordInput}}
class ZKModelAdmin(ModelAdmin, ModelMixinEssential, ModelMixinAction, ModelMixinExtend, ModelMixinExport):
    actions = [GeneralActionNew, GeneralActionDelete]
    action_sets = None
    actions_disabled = []
    checkbox_name = 'id'
    sort_fields = []
    hidden_fields = config.WDMS_HIDDEN
    non_display_fields = ()
    empty_value_display = '-'
    grid_template = None
    add_form_template = None
    change_form_template = None
    detail_form_template = None
    export_fields_dict = {}
    export_mimes = {'xlsx': 'application/vnd.ms-excel', 'xls': 'application/vnd.ms-excel', 'pdf': 'application/pdf', 'csv': 'application/download', 'txt': 'text/plain'}
    m2m_url_handler = {}
    search_form = None
    @staticmethod
    def get_param(key, request, default=None):
        result = request.GET.get(key, request.POST.get(key, default))
        return result
    def __init__(self, model, admin_site):
        self._list_display = copy.copy(self.list_display)
        self.model = model
        self.show_bookmarks = True
        self.opts = model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
        default_template = ['%s/%s/edit.html' % self.info, 'includes/data_edit.html']
        detail_template = ['%s/%s/detail.html' % self.info, 'includes/data_detail.html']
        if not self.add_form_template:
            self.add_form_template = default_template
        if not self.change_form_template:
            self.change_form_template = default_template
        if not self.detail_form_template:
            self.detail_form_template = detail_template
        self.admin_site = admin_site
        overrides = copy.deepcopy(FORMFIELD_FOR_DBFIELD_DEFAULTS)
        for k, v in list(self.formfield_overrides.items()):
            overrides.setdefault(k, {}).update(v)
        self.formfield_overrides = overrides
        self._change_list = None
    def row_operation(self, obj=None):
        return ''
    row_operation.short_description = 'Operation'
    def formfield_for_dbfield(self, db_field, request, **kwargs):
        """\n        Hook for specifying the form Field instance for a given database Field\n        instance.\n\n        If kwargs are given, they\'re passed to the form Field\'s constructor.\n        """
        if db_field.choices:
            return self.formfield_for_choice_field(db_field, request, **kwargs)
        else:
            if isinstance(db_field, models.ManyToManyField) or isinstance(db_field, models.ForeignKey):
                if db_field.__class__ in self.formfield_overrides:
                    kwargs = dict(self.formfield_overrides[db_field.__class__], **kwargs)
                if isinstance(db_field, models.ForeignKey):
                    formfield = self.formfield_for_foreignkey(db_field, request, **kwargs)
                else:
                    if isinstance(db_field, models.ManyToManyField):
                        formfield = self.formfield_for_manytomany(db_field, request, **kwargs)
                    else:
                        formfield = None
                if formfield and db_field.name not in self.raw_id_fields:
                        related_modeladmin = self.admin_site._registry.get(db_field.remote_field.model)
                        wrapper_kwargs = {}
                        if related_modeladmin:
                            wrapper_kwargs.update(can_add_related=False, can_change_related=False, can_delete_related=False)
                        formfield.widget = admin_widgets.ZKRelatedFieldWidgetWrapper(formfield.widget, db_field.remote_field, self.admin_site, **wrapper_kwargs)
                return formfield
            else:
                for klass in db_field.__class__.mro():
                    if klass in self.formfield_overrides:
                        kwargs = dict(copy.deepcopy(self.formfield_overrides[klass]), **kwargs)
                        return db_field.formfield(**kwargs)
                return db_field.formfield(**kwargs)
    def company_code(self, obj):
        def code(obj):
            for attr in ['company', 'department', 'area', 'employee', 'terminal']:
                if hasattr(obj, attr):
                    if hasattr(obj.__getattribute__(attr), 'company_code'):
                        return obj.__getattribute__(attr).company_code
                    else:
                        if isinstance(obj.__getattribute__(attr), str):
                            continue
                        else:
                            return code(obj.__getattribute__(attr))
        return code(obj) if code(obj) else ''
    company_code.short_description = _('company.field.code')
    def company(self, obj):
        def name(obj):
            for attr in ['company', 'department', 'area', 'employee', 'terminal']:
                if hasattr(obj, attr):
                    if hasattr(obj.__getattribute__(attr), 'company_name'):
                        return obj.__getattribute__(attr).company_name
                    else:
                        if isinstance(obj.__getattribute__(attr), str):
                            continue
                        else:
                            return name(obj.__getattribute__(attr))
        return name(obj) if name(obj) else ''
    company.short_description = _('company.field.name')
    def formfield_for_manytomany(self, db_field, request, **kwargs):
        """\n        Get a form Field for a ManyToManyField.\n        :param db_field:\n        :param request:\n        :param kwargs:\n        :return:\n        """
        from django.forms import SelectMultiple
        from django.forms import CheckboxSelectMultiple
        from django.utils.text import format_lazy
        if not db_field.remote_field.through._meta.auto_created:
            return
        else:
            db = kwargs.get('using', None)
            dj_version = get_version()[0]
            if db is None:
                if dj_version == '1':
                    db = db_field.rel.model
                else:
                    db = db_field.remote_field.model
            if db_field.name in self.raw_id_fields:
                kwargs['widget'] = widgets.ZKManyToManyRawIdWidget(db_field.remote_field, self.admin_site, using=db)
            else:
                if db_field.name in list(self.filter_vertical) + list(self.filter_horizontal):
                    kwargs['widget'] = widgets.GeneralMultiSelect(db_field.remote_field.model._meta.model_name)
            if 'queryset' not in kwargs:
                queryset = self.get_field_queryset(db, db_field, request)
                if queryset is not None:
                    kwargs['queryset'] = queryset
            form_field = db_field.formfield(**kwargs)
            if isinstance(form_field.widget, SelectMultiple) and (not isinstance(form_field.widget, CheckboxSelectMultiple)):
                    msg = ''
                    help_text = form_field.help_text
                    form_field.help_text = format_lazy('{} {}', help_text, msg) if help_text else msg
            return form_field
    @property
    def change_list(self):
        if self._change_list is None:
            raise AdminRuntimeWarning('Changelist was not initialized yet.')
        else:
            return self._change_list
    @change_list.setter
    def change_list(self, value):
        self._change_list = value
    def get_url(self, app_label, model_name, postfix, params=None):
        info = (app_label, model_name, postfix)
        view_name = '%s_%s_%s' % info
        return self.admin_site.get_url(view_name, params)
    def get_changelist(self, request, **kwargs):
        from .views.main import ZKChangeList
        return ZKChangeList
    def get_action(self, action):
        from django.utils.text import capfirst
        from mysite.admin.mixins import ActionDetail
        klass = action
        if hasattr(klass, 'short_description'):
            description = klass.short_description
        else:
            description = capfirst(action.__name__.replace('_', ' '))
        return ActionDetail(klass, action.__name__, description)
    def get_actions(self, request):
        from mysite.admin import const
        from mysite.admin.mixins import ActionDetail
        if self.actions is None:
            return OrderedDict()
        else:
            app_label, model_name = self.info
            action_cache_key = const.ACTION_CACHE_KEY.format(app=app_label, model=model_name)
            _cached_actions = cache.get(action_cache_key, None)
            if _cached_actions is None:
                actions = []
                for klass in self.__class__.mro()[:2][::(-1)]:
                    if const.ADMIN_ACTION_FILED not in klass.__dict__:
                        continue
                    else:
                        class_actions = getattr(klass, const.ADMIN_ACTION_FILED, [])
                        if not class_actions:
                            continue
                        else:
                            actions.extend([self.get_action(action) for action in class_actions])
                for klass in self.__class__.mro()[:2][::(-1)]:
                    if const.ADMIN_ACTION_SET_FIELD not in klass.__dict__:
                        continue
                    else:
                        class_action_sets = getattr(klass, const.ADMIN_ACTION_SET_FIELD, [])
                        if not class_action_sets:
                            continue
                        else:
                            for action_set in class_action_sets:
                                actions.extend([self.get_action(action) for action in action_set[1]])
                actions = [_f for _f in actions if _f]
                _cached_actions = OrderedDict([(name, ActionDetail(klass, name, desc)) for klass, name, desc in actions])
                cache.set(const.ACTION_CACHE_KEY, _cached_actions)
            else:
                _actions = []
                for action_cls in _cached_actions:
                    if isinstance(action_cls, (tuple, list)):
                        _actions.extend([(_detail.name, _detail) for _detail in [self.get_action(x) for x in action_cls[1]]])
                    else:
                        _detail = self.get_action(action_cls)
                        _actions.append((_detail.name, _detail))
                _cached_actions = OrderedDict(_actions)
            return _cached_actions
    @staticmethod
    def get_init_sort_field():
        return
    def _get_all_perms(self, request):
        return {'add': self.has_add_permission(request), 'change': self.has_change_permission(request), 'delete': self.has_delete_permission(request), 'view': self.has_view_permission(request), 'module': self.has_module_permission(request)}
    def response_add(self, request, obj, post_url_continue='../%s/'):
        """\n        Determines the HttpResponse for the add_view stage.\n        """
        return JsonResponse({'code': 0})
    def response_change(self, request, obj):
        """\n        Determines the HttpResponse for the change_view stage.\n        """
        return JsonResponse({'code': 0})
    def edit_view(self, request, *args, **kwargs):
        _id = request.POST.get('obj_id', request.GET.get('obj_id', None))
        cache.set('edit_id', _id)
        if _id:
            return self._changeform_view(request, _id, form_url='', extra_context={'edit_action': True})
        else:
            raise Http404()
    @csrf_protect_m
    def changeform_view(self, request, object_id=None, form_url='', extra_context=None):
        with transaction.atomic(using=router.db_for_write(self.model)):
            return self._changeform_view(request, object_id, form_url, extra_context)
    def check_domain_rules(self, model_form):
        return
    def check_xss_risk_form(self, model_form):
        sanitize_fields = getattr(model_form, 'sanitize_fields', None)
        exist_xss_risk, message = is_xss_in_dict(model_form.cleaned_data, sanitize_fields)
        if exist_xss_risk:
            raise AdminRuntimeWarning(message or _('not support character \"& < >\" in form'))
    def _changeform_view(self, request, object_id, form_url, extra_context):
        to_field = request.POST.get(TO_FIELD_VAR, request.GET.get(TO_FIELD_VAR))
        action_name = request.POST.get('action_name', request.GET.get('action_name', None))
        if form_url == '':
            form_url = force_str(request.path)
        model = self.model
        opts = model._meta
        if request.method == 'POST' and '_saveasnew' in request.POST:
                object_id = None
        add = object_id is None
        if add:
            obj = None
        else:
            obj = self.get_object(request, unquote(object_id), to_field)
            if obj is None:
                return self._get_obj_does_not_exist_redirect(request, opts, object_id)
        if obj is None:
            if not self.has_add_permission(request):
                return JsonResponse({'code': (-1), 'msg': get_error_message(PermissionDenied())})
        else:
            if not self.check_permission(request, obj, extra_context):
                return JsonResponse({'code': (-1), 'msg': get_error_message(PermissionDenied())})
        form_validated = False
        ModelForm = self.get_form(request, obj)
        if request.method == 'POST':
            form = ModelForm(request.POST, request.FILES, instance=obj)
            if form.is_valid():
                form_validated = True
                try:
                    self.check_xss_risk_form(form)
                except AdminRuntimeWarning as e:
                    return JsonResponse({'code': (-1), 'msg': get_error_message(e)})
                try:
                    self.check_domain_rules(form)
                    new_object = self.save_form(request, form, change=not add)
                except AdminRuntimeWarning as e:
                    return JsonResponse({'code': (-1), 'msg': get_error_message(e)})
            else:
                form_validated = False
                new_object = form.instance
            formsets, inline_instances = self._create_formsets(request, new_object, change=not add)
            if all_valid(formsets) and form_validated:
                try:
                    self.save_model(request, new_object, form, not add)
                except (AdminRuntimeWarning, DatabaseError) as e:
                    return JsonResponse({'code': (-1), 'msg': get_error_message(e)})
                self.save_related(request, form, formsets, not add)
                if add:
                    changed_message = ','.join(['{field}={val}'.format(field=form.fields.get(key).label, val=form.cleaned_data.get(key)) for key in form.changed_data])
                    if isinstance(request.user, MyUser):
                        self.log_addition(request, new_object, changed_message)
                        log_operation(request, new_object, '{action}'.format(action=_('adminLog_action_add')), changed_message)
                    return self.response_add(request, new_object)
                else:
                    changed_message = ','.join(['{field}({initial}->{changed})'.format(field=form.fields.get(key).label, initial=form.initial.get(key), changed=form.cleaned_data.get(key)) for key in form.changed_data])
                    if isinstance(request.user, MyUser):
                        self.log_change(request, new_object, changed_message)
                        log_operation(request, new_object, '{action}'.format(action=_('adminLog_action_change')), changed_message)
                    return self.response_change(request, new_object)
            else:
                form_validated = False
        else:
            if add:
                initial = {'request': request}
                form = ModelForm(initial=initial)
                formsets, inline_instances = self._create_formsets(request, form.instance, change=False)
            else:
                form = ModelForm(instance=obj)
                formsets, inline_instances = self._create_formsets(request, obj, change=True)
        if form._errors:
            return JsonResponse({'code': (-1), 'msg': export_error_dict(form._errors)})
        else:
            cls_admin_form = defined_helpers.ZKAdminForm(form, list(self.get_fieldsets(request, obj)), self.get_prepopulated_fields(request, obj), self.get_readonly_fields(request, obj), model_admin=self)
            media = self.media + cls_admin_form.media
            inline_formsets = self.get_inline_formsets(request, formsets, inline_instances, obj)
            for inline_formset in inline_formsets:
                media = media + inline_formset.media
            context = dict(self.admin_site.each_context(request), model_name=self.opts.model_name, adminform=cls_admin_form, object_id=object_id, original=obj, is_popup=IS_POPUP_VAR in request.POST or IS_POPUP_VAR in request.GET, to_field=to_field, media=media, inline_admin_formsets=inline_formsets, errors=defined_helpers.AdminErrorList(form, formsets), preserved_filters=self.get_preserved_filters(request), action_name=action_name)
            if request.method == 'POST' and (not form_validated) and ('_saveasnew' in request.POST):
                        context['show_save'] = False
                        context['show_save_and_continue'] = False
                        add = False
            context.update(extra_context or {})
            return self.render_change_form(request, context, add=add, change=not add, obj=obj, form_url=form_url)
    def add_view(self, request, form_url='', extra_context=None, *args, **kwargs):
        return self.changeform_view(request, None, form_url, extra_context)
    def get_sort_fields(self, request):
        return self.sort_fields
    def del_view(self, request, *args, **kwargs):
        some_id = request.POST.get('obj_ids', request.GET.get('obj_ids', None))
        delete_action = self._get_first_subclass_of_specific_action(GeneralActionDelete)
        if some_id:
            some_id = json.loads(some_id)
            try:
                iter(some_id)
            except TypeError:
                some_id = [some_id]
            try:
                with transaction.atomic(using=router.db_for_write(self.model)):
                    action_instance = delete_action(request, self, some_id)
                    objects = action_instance.action()
                    log_operation(request, objects, '{action}'.format(action=_('adminLog_action_delete')), '', model=self.model)
            except (AdminRuntimeWarning, ActionHandleError) as e:
                return JsonResponse({'code': (-1), 'msg': str(e)})
            return JsonResponse({'code': 0})
        else:
            return None
    def get_addition_urls(self):
        return
    def has_view_permission(self, request, obj=None):
        """\n        Returns True if the given request has permission to view the given\n        Django model instance, the default implementation doesn\'t examine the\n        `obj` parameter.\n\n        Can be overridden by the user in subclasses. In such case it should\n        return True if the given request has permission to view the `obj`\n        model instance. If `obj` is None, this should return True if the given\n        request has permission to view *any* object of the given type.\n        """
        from django.contrib.auth import get_permission_codename
        opts = self.opts
        codename = get_permission_codename('view', opts)
        return request.user.has_perm('%s.%s' % (opts.app_label, codename))
    def has_module_permission(self, request):
        """\n        Returns True if the given request has any permission in the given\n        app label.\n\n        Can be overridden by the user in subclasses. In such case it should\n        return True if the given request has permission to view the module on\n        the admin index page and access the module\'s index page. Overriding it\n        does not restrict access to the view, add, change, and delete views. Use\n        `ModelAdmin.has_(view|add|change|delete)_permission` for that.\n        """
        return request.user.has_module_perms(self.opts.app_label)
    def has_model_op_permission(self, request):
        """\n        Returns True if the given request has any operation permission in the given\n        app label.\n        """
        return request.user.has_model_op_perms(self.opts.app_label, self.opts.model_name)
    def get_urls(self):
        from django.urls import re_path
        from django.http import HttpRequest
        info = self.info
        def check_perm(request, action):
            app_label, model_name = info
            codename = '{}_{}'.format(action, model_name)
            return request.user.has_perm('{}.{}'.format(app_label, codename), **{'app': app_label, 'model_name': model_name, 'action': action, 'request': request, 'model': self.model})
        def check_has_any_op_perm(request):
            return self.has_model_op_permission(request)
        def wrap(view, action=None, clear_cache=False):
            @effective_user_required
            def wrapper(*args, **kwargs):
                if action:
                    if isinstance(args[0], HttpRequest):
                        if check_perm(args[0], action):
                            pass
                        else:
                            if action == 'view' and check_has_any_op_perm(args[0]):
                                pass
                            else:
                                return HttpResponseForbidden()
                    else:
                        raise ImproperlyConfigured('The first argument need to be request')
                result = self.admin_site.admin_view(view)(*args, **kwargs)
                if args[0].method!= 'GET' and clear_cache is True:
                        for k in getattr(self, 'cache_keys', []):
                            user = args[0].user
                            cache.delete(k)
                            if not user.is_superuser:
                                cache.delete('{key}_{user_id}'.format(key=k, user_id=user.id))
                return result
            wrapper.model_admin = self
            return update_wrapper(wrapper, view)
        urlpatterns = [re_path('^$', wrap(self.init_view, 'view'), name='%s_%s_init' % info), re_path('^table/$', wrap(self.table_view, 'view'), name='%s_%s_table' % info), re_path('^add/$', wrap(self.add_view, 'add', clear_cache=True), name='%s_%s_edit' % info), re_path('^bookmark/$', wrap(self.model_history_view), name='%s_%s_history' % info), re_path('^import_template/$', wrap(self.import_template, clear_cache=True), name='%s_%s_import_template' % info), re_path('^view_ai_analyze/$', wrap(self.view_ai_analyze), name='%s_%s_ai-analyze' % info)]
        addition_urls = self.get_addition_urls()
        if addition_urls:
            urlpatterns += addition_urls
        return urlpatterns