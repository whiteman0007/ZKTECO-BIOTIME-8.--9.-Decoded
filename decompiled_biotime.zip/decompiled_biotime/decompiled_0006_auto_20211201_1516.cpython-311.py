# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0006_auto_20211201_1516.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from __future__ import unicode_literals
from django.db import migrations
import django.db.models.deletion
import mysite.personnel.fields
from mysite.sql_utils import p_query_one, p_execute
def create_default_company(apps, schema_editor):
    from django.conf import settings
    from django.utils.encoding import force_str
    from django.utils.translation import gettext_lazy as _
    sql = 'select id, company_code from personnel_company where id=1'
    rows = p_query_one(sql)
    if not rows:
        sql = 'insert into personnel_company(company_code, company_name, is_default) values(\'1\', \'{company_name}\', {is_default})'
        if settings.DATABASE_ENGINE.lower() in ['postgresql']:
            sql = sql.format(company_name=force_str(_('company.default')), is_default=True)
        else:
            sql = sql.format(company_name=force_str(_('company.default')), is_default=1)
        p_execute(sql)
class Migration(migrations.Migration):
    dependencies = [('personnel', '0005_auto_20211201_1434')]
    operations = [migrations.RunPython(create_default_company, reverse_code=migrations.RunPython.noop)]