# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\attcode_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.att import const
from mysite.att.models import AttCode
class AttCodeForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(AttCodeForm, self).__init__(*args, **kwargs)
        if self.instance and self.instance.symbol_only:
                self.fields['display_format'].disabled = True
                self.fields['round_off'].disabled = True
                self.fields['min_val'].disabled = True
                self.initial['display_format'] = const.MINUTE
                self.initial['round_off'] = const.ROUND_OFF
    class Meta:
        model = AttCode
        fields = '__all__'
        exclude = ('code', 'symbol_only')
CODE_BREAK_HRS = [{'code': const.CODE_DURATION, 'alias': str(_('attCode.default.duration')), 'round_off': const.ROUND_OFF, 'display_format': const.HOUR_MINUTE, 'symbol': '', 'symbol_only': False}, {'code': const.CODE_DUTY_DURATION, 'alias': str(_('attCode.default.dutyDuration')), 'round_off': const.ROUND_OFF, 'display_format': const.HOUR_MINUTE, 'symbol': '', 'symbol_only': False}, {'code': const.CODE_TOTAL_HRS, 'alias': str(_('attCode.default.totalHours')), 'round_off': const.ROUND_OFF, 'display_format': const.HOUR_MINUTE, 'symbol': '', 'symbol_only': False}, {'code': const.CODE_WORKED_HRS, 'alias': str(_('attCode.default.workedHours')), 'round_off': const.ROUND_OFF, 'display_format': const.HOUR_MINUTE, 'symbol': ''
@admin.register(AttCode)
class AttCodeAdmin(admin.ZKModelAdmin):
    list_display = ('alias', 'display_format', 'symbol', 'round_off', 'min_val', 'color_setting')
    ordering = ('order',)
    form = AttCodeForm
    list_filter = ('alias',)
    @staticmethod
    def initial_data():
        for index, code in enumerate(INITIAL_DATA):
            att_code = AttCode.objects.filter(code=code['code']).first()
            if not att_code:
                AttCode(order=index + 1, **code).save(force_insert=True)
            else:
                att_code.display_format = code['display_format']
                att_code.save(force_update=True)
    def get_queryset(self, request):
        qs = super(AttCodeAdmin, self).get_queryset(request)
        qs = qs.exclude(code__in=[const.CODE_ACTUAL_BREAK, const.CODE_ACTUAL_WORKED, const.CODE_DAY_OFF, const.CODE_WEEKEND, const.CODE_HOLIDAY])
        return qs
    def has_add_permission(self, request):
        return False