# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\iclock\\migrations\\0012_alter_biophoto_first_name_alter_biophoto_last_name_and_more.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:38 UTC (1750702718)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('iclock', '0010_901_push_version_width')]
    operations = [migrations.AlterField(model_name='biophoto', name='first_name', field=models.CharField(blank=True, default='', max_length=100, null=True, verbose_name='bioPhoto_field_firstName')), migrations.AlterField(model_name='biophoto', name='last_name', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='bioPhoto_field_lastName')), migrations.AlterField(model_name='transaction', name='area_alias', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='transaction_field_areaAlias'))]