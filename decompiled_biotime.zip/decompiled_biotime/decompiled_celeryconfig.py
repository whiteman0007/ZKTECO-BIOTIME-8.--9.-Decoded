# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\celeryconfig.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from django.conf import settings
from kombu import Queue
from celery.schedules import crontab
from mysite._utils import getattr_ex
timezone = settings.TIME_ZONE
broker_url = settings.BROKER_URL
task_always_eager = False
task_serializer = 'pickle'
task_ignore_result = True
accept_content = ['pickle', 'json', 'msgpack', 'yaml']
result_backend = settings.CELERY_RESULT_BACKEND
result_serializer = 'json'
result_expires = 3600
if not settings.DEBUG:
    task_ignore_result = True
worker_log_format = '[%(asctime)s: %(levelname)s] %(message)s'
worker_task_log_format = '[%(asctime)s: %(levelname)s] [%(task_name)s] %(message)s'
if settings.DEBUG:
    task_queues = (Queue('celery', routing_key='celery'), Queue('iclock_real_time', routing_key='iclock_real_time'), Queue('att_real_time', routing_key='att_real_time'), Queue('iclock_data_upload', routing_key='iclock_data_upload'), Queue('fast_run_queue', routing_key='fast_run_queue'), Queue('low_run_queue', routing_key='low_run_queue'))
worker_max_tasks_per_child = 100
worker_concurrency = 3
DJANGO_CELERY_BEAT_TZ_AWARE = False
beat_scheduler = 'django_celery_beat.schedulers.DatabaseScheduler'
iclock.tasks.save_employee_photo = {'iclock.tasks.data_sync': {'task': 'iclock.tasks.data_sync', 'schedule': 10}, 'iclock.tasks.device_online_monitor': {'task': 'iclock.tasks.device_online_monitor', 'schedule': settings.MAX_DEVICES_STATE}, 'iclock.tasks.data_clean': {'task': 'iclock.tasks.data_clean', 'schedule': crontab(minute=15, hour=0)}, 'mobile.task.upload_gps': {'task': 'mobile.task.upload_gps', 'schedule': crontab(minute=25, hour=0)}, 'psnl.tasks.employment_status_monitoring': {'task': 'psnl.tasks.employment_status_monitoring', 'schedule': crontab(minute=1, hour=0)}, 'psnl.tasks.resigned_scanner': {'task': 'psnl.tasks.resigned_scanner', 'schedule': crontab(minute=5, hour=0, day_of_month=1, month_of_year=1)}, 'base.tasks.daily_licence_verify': {'task': 'base.tasks.daily_licence_verify', 'schedule': crontab(minute=2, hour=0)}, 'base.tasks.daily_aof_rewrite': {'task': 'base.tasks.daily_aof_rewrite',
# return (('iclock.tasks.data_sync2device', {'queue': 'iclock_real_time'}), ('iclock.tasks.data_sync', {'queue': 'iclock_real_time'}), ('iclock.tasks.push_cmd2device', {'queue': 'iclock_real_time'}), ('iclock.tasks.save_device_log', {'queue': 'iclock_data_upload'}), ('iclock.tasks.save_device_upload_log', {'queue': 'iclock_data_upload'}), ('iclock.tasks.save_device_capture', {'queue': 'iclock_data_upload'}), ('iclock.tasks.save_employee_photo', {'queue': 'iclock_data_upload'}), ('iclock.tasks.save_error_log', {'queue': 'iclock_data_upload'}), ('mobile.tasks.save_clock_capture', {'queue': 'iclock_data_upload'}), ('iclock.tasks.real_time_new_transaction', {'queue': 'att_real_time'}), ('att_real_time', {'queue': 'att_real_time'}), ('iclock.tasks.real_time_transaction', {'queue': 'att_real_time'}), ('att.tasks.run_calculation', {'queue': 'att_real_time'}), ('att.tasks.auto_calculate_daily', {