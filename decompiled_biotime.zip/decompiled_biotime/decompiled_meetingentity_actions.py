# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\meeting\\actions\\meetingentity_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:04 UTC (1750673044)

import datetime
from django.forms import ModelMultipleChoiceField, ValidationError
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.admin.action import ZKModelAction, ActionHandleError
from mysite.personnel.models import Employee
from mysite.personnel.widgets import EmployeeManyToManyMiddleWidget
class AddMeetingAttenderForm(forms.ZKActionForm):
    attender = ModelMultipleChoiceField(label=_('meetingEntity.fields.attender'), queryset=None, widget=EmployeeManyToManyMiddleWidget(), required=False)
    def __init__(self, *args, **kwargs):
        super(AddMeetingAttenderForm, self).__init__(*args, **kwargs)
        self.fields['attender'].queryset = Employee.objects.get_queryset()
class AddMeetingAttender(admin.ZKModelAction):
    verbose_name = _('meetingEntity.actions.addAttender')
    short_description = _('meetingEntity.actions.addAttender.description')
    help_txt = _('meetingEntity.actions.addAttender.helpTxt')
    action_form = AddMeetingAttenderForm
    batch_select = True
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        for instance in self.objects:
            if not data['attender']:
                raise ValidationError(_('meetingEntity.save.error.missAttender'), code='-1')
            else:
                if not instance.attender:
                    instance.attender = data['attender']
                else:
                    _attender_set = set(instance.attender.all()) | set(data['attender'])
                    if instance.room and instance.room.capacity < len(_attender_set):
                        raise ActionHandleError(_('meetingEntity.save.error.roomCapacity'))
                    else:
                        instance.attender.add(*data['attender'])
                instance.sync_new_attender2device(data['attender'])
class MeetingCalculation(ZKModelAction):
    verbose_name = _('meetingEntity.actions.calculation')
    confirmation = _('meetingEntity.actions.calculation.confirmation')
    short_description = _('meetingEntity.actions.calculation.description')
    help_txt = _('meetingEntity.actions.calculation.helpTxt')
    batch_select = True
    def action(self, *args, **kwargs):
        from mysite.meeting.calculation import meeting_calculation
        for meeting in self.objects:
            meeting_calculation(meeting)
class SyncMeeting2Device(ZKModelAction):
    verbose_name = _('meetingEntity.actions.syncMeeting2Device')
    short_description = _('meetingEntity.actions.syncMeeting2Device.description')
    help_txt = _('meetingEntity.actions.syncMeeting2Device.helpTxt')
    confirmation = _('meetingEntity.actions.syncMeeting2Device.confirmation')
    batch_select = True
    def action(self, *args, **kwargs):
        from mysite.workflow.models_choices import APPROVED
        now = datetime.datetime.now()
        for meeting in self.objects:
            if meeting.approval_status not in [APPROVED]:
                continue
            else:
                if meeting.end_time < now:
                    continue
                else:
                    if not meeting.room:
                        continue
                    else:
                        devices = meeting.room.meetingroomdevice_set.values_list('device__sn', flat=True)
                        if not devices:
                            continue
                        else:
                            meeting.sync2device(devices)
                            meeting.sync_time = now
                            meeting.original_sync_time = 'original_sync_time'
                            meeting.save(force_update=True)