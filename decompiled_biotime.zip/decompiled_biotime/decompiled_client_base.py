# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\tools\\ftpclient\\client_base.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

from abc import abstractmethod
from os.path import exists
class FTPClientBaseError(Exception):
    # return None
    pass
class FTPClientBase:
    def __init__(self, hostname, username, password, port=22):
        self.host = hostname
        self.port = port
        self.user = username
        self.passwd = password
        self.ftp = None
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.disconnect()
    @abstractmethod
    def connect(self):
        return
    @abstractmethod
    def disconnect(self):
        return
    def copy_tree(self, src, dst, copy_type='auto'):
        if copy_type == 'auto':
            copy_type = 'up' if exists(src) else 'down'
        if copy_type == 'down':
            self.download_tree(src, dst)
        else:
            self.upload_tree(src, dst)
    @abstractmethod
    def download_tree(self, src, dst):
        return
    @abstractmethod
    def upload_tree(self, src, dst):
        return
    def copy_file(self, src, dst, copy_type='auto'):
        if copy_type == 'auto':
            copy_type = 'up' if exists(src) else 'down'
        if copy_type == 'down':
            self.download_file(src, dst)
        else:
            self.upload_file(src, dst)
    @abstractmethod
    def download_file(self, src, dst):
        return
    @abstractmethod
    def upload_file(self, src, dst):
        return