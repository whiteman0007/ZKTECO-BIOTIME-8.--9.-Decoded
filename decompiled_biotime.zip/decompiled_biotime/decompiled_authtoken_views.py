# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\api\\authtoken_views.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:53 UTC (1750672973)

import datetime
import json
from django.contrib.admin.forms import AdminAuthenticationForm
from django.contrib.auth.views import LoginView
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework_simplejwt.settings import api_settings
from rest_framework.authtoken.models import Token
from mysite.api.mixin import LoggingMixin
class SuperuserObtainAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        if not user or not user.is_superuser or (not user.is_staff):
            return Response({'detail': 'superuser required.'}, status=400)
        else:
            token, created = Token.objects.get_or_create(user=user)
            return Response({'token': token.key})
class SuperuserObtainJSONWebToken(LoggingMixin, TokenObtainPairView):
    """\n    API View that receives a POST with a user\'s username and password.\n\n    Returns a JSON Web Token that can be used for authenticated requests.\n    """
    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.user or request.user
            if not user or not user.is_superuser or (not user.is_staff):
                return Response({'detail': 'superuser required.'}, status=400)
            else:
                token = serializer.validated_data.get('access')
                response_data = {'token': token}
                response = Response(response_data)
                return response
        else:
            return Response(serializer.errors, status=400)
superuser_obtain_auth_token = SuperuserObtainAuthToken.as_view()
superuser_obtain_jwt_token = SuperuserObtainJSONWebToken.as_view()
class AdminAuthForm(AdminAuthenticationForm):
    """"""
    def clean(self):
        from mysite.authurls import logon
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        if username is not None and password:
                result = logon(self.request)
                content = json.loads(result.content) if result.status_code == 200 else {}
                self.user_cache = self.request.user if content.get('ret', 1) == 0 else None
                if self.user_cache is None:
                    raise self.get_invalid_login_error()
                else:
                    self.confirm_login_allowed(self.user_cache)
        return self.cleaned_data
class LoginView_Extend(LoginView):
    """"""
    form_class = AdminAuthForm