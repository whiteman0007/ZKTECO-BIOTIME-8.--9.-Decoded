# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\report\\admin\\deduction_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:15 UTC (1750673055)

from mysite.payroll.report.base import PayRollReportAdminBase
from mysite.payroll.report.decorators import report_admin_register
from mysite.payroll.api.serializers import PayrollPayloadDeductionSerializer
from mysite.att.models.model_paycode import PayCode, LEAVE, EXCEPTION
@report_admin_register()
class DeductionAdmin(PayRollReportAdminBase):
    api_url = '/payroll/api/report/payrolldeduction/'
    model_name = 'PayrollDeduction'
    api_serializer = PayrollPayloadDeductionSerializer
    view_name = 'payrolldeduction_report'
    list_display = ['emp_code', 'first_name', 'last_name', 'department', 'calc_time', 'basic_salary', 'payment_mode_display', 'deduction', 'extra_deduction', 'loan_deduction', 'advance_deduction', 'total_deduction']
    hidden_fields = ()
    def get_pay_codes(self):
        return PayCode.objects.filter(code_type__in=[EXCEPTION, LEAVE]).order_by('display_order').values('id', 'is_display')
    def insert_ext_cols(self, cols):
        self.add_emp_ext_cols(cols)
        self.add_paycode_cols(cols)