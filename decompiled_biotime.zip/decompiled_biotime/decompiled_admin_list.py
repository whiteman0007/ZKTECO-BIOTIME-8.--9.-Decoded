# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\admin\\admin_list.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:52 UTC (1750672972)

import six
from django.contrib.admin.utils import lookup_field, display_for_value, label_for_field
from django.core.exceptions import ObjectDoesNotExist
from django.db import models
from django.utils import formats
from django.utils.encoding import force_str
from django.utils.encoding import smart_str
from django.utils.html import escape
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _
from django.conf import settings
def _update_parameters(f, d1, d2):
    if f in d2:
        d1.update(d2[f])
    else:
        if '__all__' in d2:
            for k, v in six.iteritems(d2['__all__']):
                if '%' in d1[k] or d1[k] < v:
                    d1[k] = v
    return d1
def result_headers(cl, all_perms, display_params, disabled_fields=None, column_order=None):
    lookup_opts = cl.lookup_opts
    if isinstance(lookup_opts.pk, (models.OneToOneField, models.ForeignKey)):
        pk_name = 'id'
    else:
        pk_name = lookup_opts.pk.name
    pk = lookup_opts.get_field(pk_name).attname
    sort_fields = cl.sort_fields
    if disabled_fields is None:
        disabled_fields = []
    if column_order is None:
        column_order = []
    if all([all_perms.get('change', False), all_perms.get('delete', False)]):
        total_percent = 90
    else:
        if any([all_perms.get('change', False), all_perms.get('delete', False)]):
            total_percent = 95
        else:
            total_percent = 100
    all_col = len(cl.list_display) - 1
    percent = int(total_percent / all_col)
    if display_params is None:
        display_params = {}
    list_display = cl.list_display[:]
    if column_order and all([item in list_display for item in column_order]):
            column_order = ['id'] + column_order
            for field in set(list_display) - set(column_order):
                if field not in disabled_fields:
                    column_order.append(field)
            list_display = column_order
    for i, field_name in enumerate(list_display):
        header, attr = label_for_field(field_name, cl.model, model_admin=cl.model_admin, return_attr=True)
        if pk == field_name:
            yield {'field': field_name, 'title': smart_str(header), 'fixed': 'left', 'width': 48, 'type': 'checkbox'}
            yield {'field': 'hash', 'title': '#', 'hide': True, 'unresize': True, 'minWidth': 20, 'event': 'editPopUp', 'style': 'text-decoration: underline;', 'align': 'center', 'type': 'numbers'}
        else:
            _d = {'field': field_name, 'title': smart_str(header), 'width': '{}%'.format(percent), 'sort': True if field_name in sort_fields else False}
            if field_name in disabled_fields:
                _d['hide'] = True
            yield _update_parameters(field_name, _d, display_params)
def _boolean_icon(field_val):
    from django.conf import settings
    icon_url = settings.MEDIA_URL + 'img/icon-%s.gif' % {'True': 'yes', 'False': 'no', 'None': 'unknown'}[str(field_val)]
    return format_html('<img src=\"{}\" alt=\"{}\" />', icon_url, field_val)
def display_for_field(value, field, empty_value_display, export_flag=False):
    from django.conf import settings
    from mysite.base.utils import short_date_format, short_time_format, date_time_format
    if getattr(field, 'flatchoices', None):
        return dict(field.flatchoices).get(value, empty_value_display)
    else:
        if isinstance(field, models.BooleanField) or isinstance(field, models.NullBooleanField):
            if export_flag:
                return six.text_type(value)
            else:
                return _boolean_icon(value)
        else:
            if value is None:
                return empty_value_display
            else:
                if isinstance(field, models.DateTimeField):
                    if value.year <= 1900:
                        return ''
                    else:
                        return '{datetime}'.format(datetime=date_time_format(value))
                else:
                    if isinstance(field, models.DateField):
                        return '{date}'.format(date=short_date_format(value))
                    else:
                        if isinstance(field, models.TimeField):
                            return '{time}'.format(time=short_time_format(value))
                        else:
                            if isinstance(field, models.DecimalField):
                                return formats.number_format(value, field.decimal_places)
                            else:
                                if isinstance(field, (models.IntegerField, models.FloatField)):
                                    return formats.number_format(value)
                                else:
                                    if isinstance(field, models.FileField) and value:
                                        return format_html('<a href=\"{}\">{}</a>', value.url, value)
                                    else:
                                        if False:
                                            pass
                                        return escape(display_for_value(value, empty_value_display))
def items_for_result(cl, result, form, export_flag=False):
    import datetime
    item = {}
    list_display = list(cl.list_display)
    list_display.extend(list(getattr(cl.model_admin, 'non_display_fields', [])))
    for field_name in list_display:
        empty_value_display = cl.model_admin.get_empty_value_display()
        try:
            f, attr, value = lookup_field(field_name, result, cl.model_admin)
        except (AttributeError, ObjectDoesNotExist):
            result_repr = empty_value_display
        else:
            empty_value_display = getattr(attr, 'empty_value_display', empty_value_display)
            exp_display = '{0}_exp_display'.format(field_name)
            fe_display = '{0}_viewing'.format(field_name)
            if f is None or f.auto_created:
                allow_tags = getattr(attr, 'allow_tags', False)
                boolean = getattr(attr, 'boolean', False)
                result_repr = display_for_value(value, empty_value_display, boolean)
                if allow_tags:
                    result_repr = mark_safe(result_repr)
                if isinstance(value, (datetime.date, datetime.time)):
                    pass
                else:
                    if export_flag and getattr(cl.model_admin, exp_display, None):
                        admin_display = getattr(cl.model_admin, exp_display)
                        if callable(admin_display):
                            result_repr = admin_display(result, value)
                        else:
                            result_repr = admin_display
            else:
                if isinstance(f.remote_field, models.ManyToOneRel):
                    field_val = getattr(result, f.name)
                    if field_val is None:
                        result_repr = empty_value_display
                    else:
                        if not export_flag:
                            result_repr = escape(field_val)
                        else:
                            result_repr = field_val
                else:
                    if export_flag and getattr(cl.model_admin, exp_display, None):
                        admin_display = getattr(cl.model_admin, exp_display)
                        if callable(admin_display):
                            result_repr = admin_display(result, value)
                        else:
                            result_repr = admin_display
                    else:
                        if not export_flag and getattr(cl.model_admin, fe_display, None):
                            admin_display = getattr(cl.model_admin, fe_display)
                            if callable(admin_display):
                                result_repr = admin_display(result, value)
                            else:
                                result_repr = admin_display
                        else:
                            result_repr = display_for_field(value, f, empty_value_display, export_flag)
        item[field_name] = mark_safe(force_str(result_repr))
    if False:
        pass
    return item
def yield_results(cl):
    for res in cl.result_list:
        if hasattr(cl.model_admin, 'update_result'):
            res = cl.model_admin.update_result(res)
        yield items_for_result(cl, res, None)
def process_status_update(progress_recorder, counter, total):
    if not progress_recorder:
        return
    from celery_progress.backend import AbstractProgressRecorder
    if isinstance(progress_recorder, AbstractProgressRecorder):
        if hasattr(progress_recorder.task, 'is_aborted') and progress_recorder.task.is_aborted():
            raise Exception('Async Interrupt')
    else:
        if hasattr(progress_recorder, 'is_aborted') and progress_recorder.is_aborted():
            raise Exception('Async Interrupt')
    from mysite.utils import progress_record
    progress_record(progress_recorder, counter, total, _('exportProgress.status.preparingData'))
def yield_export_results(cl, progress_recorder=None):
    counter = 0
    total = cl.result_list.count()
    for res in cl.result_list:
        if hasattr(cl.model_admin, 'update_result'):
            res = cl.model_admin.update_result(res)
        counter += 1
        process_status_update(progress_recorder, counter, total)
        yield items_for_result(cl, res, None, True)