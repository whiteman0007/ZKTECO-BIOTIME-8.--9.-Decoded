# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\templatetags\\iclock_tags.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:40 UTC (1750673020)

import datetime
import re
from html import escape
from django import template
from django.conf import settings
from django.contrib.auth.models import Group
from django.core.cache import cache
from django.db.models import Q
from django.template.defaultfilters import stringfilter
from django.utils.translation import gettext_lazy as _
from django.contrib.auth import get_user_model
from mysite.base.models import get_param_value
from mysite.i18n_backend import trans_opt
from mysite.core.utils import hasPerm
from mysite.lngdict import CMDName
from mysite.settings import VERSION, STD_DATETIME_FORMAT
from mysite.utils import loads
register = template.Library()
LClass = []
COLOR_DEV_STATUS = ['gray', 'blue', 'skyblue', '#ff8888', '#13EC30', '#13EC30', '#FE0103', '#FF830F', '#FF830F', '#13EC30']
USER = get_user_model()
@register.inclusion_tag('filters.html')
def filters(cl):
    return {'cl': cl}
def filter(cl, spec):
    return {'title': spec.title(), 'choices': list(spec.choices(cl))}
filter = register.inclusion_tag('admin/filter.html')(filter)
@register.simple_tag
def current_time(format_string):
    return str(datetime.datetime.now())
@register.filter
def HasPerm(user, operation):
    return user.has_perm(operation)
@register.filter
def reqHasPerm(request, operation):
    return hasPerm(request.user, request.model, operation)
@register.filter
def buttonItem(request, operation, iclock_url_rel=None):
    model = request.model
    if hasPerm(request.user, request.model, operation):
        return '<li><a href=\"%s/data/%s/">%s</a></li>' % (iclock_url_rel, model.__name__, model._meta.verbose_name)
    else:
        return '<li>' + model._meta.verbose_name + '</li>'
def enable_mod(mod_name):
    if mod_name == '':
        return True
    else:
        l_mod = mod_name.split(';')
        for m in l_mod:
            if m in settings.ENABLED_MOD_TMP:
                return True
        return False
@register.simple_tag
def version():
    return VERSION + ' by <a href=\"http://www.zkteco.com\">ZKTeco Inc.</a>'
@register.filter
def cap(s):
    return ('%s' % s).capitalize()
@register.filter
def is_enabled_module(mod_name):
    if mod_name == '':
        return True
    else:
        return mod_name in settings.ENABLED_MOD
@register.filter
def enabled_udisk_mod(mod_name):
    return 'udisk' in settings.ENABLED_MOD
@register.filter
def enabled_weather_mod(mod_name):
    return 'weather' in settings.ENABLED_MOD
@register.filter
def enabled_msg_mod(mod_name):
    return 'msg' in settings.ENABLED_MOD
@register.filter
def enabled_att_mod(mod_name):
    return 'att' in settings.ENABLED_MOD
@register.filter
def enabled_iaccess_mod(mod_name):
    return 'acc' in settings.ENABLED_MOD
@register.filter
def enabled_fptemp_mod(mod_name):
    return 'fptemp' in settings.ENABLED_MOD
@register.filter
def enabled_uru_mod(mod_name):
    return 'uru' in settings.ENABLED_MOD
@register.filter
def lescape(s):
    if not s:
        return ''
    else:
        return escape(s).replace('\n', '\\n').replace('\r', '\\r').replace('\'', '&#39;').replace('\"', '&quot;')
@register.filter
def LeaveList(values, field):
    l = []
    try:
        for s in values:
            l.append(s[field])
        return ','.join(l)
    except:
        for s in values:
            l.append(s[field])
        return ','.join(l)
@register.filter
def isoTime(value):
    if value:
        return str(value)[:19]
    else:
        if value == 0:
            return '0'
        else:
            return ''
@register.filter
def transLogStamp(value):
    if value and value!= '0':
        return OldDecodeTime(value)[5:]
    else:
        return ''
@register.filter
def stdTime(value):
    if value:
        return value.strftime(STD_DATETIME_FORMAT)
    else:
        return ''
@register.filter
def schName(value):
    if value:
        if int(value)!= (-1):
            schClass = FindSchClassByID(int(value))
            if schClass:
                return schClass['SchName']
        else:
            return _('NoSchClass')
    return ''
@register.filter
def hourAndMinute(value):
    if value:
        h = str(int(value) / 60)
        m = str(int(value) % 60)
        if int(m) < 10:
            m = '0' + str(m)
        return h + ':' + m
    else:
        return ''
@register.filter
def objj(value):
    if value:
        try:
            return value.decode('gb2312').encode('utf-8')
        except:
            return value
    else:
        return ''
@register.filter
def dept_related(value):
    r = ''
    j = 0
    u = value
    if u:
        deptids = userDeptList(u)
        for t in deptids:
            if j > 1:
                r += '...'
                break
            else:
                obj = department.objByID(t)
                if obj:
                    r += '%s' % obj.DeptName + ','
                j += 1
        return r[:(-1)]
    else:
        return r
@register.filter
def ding_related(value):
    r = ''
    j = 0
    u = value
    if u:
        if u.is_superuser:
            diningids = list(Dininghall.objects.filter(DelTag=0).values_list('pk', flat=True))
        else:
            diningids = getDiningByUser(u)
        for t in diningids:
            if j > 5:
                r += '...'
                break
            else:
                obj = Dininghall.objects.filter(id=t)
                if obj:
                    r += '%s' % obj[0].name + ','
                j += 1
        return r[:(-1)]
    else:
        return r
@register.filter
def zone_related(value):
    r = ''
    j = 0
    u = value
    if u:
        if u.is_superuser:
            zoneids = list(zone.objects.filter(DelTag=0).values_list('pk', flat=True))
        else:
            zoneids = userZoneList(u)
        for t in zoneids:
            if j > 5:
                r += '...'
                break
            else:
                obj = zone.objByID(t)
                if obj:
                    r += '%s' % obj.name + ','
                j += 1
        return r[:(-1)]
    else:
        return r
@register.filter
def role_related(value):
    r = ''
    j = 0
    if value:
        for t in value:
            if j > 2:
                r += '...,'
                break
            else:
                r += t.roleid.roleName + ','
                j += 1
        return r[:(-1)]
    else:
        return r
@register.filter
def shortTime0(value):
    if value:
        return value.strftime('%y-%m-%d %H:%M')
    else:
        return ''
@register.filter
def shortTime(value):
    if value:
        return value.strftime('%y-%m-%d %H:%M:%S')
    else:
        return ''
@register.filter
def vshortTime(value):
    if value:
        return value.strftime('%y%m%d%H%M')
    else:
        return ''
@register.filter
def shortDTime(value):
    if value:
        return value.strftime('%m-%d %H:%M')
    else:
        return ''
@register.filter
def onlyTime(value):
    if value:
        try:
            return value.strftime('%H:%M')
        except:
            return (value + datetime.timedelta(100)).strftime('%H:%M:%S')
    else:
        if str(value) == '00:00:00':
            return '00:00'
        else:
            return ''
@register.filter
def shortDate(value):
    if value:
        return value.strftime('%y-%m-%d')
    else:
        return ''
@register.filter
def shortDate4(value):
    if value:
        return value.strftime('%Y-%m-%d')
    else:
        return ''
@register.filter
def shortDate41(value):
    if value:
        if value.strftime('%Y-%m-%d') == '1900-01-01':
            return ''
        else:
            return value.strftime('%Y-%m-%d')
    else:
        return ''
@register.filter
def getVERIFICATIONMETHOD(value):
    try:
        return COMVERIFYS[value][1]
    except:
        return ''
Absent = {'0': _('No'), '1': _('Yes')}
@register.filter
def isYesNo(value):
    if value:
        return Absent['1']
    else:
        return Absent['0']
@register.filter
def isTrueOrFalse(value):
    if value:
        return Absent['0']
    else:
        return Absent['1']
GENDER_CHOICES = {'M': _('Male'), 'F': _('Female')}
@register.filter
def getSex(value):
    try:
        return GENDER_CHOICES[value].title()
    except:
        return ''
@register.filter
def getother(value):
    return getother_process(value)
@register.filter
def isOdd(value):
    if int(value) % 2!= 0:
        return 1
    else:
        return 0
def getAttStateStr(s):
    if s:
        return transAttState(s)
    else:
        return ''
@register.filter
def StateName(value):
    if value:
        return getAttStateStr(value)
    else:
        return ''
@register.filter
def left(value, size):
    s = '%s' % value
    if len(s) > size:
        return s[:size] + ' ...'
    else:
        return s
@register.filter
def Leave(value):
    LClass = GetLeaveClassesEx(1)
    for s in LClass:
        if value == s['LeaveID']:
            return s['LeaveName']
    return ''
@register.filter
def ExceptionStr(value):
    if value:
        return GetExceptionText(value)
    else:
        return ''
@register.filter
def AbnormiteName(value):
    if value:
        return transAbnormiteName(value)
    else:
        return ''
@register.filter
def PackList(values, field):
    l = []
    try:
        for s in values:
            l.append(s[field])
        return ','.join(l)
    except Exception as e:
        print(('PackList==', e))
        for s in values:
            l.append(s[field])
        return ','.join(l)
@register.filter
def cmdName(value):
    return getContStr(value)
DataContentNames = {'TRANSACT': '%s' % _('Transaction'), 'USERDATA': '%s' % _('employee info/fingerprint ')}
@register.filter
def dataShowStr(value):
    if value in DataContentNames:
        return value + ' <span style=\'color:#1C94C4;\'>' + DataContentNames[value] + '</span>'
    else:
        return value
@register.filter
def colorShowStr(value):
    shex = str(hex(int(value)))
    shex = shex[2:]
    shex = '000000' + shex
    shex = shex[len(shex) - 6:]
    apage = '<P style=\'background-color:#' + shex + '\'>' + str(value) + '</P>'
    return apage
@register.filter
def cmdShowStr(value):
    value = re.sub('[\t\r\n\\\\]', ' ', value)
    return left(value, 60) + ' <span style=\'color:#1C94C4;\'>' + getContStr(value) + '</span>'
@register.filter
def deptShowStr(value):
    SN = value.SN
    depts = ''
    if value.ProductType in [3, 4, 5, 15, 25]:
        deptlist = getZoneBySN(SN)
        for d in deptlist:
            try:
                obj = zone.objects.get(id=d)
                if obj.DelTag == 1:
                    depts += obj.name + str(_('(deleted),'))
                else:
                    depts += obj.name + ','
            except:
                pass
    else:
        if value.ProductType in [11, 12, 13]:
            deptlist = getDiningBySN(SN)
            for d in deptlist:
                try:
                    obj = Dininghall.objects.get(id=d)
                    depts += obj.name + ','
                except:
                    pass
        else:
            if get_param_value('opt_basic_att_zone', '0') == '1':
                deptlist = getZoneBySN(SN)
                for d in deptlist:
                    try:
                        obj = zone.objects.get(id=d)
                        if obj.DelTag == 1:
                            depts += obj.name + str(_('(deleted),'))
                        else:
                            depts += obj.name + ','
                    except:
                        pass
            else:
                deptlist = getDepartmentBySN(SN)
                if (-1) in deptlist:
                    depts += '%s,' % _('All departments')
                else:
                    j = 0
                    for d in deptlist:
                        if j > 1:
                            depts += '...,'
                            break
                        else:
                            obj = department.objByID(d)
                            if obj:
                                depts += obj.DeptName + ','
                                j += 1
    return depts[:(-1)]
@register.filter
def thumbnailUrl(obj):
    # irreducible cflow, using cdg fallback
    url = obj.getThumbnailUrl()
    if url:
        fullUrl = obj.getImgUrl()
            if not fullUrl:
                return '<img src=\'%s\' />' % url
                return '<a href=\'#\' onmouseover=showphotodiv(this,\'%s') onmouseout='dropphotodiv()'><img src='%s\' /></a>' % (fullUrl, url)
            return '<img src=\'%s\' />' % url
                    except Exception as e:
                            import traceback
                            print(traceback.print_exc())
                            print(('thumbnailUrl ', e))
                                return ''
@register.filter
def thumbnailUrlz(obj):
    # irreducible cflow, using cdg fallback
    url = obj.getThumbnailUrlz()
    if url:
        fullUrl = obj.getImgUrlz()
            if not fullUrl:
                return '<img src=\'%s\' />' % url
                return '<a href=\'#\' onmouseover=showphotozdiv(this,\'%s') onmouseout='dropphotozdiv()'><img src='%s\' /></a>' % (fullUrl, url)
            return '<img src=\'%s\' />' % url
                    except Exception as e:
                            print('')
                                return ''
@register.filter
def trans_thumbnailUrl(obj, user):
    try:
        fullUrl = obj.getImgUrl(user)
    except:
        return ''
    if fullUrl:
        return '<a href=\'#\' onmouseover=showphotodiv(this,\'%s') onmouseout='dropphotodiv()'><img src='%s\' style=\'width:80px;height:100px;\' /></a>' % (fullUrl, fullUrl)
    else:
        return ''
@register.filter
def GetAnnualleaves(value):
    return GetAnnualleave(value)
@register.filter
def GetUsedAnnualleaves(value, dateid):
    from mysite.iclock.datas import NormalAttValue
    LClass = GetLeaveClassesEx(1)
    LeaveID = 0
    Unit = 3
    MinUnit = 1
    remaindproc = 1
    for t in LClass:
        if t['LeaveID'] == int(dateid) and t['LeaveType'] == 5:
                MinUnit = t['MinUnit']
                Unit = t['Unit']
                LeaveID = t['LeaveID']
                remaindproc = t['RemaindProc']
                break
    if LeaveID == 0:
        return 0
    else:
        InScopeTime = 0
        ys = datetime.datetime.now()
        months = 1
        days = 1
        ann = annual_settings.objects.filter(Name='month_s')
        if ann.count() > 0:
            months = int(ann[0].Value)
        ann = annual_settings.objects.filter(Name='day_s')
        if ann.count() > 0:
            days = int(ann[0].Value)
        y1 = datetime.datetime(ys.year, months, days, 0, 0)
        if ys > y1:
            y2 = datetime.datetime(year=y1.year + 1, month=y1.month, day=y1.day)
        else:
            y2 = y1
            y1 = datetime.datetime(year=y1.year - 1, month=y1.month, day=y1.day)
        AttExcep = AttException.objects.filter(UserID=int(value), ExceptionID=LeaveID, InScopeTime__gt=0, AttDate__lt=y2, AttDate__gte=y1)
        for Exc in AttExcep:
            InScopeTime += NormalAttValue(Exc.InScopeTime, MinUnit, Unit, remaindproc)
        return InScopeTime
@register.filter
def GetempAnnualleaves(Annualleave, Hiredday):
    if Hiredday == None:
        return Annualleave
    else:
        if str(type(Hiredday))!= '<type \'datetime.date\'>' and str(type(Hiredday))!= '<type \'datetime.datetime\'>':
                return 0
        nowyear = datetime.datetime.now().year
        hireyear = checkTime(Hiredday).year
        if hireyear < 1960:
            return 0
        else:
            diff = nowyear - hireyear
            re = 0
            if diff >= 1 and diff < 10:
                re = 5
            else:
                if diff >= 10 and diff < 20:
                    re = 10
                else:
                    if diff >= 20:
                        re = 15
            if Annualleave!= None and Annualleave < re:
                    re = Annualleave
            return re
@register.filter
def trim(value):
    if not value and value!= 0:
            return ''
    if value == ' ':
        value = value.strip(' ')
    if str(type(value)) == '<type \'str\'>' or isinstance(value, type(' ')):
        value = value.replace('\n', ' ')
    return value
@register.filter
def killnone(value):
    if not value or value == 'None':
        value = ''
    return value
@register.filter
def field_as_td_h(field, cols):
    lbl = field.label_tag()
    c = 1
    try:
        c = cols
    except:
        pass
    helptext = field.help_text
    if helptext:
        h_text = field.help_text
        length = len(h_text)
        utf8_length = len(h_text.encode('utf-8'))
        length = (utf8_length - length) / 2 + length
        if c!= 1:
            if length > 10:
                helptext = h_text and '<span><i class=\'icon iconfont icon-xiaoxi\' title=\'%s\'></i></span>' % str(h_text) or ''
            else:
                helptext = h_text and '<p>%s</p>' % str(h_text) or ''
        else:
            if length > 30:
                helptext = h_text and '<span><i class=\'icon iconfont icon-xiaoxi\' title=\'%s\'></i></span>' % str(h_text) or ''
            else:
                helptext = h_text and '<span>%s</span>' % str(h_text) or ''
    if field.name!= 'id' and field.field.required:
            lbl = '<font color=\'red\'>*</font>' + field.label_tag()
    f_html = '<th>%s</th><td style='vertical-align:top;'>%s%s%s</td>' % (lbl, field.as_widget(), field.errors and '<ul class=\'errorlist\'>%s</ul>' % ''.join(['<li>%s</li>' % e for e in field.errors]) or '', helptext)
    return f_html
@register.filter
def getStateStr(state, SN=None):
    # irreducible cflow, using cdg fallback
    if state >= 0:
        if state == 2 and SN:
            cmds_count = devcmds.objects.filter(SN=SN).filter(Q(CmdOverTime__isnull=True, CmdTransTime__isnull=True) | Q(CmdOverTime__isnull=True, CmdTransTime__isnull=False, CmdTransTime__gt=datetime.datetime.now() - datetime.timedelta(seconds=1800))).count()
            if cmds_count > 0:
                str = '%s:%s' % ('<span style=\'color:%s ';>%s</span>' % (COLOR_DEV_STATUS[state], get_DEV_STATUS()[int(state)]), cmds_count)
            else:
                str = '<span style=\'color:%s ';>%s</span>' % (COLOR_DEV_STATUS[state], get_DEV_STATUS()[1])
        else:
            str = '<span style=\'color:%s ';>%s</span>' % (COLOR_DEV_STATUS[state], get_DEV_STATUS()[int(state)])
        return str
            pass
            return state
@register.filter
def getRecordState(state):
    if state == None:
        state = ''
    return getRecordName(state)
@register.filter
def getMeetRecordState(state):
    gStatus = GetRecordStatus()
    ret = state
    if state == 'I':
        ret = '%s' % _('Participation sign in')
    else:
        if state == 'O':
            ret = '%s' % _('Participation signing off')
    return ret
@register.filter
def get_params(pName, request=None):
    from mysite.base.sys_view import get_default_value_from_opt_save_fields
    default_value = '0'
    if pName == 'opt_basic_enroll':
        default_value = get_default_value_from_opt_save_fields('basic', 'enroll')
        isEnroll = get_param_value('opt_basic_enroll', default_value)
        if isEnroll == '1':
            return '1'
        else:
            return '0'
    else:
        if pName == 'mod_acc':
            if 'acc' in settings.SALE_MODULE:
                return '1'
            else:
                return '0'
        else:
            if pName == 'opt_email_forgot':
                default_value = get_default_value_from_opt_save_fields('email', 'forgot')
            else:
                if pName == 'acc_param_is':
                    data = loads(get_param_value('acc_param', '{}', 'acc'))
                    if data:
                        return data['is_']
                    else:
                        return 0
                else:
                    if pName == 'opt_ac_options':
                        if 'acc' not in settings.ENABLED_MOD:
                            return '0'
                        else:
                            return '1'
                    else:
                        if pName == 'opt_basic_algversion':
                            default_value = get_default_value_from_opt_save_fields('basic', 'algversion')
                        else:
                            if pName in ['opt_users_rec_pic', 'opt_basic_emp_pic', 'opt_users_vis_pic', 'opt_users_start_page', 'opt_users_allow_popup']:
                                if pName in ['opt_users_start_page']:
                                    default_value = '1'
                                if pName in ['opt_users_rec_pic']:
                                    default_value = '0'
                                default_value = get_param_value(pName, default_value, request.user.id)
                            else:
                                if pName == 'opt_users_download_system':
                                    if settings.DEMO == 1 and (not request.user.is_superuser) and (not request.user.is_anonymous):
                                                return '1'
                                else:
                                    if pName == 'demo_system':
                                        if settings.DEMO == 1 and (request.user.is_superuser or request.user.DelTag == (-1)):
                                                return '1'
                                    else:
                                        if pName == 'DEMO':
                                            if settings.DEMO == 1:
                                                return '1'
                                            else:
                                                return '0'
                                        else:
                                            p = get_param_value(pName, default_value)
                                            if p == 'on':
                                                p = '1'
                                            return p
            return default_value
@register.filter
def get_State_State(value):
    return get_State_States(value)
@register.filter
def getEmpShift(value, flag):
    r = ''
    if flag == 0:
        ru = USER_OF_RUN.objects.filter(UserID=value).order_by('-id')[:1]
        for u in ru:
            r = datetime.datetime.strftime(u.StartDate, '%Y-%m-%d') + ' ' + datetime.datetime.strftime(u.EndDate, '%Y-%m-%d') + ' ' + u.NUM_OF_RUN_ID.Name
    else:
        if flag == 1:
            ru = USER_TEMP_SCH.objects.filter(UserID=value).order_by('-id').exclude(SchclassID__lt=1)[:1]
            for u in ru:
                r = datetime.datetime.strftime(u.ComeTime, '%Y-%m-%d %H:%M') + ' ' + datetime.datetime.strftime(u.LeaveTime, '%Y-%m-%d %H:%M') + ' ' + schName(u.SchclassID)
    return r
@register.filter
def getFlag(id):
    return getFlagValue(id)
@register.filter
def getTimeDept(value):
    u = value
    if u.is_superuser:
        return '%s' % _('All departmental time slots')
    else:
        s = department.objByID(u.AutheTimeDept)
        if not s:
            s = '%s' % _('All public time')
        return s
@register.filter
def getUserCreator(value):
    s = ''
    try:
        users = UserAdmin.objects.filter(owned=value.id, dataname=str(User._meta)).values('user')
        myuser = User.objects.filter(id__in=users)
        if myuser:
            s = myuser[0].username
    except Exception as e:
        print(('getCreator =======', e))
    return s
@register.filter
def getGroupCreator(value):
    s = ''
    try:
        users = UserAdmin.objects.filter(owned=value.id, dataname=str(Group._meta)).values('user')
        myuser = User.objects.filter(id__in=users)
        if myuser:
            s = myuser[0].username
    except Exception as e:
        print(('getGroupCreator =======', e))
    return s
@register.filter
def defaultEx(value):
    if value:
        return value
    else:
        if value is None or value == '':
            return ''
        else:
            return 0
@register.filter
def filteryuanyin(value):
    try:
        value = escape(value)
    except:
        value = ''
    return value
@register.filter
def getWorkAge(value, flag):
    from mysite.personnel.models import Employee
    id = int(value)
    d = datetime.datetime.now()
    ym = flag.GET.get('y', '%s-%s' % (d.year, d.month))
    y_m = ym.split('-')
    months = 1
    days = 1
    d_y_m = datetime.date(int(y_m[0]), months, days)
    e = Employee.objByID(id)
    d_h = e.Hiredday
    if d_h:
        y1 = d_y_m.year
        m1 = d_y_m.month
        y2 = d_h.year
        m2 = d_h.month
        if y1 > y2 or (y1 == y2 and m1 > m2):
            if m1 >= m2:
                m = m1 - m2
                y = y1 - y2
            else:
                m = m1 + 12 - m2
                y = y1 - y2 - 1
            return '%s年' % y
    return ''
@register.filter
def getannual_fading(value, request):
    from mysite.iclock.nomodelview import getannual_f
    day = request.GET.get('y') + '-01'
    return getannual_f(value, day)
@register.filter
def getannual_gongsi(value, request):
    from mysite.iclock.nomodelview import getuserannual
    day = request.GET.get('y') + '-01'
    return getuserannual(value, day)
@register.filter
def GetAnnualleaves_ex(value, day):
    from mysite.iclock.nomodelview import getuserannual
    day = day.strftime('%Y-%m-%d')
    ann_day = getuserannual(value, day)
    ann_leave = LeaveClass.objects.filter(LeaveType=5, DelTag=0).order_by('LeaveID')
    if ann_leave and ann_leave[0].Unit == 1 and ann_day:
        ann = int(ann_day) * 8
    else:
        ann = ann_day
    return ann
@register.filter
def IsSuper(user):
    return user.is_superuser
@register.filter
def showTitle(value):
    try:
        r = userRoles.getallrole()
        return r[value]
    except:
        return value
@register.filter
def device_memo(value):
    dev = value
    s = ''
    if dev.ProductType not in [11, 12, 13]:
        if dev.isFptemp and dev.AlgVer and (dev.AlgVer!= '0') and dev.FWVersion:
                        s += '%s' % _('Fingerprint version:') + dev.AlgVer + ' '
        if dev.isFace and dev.FaceAlgVer and (dev.FaceAlgVer!= '-1') and (dev.FaceAlgVer!= '0'):
                        s += '%s' % _('Face version:') + str(dev.FaceAlgVer) + ' '
        if dev.Authentication == 2:
            s += '%s' % _('combination verification') + ' '
        if hasattr(dev, 'FvFunOn') and dev.FvFunOn == 1 and hasattr(dev, 'FvVersion'):
                    s += '%s' % _('Vein version:') + str(dev.FvVersion) + ' '
        if hasattr(dev, 'PvFunOn') and dev.PvFunOn == 1 and hasattr(dev, 'PvVersion'):
                    s += '%s' % _('Palmprint version:') + str(dev.PvVersion) + ' '
    if dev.pushver:
        s += 'PushVer:' + dev.pushver + ' '
    if dev.Platform:
        s += 'Platform:' + dev.Platform + ' '
    if hasattr(dev, 'mcdu'):
        s += '%s' % _('Flow of the month:') + dev.mcdu + ' '
    if dev.TransTime and dev.TransTime.year!= 2000:
            s += '%s:%s' % (str(_('synchronized personnel')), shortDTime(dev.TransTime))
    return s
@register.filter
def devdn(value):
    id = value.id
    c = IclockDininghall.objects.filter(dining=id).exclude(SN__DelTag=1).count()
    return c
@register.filter
def showprocess(val):
    value = val.process
    if value:
        role = cache.get('%s_userRoles' % get_param_value('ROLEVERSION'))
        if role:
            for r in role:
                if val.roleid == r['roleid']:
                    dd = ',<font color=\'red\'>' + r['roleName'] + '</font>,'
                else:
                    dd = ',' + r['roleName'] + ','
                cc = ',' + str(r['roleid']) + ','
                value = value.replace(cc, dd)
        else:
            role = userRoles.objects.all()
            ll = []
            for r in role:
                l = {}
                l['roleid'] = str(r.roleid)
                l['roleName'] = r.roleName
                ll.append(l)
                if val.roleid == r.roleid:
                    dd = ',<font color=\'red\'>' + r.roleName + '</font>,'
                else:
                    dd = ',' + r.roleName + ','
                cc = ',' + str(r.roleid) + ','
                value = value.replace(cc, dd)
            dt = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
            cache.set('ROLEVERSION', dt)
            cache.set('%s_userRoles' % dt, ll)
        value = value[1:(-1)]
        value = value.replace(',', '--> ')
    else:
        value = ''
    return value
@register.filter
def isModule(value, mod_name):
    return value in mod_name
@register.filter
def isExistModule(mod_name):
    mod_list = mod_name.split(';')
    for t in mod_list:
        if t in settings.SALE_MODULE:
            return True
    return False
@register.filter
def show_ProductType(value):
    if not value:
        return ''
    else:
        if value == 11:
            return str(_('consumer machine'))
        else:
            if value == 12:
                return str(_('Cashier'))
            else:
                if value == 13:
                    return str(_('subsidy machine'))
                else:
                    if value == 9:
                        return str(_('attendance machine'))
                    else:
                        if value == 4:
                            return str(_('Access Control Machine'))
                        else:
                            if value == 5:
                                return str(_('controller'))
                            else:
                                return ''
@register.filter
def show_LastLogStamp(value):
    if not value:
        return ''
    else:
        dev = value
        v = dev.ProductType
        if not v:
            return ''
        else:
            ret = ''
            if v == 11:
                ret = OldDecodeTime(dev.PosLogStamp)[5:]
            else:
                if v == 12:
                    ret = OldDecodeTime(dev.FullLogStamp)[5:]
                else:
                    if v == 13:
                        ret = OldDecodeTime(dev.AllowLogStamp)[5:]
            return ret
@register.filter
def show_LastLogId(value):
    if not value:
        return ''
    else:
        dev = value
        v = dev.ProductType
        if not v:
            return ''
        else:
            ret = ''
            if v == 11:
                ret = dev.PosLogStampId
            else:
                if v == 12:
                    ret = dev.FullLogStampId
                else:
                    if v == 13:
                        ret = dev.AllowLogStampId
            return ret
@register.filter
def get_apb_rule_name(item):
    s = item.get_details()
    return s
@register.filter
def get_interlock_rule_name(item):
    s = item.get_details()
    return s
@register.filter
def filter_config_option(key):
    settings.CARDTYPE = int(get_param_value('ipos_cardtype', 2, 'ipos'))
    if key == 'POS_ID':
        if settings.CARDTYPE == 1:
            return True
    else:
        if key == 'POS_IC':
            if settings.CARDTYPE == 2:
                return True
    return False
@register.filter
def trigcon(id):
    objs = linkage_trigger.objects.filter(linkage=id)
    c = 0
    s = ''
    for t in objs:
        s = s + ' %s' % get_EVENT_CHOICES_name(t.trigger_cond)
        if c > 2:
            break
        else:
            c += 1
    return s
@register.filter
def getclearmoney(sys_card_no, id):
    csz = CardCashSZ.objects.filter(allow_batch=id, sys_card_no=sys_card_no, hide_column=2, allow_type=1)
    if csz:
        if int(get_param_value('ipos_wallets', 0)) == 1:
            return csz[0].money_B
        else:
            return csz[0].money
    else:
        return 0
@register.filter
def AccRecords(item, iflag):
    if iflag == 'card':
        if item.event_no == 6:
            return ''
        else:
            return item.card_no
    else:
        if iflag == 'verify':
            if item.event_no == 6:
                return get_EVENT_CHOICES_name(item.verify)
            else:
                return item.get_verify_display()
        else:
            if iflag == 'point':
                return get_event_point_name(item)
@register.filter
def getEmpLostCard(id, name):
    from mysite.personnel.models import Employee
    e = Employee.objByID(id)
    obj = IssueCard.objects.filter(UserID=e.id, cardstatus=3)
    if obj:
        if name == 'cardno':
            return obj[0].cardno
        else:
            if name == 'sys_card_no':
                return obj[0].sys_card_no
            else:
                if name == 'blance':
                    return obj[0].blance
                else:
                    if name == 'itype':
                        return obj[0].itype
                    else:
                        if name == 'allow_balance':
                            return obj[0].allow_balance
                        else:
                            if name == 'Password':
                                Password = obj[0].Password or '123456'
                                return Password
    return ''
@register.filter
def IsValidLog(value, flag):
    ret = 3
    sPic = ''
    if flag == 'att':
        if value.Reserved and value.Reserved!= '0':
            de_code = decryption(value.Reserved)
            if value.TTime.strftime('%H%M%S%m%d') == de_code:
                ret = 1
            else:
                ret = 0
        else:
            ret = 2
    else:
        ret = 3
    if ret == 1:
        sPic = '%s' % '<img   src=\'../media/img/ok.gif\' style=\'width:20px;height:10px;\'/>'
    else:
        if ret == 0:
            sPic = '%s' % '<img   src=\'../media/img/error.gif\' style=\'width:20px;height:10px;\'/>'
    return sPic
@register.filter
def isDelete(name, value):
    if value == 0:
        return name
    else:
        return name + str(_('(deleted)'))
@register.filter
def isAddIclock(value):
    try:
        dev = getDevice(value.SN)
        return isYesNo(1)
    except:
        return isYesNo(0)
@register.filter
def getFileUrl(item):
    content = ''
    try:
        u = USER_SPEDAY_DETAILS.objects.get(USER_SPEDAY_ID=item)
        if u.file:
            url = '/iclock/file/userSpredyFile/%s' % u.file
            content = '&nbsp;<a  title=\'{}\' onclick=\'getFileDetail(\\\"%s\\\")\'style=\'color:green;\'>{}</a>&nbsp;'.format(str(_('View Upload File')), str(_('File browsing'))) % url
    except:
        return ''
    return content
@register.filter
def get_comkey(SN):
    try:
        dev = getDevice(SN)
    except:
        dev = None
    if dev and hasattr(dev, 'COMKey'):
        return dev.COMKey
    else:
        return ''
@register.filter
def get_records_deptName(item):
    # irreducible cflow, using cdg fallback
    from mysite.personnel.utils import formatPIN
    from mysite.personnel.models import Employee
    if not item.pin or item.pin == '0':
            return ''
            pin = formatPIN(item.pin)
            emp = Employee.objByPIN(pin)
            if emp.Dept():
                deptName = emp.Dept().DeptName
                return deptName
                return ''
@register.filter
def get_cmds_return(item):
    # irreducible cflow, using cdg fallback
    if item.CmdReturn and item.CmdReturn == 0:
        return '0(%s)' % _('Ok')
        if item.Device().ProductType in [5, 15, 25]:
            return pull_CMDName(item.CmdReturn)
            return CMDName(item.CmdReturn)
                return ''
@register.filter
def get_cmds_reserved(item):
    cache_ret = cache.get('%s-%s-%s' % (settings.UNIT, 'cmds', str(item.id)))
    ret_str = ''
    if item.CmdReturn is not None:
        ret_str = '100%'
    if cache_ret:
        rate = int(float(cache_ret['packidx']) / float(cache_ret['packcnt']) * 100)
        ret_str = '%s%(%s:%s)' % (rate, cache_ret['packidx'], cache_ret['packcnt'])
    return ret_str
@register.filter
def templatecount(item):
    from django.db.models.aggregates import Count
    from mysite.iclock.models import devicePIN
    import os
    finger = '0'
    face = '0'
    html = '<img src=\'/media/img/fingerprint.png\' title=\'' + '%s' % _('Number of fingerprints') + '\'><span>%s</span>&nbsp;' + '<img src=\'/media/img/face.png\' title=\'' + '%s' % _('Number of faces') + '\'><span>%s</span>&nbsp;' + '<img src=\'/media/img/fv.png\' title=\'' + '%s' % _('Number of finger veins') + '\'><span>%s</span>&nbsp;' + '<img src=\'/media/img/cphoto.png\' title=\'' + '%s' % _('Comparing photos') + '\'><span>%s</span>&nbsp;'
    bdata = BioData.objects.filter(UserID=item.id, bio_type__in=[1, 2, 7]).values('bio_type').annotate(fcount=Count('UserID')).order_by('bio_type')
    fpcount, fccount, fvcount, adpic = (0, 0, 0, 0)
    for data in bdata:
        if data['bio_type'] == 1:
            fpcount = str(data['fcount'])
        if data['bio_type'] == 2:
            fccount = str(data['fcount'])
        if data['bio_type'] == 7:
            fvcount = str(data['fcount'])
    adfile = settings.FILEPATH + '\\files\\photo\\ad_%s.jpg' % devicePIN(item.PIN)
    if os.path.exists(adfile):
        adpic = 1
    html = html % (fpcount, fccount, fvcount, adpic)
    return html
@register.filter
def get_wallet_type(key):
    # irreducible cflow, using cdg fallback
    ipos_wallet_type = int(get_param_value(key, '0'))
    if ipos_wallet_type == 1:
        return True
        return False
            return False
@register.filter
def hasAdDevice(item):
    from mysite.iclock.models import iclock
    objs = iclock.objects.filter(ProductType=8)
    if objs:
        return True
    else:
        return False
@register.filter(is_safe=True)
@stringfilter
def safe_json(value):
    from django.utils.safestring import mark_safe
    from django.utils.encoding import force_str
    from django.template.defaultfilters import escapejs_filter
    _js_escapes = {ord('\\'): '\\u005C', ord('\''): '\\u0027', ord('\"'): '\\u0022', ord('>'): '\\u003E', ord('<'): '\\u003C', ord('&'): '\\u0026', ord('='): '\\u003D', ord('-'): '\\u002D', ord(';'): '\\u003B', ord('`'): '\\u0060'}
    _js_escapes.update(((ord('%c' % z), '\\u%04X' % z) for z in range(32)))
    return json.dumps(escapejs_filter, ensure_ascii=False, encoding='utf-8')
trans_opt_filter = register.filter(name='trans_opt_filter')(trans_opt)