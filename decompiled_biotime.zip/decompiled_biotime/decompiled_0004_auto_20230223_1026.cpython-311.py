# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\workflow\\migrations\\0004_auto_20230223_1026.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:30 UTC (1750702770)

from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('att', '0014_auto_20230223_1026'), ('workflow', '0003_auto_20221202_1852')]
    operations = [migrations.AddField(model_name='workflowengine', name='is_leave', field=models.BooleanField(choices=[(False, 'workflowNode_scopeOption_ownDepartment'), (True, 'workflowNode_scopeOption_all')], default=False, verbose_name='workflowEngine.field.Leave')), migrations.AddField(model_name='workflowengine', name='leave_type', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='att.PayCode', verbose_name='workflowEngine.field.leaveType')), migrations.AddField(model_name='workflownode', name='to_day', field=models.IntegerField(blank=True, default=0, null=True, verbose_name='workflow.field.toDay'))]