# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\staff\\forms\\leave_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:31 UTC (1750673071)

from django.forms import ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att.models import PayCode
from mysite.att.models.model_paycode import LEAVE
from mysite.personnel.models import Employee
class LeaveForm(forms.ZKActionForm):
    start_time = forms.DateTimeField(label=_('leave_field_startTime'))
    end_time = forms.DateTimeField(label=_('leave_field_endTime'))
    pay_code = ModelChoiceField(label=_('leave.fields.payCode'), queryset=PayCode.objects.filter(code_type=LEAVE))
    apply_reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    leave_day = forms.FloatField(label=_('leave.fields.leaveDay'), initial=0, suffix=_('time.units.day'))
class EmployeeLeaveGetForm(forms.ZKActionForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset(), disabled=True)
    pay_code = forms.ModelChoiceField(label=_('leave.fields.payCode'), queryset=PayCode.objects.get_leave_queryset())
    start_time = forms.DateTimeField(label=_('leave_field_startTime'))
    end_time = forms.DateTimeField(label=_('leave_field_endTime'))
    apply_reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    leave_day = forms.FloatField(label=_('leave.fields.leaveDay'), initial=0, suffix=_('time.units.day'))
    def __init__(self, request, *args, **kwargs):
        from mysite.att.models import PayloadTimeCard
        import datetime
        super(EmployeeLeaveGetForm, self).__init__(*args, **kwargs)
        emp_id = request.GET.get('emp_id', None)
        att_date = request.GET.get('att_date', None)
        timetable_id = request.GET.get('timetable_id', None)
        if not timetable_id:
            timetable_id = None
        if att_date:
            att_date = datetime.datetime.strptime(att_date, '%Y-%m-%d')
        if not emp_id:
            return
        else:
            obj = PayloadTimeCard.objects.filter(emp_id=emp_id, att_date=att_date, time_table_id=timetable_id).first()
            if not obj:
                return
            else:
                self.fields['employee'].queryset = Employee.objects.filter(id=emp_id)
                self.fields['employee'].initial = obj.emp
                self.fields['start_time'].initial = obj.check_in
                self.fields['end_time'].initial = obj.check_out
class EmployeeLeavePostForm(EmployeeLeaveGetForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset())