# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\email_template_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import os
from xml.etree.ElementTree import parse
from mysite import admin
from mysite.admin import ZKModelAdmin
from mysite.base import DATA_ROOT
from mysite.base.models import EmailTemplate
@admin.register(EmailTemplate)
class EmailTemplateAdmin(ZKModelAdmin):
    @staticmethod
    def initial_data():
        if EmailTemplate.objects.all().count() == 0:
            doc = parse(os.path.join(DATA_ROOT, 'email_templates.xml'))
            for record in doc.iterfind('record'):
                kwargs = dict([(field.get('name'), field.text) for field in record.iterfind('field')])
                EmailTemplate(**kwargs).save(force_insert=True)