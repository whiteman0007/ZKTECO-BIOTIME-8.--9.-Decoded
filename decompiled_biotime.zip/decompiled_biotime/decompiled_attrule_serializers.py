# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\attrule_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models.model_attrule import AttRule
from mysite.att.api.serializers import util_serializers
class AttRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttRule
        fields = '__all__'
class AttRuleCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttRule
        fields = '__all__'
class AttRuleEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttRule
        fields = '__all__'
class AttRuleActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AttRule
        action_type_choices = (('delete', 'delete'),)