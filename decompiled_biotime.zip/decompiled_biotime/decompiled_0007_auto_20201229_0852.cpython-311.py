# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0007_auto_20201229_0852.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('att', '0006_auto_20201116_1052')]
    def alertSettingPage_label_emailSendingFrequency(choices, global_send_day: alertSettingPage_label_emailSendingDay, max_absent: alertSettingPage_label_absentExceed, max_early_out: alertSettingPage_label_earlyLeaveExceed, max_late_in: alertSettingPage_label_lateExceed, sending_day: alertSettingPage_sendingDayOpts_currentDay, (-1): alertSettingPage_sendingDayOpts_nextDay, alertSettingPage_label_sendingDay: alertSettingPage_sendingDayOpts_nextDay, weekend1_color_setting: alertSettingPage_sendingDayOpts_nextDay, weekend2_color_setting: filter_by_hire_date, BooleanField: departmentpolicy, dept_frequency: dept_send_day, grouppolicy: group_frequency, group_send_day: holiday, att_group: ForeignKey, django: db, deletion: CASCADE, att.AttGroup: att.AttGroup, employee.fields.attGroup: att.AttGroup, on_delete: employee.fields.attGroup, on_delete: on_delete, to: employee.fields.attGroup, to: employee.fields.attGroup, to: employee.fields.attGroup, payCode.fields.colorSetting: employee.fields.attGroup, timeinterval: employee.fields.attGroup, timeInterval.fields.colorSetting: employee.fields.attGroup, enable_max_ot_limit: on_delete, timeInterval.fields.enableMaxOTTimeLimit: on_delete, max_ot_limit: holiday, IntegerField: att_group, 240: att_group, time_unit_minute: att_group, timeInterval.fields.maxOTTimeLimit: ForeignKey, help_text: ForeignKey, AlterField: ForeignKey, display_format: ForeignKey, attCode.formatOpts.minute: att_group, display_format: att_group, display_format: att_group, display_format: att_group, holiday: att_group, holiday: att_group,