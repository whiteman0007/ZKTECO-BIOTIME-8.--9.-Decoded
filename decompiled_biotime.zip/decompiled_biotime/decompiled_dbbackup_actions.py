# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\actions\\dbbackup_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:03 UTC (1750672983)

import datetime
import os
import re
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from mysite.admin import ZKModelAction, forms
from mysite.admin.action import ActionHandleError
from mysite.base.db_const import DATABASE, EXPORT_FREQUENCY, MONTHLY_DAYS
from mysite.base.models import DBBackupLog
from mysite.base.const import BACKUP_ENCRYPTION_CHOICE, BACKUP_ENCRYPTION_DEFAULT, USER_DEFINE_PASSWORD
from mysite.tools.encryption_utils import aes_decrypt
exp = '^[a-zA-Z]:[\\\\/]([\\w@#$%&()-\\.]*[\\\\/]?)+$'
class DBBackupForm(forms.ZKActionForm):
    db_type = forms.ChoiceField(label=_('dbBackupLog_field_type'), initial=settings.DATABASE_ENGINE, choices=DATABASE, disabled=True)
    db_name = forms.CharField(label=_('dbBackupLog_field_name'), initial=settings.DATABASE_NAME, disabled=True)
    file_path = forms.CharField(label=_('dbBackupLog_field_filePath'))
    frequency = forms.ChoiceField(label=_('dbBackupLog_field_frequency'), choices=EXPORT_FREQUENCY, initial=1)
    point_day = forms.ChoiceField(label=_('dbBackupLog_field_pointDay'), choices=MONTHLY_DAYS, initial=1)
    point_time = forms.TimeField(label=_('dbBackupLog_field_pointTime'), initial='01:00')
    is_backup_photo = forms.BooleanField(label=_('dbBackupLog_field_isBackupPhoto'), required=False)
    enabled = forms.BooleanField(label=_('emailSettingPage_label_emailEnable'), required=False, initial=True)
    backup_encryption_choices = forms.ChoiceField(label=_('backup.fields.exportEncryption'), choices=BACKUP_ENCRYPTION_CHOICE, initial=BACKUP_ENCRYPTION_DEFAULT)
    auto_backup_password = forms.PasswordField(label=_('user_field_password'), required=False)
    def __init__(self, *args, **kwargs):
        super(DBBackupForm, self).__init__(*args, **kwargs)
        self.fields['file_path'].initial = settings.DATABASE_BACKUP_PATH
class DBBackupAuto(ZKModelAction):
    verbose_name = _('dbBackupLog_action_dbBackupAuto')
    action_form = DBBackupForm
    verify_password = True
    def action(self, *args, **kwargs):
        import json
        from mysite.base.models import SystemSetting
        file_path = kwargs.get('file_path', '')
        backup_choices = kwargs.get('backup_encryption_choices', '')
        backup_password = kwargs.get('auto_backup_password')
        if not file_path:
            raise ActionHandleError(_('database.backup.error.invalidPath'))
        else:
            if ':' in file_path and (not re.match(exp, file_path)):
                raise ActionHandleError(_('database.backup.error.invalidPath'))
            else:
                if backup_choices == USER_DEFINE_PASSWORD:
                    if not backup_password:
                        raise ActionHandleError(_('database.backup.password.cannot.empty'))
                else:
                    file_path = os.path.join(settings.DATABASE_BACKUP_PATH, file_path)
                if not os.path.exists(file_path):
                    try:
                        os.makedirs(file_path)
                    except Exception as e:
                        return str(e)
                obj = SystemSetting.objects.filter(name='db_backup').first()
                if not obj:
                    obj = SystemSetting(name='db_backup', value=json.dumps(kwargs))
                    obj.save(force_insert=True)
                else:
                    obj.value = json.dumps(kwargs)
                    obj.save(force_update=True)
class DBBackupManuallyForm(forms.ZKActionForm):
    file_path = forms.CharField(label=_('dbBackupLog_field_filePath'))
    is_backup_photo = forms.BooleanField(label=_('dbBackupLog_field_isBackupPhoto'), required=False)
    backup_encryption_choices = forms.ChoiceField(label=_('backup.fields.exportEncryption'), choices=BACKUP_ENCRYPTION_CHOICE, initial=BACKUP_ENCRYPTION_DEFAULT)
    auto_backup_password = forms.PasswordField(label=_('user_field_password'), required=False)
    def __init__(self, *args, **kwargs):
        super(DBBackupManuallyForm, self).__init__(*args, **kwargs)
        self.fields['file_path'].initial = settings.DATABASE_BACKUP_PATH
class DBBackupManually(ZKModelAction):
    verbose_name = _('dbBackupLog_action_dbBackupManually')
    action_form = DBBackupManuallyForm
    verify_password = True
    def action(self, *args, **kwargs):
        from mysite.base.models import SecurityPolicy
        from mysite.base.database_backup import backup
        from django.conf import settings
        set_file_path = kwargs.get('file_path', None)
        file_path = kwargs.get('file_path', None)
        is_backup_photo = kwargs.get('is_backup_photo', False)
        backup_choices = kwargs.get('backup_encryption_choices')
        backup_password = kwargs.get('auto_backup_password')
        if not file_path:
            return
        else:
            if ':' in file_path:
                if not re.match(exp, file_path):
                    raise ActionHandleError(_('database.backup.error.invalidPath'))
            else:
                file_path = os.path.join(settings.DATABASE_BACKUP_PATH, file_path)
            if not os.path.exists(file_path):
                try:
                    os.makedirs(file_path)
                except Exception as e:
                    print(str(e))
                    raise ActionHandleError(_('database.backup.error.invalidPath'))
            if backup_choices == USER_DEFINE_PASSWORD and (not backup_password):
                raise ActionHandleError(_('database.backup.password.cannot.empty'))
            else:
                backup_data = SecurityPolicy.default()
                buckup_info = {'global_backup_set': backup_data.backup_encryption, 'global_password': aes_decrypt(backup_data.backup_encryption_password) if backup_data.backup_encryption_password else '', 'auto_backup_encryption': backup_choices, 'auto_backup_password': backup_password}
                stamp, file_name = backup(file_path, buckup_info, is_backup_photo)
                operator = self.request.user.get_username()
                complete_path = os.path.join(set_file_path, file_name)
                DBBackupLog(db_type=settings.DATABASE_ENGINE, db_name=settings.DATABASE_NAME, operator=operator, backup_file=complete_path, backup_time=stamp, remark=str(self.verbose_name)).save(force_insert=True)
class DBRestoreManuallyForm(forms.ZKActionForm):
    db_name = forms.CharField(label=_('dbBackupLog_field_name'))
    backup_file = forms.CharField(label=_('dbBackupLog_field_backupFile'))
    password = forms.PasswordField(label=_('user_field_password'), required=False)
    is_restore_photo = forms.BooleanField(label=_('dbBackupLog_field_isRestorePhoto'), required=False, initial=True)
    sync_to_service_console = forms.BooleanField(label=_('dbBackuplog.field.syncToServiceConsole'), required=False, initial=False)
class DBRestoreManually(ZKModelAction):
    verbose_name = _('dbBackupLog_action_dbRestoreManually')
    action_form = DBRestoreManuallyForm
    verify_password = True
    def action(self, *args, **kwargs):
        from mysite.base.database_backup import restore
        from mysite.base.database_backup import db_file_decrypt
        photo_path = ''
        flag = False
        db_name = kwargs.get('db_name', None)
        bak_path = kwargs.get('backup_file', None)
        backup_file = bak_path
        pwd = kwargs.get('password')
        is_restore_photo = kwargs.get('is_restore_photo', False)
        sync_to_service_console = kwargs.get('sync_to_service_console', False)
        if not db_name and (not bak_path):
                return
        file_path, file_name = os.path.split(bak_path)
        if re.search('zip', file_name):
            if not pwd:
                raise ActionHandleError(_('database.backup.password.not.found'))
            else:
                bak_path, photo_path = db_file_decrypt(file_path, bak_path, pwd)
                flag = True
        restore(db_name, bak_path, flag, photo_path, need_restore_photo=is_restore_photo, sync_to_service_console=sync_to_service_console)
        stamp = datetime.datetime.now()
        operator = self.request.user.get_username()
        DBBackupLog(db_type=settings.DATABASE_ENGINE, db_name=db_name, operator=operator, backup_file=backup_file, backup_time=stamp, remark=str(self.verbose_name)).save(force_insert=True)