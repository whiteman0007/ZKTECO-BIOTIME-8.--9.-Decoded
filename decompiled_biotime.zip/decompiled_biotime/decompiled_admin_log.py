# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\models\\admin_log.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:25 UTC (1750673005)

from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from mysite import settings
from mysite.base import db_const
STATUS = (((-1), _('actionStatus_option_fail')), (0, _('actionStatus_option_success')))
class AdminLog(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name=_('adminLog_field_user'), on_delete=models.CASCADE)
    action = models.CharField(verbose_name=_('adminLog_field_action'), max_length=db_const.MAX_ACTION_NAME)
    content_type = models.ForeignKey(ContentType, models.SET_NULL, verbose_name=_('adminLog_field_contentType'), blank=True, null=True)
    targets = models.TextField(_('adminLog_field_objects'), null=True, blank=True)
    targets_repr = models.TextField(_('adminLog_field_objects'), default='', null=True, blank=True)
    action_status = models.SmallIntegerField(verbose_name=_('adminLog_field_actionStatus'), default=0, choices=STATUS)
    description = models.TextField(verbose_name=_('adminLog_field_description'), default='', blank=True, null=True)
    ip_address = models.GenericIPAddressField(verbose_name=_('adminLog_field_ipAddress'), default='', null=True, blank=True)
    can_routable = models.BooleanField(_('adminLog_field_routable'), default=False, blank=True)
    op_time = models.DateTimeField(verbose_name=_('adminLog_field_operationTime'))
    def save(self, *args, **kwargs):
        """ On save, auto-save timestamps """
        if not self.pk:
            self.op_time = timezone.now()
        return super(AdminLog, self).save(*args, **kwargs)
    class Meta:
        default_permissions = ('view',)
        app_label = db_const.APP_LABEL
        verbose_name = _('base.models.adminLog')
        verbose_name_plural = verbose_name