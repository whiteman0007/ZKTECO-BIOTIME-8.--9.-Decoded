# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\models\\auto_att_export.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:25 UTC (1750673005)

import json
from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.admin.models import BaseModel
from mysite.base.db_const import MAX_AUTO_EXPORT_CODE, MAX_AUTO_EXPORT_NAME
class AutoAttExportTask(BaseModel):
    task_code = models.CharField(_('autoAttExportTask_field_code'), unique=True, max_length=MAX_AUTO_EXPORT_CODE)
    task_name = models.CharField(_('autoAttExportTask_field_name'), max_length=MAX_AUTO_EXPORT_NAME)
    params = models.TextField(_('autoExportTask_field_params'), null=True, blank=True)
    enable = models.BooleanField(_('autoExport.fields.enable'), default=True)
    process_time = models.DateTimeField(_('autoExport.fields.processTime'), null=True, blank=True)
    def __str__(self):
        return '{code} {name}'.format(code=self.task_code, name=self.task_name)
    def __init__(self, *args, **kwargs):
        super(AutoAttExportTask, self).__init__(*args, **kwargs)
        if not self.params:
            self.options = {}
        else:
            from mysite.base.api.serializers import AutoExportReportOptionReadableSerializer
            serializer = AutoExportReportOptionReadableSerializer(data=self.get_options())
            serializer.is_valid()
            self.options = serializer.validated_data
    def get_options(self):
        if not self.params:
            return {}
        else:
            options = json.loads(self.params)
            if 'export_encryption_type' not in options:
                options['export_encryption_type'] = 0
                options['export_encryption_password'] = ''
            return options
    def report_type(self):
        return self.options.get('report_type', '')
    report_type.short_description = _('autoExport_task_report_type')
    def export_by(self):
        return self.options.get('export_policy', '')
    export_by.short_description = _('autoExport_task_export_by')
    def export_file(self):
        return self.options.get('file_prefix', '')
    export_file.short_description = _('autoExport_task_filePrefix')
    def export_format(self):
        return self.options.get('export_format', '')
    export_format.short_description = _('autoExport_task_exportFormat')
    def report_template(self):
        t = self.options.get('report_template', '')
        if not t:
            return ''
        else:
            return t.template_name
    report_template.short_description = _('autoExport_task_report_template')
    def recipient_email(self):
        return self.options.get('export_email', '')
    recipient_email.short_description = _('autoExport_task_exportEmail')
    class Meta:
        app_label = 'base'
        verbose_name = _('base_model_autoAttExportTask')
        verbose_name_plural = verbose_name