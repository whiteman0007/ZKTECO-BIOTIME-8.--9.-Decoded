# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\leave_group_config.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
import json
from dateutil import parser
from django.db.models import Q
from mysite.att.config_leave_group import default_leave_days
from mysite.att.models import LeaveGroupDetail, LeaveYearBalance, Leave
from mysite.att.models_choices import UNLIMITED_LEAVE, ONE_TIME_LEAVE, COMPENSATORY_LEAVE, FIXED_QUOTA, BASED_ON_SERVICE
from mysite.personnel.models import Employee
from mysite.utils import get_dt4mssql
from mysite.workflow.models_choices import APPROVED, REVOKE
class LeaveGroupConfig(object):
    """"""
    def __init__(self, employee: Employee, groupDetail: LeaveGroupDetail):
        self.employee = employee
        self.hireDate = get_dt4mssql(employee.hire_date, 1)
        self.groupDetail = groupDetail
        self.config_startDay = parser.parse('{0}-{1}'.format(2000, groupDetail.start_day)) if groupDetail.leave_type in (FIXED_QUOTA, BASED_ON_SERVICE) else datetime.datetime.now().date()
    def get_leave_entitlement(self, end_date: datetime.datetime, period_year: int=None, period_start: datetime.datetime=None) -> int:
        if self.groupDetail.leave_type in (COMPENSATORY_LEAVE, BASED_ON_SERVICE):
            if period_year is None or period_start is None:
                period_year, period_start, period_end = get_period(self, end_date)
            if self.groupDetail.leave_type == COMPENSATORY_LEAVE:
                from mysite.att.models import PayloadPayCode
                from mysite.att.const import CP
                compensatory_hours = sum(PayloadPayCode.objects.filter(pay_code__fixed_code=CP, emp=self.employee, att_date__lt=end_date, att_date__year=period_year).values_list('hours', flat=True))
                return compensatory_hours
            else:
                start_day = self.hireDate if self.groupDetail.set_hire_day == 1 else self.config_startDay
                service_start_date = to_datetime(year=self.hireDate.year, month=start_day.month, day=start_day.day)
                _end_date = end_date - datetime.timedelta(days=1)
                years = ((_end_date.year - service_start_date.year) * 12 + (_end_date.month - service_start_date.month)) // 12
                if years < 0:
                    return 0
                else:
                    if self.groupDetail.leave_distribution_time:
                        if years == 0:
                            years = 1 if period_start.date() >= self.hireDate else 0
                    else:
                        if self.hireDate < period_start.date():
                            years += 1
                        else:
                            if period_start.date() <= self.hireDate and _end_date.year == period_start.year:
                                    years = 1
                    if years > 0:
                        entitlement = 0
                        entitlement_detail = json.loads(self.groupDetail.entitlement_detail.replace('\'', '\"'))
                        for detail_i in entitlement_detail:
                            if years in range(detail_i['seniority_start'], detail_i['seniority_end'] + 1):
                                entitlement = int(detail_i['entitlement_days']) if detail_i['entitlement_days'] else 0
                        if years == 1 and (not self.groupDetail.set_hire_day) and (not self.groupDetail.leave_distribution_time):
                                    distribution_date = to_datetime(period_year, start_day.month, start_day.day) + datetime.timedelta(days=(-1))
                                    distribution_day = (entitlement * ((distribution_date - to_datetime(self.hireDate.year, self.hireDate.month, self.hireDate.day) + datetime.timedelta(days=1)) / 365)).days
                                    entitlement += distribution_day if distribution_day < 0 else 0
                        return entitlement
                    else:
                        return 0
        else:
            if self.groupDetail.leave_type == FIXED_QUOTA:
                return self.groupDetail.leave_entitlement
            else:
                if self.groupDetail.leave_type == ONE_TIME_LEAVE:
                    return self.groupDetail.leave_entitlement
                else:
                    if self.groupDetail.leave_type == UNLIMITED_LEAVE:
                        return 999
                    else:
                        return 0
def calculate_specific_leave_balance(config: LeaveGroupConfig, end_time: datetime.datetime):
    """"""
    end_date = datetime.datetime(end_time.year, end_time.month, end_time.day)
    period_year, period_start, period_end = get_period(config, end_date)
    if not period_year or not period_start:
        return {}
    else:
        pre_year_balance = LeaveYearBalance.objects.filter(year=period_year - 1, employee=config.employee, pay_code=config.groupDetail.pay_code).first()
        pre = {'pre_balance': pre_year_balance.pre_balance if pre_year_balance else 0, 'pre_exceed': pre_year_balance.pre_exceed if pre_year_balance else 0, 'entitlement_days': pre_year_balance.entitlement_days if pre_year_balance else 0, 'leave_day': pre_year_balance.leave_day if pre_year_balance else 0}
        pre['exceed_leave_day'] = max(pre['leave_day'] + pre['pre_exceed'] - pre['entitlement_days'] - pre['pre_balance'], 0)
        pre_remaining = 0
        if config.groupDetail.leave_type in (COMPENSATORY_LEAVE, FIXED_QUOTA, BASED_ON_SERVICE):
            if pre['exceed_leave_day'] > 0:
                if config.groupDetail.leave_type in (FIXED_QUOTA, BASED_ON_SERVICE) and config.groupDetail.allow_exceed_limit:
                        pre_remaining = -pre['exceed_leave_day']
            else:
                if config.groupDetail.leave_type in (COMPENSATORY_LEAVE, BASED_ON_SERVICE):
                    if config.groupDetail.allow_balance:
                        pre_remaining = pre['entitlement_days'] + pre['pre_balance'] - pre['leave_day'] - pre['pre_exceed']
                        pre_remaining = min(pre_remaining, config.groupDetail.max_balance)
        entitlement_days = config.get_leave_entitlement(end_date, period_year, period_start)
        year_balance = LeaveYearBalance(employee=config.employee, year=period_year, pre_balance=pre_remaining if pre_remaining > 0 else 0, entitlement_days=entitlement_days, pay_code=config.groupDetail.pay_code, leave_type=config.groupDetail.leave_type)
        def update_balance(leave_obj: Leave):
            # irreducible cflow, using cdg fallback
            if leave_obj.start_time < period_start < leave_obj.end_time:
                    leave_day_pre = default_leave_days(leave_obj.start_time, period_start, config.employee, config.groupDetail.pay_code)
                    leave_day_cur = default_leave_days(period_start, leave_obj.end_time, config.employee, config.groupDetail.pay_code)
                    leave_time_range = [[leave_obj.start_time, period_start], [period_start, leave_obj.end_time], []]
                    if leave_obj.start_time < end_date < leave_obj.end_time:
                            leave_day_cur = default_leave_days(leave_obj.start_time, end_time, config.employee, config.groupDetail.pay_code)
                            leave_day_next = default_leave_days(end_date, leave_obj.end_time, config.employee, config.groupDetail.pay_code)
                            leave_time_range = [[], [leave_obj.start_time, end_date], [end_date, leave_obj.end_time]]
                            leave_day_cur = default_leave_days(leave_obj.start_time, leave_obj.end_time, config.employee, config.groupDetail.pay_code)
                            leave_time_range = [[], [leave_obj.start_time, leave_obj.end_time], []]
            if leave_obj.approval_status == APPROVED:
                if config.groupDetail.leave_type == ONE_TIME_LEAVE:
                    year_balance.leave_day = config.groupDetail.leave_entitlement
                else:
                    year_balance.leave_day += leave_day_cur
        leaves = Leave.objects.filter(employee=config.employee, pay_code=config.groupDetail.pay_code, approval_status=APPROVED).order_by('start_time')
        leaves = leaves.filter(Q(start_time__gte=period_start, start_time__lt=end_date) | Q(end_time__gt=period_start, end_time__lte=end_date))
        if leaves.exists():
            for obj in leaves:
                update_balance(obj)
        return {'pre_balance': year_balance.pre_balance, 'leave_type': year_balance.leave_type, 'all_leave_day': year_balance.entitlement_days, 'used_leave_day': year_balance.leave_day, 'left_leave_day': max(pre_remaining + year_balance.entitlement_days - year_balance.leave_day, 0), 'allow_exceed_limit': config.groupDetail.allow_exceed_limit, 'period_year': year_balance.year}
def to_datetime(year: int, month: int, day: int) -> datetime.datetime:
    try:
        return datetime.datetime(year, month, day)
    except Exception as e:
        if month == 2 and day == 29:
            return datetime.datetime(year, 2, 28)
        else:
            raise e
def get_period(config: LeaveGroupConfig, end_date: datetime.datetime) -> tuple[int, datetime.datetime, datetime.datetime]:
    """"""
    _end_date = end_date - datetime.timedelta(days=1)
    period_year = None
    period_start = None
    period_end = None
    if config.groupDetail.leave_type == UNLIMITED_LEAVE:
        period_year = _end_date.year
        period_start = datetime.datetime(period_year, 1, 1)
        period_end = datetime.datetime(period_year + 1, 1, 1)
    else:
        if config.groupDetail.leave_type == ONE_TIME_LEAVE:
            period_year = _end_date.year
            period_start = datetime.datetime(period_year, 1, 1)
            period_end = datetime.datetime(period_year + 1, 1, 1)
        else:
            if config.groupDetail.leave_type == COMPENSATORY_LEAVE:
                period_year = _end_date.year
                period_start = datetime.datetime(period_year, 1, 1)
                period_end = datetime.datetime(period_year + 1, 1, 1)
            else:
                if config.groupDetail.leave_type == FIXED_QUOTA:
                    start_day = config.config_startDay
                    _start_day = datetime.datetime(_end_date.year, start_day.month, start_day.day)
                    if _start_day < end_date:
                        period_year = _end_date.year
                    else:
                        period_year = _end_date.year - 1
                    period_start = to_datetime(period_year, start_day.month, start_day.day)
                    period_end = to_datetime(period_year + 1, start_day.month, start_day.day)
                else:
                    if config.groupDetail.leave_type == BASED_ON_SERVICE:
                        start_day = config.hireDate if config.groupDetail.set_hire_day == 1 else config.config_startDay
                        _start_day = datetime.datetime(_end_date.year, start_day.month, start_day.day)
                        if _start_day < end_date:
                            period_year = _end_date.year
                        else:
                            period_year = _end_date.year - 1
                        period_start = to_datetime(period_year, start_day.month, start_day.day)
                        period_end = to_datetime(period_year + 1, start_day.month, start_day.day)
    return (period_year, period_start, period_end)