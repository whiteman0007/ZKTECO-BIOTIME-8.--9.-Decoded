# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\forms\\depatttrule_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

from django.forms import ModelForm, ValidationError
from django.utils.translation import gettext_lazy as _
from mysite.att.models import DeptAttRule
class DeptAttRuleCreationForm(ModelForm):
    class Meta:
        model = DeptAttRule
        fields = '__all__'
    def clean(self):
        cleaned_data = super(DeptAttRuleCreationForm, self).clean()
        if 'department' in list(cleaned_data.keys()):
            departments = cleaned_data['department']
            for i in departments:
                rule_list = i.deptattrule_set.all()
                if rule_list and rule_list[0]!= self.instance:
                    raise ValidationError(_('One or more department already has its own rules.'), code='-1')
        return cleaned_data