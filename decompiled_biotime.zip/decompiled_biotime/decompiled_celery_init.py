# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\celery_init.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

import os
from celery import Celery
from celery.utils.log import get_task_logger
from django.conf import settings
class CeleryExtend(Celery):
    """"""
    def task(self, *args, **opts):
        if 'expires' not in opts:
            opts.update({'expires': 604800})
        return super().task(*args, **opts)
    def send_task(self, name, args=None, kwargs=None, countdown=None, eta=None, task_id=None, producer=None, connection=None, router=None, result_cls=None, expires=None, publisher=None, link=None, link_error=None, add_to_parent=True, group_id=None, group_index=None, retries=0, chord=None, reply_to=None, time_limit=None, soft_time_limit=None, root_id=None, parent_id=None, route_name=None, shadow=None, chain=None, task_type=None, **options):
        """Send task by name.\n\n        Supports the same arguments as :meth:`@-Task.apply_async`.\n\n        Arguments:\n            name (str): Name of task to call (e.g., `\"tasks.add\"`).\n            result_cls (AsyncResult): Specify custom result class.\n        """
        import warnings
        from celery.exceptions import AlwaysEagerIgnored
        from celery.utils.time import maybe_make_aware
        from datetime import datetime
        from kombu.utils import maybe_list
        from kombu import uuid
        from mysite.tools.redis_utils import celery_worker_redis
        parent = have_parent = None
        amqp = self.amqp
        task_id = task_id or uuid()
        producer = producer or publisher
        router = router or amqp.router
        conf = self.conf
        if conf.task_always_eager:
            warnings.warn(AlwaysEagerIgnored('task_always_eager has no effect on send_task'), stacklevel=2)
        ignore_result = options.pop('ignore_result', False)
        options = router.route(options, route_name or name, args, kwargs, task_type)
        if expires is not None:
            if isinstance(expires, datetime):
                expires_s = (maybe_make_aware(expires) - self.now()).total_seconds()
            else:
                expires_s = expires
            if expires_s < 0:
                logger.warning(f'{task_id} has an expiration date in the past ({-expires_s}s ago).\nWe assume this is intended and so we have set the expiration date to 0 instead.\nAccording to RabbitMQ\'s documentation:\n\"Setting the TTL to 0 causes messages to be expired upon reaching a queue unless they can be delivered to a consumer immediately.\"\nIf this was unintended, please check the code which published this task.')
                expires_s = 0
            options['expiration'] = expires_s
        if not root_id or not parent_id:
            parent = self.current_worker_task
            if parent:
                if not root_id:
                    root_id = parent.request.root_id or parent.request.id
                if not parent_id:
                    parent_id = parent.request.id
                if conf.task_inherit_parent_priority:
                    options.setdefault('priority', parent.request.delivery_info.get('priority'))
        message = amqp.create_task_message(task_id, name, args, kwargs, countdown, eta, group_id, group_index, expires, retries, chord, maybe_list(link), maybe_list(link_error), reply_to or self.thread_oid, time_limit, soft_time_limit, self.conf.task_send_sent_event, root_id, parent_id, shadow, chain, ignore_result=ignore_result, argsrepr=options.get('argsrepr'), kwargsrepr=options.get('kwargsrepr'))
        if connection:
            producer = amqp.Producer(connection, auto_declare=False)
        with self.producer_or_acquire(producer) as P, P.connection._reraise_as_library_errors():
                if not ignore_result:
                    self.backend.on_task_call(P, task_id)
                serializer = options.get('serializer') or amqp.app.conf.task_serializer
                compression = options.get('compression') or amqp.app.conf.result_compression
                compression = P.compression if compression is None else compression
                headers = {} if message.headers is None else message.headers
                body, content_type, content_encoding = P._prepare(message.body, serializer, message.properties.get('content_type'), message.properties.get('content_encoding'), compression, headers)
                from base64 import standard_b64encode
                from django.utils.encoding import force_str
                body_str = force_str(standard_b64encode(body))
                routing_key = getattr(options.get('queue') or 1, 'routing_key')
                _task_id = celery_worker_redis.check_unique(routing_key, body_str)
                if _task_id:
                    task_id = _task_id
                else:
                    amqp.send_task_message(P, name, message, **options)
        result = (result_cls or self.AsyncResult)(task_id)
        result.ignored = ignore_result
        if add_to_parent:
            if not have_parent:
                parent, have_parent = (self.current_worker_task, True)
            if parent:
                parent.add_trail(result)
        return result
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')
app = CeleryExtend('mysite')
logger = get_task_logger(__name__)
app.config_from_object('mysite.celeryconfig')
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)
@app.task(bind=True, name='debug_task')
def debug_task(self, *args, **kwargs):
    print((args, kwargs))
    logger.info('Request: {0!r}'.format(self.request))
@app.task(bind=True, name='debug_queue_task')
def debug_queue_task(self, *args, **kwargs):
    return