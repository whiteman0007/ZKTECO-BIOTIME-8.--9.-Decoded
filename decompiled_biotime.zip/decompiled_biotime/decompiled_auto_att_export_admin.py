# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\auto_att_export_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin.action import ActionTuple
from mysite.admin.kernel import ZKModelAdmin
from mysite.base import actions as aac
from mysite.base.actions import ManualAttExport
from mysite.base.forms import AutoAttExportTaskCreationForm
from mysite.base.models import AutoAttExportTask
@admin.register(AutoAttExportTask)
class AutoAttExportTaskAdmin(ZKModelAdmin):
    list_display = ['task_code', 'task_name', 'report_type', 'report_template', 'export_file', 'export_format', 'export_by', 'enable', 'process_time']
    sort_fields = []
    list_filter = ['task_code', 'task_name']
    form = AutoAttExportTaskCreationForm
    actions = [ManualAttExport]
    action_sets = (ActionTuple(_('op_menu_group_task_status'), (aac.EnableTask, aac.DisableTask)),)