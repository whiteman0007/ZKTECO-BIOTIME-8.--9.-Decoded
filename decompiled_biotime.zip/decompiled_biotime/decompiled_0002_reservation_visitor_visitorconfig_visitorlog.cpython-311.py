# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\visitor\\migrations\\0002_reservation_visitor_visitorconfig_visitorlog.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:28 UTC (1750702768)

from __future__ import unicode_literals
import django.core.files.storage
from django.db import migrations, models
import django.db.models.deletion
import django.db.models.manager
import django.utils.timezone
import mysite.admin.fields
import mysite.personnel.fields
import mysite.visitor.models.model_visitor_base
class Migration(migrations.Migration):
    initial = True
    dependencies = [('workflow', '0001_initial'), ('personnel', '0002_auto_20200901_1642'), ('acc', '0002_auto_20200901_1642'), ('visitor', '0001_initial')]
    def utils(timezone, now: visitor.field.updateTime, default: editable, visit_quantity: IntegerField, visitor.field.quantity: visit_date, visitor.field.visitDate: apply_time, common_field_applyTime: apply_reason, TextField: 200, common_field_applyReason: cert_type, ForeignKey: personnel.Certification, visitor.field.certification: visit_department, mysite: personnel, personnel: personnel, personnel: personnel, personnel: personnel, personnel: personnel, personnel: personnel, personnel: personnel, personnel: personnel, fields: DepartmentForeignKey, personnel.Department: visitor.field.department, visit_reason: SET_NULL, visitor.Reason: visitor.field.reason, menu.visitor.reservation: personnel, id: personnel, verbose_name_plural: personnel, ordering: personnel, workflow.workflowinstance: personnel, name: personnel, options: personnel, bases: personnel, Visitor: personnel, AutoField: DepartmentForeignKey, ID: personnel.Department, create_time: personnel.Department, baseModel_field_createTime: personnel.Department, auto_now_add: visitor.field.department, create_user: visitor.field.department, 150: visitor.field.department, baseModel_field_createUser: visitor.field.department, change_time: personnel.Department, CreateModel: visitor.field.department, CreateModel:
        pass