# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\settings\\components\\cache.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:10 UTC (1750702750)

from mysite.settings.components.config_file import SYS_FILE
CACHE_HOST = SYS_FILE.get('REDIS_CACHE', 'CACHE_HOST', fallback='127.0.0.1')
CACHE_PORT = SYS_FILE.getint('REDIS_CACHE', 'CACHE_PORT', fallback=7397)
CACHE_PASSWORD = SYS_FILE.get('REDIS_CACHE', 'CACHE_PASSWORD', fallback='ZKSoft3')
CACHE_DB = SYS_FILE.get('REDIS_CACHE', 'CACHE_DB', fallback=1)