# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\email_setting.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import os
import json
import base64
import re
from smtplib import SMTPAuthenticationError
from django.core.mail import get_connection
from django.conf import settings
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from mysite.tools.encryption_utils import aes_encrypt, aes_decrypt
class EmailSettingUpdateSerializer(serializers.Serializer):
    smtp_server = serializers.CharField()
    smtp_server_port = serializers.IntegerField(default=25)
    enable_tls = serializers.BooleanField(default=False)
    email_account = serializers.EmailField()
    email_account_name = serializers.CharField(default=str(settings.PROJECT_NAME), required=False, allow_blank=True)
    email_password = serializers.CharField()
    email_enable = serializers.BooleanField(default=False)
    enable_find_back_pwd = serializers.BooleanField(default=False)
    def validate_email_password(self, value):
        try:
            de_password = aes_decrypt(value)
            if de_password:
                value = de_password
        except Exception as e:
            print(e)
        return value
    def validate(self, data):
        host = data.get('smtp_server')
        port = data.get('smtp_server_port')
        user = data.get('email_account')
        password = data.get('email_password')
        tls = True if data.get('enable_tls', None) else False
        ssl = False if tls else True
        try:
            connection = get_connection(host=host, port=port, username=user, password=password, use_tls=tls, use_ssl=ssl, fail_silently=False)
            connection.open()
        except SMTPAuthenticationError as e:
            e.args = list(e.args)
            error_msg = e.args[1]
            decode_list = ['utf-8', 'GB2312', 'ascii']
            for decode_temp in decode_list:
                try:
                    error_msg = error_msg.decode(decode_temp)
                    e.args = (e.args[0], error_msg)
                except UnicodeDecodeError:
                    continue
                else:
                    break
            raise ValidationError({'SMTPAuthenticationError': str(e)})
        except Exception as e:
            import traceback
            traceback.print_exc()
            raise ValidationError({'Exception': str(e)})
        data['email_password'] = aes_encrypt(str(data['email_password']))
        return data