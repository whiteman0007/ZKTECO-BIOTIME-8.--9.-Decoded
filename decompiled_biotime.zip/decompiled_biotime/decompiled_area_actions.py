# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\actions\\area_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:18 UTC (1750673058)

from django.utils.translation import gettext_lazy as _
from django.forms import ModelChoiceField, ModelMultipleChoiceField
from mysite import admin
from mysite.admin import forms
from mysite.admin.action import ActionHandleError
from mysite.personnel import widgets
from mysite.personnel.models import Employee, Area
from .personnel_actions import SetPsnlModelForm
from ..._utils import getattr_ex
class SetAreaForm(SetPsnlModelForm):
    # return None
    pass
class SetArea(admin.ZKModelAction):
    from django.conf import settings
    verbose_name = _('area_action_adjustEmployee')
    help_txt = _('area_action_adjustEmployeeHelpTxt')
    short_description = _('area_action_adjustEmployeeDescription')
    action_form = SetAreaForm
    batch_select = True
    unique_object_required = getattr_ex(settings, 'MULTI_COMPANY', False)
    def action(self, *args, **kwargs):
        emps = self.request.POST.getlist('employee')
        if not emps:
            raise ActionHandleError(_('select_none_employee'))
        else:
            objs = Employee.objects.filter(id__in=emps)
            for obj in objs:
                obj.area.set(self.objects)
                obj.save()