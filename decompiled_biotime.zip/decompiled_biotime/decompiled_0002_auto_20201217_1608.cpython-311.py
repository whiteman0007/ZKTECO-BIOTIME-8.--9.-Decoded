# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\ep\\migrations\\0002_auto_20201217_1608.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:36 UTC (1750702716)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('ep', '0001_initial')]
    operations = [migrations.RemoveField(model_name='eptransaction', name='temperature_F'), migrations.AddField(model_name='epsetup', name='is_default', field=models.BooleanField(default=True)), migrations.AddField(model_name='eptransaction', name='emp_code', field=models.CharField(default='', max_length=50, verbose_name='epTransaction.fields.employeeCode')), migrations.AlterUniqueTogether(name='eptransaction', unique_together={('emp_code', 'check_datetime')})]