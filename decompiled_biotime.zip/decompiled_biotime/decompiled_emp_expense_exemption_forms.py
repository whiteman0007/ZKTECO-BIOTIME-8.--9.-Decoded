# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\forms\\emp_expense_exemption_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
from mysite.payroll import db_const as c
from mysite.payroll.models import EmpExpenseExemption
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.personnel.widgets import EmployeeManyToManyMiddleWidget
class EmpExpenseExemptionChangeForm(ModelForm):
    employee_frm = forms.CharField(label=_('model_employee'), required=False, disabled=True)
    amount = forms.CharField(label=_('empExpenseExemption_field_amount'), required=True)
    issued_time = forms.DateTimeField(label=_('empExpenseExemption_field_issuedTime'), required=True)
    exemption_name = forms.CharField(label=_('empExpenseExemption_field_expenseExemption'), required=True, max_length=255)
    remark = forms.TextField(label=_('empExpenseExemption_field_remark'), max_length=c.MAX_LENTH_REMARK, required=False)
    def __init__(self, *args, **kwargs):
        super(EmpExpenseExemptionChangeForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['employee_frm'].initial = '{0} {1}'.format(self.instance.employee.emp_code, self.instance.employee.first_name or '')
    class Meta:
        model = EmpExpenseExemption
        fields = ['amount']
    def clean(self):
        cleaned_data = super(EmpExpenseExemptionChangeForm, self).clean()
        return cleaned_data
class EmpExpenseExemptionCreationForm(forms.ZKActionForm):
    employee = forms.EmployeeManyToManyField(label=_('model_employee'), required=False, widget=EmployeeManyToManyMiddleWidget)
    amount = forms.FloatField(label=_('empExpenseExemption_field_amount'), required=True)
    issued_time = forms.DateTimeField(label=_('empExpenseExemption_field_issuedTime'), required=True)
    exemption_name = forms.CharField(label=_('empExpenseExemption_field_expenseExemption'), required=True, max_length=255)
    remark = forms.TextField(label=_('empExpenseExemption_field_remark'), max_length=c.MAX_LENTH_REMARK, required=False)
    def clean(self):
        cleand_data = super(EmpExpenseExemptionCreationForm, self).clean()
        return cleand_data
    def save(self):
        emps = self.data.getlist('employee', None)
        if emps:
            kwargs = {}
            for emp in emps:
                kwargs.update({'employee_id': emp, 'year': self.cleaned_data.get('issued_time').year, 'amount': self.cleaned_data.get('amount'), 'issued_time': self.cleaned_data.get('issued_time'), 'remark': self.cleaned_data.get('remark'), 'exemption_name': self.cleaned_data.get('exemption_name')})
                EmpExpenseExemption(**kwargs).save()
class AddEmpExpenseExemptionAction(ZKModelAction):
    verbose_name = _('payroll_action_addEmpExpenseExemption')
    help_text = _('payroll_action_addEmpExpenseExemption')
    short_description = _('payroll_action_addEmpExpenseExemption')
    action_form = EmpExpenseExemptionCreationForm
    def action(self, *args, **kwargs):
        emps = self.request.POST.getlist('employee')
        message = ''
        if emps:
            form = EmpExpenseExemptionCreationForm(self.request.POST)
            if form.is_valid():
                form.save()
        else:
            message = _('select_employee')
        if message:
            raise AdminRuntimeWarning(message)