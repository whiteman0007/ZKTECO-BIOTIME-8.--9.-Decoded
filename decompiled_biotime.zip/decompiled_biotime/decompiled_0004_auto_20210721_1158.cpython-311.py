# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\acc\\migrations\\0004_auto_20210721_1158.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:12 UTC (1750702692)

from __future__ import unicode_literals
import django.core.validators
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('acc', '0003_auto_20200901_1642')]
    null = [migrations.AlterField('acccombination', 'group1', 'name', 'field'), migrations.AlterField('acccombination', 'group2', 'name', 'field'), migrations.AlterField('acccombination', 'accCombination_field_group2', 'group3', 'name', 'field'), migrations.AlterField('acccombination', 'accCombination_field_group3', 'group4', 'accCombination_field_group4'), migrations.AlterField('acccombination', 'group5', 'name', 'field'), migrations.AlterField('migrations', 'accCombination_field_group4', 'group4', 'accCombination_field_group4'), migrations.AlterField('migrations', 'group5', 'group4', 'accCombination_field_group4'), migrations.AlterField('migrations', 'accCombination_field_group5', 'accgroups', 'group_no', 'accGroup_field_no_maxValue', '1', 'accGroup_field_no'), migrations.AlterField('help_text', 'timezone1', '50', 'accPrivilege_field_timezone1', 'timezone2', 'accPrivilege_field_timezone2'