# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\attshift_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from mysite import admin
from django.utils.translation import gettext_lazy as _
from mysite.att import forms
from mysite.att.models import AttShift
from mysite import config
@admin.register(AttShift)
class AttShiftAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'alias') + config.WDMS_LIST_DISPLAY + ('shift_timetable', 'cycle_unit', 'shift_cycle', 'auto_shift', 'enable_ot_rule')
    list_filter = ('alias', 'cycle_unit', 'auto_shift') + config.WDMS_LIST_FILTER
    form = forms.AttShiftCreationForm
    def shift_timetable(self, obj):
        tbs = obj.shiftdetail_set.values_list('time_interval__alias', flat=True)
        return ','.join(set(tbs))
    shift_timetable.short_description = _('shift_field_timeInterval')
    def shift_detail(self, request):
        from mysite.att.views import shift_detail
        return shift_detail(request)
    def get_queryset(self, request):
        qs = super(AttShiftAdmin, self).get_queryset(request)
        if request.user.is_employee:
            qs = qs.filter(company=request.user.company)
        else:
            if not request.user.is_superuser and request.user.assign_company:
                    qs = qs.filter(company=request.user.assign_company)
        return qs