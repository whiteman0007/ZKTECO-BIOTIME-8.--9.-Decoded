# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff\\models\\approval_manuallog.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:33 UTC (1750673073)

from mysite.att.models import ManualLog
class ApprovalManuallog(ManualLog):
    def get_template_base_root(self):
        return 'att/manuallog'
    class Meta:
        default_permissions = ()
        app_label = 'staff'
        proxy = True