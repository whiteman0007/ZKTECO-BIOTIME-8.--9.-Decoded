# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff\\actions\\approval_leave_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:31 UTC (1750673071)

import datetime
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.att.actions import Approve
from mysite.att.actions.common_actions import AuditForm
from mysite.att.models import Leave
class StaffAuditLeaveForm(AuditForm):
    approval_remark = forms.TextField(label=_('leave_field_approvalReason'), required=False)
    leave_day = forms.FloatField(label=_('leave.fields.leaveDay'), initial=0, suffix=_('time.units.day'), required=False, disabled=True)
    def __init__(self, *args, **kwargs):
        super(StaffAuditLeaveForm, self).__init__(*args, **kwargs)
        try:
            self.instance = Leave.objects.get(id=kwargs.get('request').GET.get('id'))
            self.fields['leave_day'].initial = self.instance.leave_day
        except:
            return None
class StaffApproveLeave(Approve):
    action_form = StaffAuditLeaveForm
    def action(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        remark = kwargs['approval_remark']
        user = self.request.user
        for obj in self.objects:
            node = obj.get_first_pending_node()
            if not node:
                raise AdminRuntimeWarning('not find pending node')
            qs = obj.get_nodeinstance_qs(user=user)
            emp_permission_nodes = qs.values_list('id', flat=True)
            if node.id not in emp_permission_nodes:
                raise AdminRuntimeWarning('pending node can not approval by this employee')
            if node.workflow_node.from_day < obj.leave_day <= node.workflow_node.to_day:
                    obj.update_approver(self.request.user)
                    obj.approval_status = 2
                    obj.approval_remark = remark
                    obj.approval_time = datetime.datetime.now()
                    obj.save()
                    node.approval_status = 2
                    node.approver_employee = user
                    node.approval_time = datetime.datetime.now()
                    node.approval_remark = remark
                    node.save()
                    next_node = node.next_node()
                    if next_node:
                        obj.nodeinstance_set.filter(approval_status=1).update(approval_status=7)
                    else:
                        obj.nodeinstance_set.filter(approval_status=1).update(approval_status=2)
                    obj.notify2applier(2)
                    obj.notify2node(2)
                    obj.do_approve(self.request.user, remark, obj.leave_day)