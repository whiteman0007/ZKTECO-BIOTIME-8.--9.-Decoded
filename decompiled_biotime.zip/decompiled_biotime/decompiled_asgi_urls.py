# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\asgi_urls.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.urls import re_path
from mysite.asgi_sse_view import ASGI_SSE_View
from mysite.asgi_views import asgi_login_check as login_check
from mysite.asgi_views import *
@login_check
async def asgi_application(scope: dict, receive, send):
    assert scope['type'] == 'http'
    await send({'type': 'http.response.start', 'status': 200, 'headers': [[b'content-type', b'text/plain']]})
    await send({'type': 'http.response.body', 'body': b'Hello, world1!', 'more_body': True})
    await send({'type': 'http.response.body', 'body': b'Hello, world2!', 'more_body': True})
    import time
    for i in range(1, 100):
        await send({'type': 'http.response.body', 'body': b'Hello, world2!', 'more_body': True})
    await send({'type': 'http.response.body', 'body': b'Hello, world3!', 'more_body': False})
    await send({'type': 'http.response.body', 'body': b'Hello, world3!', 'more_body': False})
class TestConsumer(BasicAsyncHttpConsumer):
    @login_check
    async def handle(self, body):
        await self.send_headers(status=200, headers=[[b'content-type', b'text/plain']])
        await self.send_body(body=b'Hello, world1!', more_body=True)
        await self.send_body(body=b'Hello, world2!', more_body=True)
        await self.send(message={'type': 'http.response.body', 'body': b\'Hello, world3!\'})
        await self.send(message={'type': 'http.response.body', 'body': b\'Hello, world3!\'})
urlpatterns = [re_path('^list/export/$', BasicExportEssentialConsumer.as_asgi()), re_path('^async/payroll/get_slip/$', EmployeePayslipExportConsumer.as_asgi()), re_path('^async/personnel/USBData/export/$', EmployeeUSBDataExportConsumer.as_asgi()), re_path('^async/personnel/employee/import/$', EmployeeImportConsumer.as_asgi()), re_path('^async/personnel/EmployeeCert/import/$', EmployeeCertImportConsumer.as_asgi()), re_path('^async/personnel/EmployeePhoto/import/$', EmployeePhotoImportConsumer.as_asgi()), re_path('^async/personnel/USBData/import/$', EmployeeUSBDataImportConsumer.as_asgi()), re_path('^async/personnel/department/import/$', DepartmentImportConsumer.as_asgi()), re_path('^async/personnel/position/import/$', PositionImportConsumer.as_asgi()), re_path('^async/personnel/area/import/$', AreaImportConsumer.as_asgi()), re_path('^async/personnel/resign/import/$', ResignImportConsumer.as_asgi()), re_path('^async/personnel/certification/import/$', CertificationImportConsumer.as_asgi()), re_path('^async/att/temporaryschedule/import/$', AttTemporaryScheduleImportConsumer.as_asgi()), re_path('^async/att/leave/import/$', AttLeaveImportConsumer.as_asgi()), re_path('^async/att/attschedule/import/$', AttScheduleImportConsumer.as_asgi()), re_path('^async/att/training/import/$', AttTrainingImportConsumer.as_asgi()), re_path('^async/att/manuallog/import/$', AttManualLogImportConsumer.as_asgi()), re_path('^async/att/overtime/import/$', AttOverTimeImportConsumer.as_asgi()), re_path