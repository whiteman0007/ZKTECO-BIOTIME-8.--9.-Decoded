# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\dashboard_device_status.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

from django.utils.translation import gettext_lazy as _
from rest_framework import mixins, serializers
from mysite.att.api.serializers import NoneSerializer
from mysite.base.api.filters import TerminalStatusFilter
from mysite.base.api.utils_class import UserLayUIGenericViewSet
from mysite.iclock.models import Terminal
class TerminalStatusSerializer(serializers.ModelSerializer):
    area_name = serializers.CharField(source='area__area_name', allow_null=True)
    class Meta:
        model = Terminal
        fields = ['sn', 'alias', 'area_name', 'ip_address', 'fw_ver', 'last_activity']
class TerminalStatusViewSet(mixins.ListModelMixin, UserLayUIGenericViewSet):
    model = Terminal
    queryset = Terminal.objects.all().select_related('area')
    filterset_class = TerminalStatusFilter
    serializer_dict = {'list': TerminalStatusSerializer}
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)
    def get_queryset(self):
        from django.contrib.auth import get_user_model
        queryset = super(TerminalStatusViewSet, self).get_queryset()
        if isinstance(self.request.user, get_user_model()) and (not self.request.user.is_superuser):
                if self.request.user.auth_area.exists():
                    queryset = queryset.filter(area__in=self.request.user.auth_area.all()).distinct()
                if self.request.user.assign_company:
                    queryset = queryset.filter(area__company=self.request.user.assign_company)
        return queryset