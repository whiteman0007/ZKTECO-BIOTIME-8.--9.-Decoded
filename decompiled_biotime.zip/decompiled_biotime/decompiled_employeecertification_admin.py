# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\employeecertification_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

import datetime
from celery_progress.backend import AbstractProgressRecorder
from django.forms import ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite import config, admin
from mysite.utils import progress_record
from mysite.admin.kernel import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.admin import forms
from mysite.personnel import actions, db_const
from mysite.personnel.import_data import ImportData
from mysite.personnel.models import EmployeeCertification, Employee, Certification
from mysite.tools.progress_utils import progress_protected
class AddEmployeeCertForm(forms.ZKActionForm):
    employee = forms.EmployeeOneToOneField(label=_('employeeCert_field_employee'), required=False)
    expire_on = forms.DateField(label=_('employeeCert_field_expireOn'), initial=datetime.datetime.now)
    email_alert = forms.ChoiceField(label=_('employeeCert_field_emailAlert'), initial=True, choices=db_const.BOOLEANS)
    before = forms.IntegerField(label=_('employeeCert_field_before'), initial=0)
    certification = ModelChoiceField(queryset=Certification.objects.all(), label=_('employeeCert_field_cert'), required=True)
class AddEmployeeCert(admin.ZKModelAction):
    verbose_name = _('empCert_action_addEmployeeCert')
    help_txt = _('empCert_action_addEmployeeCertHelpTxt')
    short_description = _('empCert_action_addEmployeeCertDescription')
    action_form = AddEmployeeCertForm
    def action(self, *args, **kwargs):
        emps = self.request.POST.getlist('employee')
        if emps:
            expire_on = self.request.POST.get('expire_on', datetime.datetime.now())
            email_alert = self.request.POST.get('email_alert', 1)
            certification = self.request.POST.get('certification')
            before = self.request.POST.get('before', 0)
            for emp in emps:
                if EmployeeCertification.objects.filter(employee_id=emp, certification_id=certification):
                    from mysite.admin.action import ActionHandleError
                    raise ActionHandleError(_('the_employee_%(emp)s_is_already_has_document_%(certification)s') % {'emp': emp, 'certification': certification})
                else:
                    obj = EmployeeCertification(employee_id=emp, expire_on=expire_on, email_alert=email_alert, before=before, certification_id=certification)
                    obj.save()
        else:
            from mysite.admin.action import ActionHandleError
            raise ActionHandleError(_('select_none_employee'))
class EmployeeCertificationAdmin(ZKModelAdmin):
    list_display = ('id', 'certification', 'employee', 'expire_on', 'email_alert', 'before')
    list_filter = config.EMPLOYEE_LIST_FILTER + ('certification', 'expire_on', 'email_alert')
    actions = [AddEmployeeCert, actions.Import]
    ordering = ('expire_on',)
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        if request.user.is_superuser:
            qs = super(EmployeeCertificationAdmin, self).get_queryset(request)
        else:
            from django.db.models import Q
            qs = super(EmployeeCertificationAdmin, self).get_queryset(request).filter(Q(employee__department__in=request.user.auth_dept.all(), employee__area__in=request.user.auth_area.all())).distinct()
            if request.user.assign_company:
                qs = qs.filter(employee__company=request.user.assign_company)
        try:
            from mysite.personnel.models.model_employee import Employee
            employee_obj = Employee.objects.filter(emp_code=request.GET['emp_code'])
            if qs:
                if employee_obj:
                    qs = qs.filter(employee_id=employee_obj[0].id)
                else:
                    qs = qs.filter(employee_id=0)
            return qs
        except Exception:
            return qs
    @progress_protected
    def dataimport(self, request):
        obj_import = ImportEmployeeCertificationData(req=request, input_name='import_data', app_label=self.opts.app_label, model_name=self.opts.model_name)
        obj_import.exe_import_data()
        ret_error = obj_import.error_info
        if ret_error:
            from mysite.admin.action import ActionHandleError
            raise ActionHandleError(';'.join(ret_error))
class BaseImportData(ImportData):
    progress_recorder = None
    total = 0
    current = 0
    def __init__(self, req, input_name='import_data', app_label=None, model_name=None, **kwargs):
        from django.utils.translation import activate
        lng = kwargs.pop('template_lng', None)
        if lng:
            activate(lng)
        super(BaseImportData, self).__init__(req, input_name, app_label, model_name)
        self.progress_recorder = kwargs.pop('progress_recorder', None)
        self.stamp = None
        self.calculate_fields_verbose = ['%s' % _('employeeCert_field_employee'), '%s' % _('employeeCert_field_cert')]
        self.must_fields = ['%s' % _('employeeCert_field_employee'), '%s' % _('employeeCert_field_cert'), '%s' % _('employeeCert_field_expireOn'), '%s' % _('employeeCert_field_emailAlert'), '%s' % _('employeeCert_field_before')]
        self.employee_code = None
        self.certification_code = None
        self.expire_on = None
        self.email_alert = None
        self.before = None
    def before_insert(self):
        return True
    def data_insert(self):
        return
    def emp_valid(self, class_model, code, name):
        class_model_Obj = class_model.objects.filter(emp_code=code, company_id=self.company_id)
        if not class_model_Obj:
            return False
        else:
            return class_model_Obj[0].id
    def cer_valid(self, class_model, code, name):
        class_model_Obj = class_model.objects.filter(cert_code=code)
        if not class_model_Obj:
            return False
        else:
            return class_model_Obj[0].id
    def process_row(self, row_data, calculate_dict, index):
        # irreducible cflow, using cdg fallback
        row_data = super().process_row(row_data, calculate_dict)
        from mysite.personnel.models import Employee, Certification, EmployeeCertification
        row_data['employee_id'] = self.emp_valid(Employee, calculate_dict[_('employeeCert_field_employee')], None)
        row_data['certification_id'] = self.cer_valid(Certification, calculate_dict[_('employeeCert_field_cert')], None)
        if row_data['employee_id'] and row_data['certification_id']:
            objs = EmployeeCertification.objects.filter(employee_id=row_data['employee_id'], certification_id=row_data['certification_id'])
            if objs and (not self.need_update_old_record):
                    return False
                    if objs:
                        obj = objs[0]
                        for k, v in list(row_data.items()):
                            setattr(obj, k, v)
                    else:
                        obj = EmployeeCertification(**row_data)
                    obj.save()
            if not row_data['employee_id']:
                self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_does_not_exists') % {'index': index})
                self.error_info.append(_('error_data_on_row(%(index)s)_the_certification_code_does_not_exists') % {'index': index})
                    except Exception:
                        import traceback
                        traceback.print_exc()
    def sqlserver_insert(self):
        """\n        sqlserver 数据插入\n        """
        self.data_insert()
    def mysql_insert(self):
        """\n        mysql 数据插入\n        """
        self.data_insert()
    def oracle_insert(self):
        """\n        oracle 数据插入\n        """
        self.data_insert()
    def postgresql_insert(self):
        """\n        postgresql 数据插入\n        """
        self.data_insert()
    def after_insert(self):
        return
class ImportEmployeeCertificationData(BaseImportData):
    """"""
    def before_insert(self):
        for index in range(len(self.head)):
            e = self.head[index]
            if e == '%s' % _('employeeCert_field_employee'):
                self.employee_code = index
            if e == '%s' % _('employeeCert_field_cert'):
                self.certification_code = index
            if e == '%s' % _('employeeCert_field_expireOn'):
                self.expire_on = index
            if e == '%s' % _('employeeCert_field_emailAlert'):
                self.email_alert = index
            if e == '%s' % _('employeeCert_field_before'):
                self.before = index
        self.total = len(self.records)
        for index, elem in enumerate(self.records):
            self.current = index
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.dataVerification'))
            index += 1
            employee_code = certification_code = expire_on = email_alert = before = ''
            if self.employee_code is not None:
                employee_code = elem[self.employee_code]
            if self.certification_code is not None:
                certification_code = elem[self.certification_code]
            if self.expire_on is not None:
                expire_on = elem[self.expire_on]
            if self.email_alert is not None:
                email_alert = elem[self.email_alert]
            if self.before is not None:
                before = elem[self.before]
            if not employee_code:
                self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_is_empty') % {'index': index})
            else:
                if not Employee.objects.filter(emp_code=employee_code, company_id=self.company_id):
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_does_not_exists') % {'index': index})
            if not certification_code:
                self.error_info.append(_('error_data_on_row(%(index)s)_the_certification_code_is_empty') % {'index': index})
            else:
                if not Certification.objects.filter(cert_code=certification_code, company_id=self.company_id):
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_certification_code_does_not_exists') % {'index': index})
            if expire_on:
                try:
                    expire_on = datetime.datetime.strptime(expire_on, '%Y-%m-%d')
                except Exception:
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_expire_on_is_wrong') % {'index': index})
            if email_alert not in (_('boolean_option_no'), _('boolean_option_yes')):
                self.error_info.append(_('error_data_on_row(%(index)s)_the_email_alert_is_wrong_the_format_should_be_%(no)s/%(yes)s') % {'index': index, 'no': _('boolean_option_no'), 'yes': _('boolean_option_yes')})
            if before:
                try:
                    int(before)
                except Exception:
                    self.error_info.append(_('error_data_on_row(%(index)s)') % {'index': index})
        return True
    def data_insert(self):
        from django.db import models
        head_len = len(self.head)
        calculate_dict = {}
        for index, obj in enumerate(self.records):
            if self.progress_recorder:
                self.current = index
                progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
            obj_data = {}
            for i in range(head_len):
                for k, v in list(self.calculate_fields_index.items()):
                    if v == i:
                        calculate_dict[k] = obj[i]
                if i in self.valid_head_indexs:
                    tmp_value = obj[i]
                    f_index = self.valid_head_indexs.index(i)
                    tmp_field = self.valid_model_fields[f_index]
                    if tmp_field.choices:
                        if tmp_value in ['', None, 'None']:
                            continue
                        else:
                            tv = [e[0] for e in tmp_field.choices if e[1] == tmp_value]
                            if tv:
                                tmp_value = tv[0]
                    if not isinstance(tmp_field, models.ForeignKey):
                        key = tmp_field.attname
                        value = self.get_db_value(tmp_field, tmp_value)
                        obj_data[key] = value
            self.process_row(obj_data, calculate_dict, index)
    def after_insert(self):
        progress_record(self.progress_recorder, self.total, self.total, _('importProgress.status.finished'))
zk_site.register(EmployeeCertification, EmployeeCertificationAdmin)