# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\tools\\logging_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import os
import shutil
from logging.handlers import RotatingFileHandler
class NoConflictRotatingFileHandler(RotatingFileHandler):
    def rotate(self, source, dest):
        """\n        ============Re write by damien.=================\n        for let file not conflict in rotate.\n        change: copy old file and clear it with open(mode=\'w\')\n\n        from:\n            os.rename(source, dest)\n        to:\n            shutil.copy(source, dest)\n            with open(source, \'w\', encoding=self.encoding) as f:\n                pass\n        ================================================\n\n        When rotating, rotate the current log.\n\n        The default implementation calls the \'rotator\' attribute of the\n        handler, if it\'s callable, passing the source and dest arguments to\n        it. If the attribute isn\'t callable (the default is None), the source\n        is simply renamed to the destination.\n\n        :param source: The source filename. This is normally the base\n                       filename, e.g. \'test.log\'\n        :param dest:   The destination filename. This is normally\n                       what the source is rotated to, e.g. \'test.log.1\'.\n        """
        if not callable(self.rotator):
            if os.path.exists(source):
                shutil.copy(source, dest)
                print(source, dest)
                with open(source, 'w', encoding=self.encoding) as f:
                    pass
                return
        else:
            self.rotator(source, dest)