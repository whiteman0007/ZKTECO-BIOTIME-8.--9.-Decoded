# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\datasproc.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:36 UTC (1750673016)

from django.utils.translation import gettext_lazy as _
from mysite.utils import *
from mysite.iclock.models import *
from django.db.models.fields import AutoField
from django.contrib.auth.models import Permission, Group
from django.contrib.auth import get_user_model
import datetime
import calendar
from mysite.base.models import *
def getLocalText(ID):
    devices_label = {'Trial': '%s' % 'trial version', 'TrialDays': '%s' % 'Trial days:', 'TrialDay': '%s' % 'Use cutoff', 'ClientID': '%s' % 'Customer Number', 'Company': '%s' % 'Using Units', 'Database': '%s' % 'database', 'pushkey0': '%s' % 'Unencrypted', 'pushkey1': '%s' % 'encrypted', 'pushkey2': '%s' % 'soft encryption', 'UNAUTHORIZED': '%s' % 'unauthorized', 'RegisterTime': '%s' % 'authorization time', 'Devices': '%s' % 'authorization points', 'SoftwareSN': '%s' % 'serial number:', 'devices_label': '%s' % 'current device number', 'server_label': '%s' % '<span style=\"color:#7ac143;\">%s</span>', 'server information': '%s', '
    try:
        return Texts[ID]
    except:
        return ID
def transLeaName(leaveID):
    LeaName = {1000: str('OK'), 1007: str('Hol.'), 1008: str('NoIn'), 1009: str('NoOut'), 1004: str('Absent'), 1001: str('Late'), 1002: str('Early'), 1010: str('ROT'), 1005: str('OT'), 1013: str('FOT'), 1012: str('OUT'), 1011: str('BOUT'), 1003: str('ALF')}
    return LeaName[leaveID]
def OpName(op):
    OPNAMES = {0: 'start up', 1: 'shutdown', 2: 'validation failure', 3: 'alarm', 4: 'enter the menu', 5: 'change settings', 6: 'registration fingerprint', 7: 'registration password', 8: 'card registration', 20: 'the data in the card copied to the machine', 21: 'set time', 22: 'restore factory settings', 23: 'Delete Record', 24: 'remove administrator rights', 25: '25', group set up to amend Access: '26', modify user access control settings: '27', access time to amend paragraph: '28', amend unlock Portfolio: '29', unlock: '30', registration of new users: '31', fingerprint attribute changes: '32', stress alarm: 'stress alarm', 34: 'anti-submarine', 35: 'anti-submarine', Delete attendance photos: '35', 36: 'Delete attendance photos', Modify user information: '36', 37: 'Holiday operation', 38: 'Restore data', 39: 'Backup data', 40
    try:
        return '%s(%s)' % (OPNAMES[op], op)
    except:
        return op and '%s' % op or ''
def GetdisableFieldsIndex(user, tbl):
    if tbl == 'attShifts':
        rFieldNames = FetchModelFields('attShifts')
        dis = FetchDisabledFields(user, 'attShifts')
        result = []
        if dis:
            for t in dis:
                try:
                    result.append(rFieldNames.index(t))
                except:
                    return []
        return result
def GetAnnualleave(userid):
    if not userid:
        return ''
    else:
        t = employee.objByID(int(userid))
        if not t:
            return 0
        else:
            Hiredday = t.Hiredday
            Annualleave = t.Annualleave
            if str(type(Hiredday))!= '<type \'datetime.date\'>' and str(type(Hiredday))!= '<type \'datetime.datetime\'>':
                    return 0
            nowyear = datetime.datetime.now().year
            hireyear = checkTime(Hiredday).year
            if hireyear < 1960:
                return 0
            else:
                diff = nowyear - hireyear
                re = 0
                if diff >= 1 and diff < 10:
                    re = 5
                else:
                    if diff >= 10 and diff < 20:
                        re = 10
                    else:
                        if diff >= 20:
                            re = 15
                if Annualleave!= None and Annualleave < re:
                        re = Annualleave
                return re
def GetLeaveDays(userid, type):
    from mysite.iclock.datas import GetLeaveClasses
    LClass = GetLeaveClasses(1)
    LeaveID = 0
    for t in LClass:
        if t['LeaveType'] == int(type):
            LeaveID = t['LeaveID']
            break
    if LeaveID == 0:
        return 0
    else:
        AttExcep = AttException.objects.filter(UserID=userid, ExceptionID=LeaveID)
        return len(AttExcep)
def allowAction(startdate, itype, enddate=None):
    st = checkTime(startdate)
    if enddate!= None:
        et = checkTime(enddate)
    lock_date = int(GetParamValue('opt_basic_lock_date', '0'))
    if lock_date == 0:
        return True
    else:
        nt = datetime.datetime.now()
        current_month_maxdays = calendar.monthrange(nt.year, nt.month)
        if lock_date > current_month_maxdays[1]:
            lock_date = current_month_maxdays[1]
        lock_st = datetime.datetime(nt.year, nt.month, lock_date, 23, 59, 59)
        if lock_st >= nt:
            nt1 = nt - datetime.timedelta(lock_date)
            prev_st = datetime.datetime(nt1.year, nt1.month, 1, 0, 0, 0)
            if st < prev_st:
                return False
        else:
            curr_st = datetime.datetime(nt.year, nt.month, 1, 0, 0, 0)
            if st < curr_st:
                return False
        return True
def diffTime(diffT):
    return diffT.days * 86400 + diffT.seconds
def deleteCalcLog(**kwargs):
    now = datetime.datetime.now()
    try:
        d1 = trunc(kwargs['StartDate'])
    except:
        d1 = datetime.datetime(now.year, now.month, 1, 0, 0)
    try:
        d2 = trunc(kwargs['EndDate'])
    except:
        d2 = datetime.datetime(now.year, now.month, now.day, 23, 59, 59)
    try:
        iflag = kwargs['iflag']
    except:
        iflag = 0
    if d1 == trunc(now) and iflag == 1:
            return
    deptid = 0
    userids = []
    itype = 'calculated_date'
    if 'DeptID' in list(kwargs.keys()):
        deptid = kwargs['DeptID']
    if 'UserID' in list(kwargs.keys()):
        userids.append(int(kwargs['UserID']))
    if deptid > 0:
        userids = list(employee.objects.filter(DeptID=deptid).values_list('id', flat=True))
    for u in userids:
        sDate = d1.strftime('%Y%m%d')
        try:
            item = calcDate.objects.get(UserID_id=u)
            if sDate not in item.ItemValue:
                item.ItemValue = item.ItemValue + ',' + sDate
                item.save()
        except Exception as e:
            calcDate(UserID_id=u, ItemValue=sDate).save(force_insert=True)
def FieldIsExist(fieldName, DataModel):
    field_names = [f.column for f in DataModel._meta.fields if not isinstance(f, AutoField)]
    if fieldName in field_names:
        return True
    else:
        return False
def hourAndMinute(value):
    if value:
        h = str(int(value) / 60)
        m = str(int(value) % 60)
        if int(m) < 10:
            m = '0' + str(m)
        return h + ':' + m
    else:
        return ''
Absent = {'0': _('No'), '1': _('Yes')}
def IsYesNo(value):
    if value:
        return '%s' % Absent['1']
    else:
        return '%s' % Absent['0']
def IsTrueOrFalse(value):
    if value:
        return '%s' % Absent['0']
    else:
        return '%s' % Absent['1']