# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\auth_user_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from django.conf import settings
from django.urls import re_path
from django.contrib import admin, messages
from django.contrib.admin.options import IS_POPUP_VAR
from django.contrib.admin.utils import unquote
from django.contrib.auth import get_user_model
from django.contrib.auth import update_session_auth_hash
from django.core.exceptions import PermissionDenied
from django.db import router, transaction
from django.http import Http404, HttpResponseRedirect
from django.template.response import TemplateResponse
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.encoding import force_str
from django.utils.html import escape
from django.utils.translation import gettext, gettext_lazy as _
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from mysite.admin import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.base.actions.myuser_actions import UserDelete
csrf_protect_m = method_decorator(csrf_protect)
sensitive_post_parameters_m = method_decorator(sensitive_post_parameters())
from mysite.base.admin.forms.auth_user_form import UserChangeForm, UserCreationForm, AdminPasswordChangeForm
User = get_user_model()
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass
from mysite.base.actions import ChangePassword
class UserAdmin(ZKModelAdmin):
    actions = [ChangePassword, UserDelete]
    change_user_password_template = None
    fieldsets = ((_('Account'), {'fields': ('username', 'password', 'login_type')}), (_('Personal info'), {'fields': ('first_name', 'last_name', 'email')}), (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser', 'can_manage_all_dept', 'auth_area', 'auth_dept', 'groups')}), (_('Important dates'), {'fields': ('last_login', 'date_joined')}))
    add_fieldsets = ((_('Account'), {'fields': ('username', 'password', 'login_type')}), (_('Personal info'), {'fields': ('first_name', 'last_name', 'email')}), (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser', 'can_manage_all_dept', 'auth_area', 'auth_dept', 'groups')}), (_('Important dates'), {'fields': ('last_login', 'date_joined')}))
    add_form = UserCreationForm
    add_form_template = 'accounts/myuser/add.html'
    form = UserChangeForm
    change_password_form = AdminPasswordChangeForm
    list_display = ('username', 'first_name', 'last_name', 'email', 'groups_name', 'is_staff', 'is_superuser', 'date_joined', 'last_login', 'login_count')
    list_display_params = {'__all__': {'width': '150'}}
    list_filter = ('username', 'date_joined', 'is_staff', 'login_count', 'is_superuser', 'is_active', 'groups')
    sort_fields = ()
    ordering = ('username',)
    filter_horizontal = ('groups', 'auth_area', 'auth_dept')
    def get_fieldsets(self, request, obj=None):
        if not obj:
            return self.add_fieldsets
        else:
            return super(UserAdmin, self).get_fieldsets(request, obj)
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(UserAdmin, self).get_form(request, obj, **defaults)
    def groups_name(self, obj):
        groups = obj.groups.all()
        if not groups:
            return ''
        else:
            return ','.join([i.name for i in groups])
    groups_name.short_description = _('user_group_field_name')
    def get_urls(self):
        return [re_path('base/password_change/$', self.admin_site.admin_view(self.user_change_password), name='auth_user_password_change')] + super(UserAdmin, self).get_urls()
    def lookup_allowed(self, lookup, value):
        if lookup.startswith('password'):
            return False
        else:
            return super(UserAdmin, self).lookup_allowed(lookup, value)
    @sensitive_post_parameters_m
    @csrf_protect_m
    def add_view(self, request, form_url='', extra_context=None):
        with transaction.atomic(using=router.db_for_write(self.model)):
            return self._add_view(request, form_url, extra_context)
    def _add_view(self, request, form_url='', extra_context=None):
        if not self.has_change_permission(request):
            if self.has_add_permission(request) and settings.DEBUG:
                raise Http404('Your user does not have the \"Change user\" permission. In order to add users, Django requires that your user account have both the \"Add user\" and \"Change user\" permissions set.')
            else:
                raise PermissionDenied
        else:
            if extra_context is None:
                extra_context = {}
            username_field = self.model._meta.get_field(self.model.USERNAME_FIELD)
            defaults = {'auto_populated_fields': (), 'username_help_text': username_field.help_text}
            extra_context.update(defaults)
            return super(UserAdmin, self).add_view(request, form_url, extra_context)
    @sensitive_post_parameters_m
    def user_change_password(self, request, id, form_url=''):
        if not self.has_change_permission(request):
            raise PermissionDenied
        else:
            user = self.get_object(request, unquote(id))
            if user is None:
                raise Http404(_('%(name)s object with primary key %(key)r does not exist.') % {'name': force_str(self.model._meta.verbose_name), 'key': escape(id)})
            else:
                if request.method == 'POST':
                    form = self.change_password_form(user, request.POST)
                    if form.is_valid():
                        form.save()
                        change_message = self.construct_change_message(request, form, None)
                        self.log_change(request, user, change_message)
                        msg = gettext('user_actionChangePassword_successReturn')
                        messages.success(request, msg)
                        update_session_auth_hash(request, form.user)
                        return HttpResponseRedirect(reverse('%s:%s_%s_change' % (self.admin_site.name, user._meta.app_label, user._meta.model_name), args=(user.pk,)))
                else:
                    form = self.change_password_form(user)
                fieldsets = [(None, {'fields': list(form.base_fields)})]
                adminForm = admin.helpers.AdminForm(form, fieldsets, {})
                context = {'title': _('Change password: %s') % escape(user.get_username()), 'adminForm': adminForm, 'form_url': form_url, 'form': form, 'is_popup': IS_POPUP_VAR in request.POST or IS_POPUP_VAR in request.GET, 'add': True, 'change': False, 'has_delete_permission': False, 'has_change_permission': True, 'has_absolute_url': False, 'opts': self.model._meta, 'original': user, 'save_as': False, 'show_save': True}
                context.update(self.admin_site.each_context(request))
                request.current_app = self.admin_site.name
                return TemplateResponse(request, self.change_user_password_template or 'admin/auth/user/change_password.html', context)
    def response_add(self, request, obj, post_url_continue=None):
        """\n        Determines the HttpResponse for the add_view stage. It mostly defers to\n        its superclass implementation but is customized because the User model\n        has a slightly different workflow.\n        """
        if '_addanother' not in request.POST and IS_POPUP_VAR not in request.POST:
                request.POST = request.POST.copy()
                request.POST['_continue'] = 1
        return super(UserAdmin, self).response_add(request, obj, post_url_continue)
    def has_add_permission(self, request):
        if request.user.is_employee:
            return False
        else:
            return request.user.is_superuser
    def get_queryset(self, request):
        qs = super(UserAdmin, self).get_queryset(request)
        qs = qs.exclude(username='AnonymousUser')
        if not request.user.is_superuser:
            qs = qs.filter(is_superuser=False)
        return qs
zk_site.register(User, UserAdmin)