# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\core\\api.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from collections import OrderedDict
from rest_framework import pagination
from rest_framework.response import Response
class PageNumberPagination(pagination.PageNumberPagination):
    page_size_query_param = 'page_size'
    def get_paginated_response(self, data):
        return Response(OrderedDict([('count', self.page.paginator.count), ('msg', ''), ('code', 0), ('data', data)]))