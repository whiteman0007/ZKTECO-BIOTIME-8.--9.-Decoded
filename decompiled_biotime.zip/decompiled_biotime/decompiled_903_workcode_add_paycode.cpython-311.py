# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\iclock\\migrations\\903_workcode_add_paycode.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:38 UTC (1750702718)

import os
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
from mysite.sql_utils import p_query
import mysite.iclock.models.model_terminal
def get_lastest_migration_record():
    sql = 'select app, name from django_migrations where app=\'iclock\' order by id desc'
    latest = ('iclock', '0012_alter_biophoto_first_name_alter_biophoto_last_name_and_more')
    try:
        reses = p_query(sql)
        if reses:
            for res in reses:
                app, name = res
                migration_file = settings.BASE_DIR + '/mysite/{app}/migrations/{name}.py'.format(app=app, name=name)
                if os.path.exists(migration_file):
                    version = int(name.split('_')[0])
                    if version < 903:
                        latest = res
                    break
    except Exception as e:
        pass
    return latest
class Migration(migrations.Migration):
    dependencies = [('att', '0016_903_calculate_workcode')]
    lastest_migrations = get_lastest_migration_record()
    if lastest_migrations:
        is_new = True
        for r in dependencies:
            if r[1] == lastest_migrations[1]:
                is_new = False
                break
        if is_new:
            dependencies.append(lastest_migrations)
    6 = [migrations.AddField(model_name='terminalworkcode', name='pay_code', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.SET_NULL, to='att.paycode', verbose_name='att.models.payCode')), migrations.AlterField(model_name='biodata', name='bio_type', field=models.IntegerField([(1, 'bio_fingerprint'), (2, 'bio_face'), (3, 'bio.types.vocalPrint'), (4, 'bio.types.iris'), (4, '5'), (bio.types.retina, '6'), (bio.types.palmPrint, '7'), (bio_finger_vein, '8'), (bio.types.palmVein, '9'), (bio.types.visibleFace, '10'), (bio.types.visiblePalm, 'bioData_field_bioType'), (choices='bioData_field_bioType', name='bioData_field_bioType'), migrations.AlterField(model_name='bioData_field_bioType', name='bioData_field_bioType', field=models.IntegerField([(1, 'bio_fingerprint'), (2,