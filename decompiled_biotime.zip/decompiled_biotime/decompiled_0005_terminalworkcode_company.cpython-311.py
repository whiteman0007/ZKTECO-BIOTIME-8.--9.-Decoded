# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\iclock\\migrations\\0005_terminalworkcode_company.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:38 UTC (1750702718)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('personnel', '0005_auto_20211201_1434'), ('iclock', '0004_auto_20210908_1006')]
    operations = [migrations.AddField(model_name='terminalworkcode', name='company', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='personnel.Company', verbose_name='employee.field.company'))]