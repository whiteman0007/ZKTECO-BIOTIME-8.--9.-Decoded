# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\deptattrule_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models.model_deptattrule import DeptAttRule
from mysite.att.api.serializers import util_serializers
class DeptAttRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeptAttRule
        fields = '__all__'
class DeptAttRuleCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeptAttRule
        fields = '__all__'
class DeptAttRuleEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeptAttRule
        fields = '__all__'
class DeptAttRuleActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = DeptAttRule
        action_type_choices = (('delete', 'delete'),)