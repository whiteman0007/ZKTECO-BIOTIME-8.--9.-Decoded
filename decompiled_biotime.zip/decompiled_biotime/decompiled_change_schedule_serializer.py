# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\mobile\\api\\serializers\\change_schedule_serializer.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from rest_framework import serializers
from mysite.att.models import ChangeSchedule
from mysite.mobile.api import fields
from mysite.mobile.api.serializers import EmployeeSerializer
class ChangeScheduleSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer()
    att_date_stamp = fields.DateField(source='att_date')
    pre_timetable = serializers.CharField(source='previous_timeinterval')
    cur_timetable = serializers.CharField(source='timeinterval.alias')
    apply_stamp = fields.DateTimeField(source='apply_time')
    approval_stamp = fields.DateTimeField(source='approval_time')
    approval_desc = serializers.CharField(source='get_approval_status_display')
    class Meta:
        model = ChangeSchedule
        fields = ('id', 'employee', 'att_date_stamp', 'pre_timetable', 'cur_timetable', 'apply_reason', 'apply_stamp', 'approval_status', 'approval_desc', 'approver', 'approval_stamp', 'approval_remark')