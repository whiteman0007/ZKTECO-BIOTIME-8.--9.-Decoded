# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\leave_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.forms import ModelChoiceField
from django.forms.widgets import HiddenInput
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.att.actions import Approve
from mysite.att.actions.common_actions import AuditForm
from mysite.att.models import Leave
from mysite.att.models.model_paycode import PayCode, LEAVE
from mysite.personnel.forms.fields import EmployeeSearchChoiceField, EmployeeMultipleChoiceField
class AddLeaveForm(forms.ZKActionForm):
    employee = EmployeeSearchChoiceField()
    start_time = forms.DateTimeField(label=_('leave_field_startTime'))
    end_time = forms.DateTimeField(label=_('leave_field_endTime'))
    pay_code = ModelChoiceField(label=_('leave.fields.payCode'), queryset=PayCode.objects.filter(code_type=LEAVE))
    auto_approve = forms.BooleanField(label=_('common.fields.autoApproved'), initial=True, required=False)
    reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    leave_day = forms.FloatField(label=_('leave.fields.leaveDay'), initial=0, suffix=_('time.units.day'))
    def __init__(self, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        self.permission = APPROVAL_APPROVE_PERMISSION.get('leave')
        super(AddLeaveForm, self).__init__(*args, **kwargs)
        if not self.request or not self.request.user.has_perm(self.permission):
                self.fields['auto_approve'].widget = HiddenInput()
                self.fields['auto_approve'].initial = False
class AddLeave(ZKModelAction):
    verbose_name = _('leave_action_new')
    short_description = _('leave_action_newDescription')
    help_txt = _('leave_action_newHelpTxt')
    action_form = AddLeaveForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        if data.get('employee', None):
            obj = Leave(employee=data['employee'], start_time=data['start_time'], end_time=data['end_time'], pay_code=data['pay_code'], apply_reason=data['reason'], attachment=data['attachment'], leave_day=data['leave_day'])
            obj.save(force_insert=True)
            user = self.request.user
            if data.get('auto_approve', None) and user.has_perm(self.valid_form.permission):
                    obj.do_approve(user, _('common.fields.autoApproved'))
        else:
            raise AdminRuntimeWarning(_('select_employee'))
class BulkAddLeaveForm(forms.ZKActionForm):
    employee = EmployeeMultipleChoiceField(required=False)
    start_time = forms.DateTimeField(label=_('leave_field_startTime'))
    end_time = forms.DateTimeField(label=_('leave_field_endTime'))
    pay_code = ModelChoiceField(label=_('leave.fields.payCode'), queryset=PayCode.objects.filter(code_type=LEAVE))
    auto_approve = forms.BooleanField(label=_('common.fields.autoApproved'), initial=True, required=False)
    reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    def __init__(self, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        self.permission = APPROVAL_APPROVE_PERMISSION.get('leave')
        super(BulkAddLeaveForm, self).__init__(*args, **kwargs)
        if not self.request or not self.request.user.has_perm(self.permission):
                self.fields['auto_approve'].widget = HiddenInput()
                self.fields['auto_approve'].initial = False
class BulkAddLeave(ZKModelAction):
    verbose_name = _('leave.actions.bulkAdd')
    short_description = _('leave.actions.bulkAdd.description')
    help_txt = _('leave.actions.bulkAdd.helpTxt')
    action_form = BulkAddLeaveForm
    def action(self, *args, **kwargs):
        from mysite.att.config_leave_group import default_leave_days
        data = self.valid_form.cleaned_data
        if data.get('employee', None):
            for emp in data['employee']:
                leave_day = default_leave_days(data['start_time'], data['end_time'], emp, data['pay_code'])
                obj = Leave(employee=emp, start_time=data['start_time'], end_time=data['end_time'], pay_code=data['pay_code'], apply_reason=data['reason'], leave_day=leave_day)
                obj.save(force_insert=True)
                user = self.request.user
                if data.get('auto_approve', None) and user.has_perm(self.valid_form.permission):
                        obj.do_approve(user, _('common.fields.autoApproved'))
        else:
            raise AdminRuntimeWarning(_('select_employee'))
class AuditLeaveForm(AuditForm):
    approval_remark = forms.TextField(label=_('leave_field_approvalReason'), required=False)
    leave_day = forms.FloatField(label=_('leave.fields.leaveDay'), initial=0, suffix=_('time.units.day'), required=False, disabled=True)
    def __init__(self, *args, **kwargs):
        super(AuditLeaveForm, self).__init__(*args, **kwargs)
        try:
            self.instance = Leave.objects.get(id=kwargs.get('request').GET.get('id'))
            self.fields['leave_day'].initial = self.instance.leave_day
        except:
            return None
class ApproveLeave(Approve):
    action_form = AuditLeaveForm