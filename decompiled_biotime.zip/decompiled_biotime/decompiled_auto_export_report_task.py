# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\auto_export_report_task.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import re
import six
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from mysite.base import const, db_const
from mysite.base.api.fields import DateTimeFormatChoiceField, ChoiceDisplayField, PrimaryKeyRelatedField
from mysite.base.models import SftpSetting
from mysite.att.models import ReportTemplate
class AutoExportReportOptionSerializer(serializers.Serializer):
    report_type = serializers.CharField()
    report_template = PrimaryKeyRelatedField(queryset=ReportTemplate.objects.get_queryset())
    file_prefix = serializers.CharField()
    export_format = serializers.CharField()
    export_encryption_type = serializers.IntegerField()
    export_encryption_password = serializers.CharField(required=False, allow_blank=True)
    contains_heads = serializers.BooleanField()
    file_date = serializers.CharField()
    file_time = serializers.CharField()
    export_policy = serializers.IntegerField()
    export_interval = serializers.IntegerField()
    frequency = serializers.IntegerField()
    month_day = serializers.IntegerField()
    week_day = serializers.IntegerField()
    day = serializers.IntegerField()
    export_time = serializers.CharField()
    export_period = serializers.IntegerField()
    export_path = serializers.CharField(allow_blank=True)
    export_email = serializers.CharField(allow_blank=True)
    ftp_server = PrimaryKeyRelatedField(queryset=SftpSetting.objects.get_queryset(), required=False, allow_null=True)
    ftp_path = serializers.CharField(allow_blank=True)
    @staticmethod
    def validate_export_email(email_datas):
        for data in email_datas.split(';'):
            pattern = re.compile('^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$')
            if data and (not re.match(pattern, data)):
                raise ValidationError(detail=_('autoExport_task_error_email'))
        return email_datas
    @staticmethod
    def validate_export_time(data):
        pattern = re.compile('^([01][0-9]|2[0-3]):([0-5][0-9])$')
        points = data.split(';')
        for point in points:
            if not re.match(pattern, point):
                raise ValidationError(detail=_('autoExport_task_error_time_point'))
        return data
class AutoExportReportOptionExecutableSerializer(serializers.Serializer):
    report_type = serializers.CharField()
    report_template = serializers.PrimaryKeyRelatedField(queryset=ReportTemplate.objects.get_queryset())
    file_prefix = serializers.CharField()
    export_format = serializers.CharField()
    export_encryption_type = serializers.IntegerField()
    export_encryption_password = serializers.CharField(required=False, allow_blank=True)
    contains_heads = serializers.BooleanField()
    file_date = DateTimeFormatChoiceField(choices=const.HUMAN_SHORT_DATE)
    file_time = DateTimeFormatChoiceField(choices=const.HUMAN_SHORT_TIME)
    export_policy = serializers.IntegerField()
    export_interval = serializers.IntegerField()
    frequency = serializers.IntegerField()
    month_day = serializers.IntegerField()
    week_day = serializers.IntegerField()
    day = serializers.IntegerField()
    export_time = serializers.CharField()
    export_period = serializers.IntegerField()
    export_path = serializers.CharField(allow_blank=True)
    export_email = serializers.CharField(allow_blank=True)
    ftp_server = serializers.PrimaryKeyRelatedField(queryset=SftpSetting.objects.get_queryset(), required=False, allow_null=True)
    ftp_path = serializers.CharField(allow_blank=True)
class AutoExportReportOptionReadableSerializer(serializers.Serializer):
    report_type = ChoiceDisplayField(choices=db_const.REPORT_GROUP, data_format=six.text_type, default=db_const.TOTAL_TIME_CARD_REPORT)
    report_template = serializers.PrimaryKeyRelatedField(queryset=ReportTemplate.objects.get_queryset())
    file_prefix = serializers.CharField()
    export_format = ChoiceDisplayField(choices=const.FILE_FORMAT, data_format=six.text_type, default=const.FORMAT_XLS)
    export_encryption_type = serializers.IntegerField()
    export_encryption_password = serializers.CharField(required=False, allow_blank=True)
    contains_heads = serializers.BooleanField()
    file_date = ChoiceDisplayField(choices=const.HUMAN_SHORT_DATE, default=12)
    file_time = ChoiceDisplayField(choices=const.HUMAN_SHORT_TIME, default=11)
    export_policy = ChoiceDisplayField(choices=const.EXPORT_POLICES, default=const.BY_TIMING)
    export_interval = serializers.IntegerField()
    frequency = ChoiceDisplayField(choices=const.EXPORT_FREQUENCY, default=const.DAILY)
    month_day = serializers.IntegerField()
    week_day = serializers.IntegerField()
    day = serializers.IntegerField()
    export_time = serializers.CharField()
    export_period = ChoiceDisplayField(choices=const.EXPORT_PERIOD, default=const.PREVIOUS_PERIOD)
    export_path = serializers.CharField(allow_blank=True)
    export_email = serializers.CharField(allow_blank=True)
    ftp_server = serializers.PrimaryKeyRelatedField(queryset=SftpSetting.objects.get_queryset(), required=False, allow_null=True)
    ftp_path = serializers.CharField(allow_blank=True)