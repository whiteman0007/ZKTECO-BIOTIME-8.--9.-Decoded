# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\forms\\acc_privilege_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:49 UTC (1750672969)

from django.core.cache import cache
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.acc.models import AccPrivilege, AccGroups, AccTimezone
from mysite.admin import forms
class AccPrivilegeForm(ModelForm):
    emp = forms.CharField(label=_('accPrivilege_field_employee'), disabled=True)
    group = forms.ModelChoiceField(label=_('accPrivilege_field_group'), queryset=AccGroups.objects.all())
    timezone1 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone1'), queryset=AccTimezone.objects.all())
    timezone2 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone2'), queryset=AccTimezone.objects.all(), required=False)
    timezone3 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone3'), queryset=AccTimezone.objects.all(), required=False)
    group_verify_mode = forms.IntegerField(required=False)
    group_timezone1 = forms.IntegerField(required=False)
    group_timezone2 = forms.IntegerField(required=False)
    group_timezone3 = forms.IntegerField(required=False)
    class Meta:
        model = AccPrivilege
        fields = ('group', 'is_group_timezone', 'timezone1', 'timezone2', 'timezone3', 'verify_mode', 'is_group_verifycode')
    def __init__(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        super(AccPrivilegeForm, self).__init__(*args, **kwargs)
        try:
            self.fields['group'].queryset = AccGroups.objects.filter(area_id=self.instance.area_id)
            timezones = AccTimezone.objects.filter(area_id=self.instance.area_id)
            self.fields['timezone1'].queryset = timezones
            self.fields['timezone2'].queryset = timezones
            self.fields['timezone3'].queryset = timezones
            if self.instance.pk:
                self.fields['emp'].initial = str(self.instance.employee)
                self.fields['group_verify_mode'].initial = str(self.instance.group.verify_mode)
                self.fields['group_timezone1'].initial = str(AccTimezone.objects.filter(timezone_no=self.instance.group.timezone1, area_id=self.instance.area_id).first().id)
                self.fields['group_timezone2'].initial = str(AccTimezone.objects.filter(timezone_no=self.instance.group.timezone2, area_id=self.instance.area_id).first().id)
                self.fields['group_timezone3'].initial = str(AccTimezone.objects.filter(timezone_no=self.instance.group.timezone3, area_id=self.instance.area_id).first().id)
        except Exception:
            pass
        if self.instance.pk and self.instance.timezone1:
                self.initial['timezone1'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone1).first().id
        if self.instance.pk and self.instance.timezone2:
                self.initial['timezone2'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone2).first().id
        if self.instance.pk and self.instance.timezone3:
                self.initial['timezone3'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone3).first().id
                    except Exception as e:
                            return None
    def clean(self):
        cleaned_data = super(AccPrivilegeForm, self).clean()
        if 'timezone1' in cleaned_data and cleaned_data['timezone1']:
            cleaned_data['timezone1'] = cleaned_data['timezone1'].timezone_no
        else:
            cleaned_data['timezone1'] = 0
        if 'timezone2' in cleaned_data and cleaned_data['timezone2']:
            cleaned_data['timezone2'] = cleaned_data['timezone2'].timezone_no
        else:
            cleaned_data['timezone2'] = 0
        if 'timezone3' in cleaned_data and cleaned_data['timezone3']:
            cleaned_data['timezone3'] = cleaned_data['timezone3'].timezone_no
        else:
            cleaned_data['timezone3'] = 0
        return cleaned_data
    def save(self, commit=True):
        return super(AccPrivilegeForm, self).save(commit=False)