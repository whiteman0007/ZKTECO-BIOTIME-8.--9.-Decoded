# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\daily_exception.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.utils.html import format_html
from django.db.models import Q
from django.db.models.functions import TruncDate
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.api import fields
from mysite.att.api.base_serializers import EmployeePayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.models import PayloadTimeCard
class DailyExceptionSerializer(EmployeePayCodeRelatedReportModelSerializer):
    att_date = fields.DateField(label=_('report_column_attendanceDate'))
    clock_in = fields.TimeField(label=_('report.columns.clockIn'))
    clock_out = fields.TimeField(label=_('report.columns.clockOut'))
    weekday = fields.WeekdayField(label=_('report_column_attendanceWeekday'))
    description = serializers.SerializerMethodField(label=_('report.columns.description'), allow_null=True)
    time_table_alias = serializers.SerializerMethodField(label=_('report.columns.timetable'))
    def get_time_table_alias(self, obj):
        color = obj.get('time_table__color_setting', None)
        alias = obj.get('time_table_alias', '')
        if not color:
            return alias
        else:
            return format_html('<div style=\"color:#ffffff;background:{0}\">{1}</div>', color, alias)
    def get_description(self, obj):
        descriptions = []
        clock_in = obj.get('clock_in', None)
        clock_out = obj.get('clock_out', None)
        if not clock_in:
            descriptions.append(str(_('report.exception.missClockIn')))
        if not clock_out:
            descriptions.append(str(_('report.exception.missClockOut')))
        return ','.join(descriptions)
    class Meta:
        model = PayloadTimeCard
        fields = ('id', 'emp_id', 'emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday', 'time_table_alias', 'company_code', 'company_name', 'clock_in', 'clock_out', 'description')
class DailyExceptionFilter(ReportGenericFilter):
    class Meta:
        model = PayloadTimeCard
        fields = ['employees', 'departments', 'start_date', 'end_date']
class DailyExceptionViewSet(ReportUserGenericViewSet):
    model = PayloadTimeCard
    queryset = PayloadTimeCard.objects.filter(date_type__in=(0, 1)).order_by('emp__emp_code', 'att_date')
    filterset_class = DailyExceptionFilter
    serializer_dict = {'list': DailyExceptionSerializer, 'export': DailyExceptionSerializer}
    def __init__(self, *args, **kwargs):
        super(DailyExceptionViewSet, self).__init__(*args, **kwargs)
    def annotate_queryset(self, queryset):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            ordering = ['emp__emp_code_digit', 'emp__emp_code', 'att_date']
        else:
            ordering = ['emp__emp_code', 'att_date']
        queryset = queryset.annotate(description=TruncDate('att_date'))
        queryset = queryset.values('emp_id', 'emp__emp_code', 'emp__first_name', 'emp__last_name', 'emp__nickname', 'emp__gender', 'emp__department__dept_code', 'emp__department__dept_name', 'emp__position__position_code', 'emp__position__position_name', 'att_date', 'weekday', 'time_table_alias', 'clock_in', 'clock_out', 'description', 'emp__emp_code_digit', 'emp__company__company_code', 'emp__company__company_name', 'time_table__color_setting').order_by(*ordering)
        return queryset
    def filter_queryset(self, queryset):
        qs = super(DailyExceptionViewSet, self).filter_queryset(queryset)
        qs = qs.filter(Q(clock_in__isnull=True) | Q(clock_out__isnull=True))
        return qs
    def get_file_title(self):
        return _('att.menus.reports.dailyException')