# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\forms\\auto_import_task_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

import json
from django.forms import ModelForm
from django.forms import ValidationError
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.base import const
from mysite.base.db_const import IMPORT_DATA_TYPE
from mysite.base.db_const import WEEKDAY
from mysite.base.models import AutoImportTask, SftpSetting
ADD_USER_DEFINE = 2
MONTHLY = [(x, x) for x in range(1, 32, 1)]
class AutoImportTaskCreationForm(ModelForm):
    task_code = forms.CharField(label=_('autoExportTask_field_code'), disabled=True)
    task_name = forms.CharField(label=_('autoExportTask_field_name'))
    import_data_type = forms.ChoiceField(label=_('autoImportTask_field_import_data_type'), required=False, choices=IMPORT_DATA_TYPE, initial=1)
    existing_data = forms.BooleanField(label=_('autoImportTask_field_existing_data'), initial=False, required=False)
    enable = forms.BooleanField(label=_('autoImportTask.fields.enable'), initial=1, required=False)
    import_policy = forms.ChoiceField(label=_('autoImportTask.fields.policy'), choices=const.EXPORT_POLICES, initial=const.BY_TIMING, required=True)
    frequency = forms.ChoiceField(label=_('autoExport_task_frequency'), choices=const.EXPORT_FREQUENCY, initial=const.DAILY)
    month_day = forms.ChoiceField(label=_('autoExport_task_exportDay'), initial=1, choices=MONTHLY)
    week_day = forms.ChoiceField(label=_('autoExport_task_exportDay'), initial=1, choices=WEEKDAY)
    day = forms.ChoiceField(label=_('autoExport_task_exportDay'), initial=1, choices=((1, 1),))
    import_interval = forms.IntegerField(label=_('autoExport_task_interval'), initial=1, unit=_('timeInterval_field_workTimeDurationHelpTxt'), min_value=1)
    import_time = forms.CharField(label=_('autoImportTask_task_importTime'), initial='00:01', unit=_('HH:mm'))
    ftp_server = forms.ModelChoiceField(label=_('autoExport_task_ftpServer'), queryset=SftpSetting.objects.get_queryset(), required=False)
    ftp_path = forms.CharField(label=_('autoExport_task_ftpPath'), help_text=_('Support excel(.xlsx/.xls)'), required=False, widget=forms.widgets.ZKTextInput(attrs={'placeholder': '/Folder/'}))
    import_path = forms.CharField(label=_('autoImport_task_importPath'), help_text=_('Support excel(.xlsx/.xls)'), required=False, widget=forms.widgets.ZKTextInput(attrs={'placeholder': 'E:/Folder1/'}))
    archived_path = forms.CharField(label=_('autoImport_task_archivedPath'), required=True, widget=forms.widgets.ZKTextInput(attrs={'placeholder': 'E:/Folder/'}))
    is_add_default = True
    def __init__(self, *args, **kwargs):
        from mysite.base import threadlocals
        from mysite.personnel.models import Company
        super(AutoImportTaskCreationForm, self).__init__(*args, **kwargs)
        objs = AutoImportTask.all_objects.values('task_code')
        codes = [int(i['task_code']) for i in objs if i['task_code'].isdigit()]
        self.fields['task_code'].initial = str(max(codes) + 1 if codes else 1)
        cur_user = threadlocals.get_current_user()
        if cur_user and cur_user.id and (not cur_user.is_superuser):
                    self.fields['company'].queryset = Company.objects.filter(id=cur_user.assign_company)
                    self.fields['company'].initial = Company.objects.filter(id=cur_user.assign_company).first()
        if getattr(self.instance, 'params', None):
            params = json.loads(self.instance.params)
            for k, v in list(params.items()):
                if k not in self.fields:
                    if k == 'add_style' and int(params['add_style']) == ADD_USER_DEFINE:
                            self.is_add_default = False
                else:
                    self.fields[k].initial = v
    def clean_params(self):
        params = {}
        for f in list(self.fields.keys()):
            if f in ['task_code', 'task_name', 'company', 'enable', 'params', 'ftp_server']:
                if f == 'ftp_server':
                    ftp_obj = self.cleaned_data.get(f, '')
                    if ftp_obj:
                        params['ftp_server'] = ftp_obj.id
                if f == 'params':
                    params_data = self.cleaned_data.get('params', '')
                    add_default = 1
                    if params_data:
                        params_data = str(params_data).split(',', 1)
                        params['add_style'] = int(params_data[0])
                        params['import_interval'] = int(params['import_interval'])
                        params['frequency'] = int(params['frequency'])
                        params['import_policy'] = int(params['import_policy'])
                        if params['add_style'] == add_default:
                            dft_dict = {i: index + 2 for index, i in enumerate(params_data[1].split(','))}
                            dft_dict['emp_code'] = 1
                            params['fields'] = [dft_dict]
                        else:
                            params['fields'] = json.loads(params_data[1])
                            if params['fields'][0]:
                                if 'field' in params['fields'][0]:
                                    del params['fields'][0]['field']
                                if 'option' in params['fields'][0]:
                                    del params['fields'][0]['option']
                                if 'LAY_TABLE_INDEX' in params['fields'][0]:
                                    del params['fields'][0]['LAY_TABLE_INDEX']
            else:
                val = self.cleaned_data.get(f, '')
                params[f] = val
        return json.dumps(params)
    def clean(self):
        cleaned_data = super(AutoImportTaskCreationForm, self).clean()
        data_pre_check(cleaned_data)
        return cleaned_data
    class Meta:
        model = AutoImportTask
        fields = ('task_code', 'task_name', 'enable', 'company', 'import_data_type', 'existing_data', 'import_policy', 'frequency', 'month_day', 'week_day', 'day', 'import_interval', 'import_time', 'ftp_server', 'ftp_path', 'import_path', 'archived_path', 'params')
def data_pre_check(cleaned_data):
    import os
    from mysite.base import config
    from mysite.base.utils import check_auto_task_path
    from mysite.base import const
    params = cleaned_data.get('params', '')
    if params:
        params = json.loads(params)
        add_style = params['add_style']
        import_policy = params['import_policy']
        if int(import_policy) == 1:
            import_interval = params['import_interval']
            if import_interval and int(import_interval) < 1:
                message = _('autoExport_task_errorExportInterval')
                raise ValidationError(message, code='-1')
        if add_style == ADD_USER_DEFINE and len(params['fields']) > 0 and params['fields'][0]:
            fv_dict = params['fields'][0]
            must_fd = config.AUTOIMPORTTASK_EMPLOYEE_MUST_FIELDS
            if must_fd[0] in fv_dict and (not fv_dict[must_fd[0]]):
                message = _('auto_import_task_form_required_error')
                raise ValidationError(message, code='-1')
            else:
                v_list = [x for x in fv_dict.values() if x!= '']
                list_check_1 = set(v_list)
                if len(list_check_1)!= len(v_list):
                    message = _('auto_import_task_form_repeated_error')
                    raise ValidationError(message, code='-1')
                else:
                    list_check_2 = list(filter(add_v, v_list))
                    if len(list_check_2)!= len(v_list):
                        message = _('auto_import_task_form_int_error')
                        raise ValidationError(message, code='-1')
        archived_path = params.get('archived_path', None)
        if archived_path and (not os.path.isdir(archived_path)):
            message = _('auto_import_task_form_archived_path_error')
            raise ValidationError(message, code='-1')
        else:
            import_path = params.get('import_path', '')
            if import_path:
                if not os.path.isdir(import_path):
                    message = _('auto_import_task_form_import_path_error')
                    raise ValidationError(message, code='-1')
                else:
                    if os.path.samefile(import_path, archived_path):
                        message = _('auto_import_task_form_same_import_archived_path_error')
                        raise ValidationError(message, code='-1')
            ftp_server = params.get('ftp_server', None)
            ftp_path = params.get('ftp_path', '')
            if ftp_server:
                check, task_code, code = check_auto_task_path(ftp_server, ftp_path, import_path, const.AUTO_IMPORT)
                if check:
                    if code == (-1):
                        message = _('auto_import_task_form_ftp_path_use_export_error_%s') % str(task_code)
                        raise ValidationError(message, code='-1')
                    else:
                        if code == (-2):
                            message = _('auto_import_task_form_import_path_use_export_error_%s') % str(task_code)
                            raise ValidationError(message, code='-1')
def add_v(v):
    try:
        return int(v)
    except:
        return ''