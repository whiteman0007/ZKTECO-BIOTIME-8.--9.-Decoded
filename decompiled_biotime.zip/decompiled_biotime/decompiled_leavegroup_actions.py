# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\leavegroup_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import json
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from django.forms import ModelForm
from mysite.admin.action import ActionHandleError
from mysite.att.models import LeaveGroup
from mysite.personnel.models import Employee
from mysite.att.company_form import CompanyField4ModelForm
class AssignLeaveGroupForm(forms.ZKActionForm):
    employee = forms.EmployeeManyToManyField(label=_('model_employee'), required=False)
    def __init__(self, *args, **kwargs):
        super(AssignLeaveGroupForm, self).__init__(*args, **kwargs)
class AssignLeaveGroup(admin.ZKModelAction):
    verbose_name = _('leaveGroup.actions.AssignLeaveGroup')
    short_description = _('leaveGroup.actions.AssignLeaveGroup')
    help_txt = _('leaveGroup.actions.AssignLeaveGroup')
    action_form = AssignLeaveGroupForm
    batch_select = True
    unique_object_required = True
    def __init__(self, request, admin=None, obj_ids=None):
        super(AssignLeaveGroup, self).__init__(request, admin, obj_ids)
        if request.method == 'GET' and 'objects' in request.GET:
                import json
                self.action_form.emps_objects = json.loads(request.GET['objects'])
    def action(self, *args, **kwargs):
        from mysite.att import tasks
        emps = self.request.POST.getlist('employee')
        if not emps:
            raise ActionHandleError(_('select_none_employee'))
        else:
            objs = Employee.objects.filter(id__in=emps)
            for obj in objs:
                obj.leave_group = self.objects[0].id
                obj.save()
                tasks.restore_leaveyearbalance.delay(obj)
class AddLeaveGroupForm(CompanyField4ModelForm):
    code = forms.CharField(label=_('leaveGroup.fields.code'), max_length=50)
    name = forms.CharField(label=_('leaveGroup.fields.name'), max_length=100)
    class Meta:
        model = LeaveGroup
        fields = ('code', 'name', 'company')
    def __init__(self, *args, **kwargs):
        super(AddLeaveGroupForm, self).__init__(*args, **kwargs)
        try:
            objs = LeaveGroup.objects.values('code')
            codes = [int(i['code']) for i in objs if i['code'].isdigit()]
            self.fields['code'].initial = str(max(codes) + 1 if codes else 1)
        except Exception:
            return None
class AddLeaveGroup(admin.ZKModelAction):
    verbose_name = _('leaveGroup.actions.AddLeaveGroup')
    action_form = AddLeaveGroupForm
    def __init__(self, request, admin=None, obj_ids=None):
        super(AddLeaveGroup, self).__init__(request, admin, obj_ids)
    def action(self, *args, **kwargs):
        self.valid_form.save(commit=False)
        self.valid_form.save()