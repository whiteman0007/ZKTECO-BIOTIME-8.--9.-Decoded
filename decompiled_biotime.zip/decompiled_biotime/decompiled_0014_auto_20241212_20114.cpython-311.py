# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0014_auto_20241212_20114.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('personnel', '0013_alter_area_area_name_alter_certification_cert_name_and_more')]
    operations = [migrations.AddField(model_name='employee', name='password_reset', field=models.DateTimeField(blank=True, editable=False, null=True, verbose_name='emp_field_passwordReset'))]