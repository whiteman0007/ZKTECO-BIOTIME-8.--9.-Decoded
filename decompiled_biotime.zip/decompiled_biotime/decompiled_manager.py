# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\manager.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from .base import ReportAdminBase, ReportWrapper
class AlreadyRegistered(Exception):
    # return None
    pass
class ReportManager(object):
    """\n    A ReportManager object is a collection of ReportWrapper, ready to be hooked in to your URLconf. \n    ReportAdminBase models are registered with the ReportManager using the\n    register() method, and the get_urls() method will hook all ReportAdminBase models\' urls\n    into your URLconf.\n    """
    def __init__(self):
        self._registry = {}
    def register(self, model_or_iterable, wrapper=None, **options):
        """\n        Registers the given ReportAdminBase model(s) into registry dictionary.\n\n        The model(s) should be ReportAdminBase classes, not instances.\n\n        If a wrapper isn\'t given, it will use ReportWrapper (the default\n        admin options). \n\n        If a model is already registered, this will raise AlreadyRegistered.\n\n        """
        if issubclass(model_or_iterable, ReportAdminBase):
            model_or_iterable = [model_or_iterable]
        if not wrapper:
            wrapper = ReportWrapper
        for model in model_or_iterable:
            if model in self._registry:
                raise AlreadyRegistered('The model %s is already registered' % model.__name__)
            else:
                model_name = model.model_name
                self._registry[model_name] = wrapper(model, self)
    def get_model_admin(self, model_name):
        """\n        Returns a instance of ReportWrapper that have been registered in this ReportManager.\n        """
        return self._registry.get(model_name, None)
    def get_urls(self):
        urls = []
        for model_name, report_wrapper in self._registry.items():
            model = report_wrapper.model()
            urls += model.urls
        return urls
    @property
    def urls(self):
        return self.get_urls()
report_manager = ReportManager()