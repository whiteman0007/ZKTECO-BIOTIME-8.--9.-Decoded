# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\acc\\api\\serializers\\acctimezone_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from rest_framework import serializers
from mysite.acc.models.model_acc_timezone import AccTimezone
from mysite.att.api.serializers import util_serializers
class AccTimezoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccTimezone
        fields = ['id', 'area', 'timezone_no', 'timezone_name', 'sun_start', 'sun_end', 'sun_on', 'mon_start', 'mon_end', 'mon_on', 'tue_start', 'tue_end', 'tue_on', 'wed_start', 'wed_end', 'wed_on', 'thu_start', 'thu_end', 'thu_on', 'fri_start', 'fri_end', 'fri_on', 'sat_start', 'sat_end', 'sat_on']
class AccTimezoneCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccTimezone
        fields = '__all__'
class AccTimezoneEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccTimezone
        fields = '__all__'
class AccTimezoneActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AccTimezone
        action_type_choices = (('delete', 'delete'),)