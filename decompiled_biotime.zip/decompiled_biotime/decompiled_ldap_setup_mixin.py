# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\ldap_setup_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
class LDAPViewMixin:
    @action(methods=['get', 'post'], url_path='ldap_setup', detail=False)
    def ldap_setup(self, request, *args, **kwargs):
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='ldap_setup').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        else:
            serializer = serializers.LDAPSetupSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj = SystemSetting.objects.filter(name='ldap_setup').first()
            if not obj:
                obj = SystemSetting(name='ldap_setup')
            obj.value = json.dumps(data)
            obj.save()
            return Response(data)
    @action(methods=['post'], detail=False)
    def test_ldap_connection(self, request, *args, **kwargs):
        import ldap
        serializer = serializers.LDAPConnectionSetupSerializer(data=request.data)
        serializer.is_valid()
        try:
            data = serializer.validated_data
            ad = ldap.initialize(data['host'])
            ad.bind_s(data['username'], data['password'])
            return Response({'detail': 'Success'})
        except ldap.LDAPError as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    @action(methods=['get'], detail=False)
    def sync_ldap_employee(self, request, *args, **kwargs):
        from mysite.base.tasks import sync_ad_server_data
        sync_ad_server_data.delay()
        return Response({'detail': 'Success'})