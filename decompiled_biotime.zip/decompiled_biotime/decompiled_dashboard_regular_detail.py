# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\ep\\api\\serializers\\dashboard_regular_detail.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

from rest_framework import serializers
from mysite.ep.models import EPTransaction
class DashboardRegularDetailSerializer(serializers.ModelSerializer):
    emp_code = serializers.CharField(source='emp__emp_code')
    first_name = serializers.CharField(source='emp__first_name', allow_null=True)
    last_name = serializers.CharField(source='emp__last_name', allow_null=True)
    dept_name = serializers.CharField(source='emp__department__dept_name', allow_null=True)
    position_name = serializers.CharField(source='emp__position__position_name', allow_null=True)
    check_times = serializers.IntegerField(source='times', allow_null=True)
    class Meta:
        model = EPTransaction
        fields = ('emp_code', 'first_name', 'last_name', 'dept_name', 'position_name', 'check_date', 'check_times')