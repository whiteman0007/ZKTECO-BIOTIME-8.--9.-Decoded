# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
class AddTemplateForm(forms.ZKActionForm):
    template_name = forms.CharField(label=_('Name'))
    is_share = forms.BooleanField(label=_('reportTemplate.field.isShare'), initial=False, required=False)
    auto_export = forms.BooleanField(label=_('reportTemplate.field.isAutoExport'), initial=True, required=False)
    fixed_date_period = forms.BooleanField(label=_('reportTemplate.field.fixedDatePeriod'), initial=False, required=False)
    start_date = forms.DateField(label=_('Start Date'))
    end_date = forms.DateField(label=_('End Date'))