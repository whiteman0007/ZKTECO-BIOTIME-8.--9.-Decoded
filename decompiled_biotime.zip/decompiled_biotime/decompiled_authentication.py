# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\api\\authentication.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 09:40:19 UTC (1750671619)

from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from rest_framework_simplejwt.models import TokenUser
from rest_framework_simplejwt.authentication import JWTTokenUserAuthentication as BaseAuthentication
UserModel = get_user_model()
class JWTTokenUserAuthentication(BaseAuthentication):
    def authenticate(self, request):
        tuple_result = super().authenticate(request)
        if tuple_result is not None:
            user, access_token = tuple_result
        else:
            return None
        if isinstance(user, TokenUser):
            user = UserModel.objects.filter(id=user.id).first()
            if not user:
                user = AnonymousUser()
        return (user, access_token)