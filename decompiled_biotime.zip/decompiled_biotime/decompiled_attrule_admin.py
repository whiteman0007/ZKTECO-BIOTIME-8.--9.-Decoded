# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\attrule_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from mysite import admin
from mysite.att import forms
from mysite.att.models.model_attrule import AttRule, DEFAULT_PARAMS
@admin.register(AttRule)
class AttRuleAdmin(admin.ZKModelAdmin):
    @staticmethod
    def initial_data():
        import json
        if AttRule.objects.all().count() == 0:
            val = json.dumps(DEFAULT_PARAMS)
            att_rule = AttRule()
            att_rule.param_name = 'global_att_rule'
            att_rule.param_value = val
            super(AttRule, att_rule).save()
    def has_add_permission(self, request):
        return False