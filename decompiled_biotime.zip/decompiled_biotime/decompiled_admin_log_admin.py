# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\admin_log_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:08 UTC (1750672988)

import json
from django.core.exceptions import FieldDoesNotExist, MultipleObjectsReturned
from django.utils.encoding import force_str
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite._utils import cprint
from mysite.admin.kernel import ZKModelAdmin
from mysite.base.models import AdminLog
@admin.register(AdminLog)
class AdminLogAdmin(ZKModelAdmin):
    list_display = ['user', 'ip_address', 'op_time', 'action', 'content_type', 'targets_repr', 'action_status', 'description']
    list_display_params = {'__all__': {'width': 200}}
    sort_fields = ['-op_time']
    list_filter = ['user__username', 'action', 'description', 'ip_address', 'op_time']
    history_list_filter = ['user', 'action', 'description', 'ip_address', 'op_time']
    list_select_related = ('user', 'content_type')
    def targets_repr(self, obj):
        target_list = json.loads(obj.targets)
        if not isinstance(target_list, list):
            target_list = [target_list]
        result = []
        for tg in target_list:
            try:
                tg_obj = obj.content_type.model_class().objects.get(pk=tg)
            except (FieldDoesNotExist, MultipleObjectsReturned) as e:
                cprint('{} {}'.format(type(e), e), 'red')
            else:
                result.append(force_str(tg_obj))
        return ','.join(result)
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    targets_repr.short_description = _('adminLog_field_objects')
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return ['ip_address', 'op_time']
        else:
            return []
    def get_queryset(self, request):
        queryset = super(AdminLogAdmin, self).get_queryset(request)
        return queryset