# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\event_alert_setting_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from django.utils.translation import gettext
from mysite import admin
from mysite._utils import getattr_ex
from mysite.admin.kernel import ZKModelAdmin
from mysite.base.models import EventAlertSetting
from mysite.base import const
from mysite.authorized import auth_settings
from django.conf import settings
@admin.register(EventAlertSetting)
class EventAlertSettingAdmin(ZKModelAdmin):
    if settings.FACEBOOK_ENABLE:
        list_display = ('event', 'module', 'sub_module', 'email_alert', 'app_alert', 'sms_alert', 'facebook_alert')
    else:
        list_display = ('event', 'module', 'sub_module', 'email_alert', 'app_alert', 'sms_alert')
    @staticmethod
    def initial_data():
        if not EventAlertSetting.objects.exists():
            for event in const.ALERT_EVENTS:
                EventAlertSetting(**event).save(force_insert=True)
        if not EventAlertSetting.objects.filter(event_id__in=(const.PUNCH_IN, const.PUNCH_OUT)).exists():
            for event in const.PUNCH_ALERT_EVENTS:
                EventAlertSetting(**event).save(force_insert=True)
    def event_viewing(self, obj, value):
        return gettext(value)
    def module_viewing(self, obj, value):
        return gettext(value)
    def sub_module_viewing(self, obj, value):
        return gettext(value)
    def email_alert_viewing(self, obj, value):
        return value
    def app_alert_viewing(self, obj, value):
        return value
    def whatapp_alert_viewing(self, obj, value):
        return value
    def sms_alert_viewing(self, obj, value):
        return value
    def facebook_alert_viewing(self, obj, value):
        return value
    def lineapp_alert_viewing(self, obj, value):
        return value
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        qs = super(EventAlertSettingAdmin, self).get_queryset(request)
        if not auth_settings.ENABLE_VISITOR:
            qs = qs.exclude(event_id=const.VI_RESERVATION)
        if not auth_settings.ENABLE_MEETING:
            qs = qs.exclude(event_id__in=[const.MT_MEETING, const.MT_MANUAL_LOG])
        return qs