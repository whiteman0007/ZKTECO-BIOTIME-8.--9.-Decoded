# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\base.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

import json
import datetime
from django.conf import settings
from django.urls import re_path
from django.template.response import TemplateResponse
from django.urls import reverse
from mysite._utils import getattr_ex
from mysite.admin.utils import insert_non_model_permission
from mysite.admin.utils import login_admin_view_wrap
class MissingSetting(Exception):
    # return None
    pass
class ReportAdminBase(object):
    """Encapsulates all report admin options and functionality for a given model.\n\n    :param superior: (optional) category name of permission and url path\n    :param base_template: (optional) default html template path of report,\n        if template parameter is None, base_template will be used.\n    :param model_name: Report model name, it\'s should be unique.\n    :param view_name: Report url view name.\n    :param template: The template file path be used to render the report.\n    :param list_display: The list of display fields\' name.\n    :param hidden_fields: The list of hidden fields\' name.\n    :param sort_fields: The list of sorted fields\' name.\n    :param data_source: The API url of report data which will present on report.\n    :param required_dept_wise: Whether required department wise in auto export or not.\n    :param api_view: The API view set of this report.(As payload data set in auto export report)\n    :param serializer: The API serializer of this report.(As payload serializer in auto export report)\n    :param add_template_ui: The template file of pop-up windows( Save Layout).\n    :param load_template_ui: The template file of pop-up windows( Load Layout).\n    """
    superior = 'report'
    base_template = 'att/report/base.html'
    model_name = None
    view_name = None
    template = None
    list_display = []
    hidden_fields = []
    sort_fields = []
    data_source = ''
    required_dept_wise = False
    required_group_wise = False
    api_view = None
    serializer = None
    add_template_ui = None
    load_template_ui = None
    _data_view = None
    ext_insert_index = 9
    paycode_type = None
    fixed_code = None
    add_paycode_column = False
    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs
    @property
    def data_view(self):
        if self._data_view:
            return self._data_view
        else:
            if callable(self.api_view):
                self._data_view = self.api_view()
                return self._data_view
            else:
                return None
    @staticmethod
    def bool_value(value):
        return int(bool(value))
    def get_user_defined_hidden_fields(self, request):
        """\n        Returns user defined hidden fields. If not defined, use default hidden fields.\n        """
        from mysite.admin.utils import load_from_json
        try:
            if request.user.is_employee:
                disabled_fields = load_from_json(request.user.employeeprofile.disabled_fields, dict).get(self.model_name, None)
            else:
                disabled_fields = load_from_json(request.user.userprofile.disabled_fields, dict).get(self.model_name, None)
        except (AttributeError, KeyError):
            disabled_fields = None
        return disabled_fields
    def get_user_defined_list_display(self, request):
        """\n        Returns user defined display fields. If not defined, use default display fields.\n        """
        from mysite.admin.utils import load_from_json
        try:
            if request.user.is_employee:
                list_display = load_from_json(request.user.employeeprofile.column_order, dict).get(self.model_name, None)
            else:
                list_display = load_from_json(request.user.userprofile.column_order, dict).get(self.model_name, None)
        except (AttributeError, KeyError):
            list_display = None
        return list_display
    def add_emp_ext_cols(self, cols):
        from mysite.personnel.models import EmployeeCustomAttribute
        for f in EmployeeCustomAttribute.cache_data():
            data = {'field': 'user_defined_%s' % f.id, 'title': f.attr_name}
            cols.insert(self.ext_insert_index, data)
        return cols
    def get_emp_ext_fields(self):
        from mysite.personnel.models import EmployeeCustomAttribute
        return ['user_defined_%s' % f.id for f in EmployeeCustomAttribute.cache_data()]
    def get_layui_cols(self):
        from mysite.att.models import AttCode
        from mysite.att.models.model_paycode import PayCode
        from mysite.att import const
        from .utils import column_title, column_width
        if not self.list_display:
            return []
        else:
            extend_fields = ['company_code', 'company_name']
            if getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
                extend_fields = []
            att_codes = AttCode.objects.filter(symbol_only=False).order_by('order').values('id', 'code', 'alias', 'display_format', 'min_val', 'round_off', 'color_setting')
            dic_attCodes = {c['code']: c for c in att_codes}
            cols = [{'field': field, 'width': column_width(field), 'sort': self.bool_value(field in self.sort_fields), 'title': dic_attCodes[field]['alias'] if field in dic_attCodes else column_title(field)} for field in self.list_display if field not in extend_fields]
            if 'emp_code' in self.list_display:
                cols = self.add_emp_ext_cols(cols)
            if self.add_paycode_column:
                codes = PayCode.objects.all()
                if self.paycode_type:
                    codes = codes.filter(code_type=self.paycode_type)
                if self.fixed_code:
                    codes = codes.filter(fixed_code__in=self.fixed_code)
                codes = codes.order_by('display_order').values('id', 'name', 'display_format', 'is_display')
                for code in codes:
                    cols.append({'field': 'paycode_{0}'.format(code['id']), 'title': '{name}({unit})'.format(name=code['name'], unit=const.PAYCODE_FORMAT_DICT.get(code['display_format'], 'M')), 'hide': self.bool_value(not code['is_display'])})
            return cols
    def user_defined_cols(self, list_display, hidden_fields):
        # irreducible cflow, using cdg fallback
        """\n        Return final api fields, including dispaly and hidden fields.\n        """
        fields = dict(map(lambda x: (x['field'], x), self.get_layui_cols()))
        all_fields = list(fields.keys())
        if hidden_fields is None:
            hidden_fields = list(self.hidden_fields)
            if 'emp_code' in self.list_display:
                hidden_fields.extend(self.get_emp_ext_fields())
        if list_display is None:
            list_display = all_fields
            list_display = list(list_display)
            fixed_columns = []
            date_columns = []
            paycode_columns = []
            for column in list_display:
                if column.isdigit():
                    date_columns.append(column)
                else:
                    if column.startswith('paycode_'):
                        paycode_columns.append(column)
                    else:
                        fixed_columns.append(column)
            other_columns = list(set(all_fields) - set(list_display))
            for field in other_columns:
                if field not in hidden_fields:
                    if field.isdigit():
                        date_columns.append(field)
                        if field.startswith('paycode_'):
                            paycode_columns.append(field)
                            fixed_columns.append(field)
            date_columns.sort()
            list_display = fixed_columns + date_columns + paycode_columns
        cols = []
        for field in list_display:
            col = fields.get(field, None)
            if not col:
                continue
            else:
                if field in hidden_fields:
                    col['hide'] = 1
                cols.append(col)
        return cols
    def get_start_date(self):
        from mysite.base.utils import get_start_of_week
        from mysite.att.models import AttPolicy
        policy = AttPolicy.objects.first()
        start_of_week = 1
        if policy:
            if policy.start_of_week == 7:
                start_of_week = get_start_of_week() + 1
            else:
                start_of_week = policy.start_of_week + 1
        today = datetime.datetime.now().date()
        delta = today.isoweekday() - start_of_week
        start = today - datetime.timedelta(days=delta % 7)
        return start
    def init_context(self, request):
        """\n        Construct the context data for report render.\n        """
        from mysite.att.models import ReportTemplate
        from django.contrib.auth import get_user_model
        user = get_user_model()
        if isinstance(request.user, user):
            templates = ReportTemplate.objects.filter(builder=request.user, report=self.model_name)
        else:
            templates = ReportTemplate.objects.filter(report=self.model_name)
        templates = [(tmp.id, tmp.template_name, tmp.template_value) for tmp in templates]
        list_display = self.get_user_defined_list_display(request)
        hidden_fields = self.get_user_defined_hidden_fields(request)
        cols = self.user_defined_cols(list_display, hidden_fields)
        start_date = self.get_start_date()
        context = {'hidden_fields': [], 'ordered_fields': [], 'templates': templates, 'model_name': self.model_name, 'layui_cols': [cols], 'data_source': self.data_source, 'this_week_start': start_date.strftime('%Y-%m-%d'), 'this_week_end': (start_date + datetime.timedelta(days=6)).strftime('%Y-%m-%d'), 'last_week_start': (start_date - datetime.timedelta(days=7)).strftime('%Y-%m-%d'), 'last_week_end': (start_date - datetime.timedelta(days=1)).strftime('%Y-%m-%d')}
        if self.view_name:
            context.update({'actionUrl': reverse('biotime:%s' % self.view_name)})
        return context
    def view(self, request, *args, **kwargs):
        context = self.init_context(request)
        return TemplateResponse(request, self.template or self.base_template, context)
    def get_queryset(self):
        queryset = self.data_view.get_queryset()
        return queryset
    def filter_queryset(self, queryset):
        from django.db.models import Q
        from mysite.admin.models import STATUS_VALID, STATUS_RESIGN_PENDING
        from mysite.att.models.model_reportsetting import AttReportSetting
        att_setting = AttReportSetting.objects.first()
        start_date = self.kwargs.get('start_date')
        end_date = self.kwargs.get('end_date')
        employees = self.kwargs.get('employees', None)
        departments = self.kwargs.get('departments', None)
        areas = self.kwargs.get('areas', None)
        groups = self.kwargs.get('groups', None)
        queryset = queryset.filter(att_date__gte=start_date, att_date__lte=end_date)
        if employees:
            queryset = queryset.filter(emp_id__in=employees)
        if departments:
            queryset = queryset.filter(emp__department_id__in=departments)
        if areas:
            queryset = queryset.filter(emp__area__in=areas)
        if groups:
            queryset = queryset.filter(emp__attemployee__group_id__in=groups)
        if att_setting and (not att_setting.resign_emp):
                queryset = queryset.filter(Q(emp__status=STATUS_VALID) | Q(emp__status=None) | Q(emp__status=STATUS_RESIGN_PENDING))
        return queryset
    def annotate_queryset(self, queryset):
        queryset = self.data_view.annotate_queryset(queryset)
        return queryset
    def get_serializer(self, *args, **kwargs):
        kwargs['context'] = {'view': self.data_view}
        kwargs['many'] = True
        self._data_view.request = None
        self._data_view.format_kwarg = None
        self._data_view.action = 'export'
        return self.serializer(*args, **kwargs)
    def get_serialize_data(self):
        queryset = self.get_queryset()
        queryset = self.filter_queryset(queryset)
        queryset = self.annotate_queryset(queryset)
        serializer = self.get_serializer(queryset, many=True)
        return serializer.data
    @property
    def data(self):
        """\n        Payload data for auto export attendance report.\n        """
        return self.get_serialize_data()
    def auto_export(self, options, headers, cols, export_data, file_path, **kwargs):
        return self._data_view.auto_export(options, headers, cols, export_data, file_path, **kwargs)
    def add_template(self, request):
        """\n        View function for pop-up window `Save Layout` in report\n        """
        from .forms import AddTemplateForm
        if request.method.lower() == 'get':
            context = {'form': AddTemplateForm(data=request.GET)}
            return TemplateResponse(request, self.add_template_ui or 'att/report/add_report_template.html', context)
    def load_template(self, request):
        """\n        View function for pop-up window `Load Layout` in report\n        """
        if request.method.lower() == 'get':
            context = {'model_name': self.model_name}
            return TemplateResponse(request, self.load_template_ui or 'att/report/report_template_grid.html', context)
        else:
            return None
    def get_urls(self):
        urls = [re_path('^{0}/{1}/$'.format(self.superior, self.model_name), login_admin_view_wrap(self.view), name=insert_non_model_permission(self.superior, self.view_name)), re_path('^{0}/{1}/addTemplate/$'.format(self.superior, self.model_name), login_admin_view_wrap(self.add_template), name='{0}_add_template'.format(self.model_name)), re_path('^{0}/{1}/loadTemplate/$'.format(self.superior, self.model_name), login_admin_view_wrap(self.load_template), name='{0}_load_template'.format(self.model_name))]
        return urls
    @property
    def urls(self):
        return self.get_urls()
class ReportWrapper(object):
    """\n    This class is a wrapper to a given manager to add the model for the ReportManager.\n    """
    def __init__(self, model, manager):
        self.model = model
        self.manager = manager