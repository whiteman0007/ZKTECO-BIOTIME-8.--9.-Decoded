# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0015_auto_20241212_20114.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('base', '0014_eventalertsetting_lineapp_alert')]
    operations = [migrations.AddField(model_name='securitypolicy', name='reset_password_frequency', field=models.SmallIntegerField(default=120, verbose_name='securityPolicy.fields.resetPasswordFrequency')), migrations.AddField(model_name='securitypolicy', name='reset_password_validity', field=models.SmallIntegerField(default=10, verbose_name='securityPolicy.fields.resetPasswordValidity'))]