# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\management\\commands\\calc_att_test.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:58 UTC (1750672978)

import datetime
import pprint
import unittest
from django.core.management.base import BaseCommand
from mysite.personnel.models.model_area import Area
from mysite.personnel.models.model_department import Department
from mysite.personnel.models.model_employee import Employee
from mysite.iclock.models.model_transaction import Transaction
from mysite.att.models import PayCode
from mysite.att.models.model_breaktime import BreakTime
from mysite.att.models.model_timeinterval import TimeInterval
from mysite.att.models.model_attshift import AttShift
from mysite.att.models.model_shiftdetail import ShiftDetail
from mysite.att.models.model_attschedule import AttSchedule
NULLSET = {'0', '0.0'}
class Command(BaseCommand):
    help = 'insert test data to databases'
    def handle(self, *args, **options):
        main()
        print('OK')
def get_dept(dept_name):
    obj = Department.objects.filter(dept_name=dept_name).first()
    if obj is None:
        ids = Department.objects.all().values_list('id', flat=True)
        obj = Department()
        obj.dept_code = str(max(ids) + 1)
        obj.dept_name = dept_name
        obj.save()
    return obj
def get_emp(first_name, department=None):
    emp = Employee.objects.filter(first_name=first_name).first()
    if emp is None:
        ids = Department.objects.values_list('id', flat=True)
        emp = Employee()
        emp.emp_code = str(max(ids) + 1)
        emp.first_name = first_name
        emp.hire_date = (datetime.datetime.now() - datetime.timedelta(days=100)).date()
        emp.department = department if department else Department.objects.all().first()
        emp.save()
        emp.area = [Area.objects.all().first()]
        emp.save()
    return emp
def get_tran(emp, punch_time, punch_state=None):
    tran = Transaction.objects.filter(emp_code=emp.emp_code, punch_time=punch_time).first()
    if tran is None:
        tran = Transaction()
        tran.emp_code = emp.emp_code
        tran.verify_type = 1
        tran.punch_time = punch_time
        tran.upload_time = punch_time
        tran.sync_status = 1
        tran.punch_state = 0
        tran.emp_id = emp.id
        tran.terminal_sn = 'TEST0000000001'
        tran.save()
    return tran
def get_break(alias, start, end, **kwargs):
    bk = BreakTime.objects.filter(alias=alias).first()
    if bk is None:
        bk = BreakTime(**kwargs)
        bk.alias = alias
        bk.period_start = start
        bk.period_end = end
        bk.save()
    return bk
def get_interval(alias, in_time, duration):
    tt = TimeInterval.objects.filter(alias=alias).first()
    if tt is None:
        tt = TimeInterval()
        tt.alias = alias
        tt.in_time = in_time
        tt.duration = duration
        tt.save()
    return tt
def get_shift(alias):
    s = AttShift.objects.filter(alias=alias).first()
    if s is None:
        s = AttShift()
        s.alias = alias
        s.auto_shift = False
        s.save()
    return s
def get_shift_detail(shift, interval, day_index):
    shift = AttShift.objects.all()[0]
    sd = ShiftDetail.objects.filter(day_index=day_index, shift=shift).first()
    if sd is None:
        sd = ShiftDetail()
        sd.day_index = day_index
        sd.shift = shift
        sd.time_interval = interval
        sd.in_time = interval.in_time
        in_time = datetime.datetime.combine(datetime.datetime.now().date(), interval.in_time)
        sd.out_time = (in_time + datetime.timedelta(minutes=interval.duration)).time()
        sd.save()
    return sd
def get_emp_sche(emp, shift, start, end):
    sche = AttSchedule.objects.filter(employee=emp, start_date=start, end_date=end).first()
    if sche is None:
        sche = AttSchedule()
        sche.employee = emp
        sche.shift = shift
        sche.start_date = start
        sche.end_date = end
        sche.save()
    return sche
def get_time_card(employee, start_date, end_date):
    from django.test import Client
    if isinstance(start_date, datetime.date):
        start_date = start_date.strftime('%Y-%m-%d')
    if isinstance(end_date, datetime.date):
        end_date = end_date.strftime('%Y-%m-%d')
    params = {'page': '1', 'page_size': 20, 'start_date': start_date, 'end_date': end_date, 'departments': '-1', 'areas': '-1', 'groups': '-1', 'employees': employee}
    c = Client()
    c.login(username='admin', password='admin')
    url = '/att/api/totalTimeCardReportV2/'
    response = c.get(url, params)
    return response.json()['data']
def report_assert_equal(data1, data2, strict=True):
    key1 = set(data1.keys())
    key2 = set(data2.keys())
    for key in key1 & key2:
        v1, v2 = (data1[key], data2[key])
        if v1 and v2:
            assert v1 == v2, 'key %s, value %s != %s' % (key, v1, v2)
        else:
            if v1:
                assert v1 in NULLSET, 'key %s, value %s not in %s' % (key, v1, NULLSET)
            else:
                if v2:
                    assert v2 in NULLSET, 'key %s, value %s not in %s' % (key, v2, NULLSET)
    if not strict:
        return
    else:
        for key in key1 - key2:
            v1 = data1[key]
            if v1:
                assert v1 in NULLSET, 'key %s, value %s not in %s' % (key, v1, NULLSET)
        for key in key2 - key1:
            v2 = data2[key]
            if v2:
                assert v2 in NULLSET, 'key %s, value %s not in %s' % (key, v2, NULLSET)
def clean_time_card(time_card):
    pc_dict = {i.id: i for i in PayCode.objects.all()}
    attcode_key = {'break_duration', 'duty_duration', 'total_ot', 'worked_hrs', 'total_hrs', 'remaining', 'total_leave', 'unschedule', 'duration'}
    time_card_paycode = {}
    for k, v in time_card.items():
        if k.startswith('paycode_'):
            paycode_id = int(k[8:])
            obj = pc_dict.get(paycode_id)
            time_card_paycode[obj.code] = v
    time_card_attcode = {}
    for k, v in time_card.items():
        if k in attcode_key:
            time_card_attcode[k] = v
    return (time_card_attcode, time_card_paycode)
def test1():
    from mysite.att.calc_new.tasks import manual_att_calculate
    dept = get_dept('test1')
    emp = get_emp('test_first_name')
    _break = get_break('test_break_1', datetime.time(hour=12), datetime.time(hour=14))
    interval = get_interval('test_interval_1', datetime.time(hour=9), 540)
    shift = get_shift('test_shift_1')
    get_shift_detail(shift, interval, 1)
    get_shift_detail(shift, interval, 2)
    get_shift_detail(shift, interval, 3)
    get_shift_detail(shift, interval, 4)
    get_shift_detail(shift, interval, 5)
    shift.save()
    sche_start = datetime.date(2021, 10, 1)
    sche_end = datetime.date(2021, 10, 31)
    sche = get_emp_sche(emp, shift, sche_start, sche_end)
    emp_ids = [emp.id]
    get_tran(emp, datetime.datetime(2021, 10, 1, 9))
    get_tran(emp, datetime.datetime(2021, 10, 1, 18))
    calc_start = datetime.date(2021, 10, 1)
    calc_end = datetime.date(2021, 10, 1)
    manual_att_calculate(emp_ids, calc_start, calc_end)
    time_card = get_time_card(emp_ids, sche_start, sche_start)[0]
    attcode, paycode = clean_time_card(time_card)
    pprint.pprint(attcode)
    pprint.pprint(paycode)
    time_card_data = {'full_attendance': 1, 'work_day': '1.0'}
    check_attcode = {'duration': '09:00', 'duty_duration': '09:00', 'total_hrs': '09:00', 'worked_hrs': '09:00', 'remaining': '', 'total_leave': '', 'total_ot': '', 'break_duration': '', 'unschedule': ''}
    check_paycode = {'REG': '9.0', 'L': '', 'E': '', 'A': ''}
    report_assert_equal(time_card, time_card_data, strict=False)
    report_assert_equal(check_attcode, attcode)
    report_assert_equal(check_paycode, paycode)
def main():
    test1()