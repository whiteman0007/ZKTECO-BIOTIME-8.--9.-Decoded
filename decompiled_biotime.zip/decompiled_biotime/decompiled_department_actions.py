# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\actions\\department_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:18 UTC (1750673058)

from django.forms import ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.admin.action import ActionHandleError
from mysite.personnel import widgets
from mysite.personnel.models import Employee, Department
from .personnel_actions import SetPsnlModelForm
class SetDepartmentForm(SetPsnlModelForm):
    # return None
    pass
class SetDepartment(admin.ZKModelAction):
    verbose_name = _('department_action_adjustEmployee')
    help_txt = _('department_action_adjustEmployeeHelpTxt')
    short_description = _('department_action_adjustEmployeeDescription')
    action_form = SetDepartmentForm
    batch_select = True
    unique_object_required = True
    def action(self, *args, **kwargs):
        emps = self.request.POST.getlist('employee')
        if not emps:
            raise ActionHandleError(_('select_none_employee'))
        else:
            Employee.objects.filter(id__in=emps).update(department=self.objects[0])