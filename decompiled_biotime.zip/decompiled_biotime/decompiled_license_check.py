# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\management\\commands\\license_check.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:21 UTC (1750673001)

import os
import re
import datetime
import uuid
import psutil
from django.core.management.base import BaseCommand
from django.conf import settings
try:
    from mysite.core.zkmimi import getISVALIDDONGLE, get_mac4network_card, get_mac4multiple_network_card
except Exception:
    pass
USE_UUID = True
try:
    from mysite.core.zkmimi import MAC_BY_UUID
    USE_UUID = MAC_BY_UUID
except Exception:
    try:
        from mysite.core.zkmimi import VM_DETECT
        USE_UUID = not VM_DETECT
    except Exception:
        pass
class Command(BaseCommand):
    help = 'check license'
    def handle(self, *args, **options):
        main()
def get_license_id():
    lic_xml = settings.ADDITION_FILE_ROOT + '\\license\\BioTime-License.xml'
    if os.path.isfile(lic_xml):
        try:
            import xml.etree.cElementTree as ET
        except ImportError:
            import xml.etree.ElementTree as ET
        tree = ET.parse(lic_xml)
        root = tree.getroot()
        license_id = root.find('id').text
    else:
        license_id = ''
    return license_id
def license_compare(binding_type, auth_data):
    license_mac = auth_data.get('MAC')
    system_mac = auth_data.get('SYSTEM_MAC')
    print('[*]BINDING TYPE: {}'.format(binding_type))
    print('[*]LICENSE UUID: [{}]'.format(license_mac))
    print('[*]SYSTEM  UUID: [{}]'.format(system_mac))
    if not license_mac:
        print('[*]Trial License')
    else:
        if license_mac.lower() == system_mac.lower():
            print('[*]Available License')
        else:
            print('[*]Unavailable license, BINDING MISMATCH, please check any hardware changed')
def main():
    auth_data = getISVALIDDONGLE()[1]
    binding_type = auth_data.get('TYPE', None)
    if binding_type is not None:
        return license_compare(binding_type, auth_data)
    else:
        util_mac = ''
        all_macs = {}
        for k, v in psutil.net_if_addrs().items():
            address = [_v for _v in v if '-' in _v.address]
            if not address:
                continue
            else:
                all_macs[k] = []
                for _v in address:
                    all_macs[k].append(_v.address.replace('-', ''))
        util_mac = get_mac4network_card()
        uuid_mac = str(uuid.uuid1())[(-12):].upper()
        license_mac = auth_data.get('MAC')
        try:
            zk_all_macs = get_mac4multiple_network_card()
        except Exception:
            zk_all_macs = []
        print('[*]ALL MACS: %s' % zk_all_macs)
        for i in all_macs:
            print('\t%s: %s' % (i, all_macs[i]))
        print('[*]UUID MAC: {}'.format(uuid_mac))
        print('[*]UTIL MAC: {}'.format(util_mac))
        print('\n[*]LICENSE MAC: %s' % license_mac)
        print('[*]LICENSE ID: %s' % get_license_id())
        print('[*]LICENSE INFO: %s' % auth_data)
        server_macs = []
        for each in all_macs:
            for mac in all_macs[each]:
                if mac:
                    server_macs.append(mac)
        print('\n########### license check result ##############')
        if not license_mac:
            print('>>>>>> LICENSE MAC is None!')
        else:
            if USE_UUID:
                print('>>>>>> zkmimi is use old UUID MAC, if error happen, update zkmimi.pyd.')
                if license_mac in server_macs:
                    print('>>>>>> LICENSE MAC is in ALL MACS')
                    print('>>>>>> If can not login in, need update zkmimi.pyd, and reset license')
                else:
                    print('>>>>>> LICENSE MAC is not in ALL MACS')
                    print('>>>>>> Need update zkmimi.pyd. and reset license.')
            else:
                print('>>>>>> zkmimi is use UTIL MAC, no need update zkmimi.pyd.')
                if license_mac in server_macs:
                    print('>>>>>> LICENSE MAC is OK. if can not login, contect us.')
                else:
                    print('>>>>>> LICENSE MAC is not in ALL MACS, ')
                    print('>>>>>> Ask for client result about network MAC change result.')
                    print('>>>>>> Reset license if this error first happen.')