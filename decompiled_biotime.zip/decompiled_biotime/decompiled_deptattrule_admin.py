# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\deptattrule_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import datetime
from django.utils.translation import gettext_lazy as _
from django import forms as django_forms
from mysite import admin
from mysite.admin import forms
from mysite.att.models import DeptAttRule
from mysite.personnel import fields, widgets
from mysite.personnel.models import Department
from mysite.att import forms as model_forms
class BatchAddDepartmentRuleForm(forms.ZKActionForm):
    alias = forms.CharField(label=_('deptAttRule_field_alias'))
    department = django_forms.ModelMultipleChoiceField(queryset=Department.objects.all(), label=_('deptAttRule_field_department'), widget=widgets.DepartmentSelectMultiple)
    rule = forms.TextField(initial='')
class BatchAddDepartmentRule(admin.ZKModelAction):
    verbose_name = _('departmentRule_action_batchAdd')
    short_description = _('departmentRule_action_batchAddDescription')
    help_txt = _('departmentRule_action_batchAddHelpTxt')
    action_form = BatchAddDepartmentRuleForm
    def action(self, *args, **kwargs):
        depts = self.request.POST.getlist('department', None)
        rule = self.request.POST.get('rule', None)
        alias = self.request.POST.get('alias', None)
        if depts and rule:
                objs = DeptAttRule.objects.filter(department_id__in=depts).values_list('department__dept_name')
                if objs:
                    raise django_forms.ValidationError('%s' % _('%(department)s_already_setup_rule') % {'department': ','.join(objs[0])})
                else:
                    for dept in depts:
                        holiday = DeptAttRule(alias=alias, department_id=dept, rule=rule)
                        holiday.save()
@admin.register(DeptAttRule)
class DeptAttRuleAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'department', 'alias')
    list_filter = ('alias', 'department__dept_code', 'department__dept_name')
    formfield_overrides = {fields.DepartmentForeignKey: {'widget': widgets.DepartmentRadioSelect}}
    actions = (BatchAddDepartmentRule,)
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        query_set = super(DeptAttRuleAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_dept.exists():
                query_set = query_set.filter(department__in=request.user.auth_dept.all())
        return query_set