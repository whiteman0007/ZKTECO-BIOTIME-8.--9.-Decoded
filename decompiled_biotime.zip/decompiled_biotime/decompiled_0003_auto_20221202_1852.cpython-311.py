# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\workflow\\migrations\\0003_auto_20221202_1852.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:30 UTC (1750702770)

from __future__ import unicode_literals
from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('workflow', '0002_auto_20211201_1434')]
    operations = [migrations.AlterModelOptions(name='workflowengine', options={'default_permissions': ('delete', 'change', 'view'), 'verbose_name': 'workflow_model_workflowEngine'})]