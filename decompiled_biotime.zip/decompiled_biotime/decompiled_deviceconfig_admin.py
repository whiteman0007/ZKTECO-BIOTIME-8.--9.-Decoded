# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\admin\\deviceconfig_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

from mysite import admin
from mysite.iclock.models import DeviceModuleConfig
from mysite.settings.components.secretes import THAILAND
@admin.register(DeviceModuleConfig)
class DeviceConfigAdmin(admin.ZKModelAdmin):
    @staticmethod
    def initial_data():
        if DeviceModuleConfig.objects.all().count() == 0:
            if THAILAND.fget():
                c = DeviceModuleConfig()
                c.transaction_retention = 9999
                c.command_retention = 9999
                c.dev_log_retention = 9999
                c.upload_log_retention = 9999
                c.timezone = 7
                c.save()
            else:
                c = DeviceModuleConfig()
                c.transaction_retention = 9999
                c.command_retention = 9999
                c.dev_log_retention = 9999
                c.upload_log_retention = 9999
                c.save()