# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\admin\\acc_combination_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.core.cache import cache
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.acc import actions
from mysite.acc.forms import AccCombinationForm
from mysite.acc.models import AccCombination
from mysite.personnel.models import Area
@admin.register(AccCombination)
class AccCombinationAdmin(admin.ZKModelAdmin):
    actions = [actions.CloneToArea]
    list_display = ('id', 'combination_no', 'combination_name', 'group1', 'group2', 'group3', 'group4', 'group5')
    list_filter = ('combination_no', 'combination_name')
    add_form = AccCombinationForm
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def clone_to_area(self, request, objects):
        areas = request.POST.getlist('area', [])
        if not areas:
            raise Exception('{error}'.format(error=_('employee_actionError_areaIsRequired')))
        else:
            for obj in objects:
                for area in areas:
                    if obj.area.pk == area:
                        continue
                    else:
                        obj.clone_combination(area)
    def get_queryset(self, request):
        from mysite.acc.utils import get_current_area
        qs = super(AccCombinationAdmin, self).get_queryset(request)
        is_get_table = request.path.find('table') > 0 or request.path.find('export') > 0
        current_area = get_current_area(request)
        if is_get_table:
            qs = qs.filter(area__pk=current_area)
        if not request.user.is_superuser and request.user.auth_area.all():
                qs = qs.filter(area__in=request.user.auth_area.all()).distinct()
        return qs
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(AccCombinationAdmin, self).get_form(request, obj, **defaults)