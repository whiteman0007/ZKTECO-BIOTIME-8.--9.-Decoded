# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\ep\\api\\serializers\\configuration_serializer.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

from rest_framework import serializers
from mysite.ep.models import EPSetup
class EPSetupSerializer(serializers.ModelSerializer):
    temp_alarm = serializers.BooleanField(required=False, default=False)
    mask_alarm = serializers.BooleanField(required=False, default=False)
    class Meta:
        model = EPSetup
        fields = ('temp_unit', 'temp_warning', 'temp_alarm', 'mask_alarm')