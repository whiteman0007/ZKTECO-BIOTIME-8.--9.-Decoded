# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\templatetags\\cont_ex_tags.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from django import template
register = template.Library()
@register.inclusion_tag('includes/docs_link.html')
def api_docs(enable_api):
    return {'enable_api': enable_api}
@register.filter(name='daysmonths')
def daysmonths(val, month: int=None):
    if val == 'month':
        months = {1: 'time.months.january', 2: 'time.months.february', 3: 'time.months.march', 4: 'time.months.april', 5: 'time.months.may', 6: 'time.months.june', 7: 'time.months.july', 8: 'time.months.august', 9: 'time.months.september', 10: 'time.months.october', 11: 'time.months.november', 12: 'time.months.december'}
        return months
    else:
        if val == 'day':
            if month in [1, 3, 5, 7, 8, 10, 12]:
                return range(1, 32)
            else:
                if month == 2:
                    return range(1, 30)
                else:
                    return range(1, 31)