# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\django_sql_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

import traceback
from django.db import connection, transaction, DatabaseError, IntegrityError
def fetch_all(sql):
    rows = None
    try:
        cursor = connection.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
    except (DatabaseError, IntegrityError):
        traceback.print_exc()
    except Exception:
        traceback.print_exc()
    return rows
def fetch_one(sql):
    row = None
    try:
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchone()
    except (DatabaseError, IntegrityError):
        import traceback
        traceback.print_exc()
    except Exception:
        import traceback
        traceback.print_exc()
    return row
@transaction.atomic
def execute(sql):
    ret = None
    try:
        cursor = connection.cursor()
        cursor.execute(sql)
        ret = cursor.rowcount
    except (DatabaseError, IntegrityError):
        import traceback
        traceback.print_exc()
    except Exception:
        traceback.print_exc()
    finally:
        if ret == (-1):
            ret = (-2)
    return ret
@transaction.atomic
def multi_exec(sqls):
    res = []
    flag = True
    try:
        cursor = connection.cursor()
        for sql in sqls:
            cursor.execute(sql)
            res.append(cursor.rowcount)
    except (DatabaseError, IntegrityError):
        traceback.print_exc()
        flag = False
    except Exception:
        traceback.print_exc()
        flag = False
    finally:
        if (-1) in res:
            flag = False
            res = [(-2)]
    return (res, flag)
def custom_Sql(sql, action=True):
    cursor = connection.cursor()
    cursor.execute(sql)
    if action:
        connection._commit()
    return cursor