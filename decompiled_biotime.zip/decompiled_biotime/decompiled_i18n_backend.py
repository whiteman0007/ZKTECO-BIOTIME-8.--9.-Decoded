# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\i18n_backend.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

import os
import sys
from collections import OrderedDict
from django.core.cache import cache
from django.utils.module_loading import import_string
from django.utils.translation import gettext
from mysite import settings
BUILTIN_OPTION = frozenset(('time & security refinement management platform', 'card cost', 'don&#39;t allow deletion, can be modified', 'expense card cost', 'general department', 'manual supplement consumption', 'promotional recharge', 'recharge', 'refund', 'staff card', 'wechat recharge', 'consumption', 'correction', 'count', 'counting error correction', 'fixed time period', 'management fee', 'recharge on alipay', 'subsidy', '24 hours all day traffic', 'annual leave', 'default area', 'home leave', 'number %d batch', 'private affair leave', 'public', 'sick leave', 'wiegand26', 'wiegand26a', 'wiegand34', 'wiegand34a', 'wiegand36', 'wiegand37', 'wiegand37a', 'wiegand50', 'wiegand66', 'automatic matching', 'headquarters restaurant', 'breakfast', 'chinese food', 'dinner', 'nightingale', 'meal 05', 'meal 06', 'meal 07', 'meal 08', 'default 1', 'default 2', 'default 3', 'default 4',
LANG_DICT = {'zh_hant': 'zh_tw', 'zh_hans': 'zh_cn'}
def format_lang_code(lang):
    """ 格式化语言代号\n    1) 统一转为小写\n    2) 统一采用 \'_\' 作为分隔符\n    3) 对同一语言的多个别名，进行重新映射\n    :param lang: 原始语言代号\n    :return: 格式化后的语言代号\n    """
    if not isinstance(lang, str):
        return
    else:
        lang = lang.lower().replace('-', '_')
        lang = LANG_DICT.get(lang, lang)
        return lang
def exist_lang_code(lang):
    """ 用于判断传入的 `语言代号` 是否是系统所支持的语言\n    :param lang: 原始语言代号\n    :return: True or False\n    """
    all_lang = (_lang.lower() for _lang in os.listdir(settings.LOCALE_PATHS[0]))
    lang = format_lang_code(lang)
    if lang in all_lang:
        return True
    else:
        return False
class InvalidMultiLangBackendError(Exception):
    # return None
    pass
class MultiLangLayer:
    def __init__(self, lang=None, _cache=cache):
        self._cache = _cache
        cached_lang = self._cache.get('current_language')
        lang = lang if lang else cached_lang
        if not exist_lang_code(lang):
            self._lang = None
        else:
            self._lang = lang
    def trans(self):
        return
    @staticmethod
    def wrap_key(lang, key):
        """ [工具函数] 用于获得添加了 `语言代号` 的键\n        :param lang: 语言\n        :param key: 原始的键\n        :return: 添加了 `语言代号` 的键\n        """
        if lang:
            wrapped_key = '<{}_{}>'.format(key, lang)
        else:
            sys.stderr.write('### No Specified valid language while get cache')
            wrapped_key = key
        return wrapped_key
    def set(self, key, value, timeout=86400):
        """[兼容 MemCache 接口] 设置快取映射"""
        wrapped_key = self.wrap_key(self._lang, key)
        self._cache.set(wrapped_key, value, timeout)
    def get(self, key):
        """[兼容 MemCache 接口] 用 key 从 cache 取得对应的地区化后的值"""
        wrapped_key = self.wrap_key(self._lang, key)
        return self._cache.get(wrapped_key)
    def delete(self, key):
        """[兼容 MemCache 接口] 删除所有可用语言对应的键"""
        for lang in LayerHandler.all_lang():
            wrapped_key = self.wrap_key(lang, key)
            self._cache.delete(wrapped_key)
    def delete_single(self, key):
        """[兼容 MemCache 接口] 仅删除当前使用语言代码对应的键"""
        wrapped_key = self.wrap_key(self._lang, key)
        self._cache.delete(wrapped_key)
    def __repr__(self):
        return '<MultiLangLayer {}>'.format(self._lang)
def _create_layer(backend, **kwargs):
    try:
        backend_cls = import_string(backend)
    except ImportError as e:
        raise InvalidMultiLangBackendError('Could not find backend \'%s': %s' % (backend, e))
    return backend_cls(**kwargs)
class LayerHandler(object):
    """\n    A Multi-Language Layer Handler to manage access to layer instances.\n    这是一个多国语言层用于管理上层(业务层)对『层实例』的访问\n    Ensures only one instance of each lang exists per thread.\n    确保每个线程中每个语言只存在一个『层实例』\n    """
    _AVAILABLE_LANGUAGES = set()
    _LAYERS = None
    def __init__(self):
        return
    def __getitem__(self, lang):
        """重写 `obj[index]` 方法"""
        lang = format_lang_code(lang)
        if lang is None or not exist_lang_code(lang):
            lang = format_lang_code(settings.LANGUAGE_CODE)
        try:
            return self._LAYERS[lang]
        except (AttributeError, TypeError):
            self._LAYERS = OrderedDict()
        except KeyError:
            pass
        LayerHandler._AVAILABLE_LANGUAGES.add(lang)
        layer = _create_layer('mysite.i18n_backend.MultiLangLayer', lang=lang)
        self._LAYERS[lang] = layer
        return layer
    def all_layer(self):
        """查看所有的语言层"""
        return list(getattr(self, '_LAYERS', {}).values())
    @classmethod
    def all_lang(cls):
        """查看现有的所有语言"""
        for lang in cls._AVAILABLE_LANGUAGES:
            yield lang
layers = LayerHandler()
class DefaultLangProxy(object):
    """\n    Proxy access to the default Lang object\'s attributes.\n    代理： 对用户包括（程序员）透明的默认语言代理, 使用时和一般的 cache 的常见接口完全一致\n    """
    KEY = 'current_language'
    CACHE = cache
    DEFAULT_LANGUAGE = settings.LANGUAGE_CODE
    def __getattr__(self, name):
        """重写 `obj.field_name` 方法"""
        return getattr(layers[DefaultLangProxy.get_language() or DefaultLangProxy.DEFAULT_LANGUAGE], name)
    def __setattr__(self, name, value):
        """重写 `obj.field_name = new_value` 方法"""
        return setattr(layers[DefaultLangProxy.get_language() or DefaultLangProxy.DEFAULT_LANGUAGE], name, value)
    def __delattr__(self, name):
        """重写 `del obj.field_name` 方法"""
        return delattr(layers[DefaultLangProxy.get_language() or DefaultLangProxy.DEFAULT_LANGUAGE], name)
    @staticmethod
    def set_language(lang):
        key = DefaultLangProxy.KEY
        lang = format_lang_code(lang)
        orig_lang = DefaultLangProxy.CACHE.get(key)
        if orig_lang is None:
            DefaultLangProxy.CACHE.set(key, lang)
        else:
            if orig_lang!= lang:
                DefaultLangProxy.CACHE.set(key, lang)
    @staticmethod
    def get_language():
        return DefaultLangProxy.CACHE.get(DefaultLangProxy.KEY)
lang_layer = DefaultLangProxy()
def trans_opt(text):
    if BUILTIN_OPTION.get(text.lower(), False):
        return gettext(text)
    else:
        return text
def trans_form_field(text):
    if isinstance(text, str):
        from html.parser import HTMLParser
        parser = HTMLParser()
        text = trans_opt(text)
        if '&#39;' in text:
            text = parser.unescape(text)
    return text
def need_trans_properties(*props):
    """\n    Make attributes of a class to translate.\n    """
    def class_decorator(cls):
        class NewClass(cls):
            """\"This is the overwritten class"""
            def __getattribute__(self, name):
                ret_val = None
                if name not in props:
                    ret_val = super(cls, self).__getattribute__(name)
                else:
                    if name not in self.__dict__:
                        pass
                    else:
                        ret_val = trans_opt(name)
                return ret_val
        cls_dir = dir(cls)
        new_cls_dir = dir(NewClass)
        for prop in (key for key in cls_dir if not callable(key) and key not in ['__getattribute__', '__dict__']):
            try:
                setattr(NewClass, prop, cls.__getattribute__(cls, prop))
            except AttributeError:
                print(prop)
        for prop in (key for key in new_cls_dir if key not in cls_dir and key not in ['__getattribute__']):
            print((prop, getattr(NewClass, prop)))
            delattr(NewClass, prop)
        NewClass.__name__ = cls.__name__
        return NewClass
    return class_decorator