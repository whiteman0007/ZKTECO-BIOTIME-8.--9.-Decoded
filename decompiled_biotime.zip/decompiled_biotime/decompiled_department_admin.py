# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\department_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

import copy
from celery_progress.backend import AbstractProgressRecorder
from django.core.cache import cache
from django.forms import ModelForm, ModelChoiceField
from django.utils.translation import gettext_lazy as _
from django.forms.widgets import HiddenInput
from django.conf import settings
from mysite import config
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.admin.action import ActionHandleError
from mysite.admin.kernel import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.personnel import db_const, actions, widgets
from mysite.personnel.fields import CompanyForeignKey
from mysite.personnel.import_data import ImportData
from mysite.personnel.models import Department, Employee, Company
from mysite.personnel.admin.company_admin import CompanyField4ModelForm, CompanyField4ModelChangeForm
from mysite.tools.progress_utils import progress_protected
from mysite.personnel.forms.fields import EmployeeSearchChoiceField
from mysite.utils import progress_record
class DepartmentCreationForm(CompanyField4ModelForm):
    dept_code = forms.CharField(label=_('department_field_code'), max_length=db_const.MAX_DEPARTMENT_CODE)
    dept_name = forms.CharField(label=_('department_filed_name'), max_length=db_const.MAX_DEPARTMENT_NAME)
    parent_dept = ModelChoiceField(queryset=Department.objects.all(), label=_('department_field_parentDepartment'), required=False, widget=widgets.DepartmentRadioSelect)
    dept_manager = EmployeeSearchChoiceField(label=_('department.field.deptManager'), required=False)
    def __init__(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        super(DepartmentCreationForm, self).__init__(*args, **kwargs)
        objs = Department.objects.values('dept_code')
        codes = [int(i['dept_code']) for i in objs if i['dept_code'].isdigit()]
        self.fields['dept_code'].initial = str(max(codes) + 1 if codes else 1)
        if settings.ENABLE_WDMS:
            self.fields['dept_manager'].widget = forms.ZKHiddenInput()
                except Exception:
                        return None
    class Meta:
        models = Department
        fields = ('company', 'dept_code', 'dept_name', 'parent_dept', 'dept_manager')
class DepartmentChangeForm(CompanyField4ModelChangeForm):
    dept_code = forms.CharField(label=_('department_field_code'), max_length=db_const.MAX_DEPARTMENT_CODE, required=False, disabled=True)
    dept_name = forms.CharField(label=_('department_filed_name'), max_length=db_const.MAX_DEPARTMENT_NAME)
    parent_dept = ModelChoiceField(queryset=Department.objects.all(), label=_('department_field_parentDepartment'), required=False, widget=widgets.DepartmentRadioSelect)
    dept_manager = EmployeeSearchChoiceField(label=_('department.field.deptManager'), required=False, company='')
    def __init__(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        super(DepartmentChangeForm, self).__init__(*args, **kwargs)
        if self.instance and getattr_ex(settings, 'MULTI_COMPANY', False):
                self.fields['dept_manager'] = EmployeeSearchChoiceField(label=_('department.field.deptManager'), required=False, company=str(self.instance.company_id))
        self.fields['parent_dept'].company_belong = self.instance.company_id
        if settings.ENABLE_WDMS:
            self.fields['dept_manager'].widget = forms.ZKHiddenInput()
                    return
    class Meta:
        models = Department
        fields = ('dept_code', 'dept_name', 'parent_dept', 'dept_manager')
class DepartmentAdmin(ZKModelAdmin):
    list_display = ('id', 'dept_code', 'dept_name') + config.WDMS_LIST_DISPLAY + ('parent_dept', 'employee_count', 'resigned_count', 'dept_manager')
    list_display_params = {'dept_code': {'width': 200}, 'dept_name': {'width': 250}, 'parent_dept': {'width': 250}, 'get_employees': {'width': 200}, 'dept_manager': {'width': 200}}
    sort_fields = ('dept_code', 'dept_name')
    cache_keys = ('department_tree_nodes', 'department-parent_dept-tree', 'department-parent_dept-map')
    add_form = DepartmentCreationForm
    form = DepartmentChangeForm
    formfield_overrides = {CompanyForeignKey: {'widget': widgets.CompanyRadioSelect(attrs={'onchange': True, 'change_params': {'onchange_field': 'parent_dept', 'onchange_field_model': 'department', 'onchange_api_name': 'dept_name', 'input_type': 'radio', 'onchange_parent_name': 'parent_dept', 'filter_field': 'company', 'contact_name': 'company'}})}}
    actions = [actions.Import, actions.SetDepartment]
    list_filter = ('dept_code', 'dept_name') + config.WDMS_LIST_FILTER
    list_select_related = ('parent_dept',)
    def company_code(self, obj):
        if obj.company:
            return obj.company.company_code
        else:
            return ''
    company_code.short_description = _('company.field.code')
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(DepartmentAdmin, self).get_form(request, obj, **defaults)
    @progress_protected
    def dataimport(self, request):
        obj_import = ImportDeptData(req=request, input_name='import_data', app_label=self.opts.app_label, model_name=self.opts.model_name)
        obj_import.exe_import_data()
        ret_error = obj_import.error_info
        if ret_error:
            raise ActionHandleError(';'.join(ret_error))
    def data_import(self, request, **kwargs):
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ImportDeptData(request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        process.exe_import_data()
        if process.error_info:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.error_info[0]
    @staticmethod
    def initial_data():
        from django.utils.encoding import force_str
        if Department.objects.all().count() == 0:
            Department(dept_code='1', dept_name=force_str(_('default_department')), is_default=True, company_id=1).save()
    def get_queryset(self, request):
        qs = super(DepartmentAdmin, self).get_queryset(request)
        if request.user.is_employee:
            return qs.filter(company=request.user.company)
        else:
            if request.user.is_superuser or not request.user.auth_dept.exists():
                qs = super(DepartmentAdmin, self).get_queryset(request)
            else:
                qs = request.user.auth_dept.all()
            if not request.user.is_superuser and request.user.assign_company:
                    qs = qs.filter(company=request.user.assign_company)
            return qs.select_related('parent_dept')
class ImportDeptData(ImportData):
    progress_recorder = None
    total = 0
    current = 0
    def __init__(self, req, input_name='import_data', app_label=None, model_name=None, **kwargs):
        from django.utils.translation import activate
        lng = kwargs.pop('template_lng', None)
        if lng:
            activate(lng)
        super(ImportDeptData, self).__init__(req, input_name, app_label, model_name)
        self.progress_recorder = kwargs.pop('progress_recorder', None)
        self.stamp = None
        self.calculate_fields_verbose = ['%s' % _('department_field_parentDepartment')]
        self.must_fields = ['%s' % _('department_field_code'), '%s' % _('department_filed_name'), '%s' % _('department_field_parentDepartment')]
        self.exist_codes = []
        self.dCode = None
        self.dName = None
        self.dpCode = None
    def is_valid_record(self, elem, records, store):
        """判断是否设置了一个部门的上级部门为其自身或其子部门"""
        check_list = [elem]
        while check_list:
            check_item = check_list.pop()
            store.insert(0, check_item)
            for e in records:
                try:
                    d_pcode = check_item[self.dpCode]
                except Exception:
                    d_pcode = ''
                d_pcode = d_pcode and d_pcode.strip() or ''
                d_code = e[self.dCode]
                d_code = d_code and d_code.strip() or ''
                if d_code and d_pcode == d_code:
                        if e in store:
                            return False
                        else:
                            check_list.append(e)
        return True
    def before_insert(self):
        for index in range(len(self.head)):
            e = self.head[index]
            if e == '%s' % _('department_field_code'):
                self.dCode = index
            if e == '%s' % _('department_filed_name'):
                self.dName = index
            if e == '%s' % _('department_field_parentDepartment'):
                self.dpCode = index
        max_len = max(self.dpCode, self.dName, self.dpCode)
        all_records = copy.deepcopy(self.records)
        exist_data = Department.objects.filter(company_id=self.company_id).values_list('dept_code', 'dept_name', 'parent_dept__dept_code')
        new_codes = [e[self.dCode] for e in all_records]
        self.exist_codes = [e[0] for e in exist_data]
        for i, c in enumerate(self.exist_codes):
            if c not in new_codes:
                db_data = exist_data[i]
                data = [''] * (max_len + 1)
                data[self.dpCode] = db_data[0]
                data[self.dName] = db_data[1] or ''
                data[self.dpCode] = db_data[2] or ''
                all_records.append(data)
        d_level = {}
        self.total = len(self.records)
        for index, elem in enumerate(self.records):
            self.current = index
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.dataVerification'))
            index += 1
            d_code = elem[self.dCode]
            d_name = elem[self.dName]
            dp_code = elem[self.dpCode]
            if not d_code:
                self.error_info.append(_('error_data_on_row(%(index)s)_department_code_is_empty') % {'index': index})
            else:
                if len(d_code) > db_const.MAX_DEPARTMENT_CODE:
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_length_of_department_code_maximum_is_%(length)s') % {'index': index, 'length': db_const.MAX_DEPARTMENT_CODE})
            if not d_name:
                self.error_info.append(_('error_data_on_row(%(index)s_the_department_name_can_not_be_empty') % {'index': index})
            else:
                if len(d_name) > db_const.MAX_DEPARTMENT_NAME:
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_length_of_department_name_maximum_is_%(length)s') % {'index': index, 'length': db_const.MAX_DEPARTMENT_NAME})
            if dp_code and len(dp_code) > db_const.MAX_DEPARTMENT_CODE:
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_length_of_parent_department_code_maximum_is_%(length)s') % {'index': index, 'length': db_const.MAX_DEPARTMENT_CODE})
            store = []
            if not self.is_valid_record(elem, all_records, store):
                self.error_info.append(_('the_%(index)s_rows_of_data_can_not_be_set_higher_authorities_to_%(index_name)s_sector_or_sub-sector_of_its_own') % {'index': index, 'index_name': d_name})
                return False
            else:
                for c, v in enumerate(store):
                    key = '%s' % c
                    depts = d_level.get(key, [])
                    if v not in depts:
                        depts.append(v)
                    d_level[key] = depts
        items = list(d_level.items())
        self.records = items
        return True
    def records_analysis(self, insert_dept):
        return
    def data_insert(self):
        head_len = len(self.head)
        calculate_dict = {}
        overwrite = self.need_update_old_record
        count = 0
        for level, ds in self.records:
            for d in ds:
                self.current = count
                progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
                count += 1
                row_fields_select = {}
                code = d[self.dCode]
                if code not in self.exist_codes or overwrite:
                    for index in range(head_len):
                        for k, v in list(self.calculate_fields_index.items()):
                            if v == index:
                                calculate_dict[k] = d[index]
                        if index in self.valid_head_indexs:
                            tmp_value = d[index]
                            f_index = self.valid_head_indexs.index(index)
                            tmp_field = self.valid_model_fields[f_index]
                            if tmp_field.choices:
                                tv = [e[0] for e in tmp_field.choices if e[1] == tmp_value]
                                if tv:
                                    tmp_value = tv[0]
                            key = tmp_field.attname
                            value = self.get_db_value(tmp_field, tmp_value)
                            row_fields_select[key] = value
                    row_data = self.process_row(row_fields_select, calculate_dict)
                    try:
                        objs = Department.objects.filter(dept_code=code, company_id=self.company_id)
                        if objs:
                            obj = objs[0]
                            for k, v in list(row_data.items()):
                                setattr(obj, k, v)
                        else:
                            obj = Department(**row_data)
                        obj.company_id = self.company_id
                        obj.save()
                    except Exception as e:
                        self.error_info.append(e)
                        import traceback
                        traceback.print_exc()
            for k in getattr(DepartmentAdmin, 'cache_keys', []):
                cache.delete(k)
    def sqlserver_insert(self):
        self.data_insert()
    def mysql_insert(self):
        self.data_insert()
    def oracle_insert(self):
        self.data_insert()
    def postgresql_insert(self):
        self.data_insert()
    def after_insert(self):
        progress_record(self.progress_recorder, self.total, self.total, _('importProgress.status.finished'))
    def process_row(self, row_data, calculate_dict):
        row_data = super().process_row(row_data, calculate_dict)
        key = '%s' % _('department_field_parentDepartment')
        dpCode = str(calculate_dict.get(key, ''))
        if dpCode:
            parent = Department.objects.filter(dept_code=dpCode, company_id=self.company_id)
            if not parent:
                pName = dpCode
                obj = Department(dept_code=dpCode, dept_name=pName, company_id=self.company_id)
                obj.save()
            else:
                obj = parent[0]
            row_data['parent_dept_id'] = obj.pk
        return row_data
zk_site.register(Department, DepartmentAdmin)