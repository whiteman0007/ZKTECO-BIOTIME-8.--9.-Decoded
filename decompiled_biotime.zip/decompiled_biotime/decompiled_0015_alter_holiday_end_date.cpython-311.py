# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0015_alter_holiday_end_date.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

import datetime
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0014_auto_20230223_1026')]
    operations = [migrations.AlterField(model_name='holiday', name='end_date', field=models.DateField(default=datetime.datetime.now, verbose_name='holiday_field_endDate'))]