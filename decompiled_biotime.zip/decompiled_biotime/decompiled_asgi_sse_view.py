# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\asgi_sse_view.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from mysite.asgi_sse_redis import AsyncRedisQueueConsumer
class ASGI_SSE_View(AsyncRedisQueueConsumer):
    def get_redis_channel(self):
        user = self.scope['user']
        channel = self.scope['url_route']['kwargs'].get('channel', '')
        if hasattr(user, 'is_employee') and user.is_employee:
            return 'sse_%s_%s' % (user.emp_code, channel)
        else:
            return 'sse_%s_%s' % (user.username, channel)