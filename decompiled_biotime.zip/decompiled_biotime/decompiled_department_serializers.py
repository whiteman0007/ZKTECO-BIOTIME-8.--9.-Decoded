# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\api\\serializers\\department_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

from rest_framework import serializers
from mysite.personnel.models.model_department import Department
from mysite.personnel.models.model_company import Company
from mysite.personnel.utils import get_default_company, get_default_company_id
class SimpleDepartmentSerializer(serializers.ModelSerializer):
    parent_dept_name = serializers.CharField(source='parent_dept.dept_name', allow_null=True)
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept', 'parent_dept_name']
class ParentDepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept']
class DepartmentSerializer(serializers.ModelSerializer):
    parent_dept = ParentDepartmentSerializer()
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept']
class DepartmentExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept']
class DepartmentCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept']
class DepartmentEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept']
        extra_kwargs = {'dept_code': {'required': False, 'read_only': True}, 'dept_name': {'required': False, 'allow_null': False}}
class DepartmentDataSerializer(serializers.ModelSerializer):
    grade = serializers.CharField(default='dept')
    name = serializers.SerializerMethodField()
    pId = serializers.SerializerMethodField()
    def get_name(self, obj):
        return '{code} {name}'.format(code=obj.dept_code, name=obj.dept_name or '')
    def get_pId(self, obj):
        return getattr(obj, 'parent_dept_id', 0)
    class Meta:
        model = Department
        fields = ('id', 'name', 'pId', 'grade')
class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'company_code', 'company_name']
class WDMSDepartmentSerializer(DepartmentSerializer):
    company = CompanySerializer()
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept', 'company']
class WDMSDepartmentCreateSerializer(DepartmentCreateSerializer):
    company = serializers.CharField()
    def validate_company(self, company):
        if isinstance(company, str):
            return Company.objects.filter(id=company).first()
        else:
            return company
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept', 'company']
class WDMSDepartmentEditSerializer(DepartmentEditSerializer):
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name', 'parent_dept', 'company']
        extra_kwargs = {'dept_code': {'required': False, 'read_only': True}, 'dept_name': {'required': False, 'allow_null': False}, 'company': {'required': False, 'read_only': True}}