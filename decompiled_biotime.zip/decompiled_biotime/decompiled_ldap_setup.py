# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\ldap_setup.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from rest_framework import serializers
from mysite.base.utils import get_aes_decrypt
from mysite.tools.encryption_utils import aes_encrypt
class LDAPConnectionSetupSerializer(serializers.Serializer):
    host = serializers.CharField()
    port = serializers.IntegerField()
    username = serializers.CharField()
    password = serializers.CharField()
    def validate_host(self, value):
        print('[*]Host:', value)
        return value
    def validate_port(self, value):
        print('[*]Port:', value)
        return value
    def validate_username(self, value):
        print('[*]Username:', value)
        return value
    def validate_password(self, value):
        return get_aes_decrypt(value)
class MapFieldSerializer(serializers.Serializer):
    fn = serializers.CharField(required=False, allow_blank=True)
    mn = serializers.CharField(required=False, allow_blank=True)
    def validate_fn(self, value):
        return value
    def validate_mn(self, value):
        return value
class LDAPSetupSerializer(serializers.Serializer):
    host = serializers.CharField()
    port = serializers.IntegerField()
    username = serializers.CharField()
    password = serializers.CharField()
    emp_auth = serializers.BooleanField(required=False)
    emp_location = serializers.CharField(required=False, allow_blank=True)
    emp_fields = MapFieldSerializer(many=True)
    emp_sync = serializers.BooleanField(required=False)
    sync_frequency = serializers.IntegerField(required=False)
    sync_day = serializers.IntegerField(required=False)
    sync_time = serializers.TimeField(required=False, allow_null=True)
    user_location = serializers.CharField(required=False, allow_blank=True)
    user_fields = MapFieldSerializer(many=True)
    user_auth = serializers.BooleanField(required=False)
    def validate_host(self, value):
        return value
    def validate_port(self, value):
        return value
    def validate_emp_fields(self, value):
        return value
    def validate_sync_time(self, value):
        if value:
            return value.strftime('%H:%M:%S')
        else:
            return value
    def validate_password(self, value):
        return aes_encrypt(get_aes_decrypt(value))