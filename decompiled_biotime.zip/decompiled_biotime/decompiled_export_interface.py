# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\tools\\export_utils\\export_interface.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

class ExportInterface(object):
    """"""
    def save_file(self, basedir=None):
        raise NotImplementedError('Not Implemented.')
    def get_response(self):
        raise NotImplementedError('Not Implemented.')