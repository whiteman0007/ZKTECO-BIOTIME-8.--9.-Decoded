# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\customattribute_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
import json
from mysite.admin import forms
from mysite.admin.sites import zk_site
from mysite.admin.kernel import ZKModelAdmin
from mysite.personnel import db_const
from mysite.personnel.models import EmployeeCustomAttribute, Employee
class CustomAttributeForm(ModelForm):
    attr_name = forms.CharField(label=_('employeeCustomAttribute.fields.attr_name'), max_length=db_const.MAX_ATTRIBUTE_NAME)
    attr_type = forms.ChoiceField(label=_('employeeCustomAttribute.fields.attr_type'), choices=db_const.ATTRTYPE_CHOICES)
    is_unique = forms.BooleanField(label=_('employeeCustomAttribute.fields.is_unique'), required=False)
    enable = forms.BooleanField(label=_('employeeCustomAttribute.fields.enable'), required=False)
    class Meta:
        model = EmployeeCustomAttribute
        fields = ('attr_name', 'attr_type', 'attr_value', 'is_unique', 'enable')
    def clean_attr_value(self):
        att_value = json.loads(self.cleaned_data['attr_value'])
        values = [value for value in att_value if value['option']]
        return json.dumps(values)
class CustomAttributeAdmin(ZKModelAdmin):
    list_display = ('id', 'attr_name', 'attr_type', 'is_unique', 'enable')
    sort_fields = ('attr_type', 'enable')
    form = CustomAttributeForm
    list_filter = ('attr_name', 'attr_type', 'is_unique', 'enable')
zk_site.register(EmployeeCustomAttribute, CustomAttributeAdmin)