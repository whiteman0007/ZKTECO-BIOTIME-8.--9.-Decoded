# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\fields.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import six
import json
import datetime
from django.utils.html import format_html
from rest_framework import fields, serializers
from mysite.att import utils
from mysite.att.calc_new import get_hours_or_minutes, get_hhmm
from mysite.att.utils import weekday_format
from mysite.att.models.model_paycode import WORKDAY, HOUR, MINUTE, HOUR_MINUTE
class DateTimeField(fields.DateTimeField):
    def to_representation(self, value):
        if not value:
            return
        else:
            if isinstance(value, six.string_types):
                return value
            else:
                return utils.short_date_format(value) + ' ' + utils.short_time_format(value)
class DateField(fields.DateField):
    def to_representation(self, value):
        if not value:
            return
        else:
            if isinstance(value, six.string_types):
                return value
            else:
                return utils.short_date_format(value)
class TimeField(fields.TimeField):
    def to_representation(self, value):
        if not value:
            return
        else:
            if isinstance(value, six.string_types):
                return value
            else:
                return utils.short_time_format(value)
class WeekdayField(fields.DateField):
    def to_representation(self, value):
        if value is None:
            return
        else:
            if isinstance(value, six.string_types):
                return value
            else:
                if isinstance(value, datetime.date):
                    return str(weekday_format(value.weekday()))
                else:
                    return str(weekday_format(value))
class TotalIntegerField(serializers.IntegerField):
    pay_code = None
    def __init__(self, pay_code, **kwargs):
        self.pay_code = pay_code
        super(TotalIntegerField, self).__init__(**kwargs)
    def to_representation(self, obj):
        val = super(TotalIntegerField, self).to_representation(obj)
        if not val:
            return ''
        else:
            return get_hours_or_minutes(val, self.pay_code)
class PayCodeIntegerField(serializers.IntegerField):
    pay_code = None
    def __init__(self, pay_code, **kwargs):
        self.pay_code = pay_code
        super(PayCodeIntegerField, self).__init__(**kwargs)
    def to_representation(self, obj):
        val = super(PayCodeIntegerField, self).to_representation(obj)
        if not val:
            return ''
        else:
            return get_hhmm(val, self.pay_code)
class PayCodeIntegerColorfulField(PayCodeIntegerField):
    def to_representation(self, obj):
        val = super(PayCodeIntegerColorfulField, self).to_representation(obj)
        if not val:
            return ''
        else:
            if self.pay_code and self.pay_code.get('color_setting', None):
                return format_html('<div style=\"color:{0}\">{1}</div>', self.pay_code['color_setting'], val)
            else:
                return val
class PayCodeDecimalField(serializers.DecimalField):
    pay_code = None
    def __init__(self, pay_code, **kwargs):
        self.pay_code = pay_code
        super(PayCodeDecimalField, self).__init__(**kwargs)
    def to_representation(self, value):
        val = super(PayCodeDecimalField, self).to_representation(value)
        if not val:
            return ''
        else:
            return val
class PayCodeDecimalColorfulField(PayCodeDecimalField):
    def to_representation(self, value):
        val = super(PayCodeDecimalColorfulField, self).to_representation(value)
        if not val:
            return ''
        else:
            if self.pay_code and self.pay_code.get('color_setting', None):
                return format_html('<div style=\"color:{0}\">{1}</div>', self.pay_code['color_setting'], val)
            else:
                return val
class TimeCardPayCodeIntegerField(serializers.IntegerField):
    pay_code = None
    def __init__(self, pay_code, **kwargs):
        self.pay_code = pay_code
        super(TimeCardPayCodeIntegerField, self).__init__(**kwargs)
    def to_representation(self, obj):
        if not obj:
            return ''
        else:
            payload = json.loads(obj)
            values = payload.get(self.field_name, {})
            data_format = self.pay_code['display_format']
            if data_format == MINUTE:
                value = values.get('minutes', None)
            else:
                if data_format == HOUR_MINUTE:
                    value = values.get('minutes', None)
                    if not value:
                        return ''
                    else:
                        value = int(value)
                        return '{hour:0>2d}:{minute:0>2d}'.format(hour=value // 60, minute=value % 60)
                else:
                    value = values.get('duration', None)
            if not value:
                return ''
            else:
                return super(TimeCardPayCodeIntegerField, self).to_representation(value)
class TimeCardPayCodeIntegerColorfulField(TimeCardPayCodeIntegerField):
    def to_representation(self, obj):
        val = super(TimeCardPayCodeIntegerColorfulField, self).to_representation(obj)
        if not val:
            return ''
        else:
            if self.pay_code and self.pay_code.get('color_setting', None):
                return format_html('<div style=\"color:{0}\">{1}</div>', self.pay_code['color_setting'], val)
            else:
                return val
class TimeCardPayCodeDecimalField(serializers.DecimalField):
    pay_code = None
    def __init__(self, pay_code, **kwargs):
        self.pay_code = pay_code
        super(TimeCardPayCodeDecimalField, self).__init__(**kwargs)
    def to_representation(self, value):
        if not value:
            return ''
        else:
            payload = json.loads(value)
            values = payload.get(self.field_name, {})
            data_format = self.pay_code['display_format']
            if data_format == WORKDAY:
                value = values.get('workday', None)
            else:
                if data_format == HOUR:
                    value = values.get('hours', None)
                else:
                    value = values.get('duration', None)
            if not value:
                return ''
            else:
                return super(TimeCardPayCodeDecimalField, self).to_representation(value)
class TimeCardPayCodeDecimalColorfulField(TimeCardPayCodeDecimalField):
    def to_representation(self, value):
        val = super(TimeCardPayCodeDecimalColorfulField, self).to_representation(value)
        if not val:
            return ''
        else:
            if self.pay_code and self.pay_code.get('color_setting', None):
                return format_html('<div style=\"color:{0}\">{1}</div>', self.pay_code['color_setting'], val)
            else:
                return val