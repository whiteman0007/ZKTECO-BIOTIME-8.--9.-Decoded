# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\company_stamp_setting_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
class CompanyStampSettingViewMixin:
    @action(methods=['get', 'post'], url_path='company_stamp_setting', detail=False)
    def company_stamp_setting(self, request, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='company_stamp_setting').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        serializer = serializers.CompanyStampSettingUpdateSerializer(data=request.data)
        serializer.is_valid()
        if serializer.errors:
            return Response(serializer.error_messages)
            data = serializer.validated_data
            obj, created = SystemSetting.objects.update_or_create(name='company_stamp_setting', defaults={'value': json.dumps(data)})
                return Response(data)
                except Exception as e:
                        return Response(str(e), status=status.HTTP_417_EXPECTATION_FAILED)