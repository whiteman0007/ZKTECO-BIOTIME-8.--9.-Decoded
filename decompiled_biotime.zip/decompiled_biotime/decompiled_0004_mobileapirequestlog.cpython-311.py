# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\mobile\\migrations\\0004_mobileapirequestlog.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:58 UTC (1750702738)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('personnel', '0004_auto_20210908_1006'), ('mobile', '0003_auto_20201229_0852')]
    operations = [migrations.CreateModel(name='MobileApiRequestLog', fields=[('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('username_persistent', models.CharField(blank=True, max_length=200, null=True, verbose_name='APIRequestLog.fields.requestUser')), ('view', models.CharField(blank=True, null=True, verbose_name='method called by this endpoint')), ('data', models.CharField(blank=True, null=True, verbose_name='APIRequestLog.fields.data')), ('response', models.PositiveIntegerField(blank=True, null=True, verbose_name='APIRequestLog.fields.response')), ('user', models.ForeignKey(blank=True, null=True, verbose_name='DateTimeField')), ('django', models.ForeignKey(blank=True, null=True, verbose_name='APIRequestLog.fields.requestTime')), ('db', models.ForeignKey(blank=True, null=True, verbose_name='