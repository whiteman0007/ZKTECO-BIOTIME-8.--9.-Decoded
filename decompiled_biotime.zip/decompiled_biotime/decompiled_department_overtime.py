# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\department_overtime.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.db.models import Count
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.api.base_serializers import PayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.api.utils_class import SumPayCodeDuration
from mysite.att.models import PayloadPayCode
from mysite.att.models.model_paycode import PayCode, OVERTIME
class DepartmentOvertimeSerializer(PayCodeRelatedReportModelSerializer):
    company_code = serializers.CharField(label=_('company.field.code'), source='emp__company__company_code', allow_null=True)
    company_name = serializers.CharField(label=_('company.field.name'), source='emp__company__company_name', allow_null=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='emp__department__dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='emp__department__dept_name', allow_null=True)
    total_emp = serializers.IntegerField(label=_('report_column_employeeCount'), source='emp_count')
    class Meta:
        model = PayloadPayCode
        fields = ('id', 'dept_code', 'dept_name', 'total_emp', 'company_code', 'company_name')
class DepartmentOvertimeFilter(ReportGenericFilter):
    class Meta:
        model = PayloadPayCode
        fields = ['departments', 'start_date', 'end_date']
class DepartmentOvertimeViewSet(ReportUserGenericViewSet):
    model = PayloadPayCode
    queryset = PayloadPayCode.objects.filter(pay_code__code_type=OVERTIME).filter(duration__gt=0)
    filterset_class = DepartmentOvertimeFilter
    serializer_dict = {'list': DepartmentOvertimeSerializer, 'export': DepartmentOvertimeSerializer}
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.filter(code_type=OVERTIME).order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def annotate_queryset(self, queryset):
        queryset = queryset.values('emp__department_id', 'emp__department__dept_code', 'emp__department__dept_name').order_by('emp__department_id')
        values = {'emp_count': Count('emp', distinct=True)}
        if self.pay_codes:
            for pay_code in self.pay_codes:
                self.summary_fields.append('paycode_{index}'.format(index=pay_code['id']))
                values['paycode_{index}'.format(index=pay_code['id'])] = SumPayCodeDuration(pay_code)
            queryset = queryset.annotate(**values)
        return queryset
    def get_file_title(self):
        return _('att.menus.reports.departmentOvertimeSummary')