# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\employee_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

from django.conf import settings
from django.urls import re_path
from django.db.models import Q
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views.decorators.csrf import csrf_protect
from mysite import config
from mysite.admin import fields as admin_fields
from mysite.admin.action import ActionTuple
from mysite.admin.forms import widgets as admin_widgets
from mysite.admin.kernel import ZKModelAdmin
from mysite.admin.models import STATUS_VALID
from mysite.admin.sites import zk_site
from mysite.personnel import actions as psnl_actions
from mysite.personnel import fields
from mysite.personnel import forms
from mysite.personnel import widgets
from mysite.personnel.db_const import APP_LABEL
from mysite.personnel.models import Employee
from mysite.personnel.views import faceReg, saveFacePhoto
from mysite.workflow import widgets as workflow_widgets
from . import employee_admin_mixins as mixins
from .filters import FPListFilter, FaceListFilter, PalmListFilter, FaceVLListFilter, VlFaceListFilter
csrf_protect_m = method_decorator(csrf_protect)
class EmployeeAdmin(ZKModelAdmin, mixins.EmployeeExtMixin, mixins.EmployeeDataImportMixin, mixins.EmployeePhotoImportMixin, mixins.EmployeeCertificateImportMixin, mixins.EmployeeUSBDataImportMixin, mixins.EmployeeUSBDataExportMixin):
    """\n    Admin Class for Employee\n    """
    show_full_result_count = False
    list_filter = ('emp_code', 'first_name', 'emp_type', 'flow_role__role_name', 'department__dept_code', 'department__dept_name') + config.WDMS_LIST_FILTER + ('position__position_code', 'position__position_name', 'area__area_code', 'area__area_name', 'email', 'nickname', 'last_name', 'card_no', 'dev_privilege') + config.WDMS_FILTER_APP_STATUS + ('gender',)
    list_display_params = {'__all__': {'width': '150'}}
    sort_fields = ('emp_code', 'first_name', 'last_name', 'card_no', 'gender')
    pk_ordering = ''
    import_fields = ('employee_code', 'first_name', 'department', 'position', 'card_no')
    add_form = forms.EmployeeAddForm
    form = forms.EmployeeChangeForm
    formfield_overrides = {fields.CompanyForeignKey: {'required': True, 'widget': widgets.CompanyRadioSelect(attrs={'onchange': True, 'first_click': 1, 'change_params': {'onchange_field': 'department,position,group', 'onchange_field_model': 'department,position,att_group', 'onchange_api_name': 'dept_name,position_name,name', 'onchange_parent_name': 'parent_dept,parent_position,parent_group', 'input_type': 'radio', 'filter_field': 'company', 'contact_name': 'company'}, 'multionchange_params': {'onchange_field': 'area,flow_role', 'onchange_field_model': 'area,workflow_role', 'onchange_api_name': 'area_name,role_name', 'input_type': 'checkbox', 'onchange_parent_name': 'parent_area,parent_role'}})}, fields.DepartmentForeignKey: {'widget': widgets.DepartmentRadioSelect}, fields.PositionForeignKey: {'widget': widgets.PositionRadioSelect}, fields.AreaManyToManyField: {'widget': widgets.AreaSelectMultiple}, fields.WorkflowRoleManyToManyField: {'widget': workflow_widgets.WorkflowRoleMultipleWidget}, admin_fields.PasswordField: {'widget': admin_widgets.
    fingers_params = []
    action_sets = (ActionTuple(_('op_menu_group_import'), (psnl_actions.ImportEmployee, psnl_actions.ImportDocument, psnl_actions.ImportPhoto, psnl_actions.ImportUSBData)), ActionTuple(_('op_menu_group_adjustment'), (psnl_actions.AdjustDepartment, psnl_actions.PositionTransfer, psnl_actions.AdjustArea, psnl_actions.PassProbation, psnl_actions.Resignation)), ActionTuple(_('op_menu_group_app'), (psnl_actions.EnableApp, psnl_actions.DisableApp)), ActionTuple(_('op_menu_group_more'), (psnl_actions.ResynchronizeDevice, psnl_actions.ReUploadFromDevice, psnl_actions.DeleteBiometricTemplates, psnl_actions.ExportUSBData)))
    if settings.ENABLE_WDMS:
        tmp_actions_set = []
        for i in action_sets:
            if i.name == _('op_menu_group_app'):
                continue
            else:
                tmp_actions_set.append(i)
        action_sets = tmp_actions_set
        add_form_template = 'personnel/employee/wdms_edit.html'
        change_form_template = 'personnel/employee/wdms_edit.html'
    def get_ordering(self, request):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            return ('emp_code_digit', 'emp_code')
        else:
            return ('emp_code',)
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(EmployeeAdmin, self).get_form(request, obj, **defaults)
    def company_code(self, obj):
        if obj.company:
            return obj.company.company_code
        else:
            return ''
    company_code.short_description = _('company.field.code')
    @property
    def list_display(self):
        return self.get_ext_list_display()
    @property
    def hidden_fields(self):
        return self.get_ext_hidden_fields()
    def update_result(self, obj):
        areas = obj.area.all().values('area_code', 'area_name')
        setattr(obj, 'area_codes', ','.join([area['area_code'] for area in areas]))
        setattr(obj, 'area_alias', ','.join([area['area_name'] for area in areas]))
        return obj
    def app_status_viewing(self, obj, val):
        from django.utils.html import format_html
        icon_url = settings.MEDIA_URL + 'img/icons/enable%(state)s.gif' % {'state': val}
        return format_html('<img src=\"{}\" alt=\"{}\" />', icon_url, val)
    def employee_area(self, obj):
        return obj.area_alias
    employee_area.short_description = _('emp_field_area')
    def employee_area_code(self, obj):
        return obj.area_codes
    employee_area_code.short_description = _('area_field_code')
    def dept_code(self, obj):
        return obj.department.dept_code
    dept_code.short_description = _('department_field_code')
    def get_addition_urls(self):
        urlpatterns = [re_path('^import_field/$', view=self.get_list_import, name='{}_{}_import_fields'.format(*self.info)), re_path('^upload_template/$', view=self.get_import_template, name='{}_{}_upload_template'.format(*self.info)), re_path('^facereg/$', view=faceReg, name='%s_facereg' % APP_LABEL), re_path('^saveFacePhoto/', view=saveFacePhoto, name='%s_savePhoto' % APP_LABEL)]
        return urlpatterns
    def get_queryset(self, request):
        qs = self.model.objects.all()
        qs = qs.select_related('department', 'position')
        if not request.user.is_superuser:
            if request.user.auth_dept.all():
                qs = qs.filter(department__in=request.user.auth_dept.all())
            if request.user.auth_area.all():
                qs = qs.filter(area__in=request.user.auth_area.all()).distinct()
            if request.user.assign_company:
                qs = qs.filter(company=request.user.assign_company)
        qs = qs.filter(Q(status=STATUS_VALID) | Q(status=None))
        return qs
zk_site.register(Employee, EmployeeAdmin)