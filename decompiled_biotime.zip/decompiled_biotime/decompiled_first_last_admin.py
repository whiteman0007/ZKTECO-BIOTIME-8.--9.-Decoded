# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\first_last_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.views.report.view_report_firstlast import FirstLastReportViewSet, FirstLastReportSerializer
@report_register()
class FirstLastAdmin(ReportAdminBase):
    model_name = 'firstLastReport'
    view_name = 'first_last_report'
    template = 'att/report/first_last.html'
    api_view = FirstLastReportViewSet
    serializer = FirstLastReportSerializer
    data_source = '/att/api/firstLastReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday', 'first_punch', 'last_punch', 'total_time')
    hidden_fields = ('company_code', 'last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = ('emp_code', 'dept_code', 'att_date')
    def get_serialize_data(self):
        queryset = self.get_queryset()
        queryset = self.filter_queryset(self.annotate_queryset(queryset))
        serializer = self.get_serializer(queryset, many=True)
        return serializer.data