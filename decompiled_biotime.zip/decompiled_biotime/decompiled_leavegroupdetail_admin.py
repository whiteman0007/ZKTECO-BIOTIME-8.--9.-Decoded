# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\leavegroupdetail_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from mysite import admin
from mysite.att.models import LeaveGroupDetail
from django.utils.translation import gettext_lazy as _
@admin.register(LeaveGroupDetail)
class LeaveGroupDetailAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'leave_type', 'get_base_on_service_disaplay', 'pay_code', 'pay_code_id', 'pay_code_name', 'allow_leave_day', 'min_leave_day', 'deduct_holiday_day', 'leave_entitlement', 'leave_interval', 'leave_distribution_time', 'start_day', 'set_hire_day', 'allow_balance', 'max_balance')
    def get_base_on_service_disaplay(self, obj):
        return str(_('leaveGroupDetail.statusOpts.basedOnService'))
    def pay_code_name(self, obj):
        return obj.pay_code.name
    pay_code_name.short_description = _('payCode.fields.name')