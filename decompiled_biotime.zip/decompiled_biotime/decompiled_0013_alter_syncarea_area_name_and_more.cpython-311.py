# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0013_alter_syncarea_area_name_and_more.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('base', '0012_linenotifysetting_send_photo_linenotifyforemployee')]
    operations = [migrations.AlterField(model_name='syncarea', name='area_name', field=models.CharField(max_length=100, verbose_name='area_field_name')), migrations.AlterField(model_name='syncdepartment', name='dept_name', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='area_field_name')), migrations.AlterField(model_name='syncemployee', name='dept_name', field=models.CharField(blank=True, max_length=200, null=True, verbose_name='department_filed_name')), migrations.AlterField(model_name='syncemployee', name='last_name', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='emp_field_lastName'))]