# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0003_auto_20200909_1810.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('personnel', '0002_auto_20200901_1642'), ('att', '0002_auto_20200901_1642')]
    operations = [migrations.AlterUniqueTogether(name='payloadtimecard', unique_together=set([('emp', 'att_date', 'time_table')]))]