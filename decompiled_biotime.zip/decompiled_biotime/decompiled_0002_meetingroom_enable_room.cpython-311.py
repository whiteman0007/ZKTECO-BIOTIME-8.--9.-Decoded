# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\meeting\\migrations\\0002_meetingroom_enable_room.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:58 UTC (1750702738)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('meeting', '0001_initial')]
    operations = [migrations.AddField(model_name='meetingroom', name='enable_room', field=models.BooleanField(default=True, verbose_name='meetingRoom.fields.enableRoom'))]