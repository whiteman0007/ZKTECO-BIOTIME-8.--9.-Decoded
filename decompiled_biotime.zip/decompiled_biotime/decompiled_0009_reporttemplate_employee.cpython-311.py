# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0009_reporttemplate_employee.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('personnel', '0004_auto_20210908_1006'), ('att', '0008_auto_20210908_1006')]
    operations = [migrations.AddField(model_name='reporttemplate', name='employee', field=models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, to='personnel.Employee'))]