# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\auto_export_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import json
import re
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite._utils import getattr_ex
from mysite.admin.kernel import ZKModelAdmin
from mysite.base.models import AutoExportTask
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.base import actions as aac
from mysite.base.forms import AutoExportTaskCreationForm
from mysite.admin.action import ActionTuple
from mysite import config
@admin.register(AutoExportTask)
class AutoExportTaskAdmin(ZKModelAdmin):
    list_display = ('task_code', 'task_name', 'export_file', 'export_format', 'export_by', 'enable', 'process_time')
    sort_fields = []
    list_filter = ('task_code', 'task_name')
    form = AutoExportTaskCreationForm
    actions = (aac.ManualExport,)
    action_sets = (ActionTuple(_('op_menu_group_task_status'), (aac.EnableTask, aac.DisableTask)),)
    def get_queryset(self, request):
        from django.conf import settings
        qs = super(AutoExportTaskAdmin, self).get_queryset(request)
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            company = None
            objs_id_list = []
            if not request.user.is_superuser:
                if request.user.assign_company:
                    company = request.user.assign_company
                else:
                    if request.user.auth_dept.exists():
                        company = request.user.auth_dept.all().first().company.id
                    else:
                        if request.user.auth_area.exists():
                            company = request.user.auth_area.all().first().company.id
            if company:
                for task_obj in qs:
                    if task_obj.get_options().get('company', None) == company:
                        objs_id_list.append(task_obj.id)
                qs = qs.filter(id__in=objs_id_list)
        return qs