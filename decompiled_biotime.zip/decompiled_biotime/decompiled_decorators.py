# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\decorators.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

def report_register():
    """\n    A decorator to registers the given report admin classes with\n    ReportManager:\n\n    @report_register()\n    class TotalTimeCardAdmin(ReportAdminBase):\n        pass\n    """
    from .manager import report_manager
    from .base import ReportAdminBase
    def wrapper(report_admin):
        if not issubclass(report_admin, ReportAdminBase):
            raise ValueError('Wrapped class must subclass ReportBase.')
        else:
            report_manager.register(report_admin)
            return report_admin
    return wrapper