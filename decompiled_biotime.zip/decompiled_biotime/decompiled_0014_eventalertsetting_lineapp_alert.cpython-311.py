# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0014_eventalertsetting_lineapp_alert.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('base', '0013_alter_syncarea_area_name_and_more')]
    operations = [migrations.AddField(model_name='eventalertsetting', name='lineapp_alert', field=models.BooleanField(default=False, verbose_name='eventAlertSetting.fields.lineAppAlert'))]