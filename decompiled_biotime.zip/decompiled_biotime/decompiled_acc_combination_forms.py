# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\forms\\acc_combination_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:49 UTC (1750672969)

from django.core.cache import cache
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.acc.models import AccCombination, AccGroups
from mysite.admin import forms
from mysite.personnel.models import Area
class AccCombinationForm(ModelForm):
    area = forms.ModelChoiceField(label=_('accPrivilege_field_area'), queryset=Area.objects.all(), disabled=True)
    combination_no = forms.IntegerField(label=_('accCombination_field_no'), disabled=True)
    group1 = forms.ModelChoiceField(label=_('accCombination_field_group1'), queryset=AccGroups.objects.all(), required=False)
    group2 = forms.ModelChoiceField(label=_('accCombination_field_group2'), queryset=AccGroups.objects.all(), required=False)
    group3 = forms.ModelChoiceField(label=_('accCombination_field_group3'), queryset=AccGroups.objects.all(), required=False)
    group4 = forms.ModelChoiceField(label=_('accCombination_field_group4'), queryset=AccGroups.objects.all(), required=False)
    group5 = forms.ModelChoiceField(label=_('accCombination_field_group5'), queryset=AccGroups.objects.all(), required=False)
    class Meta:
        model = AccCombination
        fields = '__all__'
    def __init__(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        super(AccCombinationForm, self).__init__(*args, **kwargs)
        try:
            request = kwargs.get('initial', None)
            current_area = 1
            if request:
                current_area = request['request'].GET.get('current_area', 1)
            if args and args[0]['area']:
                    current_area = args[0]['area']
            if self.instance.area_id:
                current_area = self.instance.area_id
            groups = AccGroups.objects.filter(area_id=current_area)
            self.fields['group1'].queryset = groups
            self.fields['group2'].queryset = groups
            self.fields['group3'].queryset = groups
            self.fields['group4'].queryset = groups
            self.fields['group5'].queryset = groups
            self.fields['area'].initial = current_area
        except Exception:
            pass
        if self.instance.pk and self.instance.group1:
                self.initial['group1'] = AccGroups.objects.filter(area=self.instance.area, group_no=self.instance.group1).first().id
        if self.instance.pk and self.instance.group2:
                self.initial['group2'] = AccGroups.objects.filter(area=self.instance.area, group_no=self.instance.group2).first().id
        if self.instance.pk and self.instance.group3:
                self.initial['group3'] = AccGroups.objects.filter(area=self.instance.area, group_no=self.instance.group3).first().id
        if self.instance.pk and self.instance.group4:
                self.initial['group4'] = AccGroups.objects.filter(area=self.instance.area, group_no=self.instance.group4).first().id
        if self.instance.pk and self.instance.group5:
                self.initial['group5'] = AccGroups.objects.filter(area=self.instance.area, group_no=self.instance.group5).first().id
                    except Exception as e:
                            return None
    def clean(self):
        cleaned_data = super(AccCombinationForm, self).clean()
        if cleaned_data['group1']:
            cleaned_data['group1'] = cleaned_data['group1'].group_no
        else:
            cleaned_data['group1'] = 0
        if cleaned_data['group2']:
            cleaned_data['group2'] = cleaned_data['group2'].group_no
        else:
            cleaned_data['group2'] = 0
        if cleaned_data['group3']:
            cleaned_data['group3'] = cleaned_data['group3'].group_no
        else:
            cleaned_data['group3'] = 0
        if cleaned_data['group4']:
            cleaned_data['group4'] = cleaned_data['group4'].group_no
        else:
            cleaned_data['group4'] = 0
        if cleaned_data['group5']:
            cleaned_data['group5'] = cleaned_data['group5'].group_no
        else:
            cleaned_data['group5'] = 0
        return cleaned_data