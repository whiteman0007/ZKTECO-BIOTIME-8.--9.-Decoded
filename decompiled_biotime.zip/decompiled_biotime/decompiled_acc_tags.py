# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\templatetags\\acc_tags.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:51 UTC (1750672971)

from django import template
register = template.Library()