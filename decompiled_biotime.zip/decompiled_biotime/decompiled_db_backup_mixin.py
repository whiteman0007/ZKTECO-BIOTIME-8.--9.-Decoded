# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\db_backup_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
class DBBackupViewMixin:
    @action(methods=['get', 'post'], url_path='db_backup', detail=False)
    def db_backup(self, request, *args, **kwargs):
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='db_backup').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        else:
            serializer = serializers.DBBackupUpdateSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj = SystemSetting.objects.filter(name='db_backup').first()
            if not obj:
                obj = SystemSetting(name='db_backup')
            obj.value = json.dumps(data)
            obj.save()
            return Response(data)