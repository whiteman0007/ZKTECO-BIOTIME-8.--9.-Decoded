# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0002_auto_20200901_1642.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from __future__ import unicode_literals
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import mysite.base.models.modelless
import mysite.personnel.fields
class Migration(migrations.Migration):
    initial = True
    dependencies = [('contenttypes', '0002_remove_content_type_name'), ('personnel', '0001_initial'), ('base', '0001_initial'), migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [migrations.AddField(model_name='linenotifysetting', name='line_notify_dept', field=mysite.personnel.fields.DepartmentForeignKey(null=True, on_delete=django.db.models.deletion.CASCADE, to='personnel.Department', verbose_name='lineNotify_field_department')), migrations.AddField(model_name='bookmark', name='content_type', field=models.ForeignKey(blank=True, null=True, to='contenttypes.ContentType', verbose_name='bookmark_field_user')), migrations.AddField(model_name='adminlog', name='content_type', field=models.ForeignKey(blank=True, null=True, to='contenttypes.ContentType', verbose_name='adminLog_field_contentType')), migrations.AlterUniqueTogether(name='linenotifysetting', unique_together=set([('line_notify_dept', 'personnel', 'ParaName'), ('ParaType', 'unique_together'), ('adminlog', 'SET_NULL', 'adminLog_field_contentType'), ('adminLog_field_user', 'CreateModel'), ('SystemSettingPermission', 'System Setting Permission', 'System Setting Permissions',