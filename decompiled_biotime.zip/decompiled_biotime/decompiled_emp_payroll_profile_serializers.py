# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\api\\serializers\\emp_payroll_profile_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from rest_framework import serializers
from mysite.payroll.models import EmpPayrollProfile
class EmpPayrollProfileSerializer(serializers.ModelSerializer):
    employee = serializers.IntegerField(source='employee.id')
    class Meta:
        model = EmpPayrollProfile
        fields = ['id', 'employee', 'emp_code', 'first_name', 'last_name', 'department', 'payment_mode', 'payment_type', 'bank_name', 'bank_account', 'agent_id', 'agent_account']
class EmpPayrollProfileExportSerializer(serializers.ModelSerializer):
    payment_mode = serializers.CharField(source='get_payment_mode_display')
    payment_type = serializers.CharField(source='get_payment_type_display')
    class Meta:
        model = EmpPayrollProfile
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'department', 'payment_mode', 'payment_type', 'bank_name', 'bank_account', 'agent_id', 'agent_account']