# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\admin\\biodata_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

from django.utils.translation import gettext_lazy as _
from mysite import config
from mysite.admin.kernel import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.iclock.models import BioData
class BioDataAdmin(ZKModelAdmin):
    list_display = ('employee_code', 'employee_first_name') + config.WDMS_LIST_DISPLAY + ('employee_last_name', 'bio_type', 'bio_no', 'major_ver', 'minor_ver', 'sn', 'update_time')
    sort_fields = ('bio_type', 'major_ver')
    list_filter = config.EMPLOYEE_LIST_FILTER + config.WDMS_LIST_FILTER_EMPLOYEE + ('bio_type', 'bio_no', 'bio_index', 'major_ver', 'sn', 'update_time')
    list_select_related = True
    actions = None
    def company(self, obj):
        if obj.employee and obj.employee.company:
            return obj.employee.company.company_name
        else:
            return ''
    company.short_description = _('company.field.name')
    def company_code(self, obj):
        if obj.employee and obj.employee.company:
            return obj.employee.company.company_code
        else:
            return ''
    company_code.short_description = _('company.field.code')
    def employee_code(self, obj):
        return obj.employee.emp_code
    employee_code.short_description = _('emp_field_employeeCode')
    def employee_first_name(self, obj):
        return obj.employee.first_name
    employee_first_name.short_description = _('emp_field_firstName')
    def employee_last_name(self, obj):
        return obj.employee.last_name
    employee_last_name.short_description = _('emp_field_lastName')
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        qs = super(BioDataAdmin, self).get_queryset(request)
        if request.user.is_employee:
            qs = qs.filter(employee__company=request.user.company)
        else:
            if not request.user.is_superuser:
                if request.user.auth_dept.exists():
                    qs = qs.filter(employee__department__in=request.user.auth_dept.all()).select_related('employee')
                if request.user.auth_area.exists():
                    from mysite.personnel.models import Employee
                    employees = Employee.objects.filter(area__in=request.user.auth_area.all())
                    qs = qs.filter(employee__in=employees).distinct()
                if request.user.assign_company:
                    qs = qs.filter(employee__company=request.user.assign_company)
        return qs
    @staticmethod
    def initial_data():
        biodatas = BioData.objects.filter(minor_ver__isnull=True)
        if biodatas:
            biodatas.update(minor_ver='0')
zk_site.register(BioData, BioDataAdmin)