# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\ep\\ep_setup_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:32 UTC (1750673012)

from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.ep.models import EPSetup
from mysite.ep.db_const import CELSIUS, TEMP_UNIT
class EPSetUpForm(ModelForm):
    temp_alarm = forms.BooleanField(label=_('epSetup.fields.temperatureAlarm'), initial=0, required=False)
    mask_alarm = forms.BooleanField(label=_('epSetup.fields.maskAlarm'), initial=0, required=False)
    temp_warning = forms.DecimalField(label=_('epSetup.fields.temperatureWarning'), required=True)
    temp_unit = forms.ChoiceField(choices=TEMP_UNIT, initial=CELSIUS)
    class Meta:
        model = EPSetup
        fields = ['temp_alarm', 'mask_alarm', 'temp_warning', 'temp_unit']