# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\iutils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

global deptversion
global d_deptDict
"""\n有关部门的规则\n\n1 前台没有选择包含子部门时 查询的数据是指当前部门的数据\n2 前台选择包含子部门时 分如下情况\n   如果选择的部门为总公司级即第一级部门 系统将认为是所有部门 在有关查询条件中不要加部门限制 getAllAuthChildDept返回的结果为[-1]\n   如果不是第一级时对超级用户将自动包括其下级所有部门 如果是普通用户结果是被授权的所有子部门getAllAuthChildDept返回的结果为[3,4,5...]\n\n"""
from django.core.cache import cache
from mysite.base.models import get_param_value, SysParam
from django.conf import settings
import datetime
d_deptDict = {}
deptversion = ''
gStatus = []
def Childrens(DeptID, d_item):
    try:
        ret = d_item[DeptID]
    except:
        ret = []
    return ret
def AllChildrens(curid, d_item, start=[]):
    """获取当前部门下的所有子部门，不含当前部门"""
    for d in Childrens(curid, d_item):
        if d not in start:
            start.append(d)
            AllChildrens(d, d_item, start)
def userDeptList(user, dataModel):
    from mysite.personnel.models.model_department import Department
    v = get_param_value('DEPT_VERSION')
    settings.DEPT_VERSION = v
    Result = cache.get('%s_userdepts_%s_%s' % (settings.UNIT, user.id, settings.DEPT_VERSION))
    if Result:
        return Result
    else:
        d_item = get_dept_as_dict(user, dataModel)
        Result = []
        if user.is_superuser or user.is_alldept:
            rs_dept = Department.objects.all().exclude(del_flag=1).order_by('parent_dept', 'dept_code')
            for t in rs_dept:
                Result.append(int(t.DeptID))
        else:
            rs_dept = Department.objects.filter(user=user).exclude(dept__del_tag=1).order_by('dept')
            for t in rs_dept:
                if t.iscascadecheck == 1:
                    rs = []
                    AllChildrens(int(t.dept_id), d_item, rs)
                    Result += rs
                Result.append(int(t.dept_id))
        Result = list(set(Result))
        cache.set('%s_userdepts_%s_%s' % (settings.UNIT, user.id, settings.DEPT_VERSION), Result, timeout=86400)
        return Result
def getAvailableParentDepts(dataKey, request, dataModel):
    from mysite.personnel.models.model_department import Department
    if not dataKey:
        return []
    else:
        if dataKey == 1:
            return [1]
        else:
            obj = Department.objByID(dataKey)
            d_item = get_dept_as_dict(None, dataModel)
            childDepts = []
            AllChildrens(dataKey, d_item, childDepts)
            pDepts = Department.objects.exclude(DeptID__in=childDepts).values_list('DeptID', flat=True)
            pDepts = list(pDepts)
            try:
                pDepts.remove(dataKey)
            except Exception as e:
                pass
            return pDepts
def get_dept_as_dict(user=None, funid=None, dataModel=None):
    global deptversion
    global d_deptDict
    ver = get_param_value(funid.upper() + '_VERSION')
    if deptversion!= ver:
        d_deptDict = cache.get('%s_%s_dict_%s' % (settings.UNIT, funid.lower(), ver))
    if d_deptDict:
        deptversion = ver
        return d_deptDict
    else:
        d_deptDict = cache.get('%s_%s_dict_%s' % (settings.UNIT, funid.lower(), ver))
        if d_deptDict:
            deptversion = ver
            return d_deptDict
        else:
            ll = {}
            j = 0
            nt = datetime.datetime.now()
            secs = (nt.day * 24 * 3600 + nt.hour * 3600 + nt.minute * 60 + nt.second) / 60
            field_names = dataModel._meta.fields
            parent_name = ''
            for field_name in field_names:
                if 'parent' in field_name.attname:
                    parent_name = field_name.attname
                    break
            if not parent_name:
                return False
            else:
                objs = dataModel.objects.exclude(del_flag=1).order_by(parent_name)
                for o in objs:
                    j = j + 1
                    try:
                        parent_obj = getattr(o, parent_name)
                    except:
                        parent_obj = None
                    if parent_obj:
                        try:
                            ll[str(parent_obj)].append(int(o.id))
                        except:
                            try:
                                ll[str(parent_obj)] = []
                                ll[str(parent_obj)].append(int(o.id))
                            except:
                                pass
                ll['count'] = j
                cache.set('%s_%s_dict_%s' % (settings.UNIT, funid.lower(), ver), ll)
                cache.delete('_is_loading_%s' % secs)
                return ll
def get_pos_as_dict(user=None):
    global deptversion
    global d_deptDict
    from mysite.personnel.models.model_department import Department
    ver = get_param_value('POSITION_VERSION')
    if deptversion!= ver:
        d_deptDict = cache.get('%s_deptdict_%s' % (settings.UNIT, ver))
    if d_deptDict:
        deptversion = ver
        return d_deptDict
    else:
        d_deptDict = cache.get('%s_deptdict_%s' % (settings.UNIT, ver))
        if d_deptDict:
            deptversion = ver
            return d_deptDict
        else:
            dept_list = []
            ll = {}
            j = 0
            i = 0
            nt = datetime.datetime.now()
            secs = (nt.day * 24 * 3600 + nt.hour * 3600 + nt.minute * 60 + nt.second) / 60
            is_loading = cache.get('_is_loading_%s' % secs)
            objs = Department.objects.exclude(del_flag=1).order_by('parent_dept', 'dept_code')
            for o in objs:
                j = j + 1
                if o.parent_dept_id:
                    try:
                        ll[str(o.parent_dept_id)].append(int(o.id))
                    except:
                        try:
                            ll[str(o.parent_dept_id)] = []
                            ll[str(o.parent_dept_id)].append(int(o.id))
                        except:
                            pass
            ll['count'] = j
            cache.set('%s_deptdict_%s' % (settings.UNIT, ver), ll)
            cache.delete('_is_loading_%s' % secs)
            return ll