# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\actions\\adjust_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.acc.models import AccPrivilege
from mysite.admin import forms
from mysite.admin.action import ActionHandleError
class AdjustForm(forms.ZKActionForm):
    emp = forms.AreaEmployeeManyToManyField(label=_('model_employee'), required=False)
class SetEmployeeGroup(admin.ZKModelAction):
    verbose_name = _('position_action_adjustEmployee')
    help_txt = _('position_action_adjustEmployeeHelpTxt')
    short_description = _('position_action_adjustEmployeeDescription')
    action_form = AdjustForm
    unique_object_required = True
    def action(self, *args, **kwargs):
        employees = self.request.POST.getlist('employee')
        if not employees:
            raise ActionHandleError(_('select_none_employee'))
        else:
            for emp in employees:
                privilege = AccPrivilege.objects.filter(area=self.objects[0].area, employee_id=emp).first()
                if not privilege:
                    privilege = AccPrivilege()
                    privilege.area = self.objects[0].area
                    privilege.employee_id = emp
                    privilege.is_group_timezone = 1
                if privilege.is_group_timezone:
                    privilege.timezone1 = self.objects[0].timezone1
                    privilege.timezone2 = self.objects[0].timezone2
                    privilege.timezone3 = self.objects[0].timezone3
                privilege.group = self.objects[0]
                privilege.save()