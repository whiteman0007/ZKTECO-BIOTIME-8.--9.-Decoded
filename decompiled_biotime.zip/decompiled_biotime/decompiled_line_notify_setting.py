# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\models\\line_notify_setting.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:25 UTC (1750673005)

from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.core.cache import cache
from django.db.models import signals
from django.dispatch import receiver
from mysite.personnel.fields import DepartmentForeignKey
from mysite.personnel.models import Employee
from mysite.personnel.models.model_department import Department, get_all_childrens_by_deptid
from mysite.base import db_const
MAX_NVARCHAR_TOKEN = 200
MAX_NVARCHAR_REMARK = 200
MAX_NVARCHAR_HEAD = 100
MAX_NVARCHAR_TAIL = 100
CACHE_KEY_SEND = '%s_line_notify_send' % settings.UNIT
CACHE_KEY_EMP_SEND = '%s_line_notify_send_{emp_code}' % settings.UNIT
LINENOTIFYSETTING_DEPT_TASK_NAME = 'base.tasks_ex.line_notify_dept-{key}'
AVAILABLE_CHOICE = ((1, _('enableStatus_option_enable')), (0, _('enableStatus_option_disable')))
BOOLEAN_CHOICE = ((1, _('boolean_option_yes')), (0, _('boolean_option_no')))
MESSAGE_TYPE = ((100, _('lineNotifySetting_messageType_realTime')), (200, _('lineNotifySetting_messageType_intradayAttendanceSummary')))
FOR_EMPLOYEE_MESSAGE_TYPE = ((100, _('Attendance record')),)
class LineNotifyBase(models.Model):
    line_notify_token = models.CharField(_('lineNotify_field_lineNotifyToken'), max_length=MAX_NVARCHAR_TOKEN, blank=False, null=True, help_text=_('lineNotify_field_lineNotifyTokenHelpTxt'))
    send_photo = models.BooleanField(_('lineNotify_field_sendPhoto'), default=True, null=False, blank=False)
    push_time = models.TimeField(_('lineNotify_field_pushTime'), null=True, blank=True)
    is_valid = models.IntegerField(_('lineNotify_field_isValid'), null=True, blank=True, choices=AVAILABLE_CHOICE)
    remark = models.CharField(_('lineNotify_field_remark'), null=True, blank=True, max_length=MAX_NVARCHAR_REMARK)
    class Meta:
        abstract = True
class LineNotifySetting(LineNotifyBase):
    """ For Department """
    line_notify_dept = DepartmentForeignKey(Department, verbose_name=_('lineNotify_field_department'), blank=False, null=True, on_delete=models.CASCADE)
    include_sub_department = models.IntegerField(_('lineNotify_field_includeSubDepartment'), null=True, blank=True, choices=BOOLEAN_CHOICE)
    message_type = models.IntegerField(_('lineNotify_field_messageType'), default=100, null=True, blank=True, choices=MESSAGE_TYPE)
    message_head = models.CharField(_('lineNotify_field_messageHead'), null=True, blank=True, max_length=MAX_NVARCHAR_HEAD)
    message_tail = models.CharField(_('lineNotify_field_messageTail'), null=True, blank=True, max_length=MAX_NVARCHAR_TAIL)
    class Meta:
        app_label = db_const.APP_LABEL
        verbose_name = _('base_model_lineNotifySetting')
        unique_together = (('line_notify_dept', 'line_notify_token', 'message_type'),)
    def save(self, force_insert=False, force_update=False, using=None, update_fields=None):
        self.delete_cache()
        super(LineNotifySetting, self).save(force_insert, force_update, using, update_fields)
    @staticmethod
    def obj_list_by_deptid(deptid):
        obj_list = []
        cached_obj = cache.get('%s_enable_line_notify_%s' % (settings.UNIT, deptid))
        if cached_obj:
            obj_list.extend(cached_obj)
            return obj_list
        else:
            include_sub_dept_qs = LineNotifySetting.objects.filter(include_sub_department=1, is_valid=1).exclude(line_notify_dept_id=deptid)
            for qs in include_sub_dept_qs:
                dept_list = get_all_childrens_by_deptid(qs.line_notify_dept_id).values_list('id', flat=True)
                if deptid in dept_list:
                    obj_list.append(qs)
            obj_list.extend(list(LineNotifySetting.objects.filter(line_notify_dept_id=deptid, is_valid=1)))
            cache.set('%s_enable_line_notify_%s' % (settings.UNIT, deptid), obj_list)
            return obj_list
    def delete_cache(self):
        relate_deptids = [self.line_notify_dept_id]
        if self.pk is None:
            if self.include_sub_department == 1 and self.is_valid == 1:
                    relate_deptids.extend(get_all_childrens_by_deptid(self.line_notify_dept_id).values_list('id', flat=True))
        else:
            relate_deptids.extend(get_all_childrens_by_deptid(self.line_notify_dept_id).values_list('id', flat=True))
        for deptid in relate_deptids:
            cache.delete('%s_enable_line_notify_%s' % (settings.UNIT, deptid))
        cache.delete(CACHE_KEY_SEND)
def get_line_notify_send_flag():
    cached_obj = cache.get(CACHE_KEY_SEND)
    if cached_obj is not None:
        return cached_obj
    else:
        cached_obj = LineNotifySetting.objects.filter(is_valid=1).count()
        cache.set(CACHE_KEY_SEND, cached_obj)
        return cached_obj
class LineNotifyForEmployee(LineNotifyBase):
    """ For employee """
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE)
    message_type = models.IntegerField(_('lineNotify_field_messageType'), default=100, null=True, blank=True, choices=FOR_EMPLOYEE_MESSAGE_TYPE)
    message_head = models.CharField(_('lineNotify_field_messageHead'), null=True, blank=True, max_length=MAX_NVARCHAR_HEAD)
    message_tail = models.CharField(_('lineNotify_field_messageTail'), null=True, blank=True, max_length=MAX_NVARCHAR_TAIL)
    def save(self, force_insert=False, force_update=False, using=None, update_fields=None):
        self.set_cache()
        super(LineNotifyForEmployee, self).save(force_insert, force_update, using, update_fields)
    def delete(self, using=None, keep_parents=False):
        self.delete_cache()
        super(LineNotifyForEmployee, self).delete(using, keep_parents)
    def set_cache(self):
        cache_key = CACHE_KEY_EMP_SEND.format(emp_code=self.employee.emp_code)
        cache.set(cache_key, self)
    def delete_cache(self):
        cache_key = CACHE_KEY_EMP_SEND.format(emp_code=self.employee.emp_code)
        cache.delete(cache_key)
    @staticmethod
    def get_obj(emp_code):
        cache_key = CACHE_KEY_EMP_SEND.format(emp_code=emp_code)
        cached_obj = cache.get(cache_key)
        if cached_obj is not None:
            return cached_obj
        else:
            cached_obj = LineNotifyForEmployee.objects.filter(employee__emp_code=emp_code).last()
            if not cached_obj:
                cache.set(cache_key, 0, 43200)
            else:
                cache.set(cache_key, cached_obj)
            return cached_obj
@receiver(signals.post_save, sender=LineNotifySetting)
def post_save_receiver_for_dept(sender, instance, created, *args, **kwargs):
    create_periodic_task(sender, instance, created, *args, **kwargs)
def create_periodic_task(sender, instance, created, *args, **kwargs):
    import json
    from django_celery_beat.models import CrontabSchedule, PeriodicTask
    task_name = LINENOTIFYSETTING_DEPT_TASK_NAME.format(key=instance.pk)
    periodic_task = PeriodicTask.objects.filter(name=task_name).first()
    if periodic_task:
        if instance.message_type == 200 and instance.push_time:
            schedule, _new = CrontabSchedule.objects.get_or_create(hour='%s' % instance.push_time.hour, minute='%s' % instance.push_time.minute, day_of_week=get_workday(), timezone=settings.TIME_ZONE)
            periodic_task.args = json.dumps([instance.line_notify_dept_id])
            periodic_task.crontab = schedule
            periodic_task.enabled = bool(instance.is_valid)
            periodic_task.save()
        else:
            periodic_task.args = json.dumps([instance.line_notify_dept_id])
            periodic_task.enabled = False
            periodic_task.save()
    else:
        if instance.message_type == 200 and instance.push_time and instance.is_valid:
                    schedule, _new = CrontabSchedule.objects.get_or_create(hour='%s' % instance.push_time.hour, minute='%s' % instance.push_time.minute, day_of_week=get_workday(), timezone=settings.TIME_ZONE)
                    PeriodicTask.objects.create(crontab=schedule, name=task_name, task='base.tasks_ex.intraday_attendance_summary_line_notify', args=json.dumps([instance.line_notify_dept_id]))
def get_workday():
    return '0-6'
@receiver(signals.post_delete, sender=LineNotifySetting)
def post_delete_receiver_for_dept(sender, instance, using, *args, **kwargs):
    delete_cache_for_dept(sender, instance, using, *args, **kwargs)
    delete_periodic_task(sender, instance, using, *args, **kwargs)
def delete_cache_for_dept(sender, instance, using, *args, **kwargs):
    relate_deptids = [instance.line_notify_dept_id]
    if instance.pk is None:
        if instance.include_sub_department == 1 and instance.is_valid == 1:
                relate_deptids.extend(get_all_childrens_by_deptid(instance.line_notify_dept_id).values_list('id', flat=True))
    else:
        relate_deptids.extend(get_all_childrens_by_deptid(instance.line_notify_dept_id).values_list('id', flat=True))
    for deptid in relate_deptids:
        cache.delete('%s_enable_line_notify_%s' % (settings.UNIT, deptid))
    cache.delete(CACHE_KEY_SEND)
def delete_periodic_task(sender, instance, using, *args, **kwargs):
    from django_celery_beat.models import PeriodicTask
    task_name = LINENOTIFYSETTING_DEPT_TASK_NAME.format(key=instance.pk)
    periodic_task = PeriodicTask.objects.filter(name=task_name)
    if periodic_task:
        periodic_task.delete()