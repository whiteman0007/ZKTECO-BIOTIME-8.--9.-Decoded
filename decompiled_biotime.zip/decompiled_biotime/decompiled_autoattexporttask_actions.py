# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\actions\\autoattexporttask_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:03 UTC (1750672983)

import datetime
from collections.abc import Iterable
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
def report_auto_export(dt_now, start, end, tasks, manual=False, progress_recorder=None):
    from mysite.base.api.serializers import AutoExportReportOptionExecutableSerializer
    from mysite.iclock.auto_export import auto_export_report_executor
    if not isinstance(tasks, Iterable):
        tasks = [tasks]
    for t in tasks:
        serializer = AutoExportReportOptionExecutableSerializer(data=t.get_options())
        serializer.is_valid()
        options = serializer.validated_data
        auto_export_report_executor(options, start, end, dt_now, manual=manual)
class ManualExportForm(forms.ZKActionForm):
    manual_start = forms.DateTimeField(label=_('autoExport_manualExport_startDate'), required=True)
    manual_end = forms.DateTimeField(label=_('autoExport_manualExport_endDate'), required=True)
class ManualAttExport(ZKModelAction):
    batch_select = True
    verbose_name = _('autoExport_task_action_manualExport')
    short_description = _('autoExport_task_action_manualExport_description')
    action_form = ManualExportForm
    async_progress = True
    def action(self, *args, **kwargs):
        from mysite.base.tasks import async_progress_task_wapper
        cleaned_data = self.valid_form.cleaned_data
        dt_now = datetime.datetime.now()
        call_info = {'type': 'func', 'func': report_auto_export, 'lng': self.request.LANGUAGE_CODE}
        task = async_progress_task_wapper(call_info, dt_now, cleaned_data['manual_start'], cleaned_data['manual_end'], list(self.objects), manual=True)
        return task