# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\api\\serializers\\company_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

from rest_framework import serializers
from mysite.personnel.models import Company
class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'company_code', 'company_name']
class CompanyExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'company_code', 'company_name']
class CompanyCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'company_code', 'company_name']
class CompanyEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['company_code', 'company_name']
        extra_kwargs = {'company_code': {'required': False, 'allow_null': False}, 'company_name': {'required': False, 'allow_null': False}}