# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\db_migrate_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from celery_progress.backend import AbstractProgressRecorder
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
class DbMigrateSettingViewMixin:
    @action(methods=['get', 'post'], url_path='db_migrate_setting', detail=False)
    def db_migrate_setting(self, request, *args, **kwargs):
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='db_migrate_setting').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        else:
            serializer = serializers.DbMigrateSettingUpdateSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj = SystemSetting.objects.filter(name='db_migrate_setting').first()
            if not obj:
                obj = SystemSetting(name='db_migrate_setting')
            obj.value = json.dumps(data)
            obj.save()
            return Response(data)
    @action(methods=['post', 'get'], detail=False)
    def db_migrate_run(self, request):
        from mysite.base.tasks import async_progress_task_wapper
        from mysite.base.views.db_migrate import db_migrate_executor
        call_info = {'type': 'func', 'func': db_migrate_executor, 'lng': request.LANGUAGE_CODE}
        task = async_progress_task_wapper(call_info)
        return Response({'code': 0, 'payload': {'task_id': task.id}})
    @action(methods=['get'], detail=False)
    def clear_db_migrate(self, request, *args, **kwargs):
        qs = self.get_queryset()
        qs.filter(name='db_migrate_setting').delete()
        return Response({'detail': 'Success'})