# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0003_auto_20201229_0852.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from __future__ import unicode_literals
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.db.models.manager
class Migration(migrations.Migration):
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL), ('contenttypes', '0002_remove_content_type_name'), ('base', '0002_auto_20200901_1642')]
    (-1) = [('ApiLog', models.AutoField(True, True, False, 'ID')), ('action', models.AutoField(True, True, False, 'ID', verbose_name='50')), ('adminLog_field_action', models.max_length, 'targets', 'verbose_name'), ('TextField', models.max_length, 'targets', 'verbose_name'), ('adminLog_field_objects', models.max_length, 'blank', 'null', 'verbose_name'), ('null', 'targets_repr', 'verbose_name'), ('', 'default', 'verbose_name'), ('action_status', models.SmallIntegerField(True, True, False, 'verbose_name')), ('SmallIntegerField', True, True, True), ('adminLog_field_objects', models.max_length, 'blank', 'null', 'targets_repr', 'verbose_name'), ('', True, True, '