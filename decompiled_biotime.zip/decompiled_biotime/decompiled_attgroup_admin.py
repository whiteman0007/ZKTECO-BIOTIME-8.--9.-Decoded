# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\attgroup_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.conf import settings
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite import config
from mysite import admin
from mysite.admin import forms
from mysite.att.actions import SetGroup
from mysite.att.models import AttGroup
from mysite.att.company_form import CompanyField4ModelForm, CompanyField4ModelChangeForm
class AttGroupCreationForm(CompanyField4ModelForm):
    def __init__(self, *args, **kwargs):
        super(AttGroupCreationForm, self).__init__(*args, **kwargs)
        try:
            objs = AttGroup.objects.values('code')
            codes = [int(i['code']) for i in objs if i['code'].isdigit()]
            self.fields['code'].initial = str(max(codes) + 1 if codes else 1)
        except Exception:
            return None
    class Meta:
        models = AttGroup
        fields = ('company', 'code', 'name')
class AttGroupChangeForm(CompanyField4ModelChangeForm):
    class Meta:
        models = AttGroup
        fields = ('code', 'name')
@admin.register(AttGroup)
class AttGroupAdmin(admin.ZKModelAdmin):
    list_display = ('code', 'name', 'employee_quantity') + config.WDMS_LIST_DISPLAY
    actions = [SetGroup]
    list_filter = ('code', 'name') + config.WDMS_LIST_FILTER
    add_form = AttGroupCreationForm
    form = AttGroupChangeForm
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(AttGroupAdmin, self).get_form(request, obj, **defaults)
    def get_queryset(self, request):
        qs = super(AttGroupAdmin, self).get_queryset(request)
        if request.user.is_employee:
            return qs.filter(company=request.user.company)
        else:
            if not request.user.is_superuser and request.user.assign_company:
                    qs = qs.filter(company_id=request.user.assign_company)
            return qs
    @staticmethod
    def initial_data():
        if AttGroup.objects.all().count() == 0:
            AttGroup(code=1, name='default').save()