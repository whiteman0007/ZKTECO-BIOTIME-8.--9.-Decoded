# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff\\admin\\approval_training_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:31 UTC (1750673071)

from mysite import admin, config
from mysite.att.actions import Approve, Reject
from mysite.staff.models import ApprovalTraining
from mysite.utils import get_staff_workflow_instance
from django.utils.translation import gettext_lazy as _
@admin.register(ApprovalTraining)
class ApprovalTrainingAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'emp_code', 'first_name', 'last_name', 'department', 'position', 'emp_photo', 'pay_code', 'start_time', 'end_time', 'apply_reason', 'apply_time', 'attachment_url', 'approval_status', 'approval_remark', 'approval_time', 'last_approver')
    list_filter = config.EMPLOYEE_LIST_FILTER + ('pay_code__code', 'pay_code__name', 'start_time', 'end_time', 'approval_status')
    hidden_fields = ('last_name', 'emp_photo', 'attachment_url')
    non_display_fields = ('color',)
    actions = [Approve, Reject]
    ordering = ('-id',)
    def attachment_url(self, obj):
        if obj.attachment:
            return '/files/' + str(obj.attachment)
        else:
            return ''
    attachment_url.short_description = _('common_field_attachment')
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        queryset = super(ApprovalTrainingAdmin, self).get_queryset(request)
        queryset = get_staff_workflow_instance(request, queryset)
        return queryset