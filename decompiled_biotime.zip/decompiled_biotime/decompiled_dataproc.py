# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\iclock\\dataproc.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:36 UTC (1750673016)

import base64
import datetime
import os
from PIL import Image
from django.apps import apps
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.cache import cache
from django.utils.translation import gettext_lazy as _
from mysite.core.zkcmdproc import *
from mysite.acc.models import InterLock, FirstOpen_emp, acc_employee, combopen_comb, AccDoor, zone, timezones, level_emp, level_door, AntiPassBack, FirstOpen, linkage, linkage_trigger, linkage_inout, level, combopen_door, IclockZone, combopen_emp
from mysite.api.views import delete_data
from mysite.base.models import get_param_value
from mysite.iclock.datasproc import deleteCalcLog
from mysite.iclock.iutils import fieldVerboseName, getDeviceListByDept, getDeviceByZone, getAllAuthChildDept
from mysite.iclock.models import forgetcause, DeptAdmin, UserAdmin, USER_SPEDAY, iclock, getDevice, sendRecCMD, department, IclockDept, UpdateDeptCache, adsetting, empofdevice, BioData, SchClass, days_off, checkexact, transactions, userRoles, userRole, createThumbnail, Admachine, employee
from mysite.ipos.models import Dininghall, IclockDininghall, ICcard, IssueCard, CARD_VALID, CARD_LOST, Merchandise, StoreDetail, Allowance, KeyValue, KeyValuemechine, CARD_INVALID, CARD_INACTIVE
from mysite.meeting.models import Meet_details, Meet, MeetLocation, meet_devices
from mysite.utils import customSql, delEmpInDevice, trunc, getJSResponse, getStoredFileName, saveCmd
def batchOp(request, dataModel, func):
    if request.method == 'POST':
        keys = request.POST.getlist('K')
    else:
        keys = request.GET.getlist('K')
    info = []
    ret = None
    t1 = datetime.datetime.now()
    try:
        for i in keys:
            if dataModel == USER_SPEDAY:
                u = USER_SPEDAY.objects.filter(id=int(i))[0]
                deleteCalcLog(UserID=int(u.UserID_id), StartDate=u.StartSpecDay, EndDate=u.EndSpecDay)
            d = dataModel.objects.in_bulk([i])
            dev = d[list(d.keys())[0]]
            ret = func(dev)
        if '%s' % ret == ret:
            info.append(ret)
    except:
        pass
    if len(keys) < 3 and dataModel == iclock:
            for i in keys:
                dev = getDevice(i)
                sendRecCMD(dev)
    t1 = datetime.datetime.now() - t1
    if len(info) > 0:
        return ',\n'.join(['%s' % f for f in info])
    else:
        return ret
dict_del_table = {str(employee): ['fptemp'], str(iclock): []}
def delData(request, dataModel):
    if request.method == 'POST':
        keys = request.POST.getlist('K')
    else:
        keys = request.GET.getlist('K')
    User = get_user_model()
    if dataModel == InterLock:
        objs = InterLock.objects.filter(id__in=keys)
        for t in objs:
            clear_interlock([t.device_id])
    if dataModel == FirstOpen_emp:
        emps = FirstOpen_emp.objects.filter(pk__in=keys)
        try:
            deleteFirstCardEmpfromAcc(objs, emps)
        except Exception as e:
            print(('4444444444', e))
    if dataModel == combopen_emp:
        from mysite.acc.accviews import sync_multiPerson
        emps = combopen_emp.objects.filter(id__in=keys).values('UserID')
        morecard_group = combopen_emp.objects.filter(id__in=keys).distinct().values('combopen')
        acc_employee.objects.filter(UserID__in=emps).update(morecard_group=None)
        doors = combopen_comb.objects.filter(combopen=morecard_group).distinct().values_list('combopen_door__door', flat=True)
        snlist = list(AccDoor.objects.filter(id__in=doors).distinct().values_list('device_id', flat=True))
        sync_multiPerson(snlist)
    if dataModel == forgetcause and keys:
            keys = keys[0].split(',')
            dataModel.objects.filter(id__in=keys).delete()
    if dataModel == User:
        dataModel.objects.filter(id__in=keys).exclude(id=request.user.id).exclude(username='employee').update(DelTag=1)
        DeptAdmin.objects.filter(user__in=keys).exclude(user=request.user).delete()
        UserAdmin.objects.filter(owned__in=keys).delete()
        sql = 'delete from auth_user_groups where myuser_id in (%s)' % ','.join(keys)
        try:
            customSql(sql)
        except Exception as e:
            raise e
    else:
        if dataModel == Group:
            for i in keys:
                pass
        else:
            if dataModel == Meet_details:
                from mysite.meeting.views import delete_meet_pers
                objs = dataModel.objects.filter(pk__in=keys)
                delete_meet_pers(objs)
                dataModel.objects.filter(pk__in=keys).delete()
            else:
                if dataModel == department:
                    if '1' in keys:
                        raise Exception('%s' % 'The root department is not allowed to delete, you can modify the number and name')
                    else:
                        if dataModel.objects.filter(parent__in=keys).exclude(DelTag=1).count() > 0:
                            raise Exception('%s' % 'The selected department exists in the lower department and is not allowed to delete')
                        else:
                            if employee.objects.filter(DeptID__in=keys).exclude(DelTag=1).count() > 0:
                                raise Exception('%s' % 'The selected department exists and people are not allowed to delete')
                            else:
                                IclockDept.objects.filter(dept__in=keys).delete()
                                DeptAdmin.objects.filter(dept__in=keys).delete()
                                dataModel.objects.filter(pk__in=keys).exclude(pk=1).update(DelTag=1)
                                UpdateDeptCache()
                else:
                    if dataModel == Dininghall:
                        if '1' in keys:
                            raise Exception('%s' % 'Root restaurant is not allowed to delete, you can modify the name')
                        else:
                            if IclockDininghall.objects.filter(dining__in=keys).exclude(SN__DelTag=1).count() > 0:
                                raise Exception('%s' % 'The selected restaurant exists and the device is not allowed to delete')
                            else:
                                dataModel.objects.filter(pk__in=keys).exclude(pk=1).delete()
                    else:
                        if dataModel == ICcard:
                            if '1' in keys:
                                raise Exception('%s' % 'System card class is not allowed to be deleted, information can be modified')
                            else:
                                isscardobj = IssueCard.objects.filter(itype__in=keys, cardstatus__in=[CARD_VALID, CARD_LOST])
                                if isscardobj:
                                    raise Exception('%s' % 'The selected card class is in use and is not allowed to be deleted')
                                else:
                                    dataModel.objects.filter(pk__in=keys).exclude(pk=1).update(DelTag=1)
                        else:
                            if dataModel == Merchandise:
                                code_list = dataModel.objects.filter(id__in=keys).values_list('code', flat=True)
                                for c in code_list:
                                    if StoreDetail.objects.filter(store_code=c):
                                        dataModel.objects.filter(code=c).update(DelTag=1)
                                    else:
                                        dataModel.objects.filter(code=c).delete()
                            else:
                                if dataModel == Allowance:
                                    ts = dataModel.objects.filter(pk__in=keys)
                                    if ts:
                                        for t in ts:
                                            if t.is_pass == 1:
                                                raise Exception('%s' % 'The subsidy has been approved and is not allowed to be deleted')
                                    dataModel.objects.filter(pk__in=keys).delete()
                                else:
                                    if dataModel == Merchandise:
                                        from mysite.core.zkcmdproc import delete_pos_device_info
                                        devset = iclock.objects.filter(ProductType__in=[11, 12, 13]).exclude(DelTag=1)
                                        datalist = dataModel.objects.filter(pk__in=keys)
                                        op = ''
                                        tablename = 'STOREINFO'
                                        delete_pos_device_info(devset, datalist, op, tablename)
                                        dataModel.objects.filter(pk__in=keys).update(DelTag=1)
                                    else:
                                        if dataModel == KeyValue:
                                            from mysite.core.zkcmdproc import delete_pos_device_info
                                            ts = KeyValuemechine.objects.filter(keyvalue__in=keys)
                                            if ts:
                                                devset = []
                                                for t in ts:
                                                    devset.append(t.SN)
                                            else:
                                                devset = iclock.objects.filter(ProductType__in=[11, 12, 13]).exclude(DelTag=1)
                                            datalist = dataModel.objects.filter(pk__in=keys)
                                            op = ''
                                            tablename = 'PRESSKEY'
                                            delete_pos_device_info(devset, datalist, op, tablename)
                                            dataModel.objects.filter(pk__in=keys).update(DelTag=1)
                                            KeyValuemechine.objects.filter(keyvalue__in=keys).delete()
                                        else:
                                            if dataModel == zone:
                                                if '1' in keys:
                                                    raise Exception('%s' % 'The root zone is not allowed to be deleted, you can modify the number and name')
                                                else:
                                                    if dataModel.objects.filter(parent__in=keys).exclude(DelTag=1).count() > 0:
                                                        raise Exception('%s' % 'The selected area exists in the subordinate area and is not allowed to be deleted')
                                                    else:
                                                        dataModel.objects.filter(id__in=keys).update(DelTag=1)
                                            else:
                                                if dataModel == timezones:
                                                    if '1' in keys:
                                                        raise Exception('%s' % 'The initial time period is not allowed to be deleted and can be modified')
                                                    else:
                                                        dataModel.objects.filter(pk__in=keys).exclude(pk=1).update(DelTag=1)
                                                else:
                                                    if dataModel == level_emp:
                                                        Levels = list(level_emp.objects.filter(pk__in=keys).distinct().values_list('level', flat=True))
                                                        level_emps = level_emp.objects.filter(pk__in=keys)
                                                        empss = list(level_emps.values_list('UserID', flat=True))
                                                        emps = employee.objects.filter(id__in=empss)
                                                        doors = level_door.objects.filter(level__in=Levels).values('door')
                                                        devs = AccDoor.objects.filter(id__in=doors).distinct().values_list('device', flat=True)
                                                        level_emps.delete()
                                                        try:
                                                            zk_send_acc_data(emps, devs)
                                                        except Exception as e:
                                                            print(('level_emp4444444444', e))
                                                    else:
                                                        if dataModel == AntiPassBack:
                                                            objs = AntiPassBack.objects.filter(pk__in=keys)
                                                            for obj in objs:
                                                                clear_antipassback(obj.device.SN)
                                                            objs.delete()
                                                        else:
                                                            if dataModel == FirstOpen:
                                                                FirstOpen_emp.objects.filter(firstopen__in=keys).delete()
                                                                sendFirstCardToAcc(keys)
                                                                FirstOpen.objects.filter(id__in=keys).delete()
                                                            else:
                                                                if dataModel == linkage:
                                                                    objs = linkage.objects.filter(pk__in=keys)
                                                                    for link in objs:
                                                                        SN = link.device_id
                                                                        trig_objs = linkage_trigger.objects.filter(linkage=link)
                                                                        del_linkage_trig(SN, trig_objs)
                                                                        trig_objs.delete()
                                                                        linkage_inout.objects.filter(linkage=link).delete()
                                                                    objs.delete()
                                                                else:
                                                                    if dataModel == level:
                                                                        Levels = keys
                                                                        emps = level_emp.objects.filter(level__in=keys).values('UserID')
                                                                        emps = employee.objects.filter(id__in=emps)
                                                                        try:
                                                                            deleteEmpfromAcc(Levels, emps, [], (-1))
                                                                        except Exception as e:
                                                                            print(('4444444444', e))
                                                                        level_door.objects.filter(level__in=keys).delete()
                                                                        level_emp.objects.filter(level__in=keys).delete()
                                                                        level.objects.filter(pk__in=keys).delete()
                                                                        levels = list(level_emp.objects.filter(UserID__in=emps).values_list('level', flat=True))
                                                                    else:
                                                                        if dataModel == combopen_door:
                                                                            objs = combopen_door.objects.filter(id__in=keys)
                                                                            clear_multimcard(objs)
                                                                            combopen_comb.objects.filter(combopen_door__in=keys).delete()
                                                                            objs.delete()
                                                                        else:
                                                                            if dataModel == adsetting:
                                                                                objs = adsetting.objects.filter(id__in=keys)
                                                                                for obj in objs:
                                                                                    deleteAdData(obj.id)
                                                                                objs.delete()
                                                                            else:
                                                                                if dataModel == Meet:
                                                                                    objs = Meet.objects.filter(id__in=keys)
                                                                                    for obj in objs:
                                                                                        deleteMeetData(obj)
                                                                                    objs.delete()
                                                                                else:
                                                                                    if fieldVerboseName(dataModel, 'del_flag'):
                                                                                        if settings.DEMO == 1 and request.user.DelTag!= (-2):
                                                                                            raise Exception(str('The demo system does not allow deletion'))
                                                                                        else:
                                                                                            if dataModel == MeetLocation:
                                                                                                now = datetime.datetime(datetime.datetime.today().year, datetime.datetime.today().month, datetime.datetime.today().day, 0, 0, 0)
                                                                                                if Meet.objects.filter(LocationID__pk__in=keys).exclude(Endtime__lt=now).count() > 0:
                                                                                                    raise Exception(str('The conference room is in an occupied state and cannot be deleted'))
                                                                                            if dataModel == iclock:
                                                                                                for sn in keys:
                                                                                                    IclockDininghall.objects.filter(SN__exact=sn).delete()
                                                                                                    IclockDept.objects.filter(SN=sn).delete()
                                                                                                    IclockZone.objects.filter(SN=sn).delete()
                                                                                                    doorids = AccDoor.objects.filter(device=sn).values_list('pk', flat=True)
                                                                                                    objs = linkage.objects.filter(device=sn)
                                                                                                    for link in objs:
                                                                                                        SN = link.device_id
                                                                                                        trig_objs = linkage_trigger.objects.filter(linkage=link)
                                                                                                        del_linkage_trig(SN, trig_objs)
                                                                                                        trig_objs.delete()
                                                                                                        linkage_inout.objects.filter(linkage=link).delete()
                                                                                                    objs.delete()
                                                                                                    InterLocks = InterLock.objects.filter(device=sn)
                                                                                                    AntiPassBacks = AntiPassBack.objects.filter(device=sn)
                                                                                                    for obj in AntiPassBacks:
                                                                                                        clear_antipassback(obj.device.SN)
                                                                                                    AntiPassBacks.delete()
                                                                                                    for t in InterLocks:
                                                                                                        clear_interlock([t.device_id])
                                                                                                    level_door.objects.filter(door__pk__in=doorids).delete()
                                                                                                    empofdevice.objects.filter(SN=sn).delete()
                                                                                                    meet_devices.objects.filter(SN__SN=sn).delete()
                                                                                                    device = getDevice(sn)
                                                                                                    device.Alias = ''
                                                                                                    device.IPAddress = None
                                                                                                    device.Style = None
                                                                                                    device.MaxAttLogCount = None
                                                                                                    device.State = 1
                                                                                                    device.pushver = ''
                                                                                                    device.ProductType = None
                                                                                                    device.save()
                                                                                            if dataModel == employee:
                                                                                                issuecards = IssueCard.objects.filter(UserID_id__in=keys, cardstatus__in=[CARD_VALID, CARD_LOST])
                                                                                                cardblance_zero = True
                                                                                                for i in issuecards:
                                                                                                    if i.blance > 0 or i.allow_balance > 0:
                                                                                                        cardblance_zero = False
                                                                                                        break
                                                                                                if not cardblance_zero:
                                                                                                    raise Exception(str('In the selected person, the card account has a balance, and the deletion fails.'))
                                                                                                else:
                                                                                                    settings.CARDTYPE = int(get_param_value('ipos_cardtype', 1, 'ipos'))
                                                                                                    emps = dataModel.objects.filter(pk__in=keys)
                                                                                                    iclocks = iclock.objects.filter(ProductType__in=[5, 15, 25]).exclude(DelTag=1)
                                                                                                    dataModel.objects.filter(pk__in=keys).update(OpStamp=datetime.datetime.now())
                                                                                                    for t in emps:
                                                                                                        delEmpInDevice(t.PIN, (-1))
                                                                                                        t.delpic()
                                                                                                        for dev in iclocks:
                                                                                                            delete_data(dev.SN, 'user', 'Pin=%s' % t.pin())
                                                                                                        try:
                                                                                                            objcard = IssueCard.objects.get(UserID_id=t.id, cardstatus__in=[CARD_VALID, CARD_LOST])
                                                                                                        except:
                                                                                                            objcard = None
                                                                                                        if objcard:
                                                                                                            objcard.cardstatus = CARD_INVALID
                                                                                                            objcard.save()
                                                                                                            if settings.CARDTYPE == 2:
                                                                                                                iposdevs = iclock.objects.filter(ProductType__in=[11, 12, 13]).exclude(DelTag=1)
                                                                                                                update_pos_device_info(iposdevs, [objcard], 'USERINFO')
                                                                                                        try:
                                                                                                            inactive_card = IssueCard.objects.get(UserID_id=t.id, cardstatus=CARD_INACTIVE)
                                                                                                        except:
                                                                                                            inactive_card = None
                                                                                                        if inactive_card:
                                                                                                            inactive_card.cardstatus = CARD_INVALID
                                                                                                            inactive_card.save()
                                                                                                        cache.delete('%s_iclock_emp_PIN_%s' % (settings.UNIT, t.PIN))
                                                                                                        cache.delete('%s_iclock_emp_%s' % (settings.UNIT, t.id))
                                                                                                    combopen_emp.objects.filter(UserID__in=emps).delete()
                                                                                                    BioData.objects.filter(UserID__in=emps).delete()
                                                                                                    dataModel.objects.filter(pk__in=keys).update(OpStamp=datetime.datetime.now(), EName='', Card='', Password='', Privilege=0)
                                                                                                    cache.set('emp_change_flag', 1)
                                                                                            if dataModel == SchClass:
                                                                                                sch = dataModel.objects.filter(pk__in=keys)
                                                                                                for s in sch:
                                                                                                    cache.delete('%s_iclock_schclass_%s' % (settings.UNIT, s.SchclassID))
                                                                                                cache.delete('%s_schclasses' % settings.UNIT)
                                                                                            dataModel.objects.filter(pk__in=keys).update(DelTag=1)
                                                                                    else:
                                                                                        rows = dataModel.objects.filter(pk__in=keys)
                                                                                        if dataModel == USER_SPEDAY:
                                                                                            for row in rows:
                                                                                                deleteCalcLog(UserID=row.UserID_id, StartDate=row.StartSpecDay, EndDate=row.EndSpecDay)
                                                                                            from mysite.iclock.fileprocess import del_spedy_file
                                                                                            del_spedy_file(keys)
                                                                                        else:
                                                                                            if dataModel == days_off:
                                                                                                for row in rows:
                                                                                                    deleteCalcLog(UserID=row.UserID, StartDate=row.FromDate, EndDate=row.ToDate)
                                                                                            else:
                                                                                                if dataModel == checkexact:
                                                                                                    for row in rows:
                                                                                                        transactions.objects.filter(UserID=row.UserID, TTime=row.CHECKTIME, Verify=5).delete()
                                                                                                else:
                                                                                                    if dataModel == userRoles:
                                                                                                        ids = []
                                                                                                        for row in rows:
                                                                                                            if userRole.objects.filter(roleid__roleid=row.roleid).count() > 0 or employee.objects.filter(Title=row.roleName).count() > 0:
                                                                                                                ids.append(row.roleid)
                                                                                                            else:
                                                                                                                row.delete()
                                                                                                        if ids:
                                                                                                            names = userRoles.objects.filter(roleid__in=ids).values_list('roleName', flat=True)
                                                                                                            raise Exception(str('The job %s is in use cannot be deleted and the remaining jobs have been deleted') % ','.join(names))
                                                                                        dataModel.objects.filter(pk__in=keys).delete()
        if settings.DEMO == 1:
            obj = Group.objects.get(id=i)
            if obj.name in ['zkteco1224']:
                raise Exception('%s' % 'The administrative group being used is not allowed to delete')
        sql = 'select count(*) from auth_user_groups where group_id=%s' % i
        cs = customSql(sql, action=False)
        c = cs.fetchone()[0]
        if c == 0:
            dataModel.objects.all().filter(pk=i).delete()
        else:
            raise Exception('%s' % 'The administrative group being used is not allowed to delete')
def empLeave(emp):
    emp.OffDuty = 1
    emp.OpStamp = datetime.datetime.now()
    emp.save()
    cache.set('emp_change_flag', 1)
def changeEmpDept(dept, emp):
    sns = getDeviceListByDept(emp.DeptID_id)
    for sn in sns:
        device = getDevice(sn)
        zk_delete_data(device, emp.pin(), 'user')
    emp.DeptID = dept
    emp.OpStamp = datetime.datetime.now()
    emp.save()
    cache.set('emp_change_flag', 1)
def restoreEmpLeave(emp):
    emp.OffDuty = 0
    emp.OpStamp = datetime.datetime.now()
    emp.Hiredday = trunc(datetime.datetime.now())
    emp.save()
    cache.set('emp_change_flag', 1)
def setBlack(emp):
    emp.Employeetype = 12
    emp.OpStamp = datetime.datetime.now()
    emp.save()
    cache.set('emp_change_flag', 1)
def restoreEmpBlack(emp):
    emp.Employeetype = None
    emp.OpStamp = datetime.datetime.now()
    emp.save()
    cache.set('emp_change_flag', 1)
def deleteEmpFromDeviceByZone(emp, City):
    if not City:
        return
    else:
        if get_param_value('opt_basic_att_zone', '0')!= '1':
            return
        else:
            sns = getDeviceByZone(City)
            for sn in sns:
                device = getDevice(sn)
                zk_delete_data(device, emp.PIN, 'user')
def moveEmpToDev(devs, emp, cursor=None):
    appendEmpToDevNew(devs, emp, cursor)
def del_by_fk(dataModel, pk, app_label='iclock'):
    table_fk = []
    datas = dataModel.objects.all()
    if datas:
        for row in dir(datas[0]):
            r = str(row)
            if r.endswith('_set'):
                table_fk.append(r[:(-4)])
    if str(dataModel) in dict_del_table:
        for row in dict_del_table[str(dataModel)]:
            if row in table_fk:
                table_fk.remove(row)
    for row_table in table_fk:
        to_field = dataModel._meta.pk.name
        model_fk = apps.get_model(app_label, row_table)
        fields = model_fk._meta.fields
        for row_field in fields:
            try:
                if 'ForeignKey' in str(type(row_field)) and to_field == row_field.name:
                        rs = eval('model_fk.objects.all().filter(' + to_field + '=pk)')
                        rs = len(rs)
                        for row_rs in rs:
                            setattr(row_rs, to_field, None)
                            row_rs.save()
            except:
                continue
def staAData(dObj, state):
    if dObj.State!= state:
        dObj.State = state
        dObj.save()
        if dObj.ProductType in [15]:
            cache.set(settings.UNIT + '_restart_pull', 1)
def staData(request, dataModel, state):
    batchOp(request, dataModel, lambda d: staAData(d, state))
def saveEmpComverify(request):
    isContainedChild = request.POST.get('isContainChild', '0')
    deptIDs = request.POST.get('deptIDs', '')
    userIDs = request.POST.get('UserIDs', '')
    comverify = request.POST.get('comverify', '')
    ids = []
    if len(userIDs) > 0 and userIDs!= 'null':
        empids = userIDs.split(',')
    else:
        if len(deptIDs) > 0:
            deptidlist = deptIDs.split(',')
            deptids = deptidlist
            if isContainedChild == '1':
                deptids = []
                for d in deptidlist:
                    if int(d) not in deptids:
                        deptids += getAllAuthChildDept(d, request)
            empids = employee.objects.filter(DeptID__in=deptids, OffDuty__lt=1).exclude(DelTag=1).values_list('id', flat=True)
    for empid in empids:
        emp = employee.objects.get(id=empid)
        if comverify == '':
            emp.VERIFICATIONMETHOD = None
        else:
            emp.VERIFICATIONMETHOD = comverify
        emp.OpStamp = datetime.datetime.now()
        emp.save()
    return getJSResponse({'ret': 0, 'message': '%s' % 'Save Success'})
def saveFingerData(request, emp):
    # irreducible cflow, using cdg fallback
    import json
    if not emp:
        return
    delfinger = request.POST.get('delfinger', '').split(',')
    fingers = request.POST.get('finnger10', '').split(',')
    templates = request.POST.get('template10', '').split(',')
    fptype = request.POST.get('fptype', '')
    fvids = request.POST.get('fvs', '')
    delfv = request.POST.get('delfv', '').split(',')
    fptemplates = request.POST.get('fptemplate', '').split(',')
    fvtemplates = request.POST.get('fvtemplate', '').split(',')
    img64 = request.POST.get('identity_img', '')
    if img64:
        img64 = img64.replace('\n', '').replace('\r', '').replace(' ', '')
        try:
            imgData = base64.decodestring(img64)
            pdir = settings.ADDITION_FILE_ROOT + 'photo\\' + emp.SSN + '.jpg'
            if os.path.exists(pdir):
                os.remove(pdir)
            imgsave = open(pdir, 'wb')
            imgsave.write(memoryview(imgData))
            imgsave.close()
        except Exception as e:
            print(e)
    from mysite.iclock.datamisc import saveUploadImage
    f = request.FILES.get('up_img', None)
    if f:
        pin = '%s.%s' % (emp.PIN, f.name.split('.')[1])
        fname = '%s%s/%s' % (settings.ADDITION_FILE_ROOT, 'photo', pin)
        saveUploadImage(request, 'up_img', fname)
        tbName = getStoredFileName('photo/thumbnail', None, pin)
        if os.path.exists(tbName):
            fullName = getStoredFileName('photo', None, pin)
            if os.path.exists(fullName):
                createThumbnail(fullName, tbName)
    if len(delfinger) > 0:
        for df in delfinger:
            if not df:
                continue
            else:
                t = BioData.objects.filter(UserID=emp, bio_type=1, bio_no=df, majorver='10')
                t.delete()
    if len(delfv) > 0:
        for df in delfv:
            if not df:
                continue
            else:
                t = BioData.objects.filter(UserID=emp, bio_type=7, bio_no=df, majorver='3')
                t.delete()
    fing_len = len(fingers)
    if fing_len > 1 or (fing_len == 1 and fingers[0]):
        if fptype:
            fptype = fptype.split(',')
        else:
            fptype = ['1' for i in range(fing_len)]
        for i in range(fing_len):
            t = BioData.objects.filter(UserID=emp, bio_type=1, bio_no=fingers[i], majorver='10')
            if not t:
                t = BioData()
            else:
                t = t[0]
            t.UserID = emp
            t.bio_type = 1
            t.bio_no = fingers[i]
            t.bio_tmp = templates[i]
            t.duress = fptype[i]
            t.majorver = '10'
            t.UTime = datetime.datetime.now()
            t.save()
    fv_len = len(fvids)
    if fv_len > 1 or (fv_len == 1 and fvids[0]):
                for i in range(fv_len):
                    try:
                        fv_tmpstr = ''
                        fv_tmp = fvtemplates[i]
                        fvs = fv_tmp.split('&')
                        fv_tmps = {}
                        for index, val in enumerate(fvs, 0):
                            if val:
                                fv_tmps[str(index)] = val
                        fv_tmps['9'] = fptemplates[i]
                        fv_tmpstr = json.dumps(fv_tmps)
                        print(('fv_tmpstr=', fv_tmpstr))
                    except:
                        print('fv_tmpstr compila fail.')
                        continue
                    t = BioData.objects.filter(UserID=emp, bio_type=7, bio_no=fvids[i], majorver='3')
                    if not t:
                        t = BioData()
                    else:
                        t = t[0]
                    t.UserID = emp
                    t.bio_type = 7
                    t.bio_no = fvids[i]
                    t.bio_tmp = fv_tmpstr
                    t.duress = '1'
                    t.majorver = '3'
                    t.UTime = datetime.datetime.now()
                    t.save()
def deleteMeetData(obj):
    cmdStr = 'DATA DELETE MEETINFO Code=%s' % obj.MeetID
    pers_meet = 'DATA DELETE PERSMEET Code=%s' % obj.MeetID
    mdevs = meet_devices.objects.filter(LocationID=obj.LocationID)
    for mdev in mdevs:
        if mdev.SN.ProductType == 8:
            saveCmd(mdev.SN.SN, cmdStr)
            saveCmd(mdev.SN.SN, pers_meet)
def saveMeetData(request, meet):
    try:
        from mysite.meeting.views import FormatTime
        cmdStr = 'DATA UPDATE MEETINFO MetName=%s	MetStarSignTm=%s	MetLatSignTm=%s	EarRetTm=%s	LatRetTm=%s	Code=%s	MetStrTm=%s	MetEndTm=%s' % (meet.conferenceTitle, FormatTime(meet.Enrolmenttime), FormatTime(meet.LastEnrolmenttime), FormatTime(meet.EarlySignOfftime), FormatTime(meet.LastSignOfftime), meet.MeetID, FormatTime(meet.Starttime), FormatTime(meet.Endtime))
        mdevs = meet_devices.objects.filter(LocationID=meet.LocationID)
        for mdev in mdevs:
            if mdev.SN.ProductType == 8:
                saveCmd(mdev.SN.SN, cmdStr)
    except Exception as e:
        print(e)
def deleteAdData(code):
    print(('deleteAdData=', code))
    adobjs = Admachine.objects.filter(ad__id=code)
    for adobj in adobjs:
        if adobj.ad.adfile and adobj.SN.ProductType == 8:
                cmdStr = 'DelAdvFile Type=%d\tFileName=%s' % (adobj.ad.adtype, adobj.ad.adfile)
                saveCmd(adobj.SN.SN, cmdStr)
def saveAdData(request, adobj):
    use_machine = request.POST.get('use_machine', '')
    code = request.POST.get('adcode', '')
    if adobj.adtype == 1:
        reqfile = request.FILES.get('picfile', None)
        print((reqfile, settings.ADDITION_FILE_ROOT))
        if reqfile:
            try:
                img = Image.open(reqfile)
                adpath = settings.ADDITION_FILE_ROOT + 'ad'
                if not os.path.exists(adpath):
                    os.makedirs(adpath)
                tbName = settings.ADDITION_FILE_ROOT + 'ad/' + reqfile.name
                img.save(tbName)
                adobj.adfile = reqfile.name
                adobj.save()
            except Exception as e:
                print(e)
    else:
        if adobj.adtype == 2:
            reqfile = request.FILES.get('vediofile', None)
            if reqfile:
                adobj.adfile = reqfile.name
                adobj.save()
    if use_machine:
        use_machine = request.POST.get('use_machine', '').split(',')
        Admachine.objects.filter(ad__adcode=code).delete()
        adobj = adsetting.objects.get(adcode=code)
        for t in use_machine:
            dev = getDevice(t)
            Admachine(ad=adobj, SN=dev).save()
            adurl = adobj.get_adfile_URL()
            if adurl and dev.ProductType == 8:
                    cmdStr = 'PutAdvFile Type=%d\tUrl=%s' % (adobj.adtype, adurl)
                    saveCmd(dev.SN, cmdStr)
    else:
        Admachine.objects.filter(ad__adcode=code).delete()
def getadpic():
    photopath = settings.FILEPATH + '\\files\\photo\\'
    adlist = [x.replace('ad_', '').replace('.jpg', '') for x in os.listdir(photopath) if 'ad_' in x]
    emplist = employee.objects.filter(OffDuty__lt=1).exclude(DelTag=1).values_list('PIN')
    elist = []
    for emp in emplist:
        if emp[0] in adlist:
            elist.append(emp[0])
    return len(elist)
def get_empsuminfo(request):
    result = {}
    result['empcount'] = employee.objects.filter(OffDuty__lt=1).exclude(DelTag=1).count()
    result['fpcount'] = BioData.objects.filter(bio_type=1).count()
    result['fccount'] = BioData.objects.filter(bio_type=2).count()
    result['fvcount'] = BioData.objects.filter(bio_type=7).count()
    result['adcount'] = getadpic()
    result['cardcount'] = employee.objects.exclude(Card=None).exclude(Card='').count()
    return getJSResponse(result)