# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\forms\\attRule_userGuid_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import calendar
import datetime
from django.core.exceptions import ValidationError
from django.forms import ModelMultipleChoiceField
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att import models_const
from mysite.att.models import AttShift, AttSchedule, AttEmployee
from mysite.personnel.models import Employee
class AttRuleUserGuidForm(forms.ZKActionForm):
    """\n\n    """
    @property
    def template_url(self):
        return 'att/userGuide/attRuleGuid_page.html'
    @property
    def template_url2(self):
        return 'att/userGuide/att_quick_set.html'
    in_time = forms.TimeField(label=_('att_rule_guide_setting_inTime'), initial=models_const.IN_TIME, required=True)
    out_time = forms.TimeField(label=_('att_rule_guide_setting_outTime'), initial=models_const.OUT_TIME, required=True)
    break_start = forms.TimeField(label=_('att_rule_guide_setting_breakStart'), required=False)
    break_end = forms.TimeField(label=_('att_rule_guide_setting_breakTo'), required=False)
    week_days = forms.CharField(label=_('att_rule_guid_setting_workdays'), initial='1;2;3;4;5', required=False)
    schedule_start = forms.DateField(label=_('att_rule_guide_setting_scheduleStart'), required=True)
    schedule_end = forms.DateField(label=_('att_rule_guide_setting_scheduleEnd'), required=True)
    group_by = forms.CharField(initial='emp', required=False)
    select_all = forms.BooleanField(initial=False, required=False)
    groups = forms.CharField(initial='', required=False)
    schd_employee = ModelMultipleChoiceField(queryset=Employee.objects.get_queryset(), required=False)
    shift = forms.ModelChoiceField(queryset=AttShift.objects.get_queryset(), required=False)
    schedule_cover = forms.BooleanField(initial=False, required=False)
    def clean(self):
        cleaned_data = super(AttRuleUserGuidForm, self).clean()
        if self.errors and len(self.errors) > 0:
            self.error_code = (-1)
            return cleaned_data
        else:
            self.error_code = (-2)
            if cleaned_data['break_start'] and cleaned_data['break_end'] and (cleaned_data['break_start'] >= cleaned_data['break_end']):
                raise ValidationError(_('att_rule_guide_breakStart_gte_breakEnd'), code='-1101')
            else:
                if cleaned_data['in_time'] >= cleaned_data['out_time']:
                    raise ValidationError(_('att_rule_guide_inTime_gte_outTime'), code='-1201')
                else:
                    start_date = cleaned_data.get('schedule_start', None)
                    end_date = cleaned_data.get('schedule_end', None)
                    employees = cleaned_data.get('schd_employee', None)
                    schedule_cover = cleaned_data.get('schedule_cover', None)
                    if not employees:
                        raise ValidationError(_('scheduledAssign_error_empNotFound'), code='-1401')
                    else:
                        if not start_date or not end_date:
                            raise ValidationError(_('scheduledAssign_error_datePeriodError'), code='-1402')
                        else:
                            if start_date >= end_date:
                                raise ValidationError(_('scheduledAssign_error_datePeriodError'), code='-1403')
                            else:
                                overlaps = AttSchedule.objects.filter(employee__in=employees, start_date__lte=end_date, end_date__gte=start_date)
                                if overlaps.exists():
                                    if schedule_cover:
                                        pass
                                    else:
                                        overlap = overlaps.first()
                                        raise ValidationError(_('scheduledAssign_error_schdOverlap_%(obj)s_%(start_date)s_%(end_date)s'), code='-1404', params={'obj': overlap.employee.first_name or overlap.employee.emp_code, 'start_date': overlap.start_date.strftime('%Y-%m-%d'), 'end_date': overlap.end_date.strftime('%Y-%m-%d')})
                                self.error_code = 0
                                return cleaned_data
    def clean_schd_employee(self):
        emps = self.cleaned_data.get('schd_employee', None)
        select_all = self.cleaned_data.get('select_all', None)
        if select_all:
            groups = self.cleaned_data.get('groups', '').strip()
            if not groups:
                emps = None
            else:
                groups = groups.split(',')
                group_by = self.cleaned_data.get('group_by', None)
                if group_by in ['dept']:
                    emps = Employee.objects.filter(department__in=groups)
                else:
                    if group_by in ['area']:
                        emps = Employee.objects.filter(area__in=groups)
                    else:
                        if group_by in ['group']:
                            emps = Employee.objects.filter(id__in=AttEmployee.objects.filter(group__in=groups).values_list('emp_id', flat=True))
                        else:
                            emps = None
        return emps
    def __init__(self, *args, **kwargs):
        super(AttRuleUserGuidForm, self).__init__(*args, **kwargs)
        now = datetime.datetime.now()
        self.fields['schedule_start'].initial = now.strftime('%Y-%m-01')
        this_month_start = datetime.datetime(now.year, now.month, 1)
        this_month_end = datetime.datetime(now.year, now.month, calendar.monthrange(now.year, now.month)[1])
        self.fields['schedule_end'].initial = this_month_end.strftime('%Y-%m-%d')