# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\workflow\\api\\serializers\\administrator_serializer.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:26 UTC (1750673126)

from django.contrib.auth import get_user_model
from rest_framework import serializers
from django.conf import settings
User = get_user_model()
class AdministratorSerializer(serializers.ModelSerializer):
    photo = serializers.SerializerMethodField()
    def get_photo(self, obj):
        if not obj.photo:
            return ''
        else:
            import os
            from mysite.tools.access_utils import get_access_token
            file_path = str(obj.photo.name)
            filename = os.path.basename(file_path)
            access_token = get_access_token({'n': filename, 'p': file_path})
            return '/files/{path}'.format(path=access_token)
    class Meta:
        model = User
        fields = ('id', 'first_name', 'photo', 'email')