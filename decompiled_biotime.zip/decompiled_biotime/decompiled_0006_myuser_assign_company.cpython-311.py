# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0006_myuser_assign_company.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:12 UTC (1750702692)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('accounts', '0005_auto_20210908_1006')]
    operations = [migrations.AddField(model_name='myuser', name='assign_company', field=models.IntegerField(blank=True, null=True))]