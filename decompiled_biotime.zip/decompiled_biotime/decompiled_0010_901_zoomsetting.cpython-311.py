# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0010_901_zoomsetting.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.db import migrations, models
import mysite.admin.fields
class Migration(migrations.Migration):
    dependencies = [('base', '0009_auto_20230411_1415')]
    operations = [migrations.CreateModel(name='ZoomSetting', fields=[('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('jwt_token', mysite.admin.fields.PasswordField(max_length=512, unique=True, verbose_name='zoomSetting.label.jwtToken')), ('zoom_user_email', models.EmailField(max_length=128, unique=True, verbose_name='zoomSetting.label.userEmail')), ('zoom_enable', models.BooleanField(default=True, verbose_name='zoomSetting.label.zoomEnable'))])]