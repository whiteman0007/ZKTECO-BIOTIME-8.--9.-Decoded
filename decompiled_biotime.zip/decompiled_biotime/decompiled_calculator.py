# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\views\\calculator.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:18 UTC (1750673058)

from django.template.response import TemplateResponse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from mysite.payroll.utils import check_formula
from mysite.att.models.model_paycode import PayCode, LEAVE, OVERTIME, EXCEPTION
@csrf_exempt
def calculator_view(request):
    if request.method == 'POST':
        check = request.POST.get('check', '')
        res, msg = check_formula(check)
        if not res:
            return JsonResponse({'code': (-1), 'msg': msg})
        else:
            return JsonResponse({'code': 0, 'msg': 'Success'})
    else:
        exception_pay_codes = PayCode.objects.filter(code_type=EXCEPTION).values('code', 'name')
        leave_pay_codes = PayCode.objects.filter(code_type=LEAVE).values('code', 'name')
        overtime_pay_codes = PayCode.objects.filter(code_type=OVERTIME).values('code', 'name')
        context = {'exception_pay_codes': exception_pay_codes, 'leave_pay_codes': leave_pay_codes, 'overtime_pay_codes': overtime_pay_codes}
        return TemplateResponse(request, 'payroll/calculator.html', context)