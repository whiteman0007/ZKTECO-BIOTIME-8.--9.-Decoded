# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\mobile\\api\\serializers\\manual_log_serializer.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from rest_framework import serializers
from mysite.att.models import ManualLog
from mysite.mobile.api import fields
from mysite.mobile.api.serializers import EmployeeSerializer
class ManualLogSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer()
    punch_stamp = fields.DateTimeField(source='punch_time')
    punch_desc = serializers.CharField(source='get_punch_state_display')
    apply_stamp = fields.DateTimeField(source='apply_time')
    approval_stamp = fields.DateTimeField(source='approval_time')
    approval_desc = serializers.CharField(source='get_approval_status_display')
    class Meta:
        model = ManualLog
        fields = ('id', 'employee', 'punch_stamp', 'punch_state', 'punch_desc', 'work_code', 'apply_reason', 'apply_stamp', 'approval_status', 'approval_desc', 'approver', 'approval_stamp', 'approval_remark')