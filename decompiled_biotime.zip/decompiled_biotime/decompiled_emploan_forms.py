# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\forms\\emploan_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from django.utils.translation import gettext_lazy as _
from django.forms import ValidationError
from mysite.admin.exceptions import AdminRuntimeWarning
from dateutil.relativedelta import relativedelta
import datetime
from mysite.admin import forms, ZKModelAction
from mysite.payroll import db_const as c
from mysite.payroll.models import EmpLoan
from mysite.personnel.widgets import MonthlyEmployeeManyToManyMiddleWidget
from mysite.utils import get_dt4mssql
class EmpLoanCreationForm(forms.ZKActionForm):
    employee = forms.EmployeeManyToManyField(label=_('model_employee'), required=False, widget=MonthlyEmployeeManyToManyMiddleWidget)
    loan_amount = forms.FloatField(label=_('empLoan_field_loanAmount'), required=True)
    loan_time = forms.DateTimeField(label=_('empLoan_field_loanTime'), required=True)
    refund_cycle = forms.ChoiceField(label=_('empLoan_field_refundCycle'), choices=c.REFUND_CYCLE, required=True)
    per_cycle_refund = forms.FloatField(label=_('empLoan_field_per_cycle_amount'), required=True)
    remark = forms.TextField(label=_('empLoan_field_remark'), max_length=c.MAX_LENTH_REMARK, required=False)
    def clean(self):
        cleand_data = super(EmpLoanCreationForm, self).clean()
        data_pre_check(cleand_data)
        return cleand_data
    def save(self, *args, **kwargs):
        from mysite.personnel.models import Employee
        emps = self.data.getlist('employee', None)
        if 'employee' in kwargs:
            kwargs.pop('employee')
        loan_date = kwargs.get('loan_time', None)
        refund_cycle = kwargs.get('refund_cycle', None)
        if loan_date and refund_cycle:
                loan_time = datetime.datetime.strptime(loan_date, '%Y-%m-%d %H:%M:%S')
                try:
                    clean_date = loan_time + relativedelta(months=+int(refund_cycle))
                    kwargs['loan_clean_time'] = clean_date
                except Exception as e:
                    print(('clean_date error', e))
                    import traceback
                    traceback.print_exc()
        if emps:
            messages = []
            for emp in emps:
                employee = Employee.objects.filter(id=emp).first()
                if isinstance(loan_date, str):
                    loan_date = datetime.datetime.strptime(loan_date, '%Y-%m-%d %H:%M:%S').date()
                if employee and get_dt4mssql(employee.hire_date, 1) > loan_date:
                        messages.append(_('leave_time_invalid_range_hiredate') % employee)
                        continue
                kwargs.update({'employee_id': emp})
                EmpLoan(**kwargs).save()
            if messages:
                raise AdminRuntimeWarning('.'.join(messages))
class AddEmpLoanAction(ZKModelAction):
    verbose_name = _('payroll_action_addEmpLoan')
    help_text = _('payroll_action_addEmpLoan')
    short_description = _('payroll_action_addEmpLoan')
    action_form = EmpLoanCreationForm
    def action(self, *args, **kwargs):
        emps = self.request.POST.getlist('employee')
        message = ''
        if emps:
            form = EmpLoanCreationForm(self.request.POST)
            form.save(self, *args, **kwargs)
        else:
            message = _('select_employee')
        if message:
            raise AdminRuntimeWarning(message)
def data_pre_check(data):
    loan_amount = data.get('loan_amount', 0)
    if loan_amount <= 0:
        raise ValidationError(_('the_amount_need_lager_than_zero'))