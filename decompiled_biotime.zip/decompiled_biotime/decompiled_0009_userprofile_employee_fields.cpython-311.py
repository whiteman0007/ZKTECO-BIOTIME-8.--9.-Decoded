# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0009_userprofile_employee_fields.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:12 UTC (1750702692)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('accounts', '0008_auto_20230223_1026')]
    operations = [migrations.AddField(model_name='userprofile', name='employee_fields', field=models.TextField(blank=True, default='', verbose_name='userProfile_field_employeeFields'))]