# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\deptpolicy_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import uuid
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.att.actions import AddDepartmentPolicy
from mysite.att.fields import PayCodeModelChoiceField
from mysite.att.models import DepartmentPolicy
from mysite.att.models_choices import OT_RULE, EMAIL_FREQUENCY, SENDING_DAY, SELECT_DAY, BOOLEANS
from django.conf import settings
class DepartmentPolicyChangeForm(ModelForm):
    use_ot = forms.ChoiceField(label=_('attRule_globalRule_overtimeRule'), choices=OT_RULE, initial=1)
    enable_compensatory = forms.BooleanField(label=_('globalRule.fields.enableCompensatory'), initial=False, required=False)
    max_hrs = forms.DecimalField(label=_('globalRule.fields.maxHrs'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d1_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d1_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d2_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d2_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d3_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d3_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w11_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w11_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w11_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w12_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w12_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w12_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w13_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w13_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w13_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h1_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h1_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h2_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h2_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h3_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h3_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t1_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t1_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t2_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t2_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t3_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t3_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    late_in2absence = forms.IntegerField(label=_('attRule_globalRule_missIn'), min_value=0, initial=100, unit=_('time.units.minute'))
    early_out2absence = forms.IntegerField(label=_('attRule_globalRule_missIn'), min_value=0, initial=100, unit=_('time.units.minute'))
    late_in_hrs = forms.IntegerField(label=_('attRule_globalRule_missIn'), min_value=0, initial=60, unit=_('time.units.minute'))
    early_out_hrs = forms.IntegerField(label=_('attRule_globalRule_missOut'), min_value=0, initial=60, unit=_('time.units.minute'))
    max_late_in = forms.IntegerField(label=_('alertSettingPage_label_lateExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    max_early_out = forms.IntegerField(label=_('alertSettingPage_label_earlyLeaveExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    max_absent = forms.IntegerField(label=_('alertSettingPage_label_absentExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    dept_frequency = forms.ChoiceField(label=_('alertSettingPage_label_emailSendingFrequency'), initial=0, choices=EMAIL_FREQUENCY)
    dept_send_day = forms.ChoiceField(label=_('alertSettingPage_label_emailSendingDay'), initial=0, choices=SELECT_DAY)
    email_send_time = forms.TimeField(label=_('alertSettingPage_label_emailSendingTime'), initial='00:00:00')
    sending_day = forms.ChoiceField(label=_('alertSettingPage_label_sendingDay'), initial=0, choices=SENDING_DAY)
    weekend1_color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    weekend2_color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    ot_pay_code = PayCodeModelChoiceField(label=_('timeInterval.fields.overtimePayCode'), required=False)
    bot_uid = forms.CharField(label=_('timeInterval.fields.botUid'), required=False)
    facebook_enable = forms.CharField(label=_(''), required=False, initial=settings.FACEBOOK_ENABLE)
    work_code_enable = forms.CharField(label=_(''), required=False, initial=settings.WORKCODE_SETTING)
    enable_workcode_calculation = forms.BooleanField(label=_('attPolicy.fields.workcodeCalculation'), initial=False, required=False)
    enable_workcode_punch_state = forms.ChoiceField(label=_('timeInterval_field_baseOnPunchType'), initial=0, choices=BOOLEANS, required=False)
    class Meta:
        model = DepartmentPolicy
        fields = ('weekend1', 'weekend2', 'max_hrs', 'day_change', 'paring_rule', 'punch_period', 'daily_ot', 'd1_pay_code', 'd1_hrs_from', 'd1_hrs_to', 'd2_pay_code', 'd2_hrs_from', 'd2_hrs_to', 'd3_pay_code', 'd3_hrs_from', 'd3_hrs_to', 'weekend_ot', 'w11_pay_code', 'w11_hrs_from', 'w11_hrs_to', 'w12_pay_code', 'w12_hrs_from', 'w12_hrs_to', 'w13_pay_code', 'w13_hrs_from', 'w13_hrs_to', 'holiday_ot', 'h1_pay_code', 'h1_hrs_from', 'h1_hrs_to', 'h2_pay_code', 'h2_hrs_from', 'h2_hrs_to', 'h3_pay_code', 'h3_hrs_from', 'h3_hrs_to', 'weekly_ot', 't1_pay_code', 't1_hrs_from', 't1_hrs_to', 't2_pay_code', 't2_hrs_from', 't2_hrs_to', 't3_pay_code', 't3_hrs_from', 't3_hrs_to', 'late_in2absence', 'early_out2absence', 'miss_in', 'late_in_hrs', 'miss_out'
    def __init__(self, *args, **kwargs):
        from mysite.att.models.model_overtime_policy import OvertimePolicy
        super(DepartmentPolicyChangeForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.initial['use_ot'] = str(self.instance.use_ot)
            self.initial['dept_frequency'] = str(self.instance.dept_frequency)
            self.initial['dept_send_day'] = str(self.instance.dept_send_day)
            self.initial['sending_day'] = str(self.instance.sending_day)
            rules = OvertimePolicy.objects.filter(master__in=(self.instance.daily_ot_rule, self.instance.weekend_ot_rule, self.instance.holiday_ot_rule, self.instance.weekly_ot_rule)).values('mode', 'pay_code', 'hrs_from', 'hrs_to', 'master')
            for rule in rules:
                prefix = 'd'
                if rule['master'] == self.instance.weekend_ot_rule:
                    prefix = 'w1'
                else:
                    if rule['master'] == self.instance.holiday_ot_rule:
                        prefix = 'h'
                    else:
                        if rule['master'] == self.instance.weekly_ot_rule:
                            prefix = 't'
                prefix_key = '{prefix}{lv}'.format(prefix=prefix, lv=rule['mode'])
                self.fields['{prefix_key}_pay_code'.format(prefix_key=prefix_key)].initial = rule['pay_code']
                self.fields['{prefix_key}_hrs_from'.format(prefix_key=prefix_key)].initial = rule['hrs_from']
                self.fields['{prefix_key}_hrs_to'.format(prefix_key=prefix_key)].initial = rule['hrs_to']
    def save(self, commit=True):
        from mysite.att.models.model_payload import department_policy_change
        from mysite.att.models.model_overtime_policy import OvertimePolicy, OT_LV1, OT_LV2, OT_LV3
        cleaned_data = self.cleaned_data
        obj = super(DepartmentPolicyChangeForm, self).save(commit=commit)
        obj.daily_ot_rule = obj.daily_ot_rule if obj.daily_ot_rule else uuid.uuid1().hex
        obj.weekend_ot_rule = obj.weekend_ot_rule if obj.weekend_ot_rule else uuid.uuid1().hex
        obj.holiday_ot_rule = obj.holiday_ot_rule if obj.holiday_ot_rule else uuid.uuid1().hex
        obj.weekly_ot_rule = obj.weekly_ot_rule if obj.weekly_ot_rule else uuid.uuid1().hex
        for prefix, master in [('d', obj.daily_ot_rule), ('w1', obj.weekend_ot_rule), ('h', obj.holiday_ot_rule), ('t', obj.weekly_ot_rule)]:
            for ot in [OT_LV1, OT_LV2, OT_LV3]:
                ot_pay_code = '{prefix}{lv}_pay_code'.format(prefix=prefix, lv=ot)
                ot_hrs_from = '{prefix}{lv}_hrs_from'.format(prefix=prefix, lv=ot)
                ot_hrs_to = '{prefix}{lv}_hrs_to'.format(prefix=prefix, lv=ot)
                _changed = [ot_pay_code, ot_hrs_from, ot_hrs_to]
                if set(self.changed_data).intersection(set(_changed)):
                    otp = OvertimePolicy.objects.filter(master=master, mode=ot).first()
                    if not otp:
                        otp = OvertimePolicy(master=master, mode=ot)
                    otp.hrs_from = cleaned_data[ot_hrs_from]
                    otp.hrs_to = cleaned_data[ot_hrs_to]
                    otp.pay_code = cleaned_data[ot_pay_code]
                    otp.save()
        _change_fields = ['use_ot', 'weekend1', 'weekend2', 'start_of_week', 'max_hrs', 'day_change', 'paring_rule', 'punch_period', 'enable_daily_ot', 'enable_weekend_ot', 'enable_holiday_ot', 'enable_weekly_ot', 'late_in2absence', 'early_out2absence', 'miss_in', 'late_in_hrs', 'miss_out', 'early_out_hrs', 'weekend1_color_setting', 'weekend2_color_setting', 'ot_pay_code', 'overtime_policy', 'd1_pay_code', 'd1_hrs_from', 'd1_hrs_to', 'd2_pay_code', 'd2_hrs_from', 'd2_hrs_to', 'd3_pay_code', 'd3_hrs_from', 'd3_hrs_to', 'w11_pay_code', 'w11_hrs_from', 'w11_hrs_to', 'w12_pay_code', 'w12_hrs_from', 'w12_hrs_to', 'w13_pay_code', 'w13_hrs_from', 'w13_hrs_to', 'h1_pay_code', 'h1_hrs_from', 'h1_hrs_to', 'h2_pay_code', 'h2_hrs_from', 'h2_hrs_to', 'h3_pay_code', 'h3_hrs_from', 'h3_hrs_to', 't1_pay_code', 't1_hrs_from'
        if self.changed_data and set(self.changed_data).intersection(set(_change_fields)):
                department_policy_change(obj)
        return obj
@admin.register(DepartmentPolicy)
class DepartmentPolicyAdmin(admin.ZKModelAdmin):
    list_filter = ('department__dept_code', 'department__dept_name')
    list_display = ('department', 'max_hrs', 'day_change', 'paring_rule', 'daily_ot', 'weekend_ot', 'holiday_ot', 'weekly_ot')
    form = DepartmentPolicyChangeForm
    actions = (AddDepartmentPolicy,)
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        queryset = super(DepartmentPolicyAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_dept.exists():
                queryset = queryset.filter(department__in=request.user.auth_dept.all())
        if not request.user.is_superuser and request.user.assign_company:
                queryset = queryset.filter(department__company=request.user.assign_company)
        queryset = queryset.select_related()
        return queryset