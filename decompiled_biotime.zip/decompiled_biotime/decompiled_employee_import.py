# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\admin\\employee_import.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

import json
from django.utils.translation import gettext_lazy as _
from mysite._utils import getattr_ex
from mysite.admin.models import STATUS_VALID
from mysite.base.model_import import ModelImport, DuplicateError
from mysite.personnel.models import EmployeeCustomAttribute, EmployeeExtraInfo, Department, Area, Employee
class ImportEmployeeData(ModelImport):
    from django.conf import settings
    primary_key = 'emp_code'
    default_department = None
    default_area = None
    if getattr_ex(settings, 'MULTI_COMPANY', False):
        allow_duplicate_primary_key = True
        unique_fields = ()
        unique_together = (('emp_code', 'company_id'),)
    def clean_organization(self, params, code_field, name_field):
        manager = params.pop('manager')
        code, name = (params.get(code_field, None), params.get(name_field, None))
        if not code and (not name):
                return
        obj = self.organization_valid(manager, code, name, code_field, name_field)
        return obj
    def clean_department(self, fk, params):
        return self.clean_organization(params, 'dept_code', 'dept_name')
    def clean_position(self, fk, params):
        return self.clean_organization(params, 'position_code', 'position_name')
    def clean_area(self, fk, params):
        manager = params.pop('manager')
        instances = []
        if params.get('area_code', None):
            for code in params['area_code']:
                obj = self.organization_valid(manager, code, None, 'area_code', 'area_name')
                instances.append(obj)
        else:
            if params.get('area_name', None):
                for name in params['area_name']:
                    obj = self.organization_valid(manager, None, name, 'area_code', 'area_name')
                    instances.append(obj)
        return instances
    def validate_emp_code(self, field, emp_code):
        from mysite.utils import get_system_setting
        from django.core.exceptions import ValidationError
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('num_emp_code') is True and (not emp_code.isdigit()):
            raise ValidationError(_('emp_code_should_be_digit'))
        else:
            return emp_code
    def clean_company(self, fk, params):
        return self.company
    def pre_save_m2m(self, obj, params, created):
        if not created:
            return
        else:
            if self.default_area is None:
                self.default_area = Area.objects.filter(is_default=True, company_id=self.company_id).first()
            obj.area.set((self.default_area,))
    def validate_ext_field(self, field, value):
        if not field.startswith('user_defined'):
            return
        else:
            return value
    def init_ext_validator(self):
        if self.ext_validator is not None:
            return
        else:
            self.ext_validator = {}
            unique_fields = EmployeeCustomAttribute.objects.filter(is_unique=True).values_list('id', flat=True)
            ext_attrs = EmployeeExtraInfo.objects.values('employee__emp_code', 'value')
            for attrs in ext_attrs:
                emp_code = attrs['employee__emp_code']
                exts = json.loads(attrs['value'])
                for f in unique_fields:
                    val = exts.get(str(f), None)
                    if not val:
                        continue
                    else:
                        key = 'user_defined_{}'.format(f)
                        self.ext_validator['{}|{}'.format(key, val)] = emp_code
    def clean_ext_field(self, field, value, existing):
        query = '{}|{}'.format(field, value)
        f = self.model_admin.get_extend_field(field)
        if query in self.ext_validator and self.ext_validator[query]!= existing:
            raise DuplicateError(_('Duplicate {}({}) of {}'.format(f.verbose_name, value, existing)))
        else:
            if f.field and f.field.is_unique:
                    self.ext_validator[query] = existing
    def pre_save_object(self, params):
        """Do something before save"""
        if not params.get('created', False):
            return
        else:
            if 'card_no' in params['attrs']:
                emp = Employee.all_objects.filter(emp_code=params['attrs']['card_no'], company_id=self.company_id).first()
                if emp and emp.emp_code!= params['attrs'].get('emp_code', None):
                    raise DuplicateError(_('employeeSave_error_duplicateCard_{emp}_{card_no}').format(emp=emp.emp_code, card_no=params['attrs']['card_no']))
                else:
                    if emp:
                        return
            if 'emp_code' in params['attrs']:
                emp = Employee.all_objects.filter(emp_code=params['attrs']['emp_code'], company_id=self.company_id).first()
                if emp:
                    return
            if self.default_department is None:
                self.default_department = Department.objects.filter(is_default=True, company_id=self.company_id).first()
            params['attrs'].update({'department': self.default_department, 'status': STATUS_VALID})
    def post_save_object(self, obj, params, created):
        """Do something after save"""
        from mysite.personnel.api.serializers import EmployeeExtraInfoSerializer
        extras = params['extras']
        if not extras:
            return
        else:
            cleaned_data = extras
            serializer = EmployeeExtraInfoSerializer(data=cleaned_data, employee=obj)
            serializer.is_valid(raise_exception=False)
            serializer.save(force_save=True)
    def organization_valid(self, cls, code, name, code_field, name_field):
        if not code and (not name):
                return
        if code:
            filters = {code_field: code}
        else:
            filters = {name_field: name}
        filters.update({'company_id': self.company_id})
        obj = cls.objects.filter(**filters).first()
        if obj and (not self.overwrite):
            return obj
        else:
            if obj and self.overwrite:
                if name and name!= getattr(obj, name_field, None):
                        setattr(obj, name_field, name)
                        obj.save(force_update=True)
                return obj
            else:
                if not code:
                    codes = cls.objects.filter(company_id=self.company_id).values_list(code_field, flat=True)
                    numeric_codes = [int(code) for code in codes if str(code).isdigit()] or [0]
                    code = max(numeric_codes) + 1
                code = str(code)
                obj, created = cls.objects.get_or_create(defaults={name_field: name or code}, **{code_field: code, 'company_id': self.company_id})
                return obj