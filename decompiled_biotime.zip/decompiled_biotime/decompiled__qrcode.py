# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\_qrcode.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:03 UTC (1750672983)

import os
import json
import qrcode
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from django.http.response import HttpResponse
def biophoto_register_qrcode(request, for_visitor=False):
    host = request.GET.get('hook', None)
    if not host:
        return HttpResponse(json.dumps({'ret': (-1), 'message': 'Failed'}))
    else:
        from mysite.tools.access_utils import get_access_token
        from mysite.admin.sites import Scopes
        valid_hours = 24
        if for_visitor:
            action = 'vlVisitorRegister'
            scopes = [Scopes.software_register_visitor_bio_photo]
        else:
            action = 'vlRegister'
            scopes = [Scopes.software_register_user_bio_photo]
        access_token = get_access_token({'scopes': scopes}, valid_time=valid_hours * 60)
        if not host.endswith('/'):
            url = '{host}/{action}/?AccessToken={token}'.format(host=host, action=action, token=access_token)
        else:
            url = '{host}{action}/?AccessToken={token}'.format(host=host, action=action, token=access_token)
        qr = qrcode.QRCode(version=5, error_correction=qrcode.ERROR_CORRECT_L, box_size=8, border=4)
        qr.add_data(url)
        qr.make(fit=True)
        store_path = os.path.join(settings.ADDITION_FILE_ROOT, 'qrcode')
        if not os.path.exists(store_path):
            os.makedirs(store_path)
        qr_path = os.path.join(store_path, 'visitor_register.png' if for_visitor else 'register.png')
        if os.path.exists(qr_path):
            os.remove(qr_path)
        img = qr.make_image()
        img = img.convert('RGBA')
        try:
            img.save(qr_path)
            return HttpResponse(json.dumps({'ret': 0, 'message': str(_('msg_QRCodeValidInHours')).format(valid_hours)}))
        except Exception as e:
            return HttpResponse(json.dumps({'ret': (-1), 'message': str(e)}))