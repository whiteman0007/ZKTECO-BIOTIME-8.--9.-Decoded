# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\daily_attendance.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.models import PayloadTimeCard
from mysite.att.utils import WEEKDAY
_WEEKDAY = dict(WEEKDAY)
class DailyAttendanceSerializer(serializers.ModelSerializer):
    emp_code = serializers.CharField(label=_('report_column_empCode'), source='emp.emp_code')
    first_name = serializers.CharField(label=_('report_column_firstName'), source='emp.first_name', allow_null=True)
    last_name = serializers.CharField(label=_('report_column_lastName'), source='emp.last_name', allow_null=True)
    nick_name = serializers.CharField(label=_('report_column_nickName'), source='emp.nickname', allow_null=True)
    gender = serializers.CharField(label=_('report_column_gender'), source='emp.get_gender_display', allow_blank=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='emp.department.dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='emp.department.dept_name', allow_null=True)
    position_code = serializers.CharField(label=_('report_column_positionCode'), source='emp.position.position_code', allow_null=True)
    position_name = serializers.CharField(label=_('report_column_positionName'), source='emp.position.position_name', allow_null=True)
    class Meta:
        model = PayloadTimeCard
        fields = ('id', 'emp_id', 'emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'dept_code', 'dept_name', 'position_code', 'position_name')
class DailyAttendanceFilter(ReportGenericFilter):
    class Meta:
        model = PayloadTimeCard
        fields = ['employees', 'departments', 'start_date', 'end_date']
class DailyAttendanceViewSet(ReportUserGenericViewSet):
    model = PayloadTimeCard
    queryset = PayloadTimeCard.objects.get_queryset().order_by('emp', 'att_date', 'clock_in')
    filterset_class = DailyAttendanceFilter
    serializer_dict = {'list': DailyAttendanceSerializer, 'export': DailyAttendanceSerializer}
    def annotate_queryset(self, queryset):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            ordering = ['emp__emp_code_digit', 'emp__emp_code']
        else:
            ordering = ['emp__emp_code']
        queryset = self.filter_queryset(self.get_queryset())
        queryset = queryset.order_by(*ordering)
        return queryset
    def get_file_title(self):
        return _('att.menus.reports.totalTimeCard')