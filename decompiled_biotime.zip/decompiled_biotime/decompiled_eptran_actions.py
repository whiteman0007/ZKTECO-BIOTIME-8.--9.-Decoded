# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\ep\\actions\\eptran_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

import datetime
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
from mysite.admin.action import ActionHandleError
from mysite.ep.db_const import MANUAL, TEMP_UNIT
from mysite.ep.models import EPSetup, EPTransaction
class AddTransactionForm(forms.ZKActionForm):
    emp = forms.EmployeeManyToManyField(label=_('epTransaction.fields.employee'), required=False)
    check_datetime = forms.DateTimeField(label=_('epTransaction.fields.checkTime'))
    temperature = forms.DecimalField(label=_('epTransaction.fields.temperature'), decimal_places=1, max_digits=4, unit='℃')
    is_mask = forms.BooleanField(label=_('epTransaction.fields.isMask'), required=False)
    def __init__(self, *args, **kwargs):
        super(AddTransactionForm, self).__init__(*args, **kwargs)
        setup = EPSetup.cache_data()
        unit = dict(TEMP_UNIT).get(int(setup.temp_unit), setup.temp_unit)
        self.fields['temperature'].widget.unit = self.fields['temperature'].unit = unit
class AddTransaction(ZKModelAction):
    verbose_name = _('epTransaction.actions.add')
    short_description = _('epTransaction.actions.add')
    help_txt = _('epTransaction.actions.add')
    action_form = AddTransactionForm
    def action(self, *args, **kwargs):
        employees = self.request.POST.getlist('emp')
        if not employees:
            raise ActionHandleError(_('select_none_employee'))
        else:
            form = AddTransactionForm(self.request.POST)
            if form.is_valid():
                cleaned_data = form.cleaned_data
                check_datetime = cleaned_data.get('check_datetime')
                temperature = cleaned_data.get('temperature')
                is_mask = cleaned_data.get('is_mask')
                for employee in employees:
                    EPTransaction(emp_id=employee, check_datetime=check_datetime, check_time=check_datetime.time(), check_date=check_datetime.date(), temperature=temperature, is_mask=is_mask, source=MANUAL).save(force_insert=True)