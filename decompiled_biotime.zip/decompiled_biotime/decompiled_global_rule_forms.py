# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\forms\\global_rule_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import json
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att.fields import PayCodeModelChoiceField
from mysite.att.models_choices import EMAIL_FREQUENCY, SENDING_DAY, SELECT_DAY, APPROVAL_CHOICE, APPROVAL_IGNORE, BOOLEANS
from django.conf import settings
OVERTIME_RULE = ((0, _('attRule_overtimeRule_disableOvertime')), (1, _('attRule_overtimeRule_calculationOvertime')), (2, _('attRule_overtimeRule_approvalOvertime')), (3, _('attRule_overtimeRule_approvalOvertimePriority')))
MISS_IN_RULE = ((1, _('attRule_missIn_late')), (2, _('attRule_missIn_absent')), (0, _('attRule_missIn_noComplete')))
MISS_OUT_RULE = ((1, _('attRule_missOut_earlyLeave')), (2, _('attRule_missOut_absent')), (0, _('attRule_missOut_noComplete')))
REQUIRED = ((0, _('attRule_globalRule_notRequired')), (1, _('attRule_globalRule_required')))
UNSCHEDULED_POLICY = ((0, _('unscheduled_ignore')), (1, _('unscheduled_move2normalWork')), (2, _('unscheduled_move2normalOvertime')), (3, _('unscheduled_move2weekendOvertime')), (4, _('unscheduled_move2holidayOvertime')))
MON, TUES, WED, THUR, FRI, SAT, SUN, NON = (0, 1, 2, 3, 4, 5, 6, 7)
WEEKEND = ((NON, _('week.days.none')), (MON, _('week.days.monday')), (TUES, _('week.days.tuesday')), (WED, _('week.days.wednesday')), (THUR, _('week.days.thursday')), (FRI, _('week.days.friday')), (SAT, _('week.days.saturday')), (SUN, _('week.days.sunday')))
WEEK = ((MON, _('week.days.monday')), (TUES, _('week.days.tuesday')), (WED, _('week.days.wednesday')), (THUR, _('week.days.thursday')), (FRI, _('week.days.friday')), (SAT, _('week.days.saturday')), (SUN, _('week.days.sunday')), (NON, _('week.days.system')))
PARING_RULE = ((1, _('punchParing.rules.firstAndLast')), (2, _('punchParing.rules.oddEven')), (3, _('punchParing.rules.punchStateBased')))
class RuleForm(forms.ZKActionForm):
    use_ot = forms.ChoiceField(label=_('attRule_globalRule_overtimeRule'), choices=OVERTIME_RULE, initial=1)
    enable_compensatory = forms.BooleanField(label=_('globalRule.fields.enableCompensatory'), initial=False, required=False)
    weekend = forms.CharField(required=False)
    weekend1 = forms.ChoiceField(label=_('globalRule.fields.weekend1'), choices=WEEKEND, required=False, initial=NON)
    weekend2 = forms.ChoiceField(label=_('globalRule.fields.weekend2'), choices=WEEKEND, required=False, initial=NON)
    start_of_week = forms.ChoiceField(label=_('globalRule.fields.startOfWeek'), choices=WEEK, initial=MON)
    max_hrs = forms.DecimalField(label=_('globalRule.fields.maxHrs'), max_digits=4, decimal_places=1, initial=12.0, unit=_('time.units.hour'), min_value=0)
    day_change = forms.TimeField(label=_('globalRule.fields.dayChange'), initial='00:00')
    paring_rule = forms.ChoiceField(label=_('globalRule.fields.paringRule'), choices=PARING_RULE)
    ot_pay_code = PayCodeModelChoiceField(label=_('timeInterval.fields.overtimePayCode'), required=False)
    overtime_policy = forms.ChoiceField(label=_('timeInterval.fields.overtimePolicy'), choices=APPROVAL_CHOICE, initial=APPROVAL_IGNORE)
    punch_period = forms.IntegerField(label=_('attRule_globalRule_duplicatePunchPeriod'), min_value=0, initial=1, unit=_('time.units.minute'))
    enable_daily_ot = forms.BooleanField(label=_('globalRule.fields.enableDailyOvertime'), initial=False, required=False)
    d1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d1_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d1_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d2_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d2_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d3_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    d3_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    enable_weekend_ot = forms.BooleanField(label=_('globalRule.fields.enableWeekendOvertime'), initial=False, required=False)
    w11_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w11_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w11_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w12_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w12_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w12_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w13_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w13_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    w13_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    enable_holiday_ot = forms.BooleanField(label=_('globalRule.fields.enableHolidayOvertime'), initial=False, required=False)
    h1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h1_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h1_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h2_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h2_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h3_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    h3_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    enable_weekly_ot = forms.BooleanField(label=_('attShift.fields.enableOvertimeRule'), initial=False, required=False)
    t1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t1_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t1_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t2_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t2_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t3_hrs_from = forms.DecimalField(label=_('globalRule.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t3_hrs_to = forms.DecimalField(label=_('globalRule.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    late_in2absence = forms.IntegerField(label=_('attRule_globalRule_lateExceedPrefix'), min_value=0, initial=100, unit=_('time.units.minute'))
    early_out2absence = forms.IntegerField(label=_('attRule_globalRule_earlyLeaveExceedPrefix'), min_value=0, initial=100, unit=_('time.units.minute'))
    miss_in = forms.ChoiceField(label=_('attRule_globalRule_missIn'), choices=MISS_IN_RULE, initial=1)
    late_in_hrs = forms.IntegerField(label=_('attRule_globalRule_missIn'), min_value=0, initial=60, unit=_('time.units.minute'))
    miss_out = forms.ChoiceField(label=_('attRule_globalRule_missOut'), choices=MISS_OUT_RULE, initial=1)
    early_out_hrs = forms.IntegerField(label=_('attRule_globalRule_missOut'), min_value=0, initial=60, unit=_('time.units.minute'))
    require_capture = forms.BooleanField(label=_('globalRule.fields.requireCapture'), initial=False, required=False)
    require_work_code = forms.BooleanField(label=_('globalRule.fields.requireWorkCode'), initial=False, required=False)
    require_punch_state = forms.BooleanField(label=_('globalRule.fields.requirePunchState'), initial=False, required=False)
    max_late_in = forms.IntegerField(label=_('alertSettingPage_label_lateExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    max_early_out = forms.IntegerField(label=_('alertSettingPage_label_earlyLeaveExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    max_absent = forms.IntegerField(label=_('alertSettingPage_label_absentExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    global_frequency = forms.ChoiceField(label=_('alertSettingPage_label_emailSendingFrequency'), initial=0, choices=EMAIL_FREQUENCY)
    global_send_day = forms.ChoiceField(label=_('alertSettingPage_label_emailSendingDay'), initial=0, choices=SELECT_DAY)
    email_send_time = forms.TimeField(label=_('alertSettingPage_label_emailSendingTime'), initial='00:00:00')
    sending_day = forms.ChoiceField(label=_('alertSettingPage_label_sendingDay'), initial=0, choices=SENDING_DAY)
    global_weekend1_color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    global_weekend2_color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    bot_uid = forms.CharField(label=_('timeInterval.fields.botUid'), required=False)
    facebook_enable = forms.CharField(label=_(''), required=False, initial=settings.FACEBOOK_ENABLE)
    work_code_enable = forms.CharField(label=_(''), required=False, initial=settings.WORKCODE_SETTING)
    global_enable_workcode_calculation = forms.BooleanField(label=_('attPolicy.fields.workcodeCalculation'), initial=False, required=False)
    global_enable_workcode_punch_state = forms.ChoiceField(label=_('timeInterval_field_baseOnPunchType'), initial=0, choices=BOOLEANS, required=False)
    def __init__(self, *args, **kwargs):
        from mysite.att.models import AttPolicy, OvertimePolicy
        super(RuleForm, self).__init__(*args, **kwargs)
        ap = AttPolicy.objects.all().first()
        if ap:
            self.fields['use_ot'].initial = str(ap.use_ot)
            self.fields['weekend1'].initial = str(ap.weekend1)
            self.fields['weekend2'].initial = str(ap.weekend2)
            self.fields['start_of_week'].initial = str(ap.start_of_week)
            self.fields['max_hrs'].initial = ap.max_hrs
            self.fields['day_change'].initial = ap.day_change
            self.fields['paring_rule'].initial = str(ap.paring_rule)
            self.fields['punch_period'].initial = ap.punch_period
            self.fields['enable_daily_ot'].initial = ap.daily_ot
            self.fields['enable_weekend_ot'].initial = ap.weekend_ot
            self.fields['enable_holiday_ot'].initial = ap.holiday_ot
            self.fields['enable_weekly_ot'].initial = ap.weekly_ot
            self.fields['late_in2absence'].initial = ap.late_in2absence
            self.fields['early_out2absence'].initial = ap.early_out2absence
            self.fields['miss_in'].initial = str(ap.miss_in)
            self.fields['late_in_hrs'].initial = ap.late_in_hrs
            self.fields['miss_out'].initial = str(ap.miss_out)
            self.fields['early_out_hrs'].initial = ap.early_out_hrs
            self.fields['require_capture'].initial = ap.require_capture
            self.fields['require_work_code'].initial = ap.require_work_code
            self.fields['require_punch_state'].initial = ap.require_punch_state
            self.fields['max_late_in'].initial = ap.max_late_in
            self.fields['max_early_out'].initial = ap.max_early_out
            self.fields['max_absent'].initial = ap.max_absent
            self.fields['global_frequency'].initial = str(ap.global_frequency)
            self.fields['global_send_day'].initial = str(ap.global_send_day)
            self.fields['email_send_time'].initial = ap.email_send_time
            self.fields['sending_day'].initial = str(ap.sending_day)
            self.fields['global_weekend1_color_setting'].initial = ap.weekend1_color_setting
            self.fields['global_weekend2_color_setting'].initial = ap.weekend2_color_setting
            self.fields['ot_pay_code'].initial = ap.ot_pay_code
            self.fields['overtime_policy'].initial = str(ap.overtime_policy)
            self.fields['enable_compensatory'].initial = ap.enable_compensatory
            self.fields['bot_uid'].initial = ap.bot_uid
            self.fields['facebook_enable'].initial = settings.FACEBOOK_ENABLE
            self.fields['work_code_enable'].initial = settings.WORKCODE_SETTING
            self.fields['global_enable_workcode_calculation'].initial = ap.enable_workcode_calculation
            self.fields['global_enable_workcode_punch_state'].initial = ap.enable_workcode_punch_state
            rules = OvertimePolicy.objects.filter(master__in=(ap.daily_ot_rule, ap.weekend_ot_rule, ap.holiday_ot_rule, ap.weekly_ot_rule)).values('mode', 'pay_code', 'hrs_from', 'hrs_to', 'master')
            for rule in rules:
                prefix = 'd'
                if rule['master'] == ap.weekend_ot_rule:
                    prefix = 'w1'
                else:
                    if rule['master'] == ap.holiday_ot_rule:
                        prefix = 'h'
                    else:
                        if rule['master'] == ap.weekly_ot_rule:
                            prefix = 't'
                prefix_key = '{prefix}{lv}'.format(prefix=prefix, lv=rule['mode'])
                self.fields['{prefix_key}_pay_code'.format(prefix_key=prefix_key)].initial = rule['pay_code']
                self.fields['{prefix_key}_hrs_from'.format(prefix_key=prefix_key)].initial = rule['hrs_from']
                self.fields['{prefix_key}_hrs_to'.format(prefix_key=prefix_key)].initial = rule['hrs_to']