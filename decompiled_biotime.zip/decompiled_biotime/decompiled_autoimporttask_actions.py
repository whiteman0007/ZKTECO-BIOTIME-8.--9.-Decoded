# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\actions\\autoimporttask_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:03 UTC (1750672983)

from django.utils.translation import gettext_lazy as _
from mysite.admin import ZKModelAction
from mysite.base.forms import AutoImportTaskCreationForm
from mysite.base.models import AutoImportTask
class AddDefault(ZKModelAction):
    verbose_name = _('autoImport_task_action_addDefault')
    short_description = _('autoImport_task_action_addDefault_description')
    help_txt = _('autoImport_task_action_addDefault_help_txt')
    action_form = AutoImportTaskCreationForm
    def action(self, *args, **kwargs):
        form = AutoImportTaskCreationForm(self.request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            task_obj = AutoImportTask(task_code=cleaned_data['task_code'], task_name=cleaned_data['task_name'], company=cleaned_data['company'], enable=cleaned_data['enable'], params=cleaned_data['params'])
            task_obj.save()
class ManualImport(ZKModelAction):
    batch_select = True
    verbose_name = _('autoImport_task_action_manualImport')
    short_description = _('autoImport_task_action_manualImport_description')
    help_txt = _('autoImport_task_action_manualImport_help_txt')
    confirmation = _('are_you_sure_to_manualImport {0} {1}')
    async_progress = True
    def action(self, *args, **kwargs):
        from mysite.base.tasks import async_progress_task_caller
        from mysite.admin.utils import get_client_ip
        ip, can_routable = get_client_ip(self.request)
        call_info = {'type': 'admin', 'model': self.admin.model, 'func': 'manual_import'}
        obj_ids = [obj.id for obj in self.objects]
        kwargs.update({'obj_ids': obj_ids, 'user': self.request.user, 'ip': ip, 'can_routable': can_routable, 'action': str(self.verbose_name)})
        task = async_progress_task_caller.delay(call_info, list(self.objects), **kwargs)
        return (task, 1)
class AddUserDefine(ZKModelAction):
    verbose_name = _('autoImport_task_action_addUserDefine')
    short_description = _('autoImport_task_action_addUserDefine_description')
    help_txt = _('autoImport_task_action_addUserDefine_help_txt')
    action_form = AutoImportTaskCreationForm
    def action(self, *args, **kwargs):
        form = AutoImportTaskCreationForm(self.request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            task_obj = AutoImportTask(task_code=cleaned_data['task_code'], task_name=cleaned_data['task_name'], company=cleaned_data['company'], enable=cleaned_data['enable'], params=cleaned_data['params'])
            task_obj.save()
class EnableTask(ZKModelAction):
    batch_select = True
    verbose_name = _('enable_autoExportTask')
    help_txt = _('enable_autoExportTask')
    short_description = _('enable_autoExportTask')
    confirmation = _('are_you_sure_to_enable_autoExportTask {0} {1}')
    def action(self, *args, **kwargs):
        for objects_i in self.objects:
            objects_i.enable = 1
            objects_i.save()
class DisableTask(ZKModelAction):
    batch_select = True
    verbose_name = _('disable_autoExportTask')
    help_txt = _('disable_autoExportTask')
    short_description = _('disable_autoExportTask')
    confirmation = _('are_you_sure_to_disable_autoExportTask {0} {1}')
    def action(self, *args, **kwargs):
        for objects_i in self.objects:
            objects_i.enable = 0
            objects_i.save()