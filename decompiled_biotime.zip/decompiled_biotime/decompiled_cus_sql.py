# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\management\\commands\\cus_sql.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:21 UTC (1750673001)

from django.db import connection
from django.core.management.base import BaseCommand
class Command(BaseCommand):
    def handle(self, *args, **options):
        cursor = connection.cursor()
        sql = ''
        cursor.execute(sql)
        data = cursor.fetchall()
        for each in data:
            print(each)
        print(len(data))