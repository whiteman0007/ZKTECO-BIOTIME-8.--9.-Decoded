# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\auto_import_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from celery_progress.backend import AbstractProgressRecorder
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views.decorators.csrf import csrf_protect
from mysite import admin
from mysite import config
from mysite.admin.action import ActionTuple
from mysite.admin.kernel import ZKModelAdmin
from mysite.base.actions import AddUserDefine, EnableTask, DisableTask, ManualImport, AddDefault
from mysite.base.filter import EnableTaskListFilter
from mysite.base.forms import AutoImportTaskCreationForm
from mysite.base.models import AutoImportTask
csrf_protect_m = method_decorator(csrf_protect)
@admin.register(AutoImportTask)
class AutoImportTaskAdmin(ZKModelAdmin):
    list_display = ['task_code', 'task_name', 'enable'] + list(config.WDMS_LIST_DISPLAY) + ['process_time']
    list_display_params = {'__all__': {'width': 200}}
    sort_fields = []
    list_filter = ('task_code', 'task_name') + config.WDMS_LIST_FILTER
    calculated_filter = (EnableTaskListFilter,)
    actions = [AddDefault, AddUserDefine, ManualImport]
    action_sets = (ActionTuple(_('op_menu_group_task_status'), (EnableTask, DisableTask)),)
    form = AutoImportTaskCreationForm
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        qs = super(AutoImportTaskAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.assign_company:
                company = request.user.assign_company
                qs = qs.filter(company_id=company)
        return qs
    @csrf_protect_m
    def import_template(self, request):
        """\n        Response for \'Download Template\' in import page\'\n        :param request:\n        :return: return import template\n        """
        import xlsxwriter
        from io import BytesIO
        from django.http.response import HttpResponse
        from mysite.base.config import AUTOIMPORTTASK_EMPLOYEE_MUST_FIELDS
        verbose_name = AUTOIMPORTTASK_EMPLOYEE_MUST_FIELDS.copy()
        custom_fields = request.GET['fields'].split(',')
        if custom_fields[0]:
            verbose_name.extend(custom_fields)
        output = BytesIO()
        wb = xlsxwriter.Workbook(output)
        sheet = wb.add_worksheet('Template')
        for i, v in enumerate(verbose_name):
            head = '{0}'.format(v)
            sheet.write(0, i, head)
            sheet.set_column(0, i, len(head) * 3)
        wb.close()
        output.seek(0)
        response = HttpResponse(output.read(), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename={0}.xls'.format(self.opts.verbose_name).encode('UTF-8')
        return response
    def manual_import(self, request, **kwargs):
        from mysite.base import const
        from mysite.base.auto_import import auto_import_executor
        from mysite.utils import progress_record
        from mysite.base import tasks
        progress_recorder = kwargs.get('progress_recorder', None)
        obj_ids = kwargs.get('obj_ids', None)
        user = kwargs.get('user', None)
        ip = kwargs.get('ip', None)
        can_routable = kwargs.get('can_routable', None)
        action = kwargs.get('action', None)
        current = 0
        total = len(obj_ids)
        progress_record(progress_recorder, current, total, _('importProgress.status.dataVerification'))
        qs = AutoImportTask.objects.filter(id__in=obj_ids)
        execute_status = None
        total_sum = 0
        for obj in qs:
            progress_record(progress_recorder, current, total, _('importProgress.status.uploading'))
            if isinstance(obj, AutoImportTask) and (not obj.enable):
                    obj.enable = 1
            info, execute_status, num = auto_import_executor(obj, manually=True, **kwargs)
            total_sum += num
            if execute_status == const.FAILED:
                err_info = _('manual_import_%s_task_code_%s_error_%s') % (str(num), str(obj.task_code), str(info))
                tasks.log_recorder.delay(user, ip, can_routable, obj_ids, action, status=execute_status, messages=str(err_info), model=AutoImportTask)
                if isinstance(progress_recorder, AbstractProgressRecorder):
                    progress_recorder.stop_task(current, total, _('importProgress.status.failed'))
                else:
                    if progress_recorder:
                        import json
                        progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(current, total), 'channel': ''})})
                return err_info
        suc_info = _('manual_import_%s') % str(total_sum)
        tasks.log_recorder.delay(user, ip, can_routable, obj_ids, action, status=execute_status, messages=str(suc_info), model=AutoImportTask)