# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\group_summary_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import GroupSummaryViewSet
from mysite.att.api.report_views.group_summary import GroupSummarySerializer
@report_register()
class GroupSummaryAdmin(ReportAdminBase):
    model_name = 'groupSummaryReport'
    view_name = 'group_summary_report'
    template = 'att/report_new/groupsummaryreport.html'
    api_view = GroupSummaryViewSet
    serializer = GroupSummarySerializer
    data_source = '/att/api/groupSummaryReport/'
    required_group_wise = True
    list_display = ('group_code', 'group_name', 'total_emp', 'total_late_times', 'total_early_leave_times', 'total_absent_times')
    hidden_fields = ()
    sort_fields = ('group_name',)
    add_paycode_column = True