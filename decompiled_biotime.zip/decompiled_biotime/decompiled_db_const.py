# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\db_const.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

__author__ = 'Arvin'
import os
import datetime
from django.conf import settings
from django.core.files.storage import FileSystemStorage
MAX_ATT_RULE_ALIAS = 50
MAX_COMPANY_NAME = 200
MAX_ESTD_ID = 100
MAX_AGENT_ID = 100
MAX_TIME_INTERVAL_ALIAS = 50
MAX_COLOR_SETTING = 30
MAX_SHIFT_ALIAS = 50
MAX_BREAK_TIME_ALIAS = 50
MAX_APPLY_REASON = 200
MAX_AUDIT_REASON = 200
MAX_APPROVER_NAME = 50
MAX_LEAVE_ALIAS = 50
MAX_HOLIDAY_ALIAS = 50
MAX_TRAINING_ALIAS = 50
APP_LABEL = 'att'
WEEK = {'monday': '0', 'tuesday': '1', 'wednesday': '2', 'thursday': '3', 'friday': '4', 'saturday': '5', 'sunday': '6'}
CALC_KEYS = ('check_in', 'check_out', 'break_out', 'break_in', 'overtime_in', 'overtime_out')
ATTACH_STORAGE = FileSystemStorage(location=os.path.relpath(settings.ADDITION_FILE_ROOT), base_url='/files/')
def upload_attachment_path(instance, filename):
    if not isinstance(instance.apply_time, datetime.datetime):
        instance.apply_time = datetime.datetime.now()
    new_file_name = '%s_%s.%s' % (instance.employee.emp_code, instance.apply_time.strftime('%Y%m%d%H%M%S'), filename.split('.')[(-1)])
    file_path = os.path.join('attachment', instance._meta.model_name, new_file_name)
    try:
        os.unlink(os.path.join(settings.ADDITION_FILE_ROOT, file_path))
    except Exception:
        pass
    return file_path