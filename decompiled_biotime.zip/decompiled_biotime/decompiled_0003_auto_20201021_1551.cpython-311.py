# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0003_auto_20201021_1551.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:12 UTC (1750702692)

from __future__ import unicode_literals
from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('accounts', '0002_auto_20200901_1642')]
    operations = [migrations.AlterModelOptions(name='userprofile', options={'default_permissions': (), 'permissions': (('enter_system_module', 'can_enter_menu_system_module'), ('enter_personnel_module', 'can_enter_personnel_module'), ('enter_terminal_module', 'can_enter_terminal_module'), ('enter_attendance_module', 'can_enter_attendance_module'), ('enter_payroll_module', 'can_enter_payroll_module'), ('enter_access_module', 'can_enter_access_module'), ('enter_visitor_module', 'can_enter_visitor_module'), ('enter_meeting_module', 'can_enter_meeting_module'), ('enter_ep_module', 'can_enter_ep_module')), 'verbose_name': 'base_model_userProfile', 'verbose_name_plural': 'base_model_userProfile'})]