# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\actions\\announcement_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

import datetime
from django.forms import ValidationError
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
from mysite.mobile.choices import PUBLIC_ANNOUNCEMENT, PRIVATE_ANNOUNCEMENT
from mysite.mobile.models import Announcement
from mysite.personnel.widgets import EmployeeManyToManyMiddleWidget
from mysite.base.models import EventAlertSetting
class AddPublicNoticeForm(forms.ZKActionForm):
    subject = forms.CharField(label=_('announcement_filed_subject'), required=True)
    content = forms.TextField(label=_('announcement_filed_content'), required=True)
    def clean(self):
        cleaned_data = super(AddPublicNoticeForm, self).clean()
        data_pre_check(self, cleaned_data)
        return cleaned_data
class AddPrivateNoticeForm(forms.ZKActionForm):
    employee = forms.EmployeeManyToManyField(label=_('announcement_filed_emp'), required=False, widget=EmployeeManyToManyMiddleWidget)
    subject = forms.CharField(label=_('announcement_filed_subject'), required=True)
    content = forms.TextField(label=_('announcement_filed_content'), required=True)
    def clean(self):
        cleaned_data = super(AddPrivateNoticeForm, self).clean()
        data_pre_check(self, cleaned_data, True)
        return cleaned_data
class AddPublicNotice(ZKModelAction):
    verbose_name = _('mobile_action_publicNotice')
    help_text = _('mobile_action_publicNoticeHelpTxt')
    short_description = _('mobile_action_publicNoticeDescription')
    action_form = AddPublicNoticeForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        instance = Announcement(category=PUBLIC_ANNOUNCEMENT, subject=data.get('subject', ''), content=data.get('content', ''), admin=self.request.user, system_sender=self.request.user.username, create_time=datetime.datetime.now())
        instance.save(force_insert=True)
class AddPrivateNotice(ZKModelAction):
    verbose_name = _('mobile_action_privateNotice')
    help_text = _('mobile_action_privateNoticeHelpTxt')
    short_description = _('mobile_action_privateNoticeDescription')
    action_form = AddPrivateNoticeForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        now = datetime.datetime.now()
        employees = data.get('employee', [])
        for emp in employees:
            instance = Announcement(category=PRIVATE_ANNOUNCEMENT, subject=data.get('subject', ''), content=data.get('content', ''), receiver_id=emp, admin=self.request.user, system_sender=self.request.user.username, create_time=now)
            instance.save(force_insert=True)
def data_pre_check(self, cleaned_data, private=False):
    content = cleaned_data.get('content')
    subject = cleaned_data.get('subject')
    if private:
        emp_ids = self.data.getlist('employee', None)
        if not emp_ids:
            raise ValidationError(_('select_employee'), code='-1')
    if not subject:
        raise ValidationError(_('title_required'), code='-1')
    else:
        if not content:
            raise ValidationError(_('content_required'), code='-1')