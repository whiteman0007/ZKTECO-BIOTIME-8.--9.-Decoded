# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\api\\serializers\\employee_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

import datetime
import json
from django.contrib.auth.hashers import make_password
from django.db.models import Count
from rest_framework import serializers
from django.core.cache import cache
from django.conf import settings
from mysite._utils import getattr_ex
from mysite.att.models.model_attemployee import AttEmployee
from mysite.personnel import db_const
from mysite.personnel.models.model_area import Area
from mysite.personnel.models.model_department import Department
from mysite.personnel.models.model_employee import Employee
from mysite.personnel.models.model_position import Position
from mysite.personnel.models.model_resign import Resign
from mysite.personnel.models.model_company import Company
from mysite.personnel.models.model_employee_customattribute import EmployeeCustomAttribute
from mysite.personnel.models.model_employee_extrainfo import EmployeeExtraInfo
from mysite.personnel.models.model_employment import Employment
from mysite.mobile.api.serializers import EmployeeSerializer
from mysite.api.serializers import FormatDateField
from mysite.utils import get_dt4mssql
class EmploymentSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer()
    class Meta:
        model = Employment
        fields = ('id', 'employee', 'employment_type', 'start_date', 'end_date', 'active_time', 'inactive_time')
class SimpleEmployeeSerializer(serializers.ModelSerializer):
    dept_name = serializers.CharField(source='department.dept_name', allow_null=True, default='')
    position_name = serializers.CharField(source='position.position_name', allow_null=True, default='')
    company_name = serializers.CharField(source='company.company_name', allow_null=True, default='')
    format_name = serializers.SerializerMethodField()
    full_name = serializers.SerializerMethodField()
    hire_date = serializers.SerializerMethodField()
    def get_hire_date(self, obj):
        return get_dt4mssql(obj.hire_date, 1)
    def get_format_name(self, obj):
        return '{code} {name}'.format(code=obj.emp_code, name=obj.first_name or '')
    def get_full_name(self, obj):
        return '{first} {last}'.format(first=obj.first_name or '', last=obj.last_name or '')
    class Meta:
        model = Employee
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'format_name', 'full_name', 'hire_date', 'dept_name', 'department', 'position', 'position_name', 'company_name')
class EmployeeWithPhotoSerializer(serializers.ModelSerializer):
    photo = serializers.SerializerMethodField()
    department_name = serializers.CharField(source='department.dept_name', default='')
    position_name = serializers.CharField(source='position.position_name', default='')
    def get_photo(self, obj):
        if not obj.photo:
            return ''
        else:
            import os
            from mysite.tools.access_utils import get_access_token
            file_path = str(obj.photo.name)
            filename = os.path.basename(file_path)
            access_token = get_access_token({'n': filename, 'p': file_path})
            if settings.ENABLE_ENCRYPT_PHOTO:
                return '/auth_files/{path}'.format(path=access_token)
            else:
                return '/files/{path}'.format(path=access_token)
    class Meta:
        model = Employee
        fields = ('id', 'emp_code', 'first_name', 'email', 'mobile', 'photo', 'department_name', 'position_name')
class EmployeeTreeDataSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()
    def get_name(self, obj):
        return '{code} {name}'.format(code=obj.emp_code, name=obj.first_name or '')
    class Meta:
        model = Employee
        fields = ('id', 'name')
class EmployeeFilterSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source='company.company_name', allow_null=True, default='')
    dept_name = serializers.CharField(source='department.dept_name', allow_null=True)
    area_name = serializers.SerializerMethodField()
    position_name = serializers.CharField(source='position.position_name', allow_null=True)
    hire_date = FormatDateField()
    filter_fields = ('department',)
    def get_area_name(self, obj):
        areas = obj.area.all()
        if areas:
            return ','.join([area.area_name for area in areas])
        else:
            return None
    class Meta:
        model = Employee
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'hire_date', 'dept_name', 'department', 'position', 'position_name', 'area', 'area_name', 'email', 'company_name')
class PositionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Position
        fields = ['id', 'position_code', 'position_name']
class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'dept_code', 'dept_name']
class AreaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Area
        fields = ['id', 'area_code', 'area_name']
class AttEmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttEmployee
        fields = ['id', 'enable_attendance', 'enable_overtime', 'enable_holiday', 'enable_schedule']
class EmployeeCodeNameSerializer(serializers.ModelSerializer):
    format_name = serializers.SerializerMethodField()
    full_name = serializers.SerializerMethodField()
    def get_format_name(self, obj):
        return '{code} {name}'.format(code=obj.emp_code, name=obj.first_name or '')
    def get_full_name(self, obj):
        return '{first} {last}'.format(first=obj.first_name or '', last=obj.last_name or '')
    class Meta:
        model = Employee
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'format_name', 'full_name')
class EmployeeSerializer(serializers.ModelSerializer):
    photo = serializers.SerializerMethodField()
    department = DepartmentSerializer()
    position = PositionSerializer()
    area = AreaSerializer(many=True)
    attemployee = AttEmployeeSerializer()
    fingerprint = serializers.SerializerMethodField()
    face = serializers.SerializerMethodField()
    palm = serializers.SerializerMethodField()
    vl_face = serializers.SerializerMethodField()
    vl_palm = serializers.SerializerMethodField()
    vl_face_photo = serializers.SerializerMethodField()
    format_name = serializers.SerializerMethodField()
    full_name = serializers.SerializerMethodField()
    hire_date = serializers.SerializerMethodField()
    def get_hire_date(self, obj):
        return get_dt4mssql(obj.hire_date, 1)
    class Meta:
        model = Employee
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'nickname', 'format_name', 'photo', 'full_name', 'device_password', 'card_no', 'department', 'position', 'hire_date', 'gender', 'birthday', 'verify_mode', 'emp_type', 'contact_tel', 'office_tel', 'mobile', 'national', 'city', 'address', 'postcode', 'email', 'enroll_sn', 'ssn', 'religion', 'attemployee', 'dev_privilege', 'area', 'app_status', 'app_role', 'update_time', 'fingerprint', 'face', 'palm', 'vl_face', 'vl_palm', 'vl_face_photo']
    def get_fields(self):
        data_dict = super().get_fields()
        custom_fields = EmployeeCustomAttribute.objects.filter(enable=True).values('id', 'attr_name')
        self.custom_attribute = {str(i['id']): i['attr_name'] for i in custom_fields}
        for k, v in self.custom_attribute.items():
            data_dict[v] = serializers.CharField(allow_blank=True, allow_null=True, max_length=128, required=False)
        return data_dict
    def to_representation(self, instance):
        dict_data = super().to_representation(instance)
        extra_info = EmployeeExtraInfo.objects.filter(employee=instance).first()
        if extra_info:
            value = json.loads(extra_info.value)
            value = {self.custom_attribute[k]: v for k, v in value.items() if self.custom_attribute.get(k)}
            dict_data.update(value)
        return dict_data
    def get_format_name(self, obj):
        return '{code} {name}'.format(code=obj.emp_code, name=obj.first_name or '')
    def get_full_name(self, obj):
        return '{first} {last}'.format(first=obj.first_name or '', last=obj.last_name or '')
    def get_photo(self, obj):
        if not obj.photo:
            return ''
        else:
            import os
            from mysite.tools.access_utils import get_access_token
            file_path = str(obj.photo.name)
            filename = os.path.basename(file_path)
            access_token = get_access_token({'n': filename, 'p': file_path})
            if settings.ENABLE_ENCRYPT_PHOTO:
                return '/auth_files/{path}'.format(path=access_token)
            else:
                return '/files/{path}'.format(path=access_token)
    def get_fingerprint(self, obj):
        bios = obj.biodata_set.filter(bio_type=1).values_list('major_ver').annotate(Count('id'))
        if bios:
            output = ','.join(['Ver %s:%s' % bio for bio in bios])
            return output
        else:
            return '-'
    def get_face(self, obj):
        bios = obj.biodata_set.filter(bio_type=2).values_list('major_ver').annotate(Count('id'))
        if bios:
            output = ','.join(['Ver %s:%s' % bio for bio in bios])
            return output
        else:
            return '-'
    def get_palm(self, obj):
        bios = obj.biodata_set.filter(bio_type=8).values_list('major_ver').annotate(Count('id'))
        if bios:
            output = ','.join(['Ver %s:%s' % bio for bio in bios])
            return output
        else:
            return '-'
    def get_vl_face(self, obj):
        bios = obj.biodata_set.filter(bio_type=9).values_list('major_ver').annotate(Count('id'))
        if bios:
            output = ','.join(['Ver %s:%s' % bio for bio in bios])
            return output
        else:
            return '-'
    def get_vl_face_photo(self, obj):
        bios = obj.biophoto_set.filter(approval_state__in=(1, 3)).count()
        return bios or '-'
    def get_vl_palm(self, obj):
        bios = obj.biodata_set.filter(bio_type=10).values_list('major_ver').annotate(Count('id'))
        if bios:
            output = ','.join(['Ver %s:%s' % bio for bio in bios])
            return output
        else:
            return '-'
class EmployeeExportSerializer(serializers.ModelSerializer):
    department = DepartmentSerializer()
    position = PositionSerializer()
    area = AreaSerializer(many=True)
    attemployee = AttEmployeeSerializer()
    class Meta:
        model = Employee
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'nickname', 'device_password', 'card_no', 'department', 'position', 'hire_date', 'gender', 'birthday', 'verify_mode', 'emp_type', 'contact_tel', 'office_tel', 'mobile', 'national', 'city', 'address', 'postcode', 'email', 'enroll_sn', 'ssn', 'religion', 'attemployee', 'dev_privilege', 'self_password', 'flow_role', 'area', 'app_status', 'app_role']
class EmployeeCreateSerializer(serializers.ModelSerializer):
    def validate(self, attrs):
        from mysite.base.models import SystemSetting
        default_password = SystemSetting.get_default_emp_password()
        attrs['app_status'] = attrs.get('app_status', 0)
        if not attrs['app_status']:
            attrs['app_status'] = 0
        attrs['app_role'] = attrs.get('app_role', 1)
        attrs['self_password'] = attrs.get('self_password', default_password)
        if not attrs['self_password']:
            attrs['self_password'] = default_password
        if not attrs['self_password'].startswith('pbkdf2_'):
            attrs['self_password'] = make_password(attrs['self_password'])
        attrs['verify_mode'] = attrs.get('verify_mode', (-1))
        attrs['dev_privilege'] = attrs.get('dev_privilege', 0)
        if not attrs.get('hire_date'):
            attrs['hire_date'] = datetime.date.today()
        if attrs.get('card_no', None):
            emp = Employee.objects.filter(card_no=attrs['card_no']).first()
            if emp:
                raise serializers.ValidationError({'Update Failed': 'Duplicate card number with {emp}'.format(emp=emp.emp_code)})
        if not settings.ENABLE_WDMS and getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
                dept, area_list, company = (attrs.get('department'), attrs.get('area'), attrs.get('company'))
                if dept.company!= company:
                    raise serializers.ValidationError({'Create Failed': 'Mismatched company pk and deparment pk'})
                else:
                    for area in area_list:
                        if area.company!= company:
                            raise serializers.ValidationError({'Create Failed': 'Mismatched company pk and area pk'})
        return attrs
    def get_fields(self):
        data_dict = super().get_fields()
        custom_fields = EmployeeCustomAttribute.objects.filter(enable=True).values('id', 'attr_name')
        self.custom_attribute = {str(i['id']): i['attr_name'] for i in custom_fields}
        for k, v in self.custom_attribute.items():
            data_dict[v] = serializers.CharField(allow_blank=True, allow_null=True, max_length=128, required=False)
        return data_dict
    def create(self, validated_data):
        datas = {}
        for k, v in self.custom_attribute.items():
            data = validated_data.get(v, None)
            if data:
                datas[k] = data
            if v in validated_data:
                validated_data.pop(v)
        datas = json.dumps(datas)
        instance = Employee.objects.filter(emp_code=validated_data['emp_code']).first()
        if not instance:
            instance = super().create(validated_data)
            EmployeeExtraInfo(employee=instance, value=datas).save()
        else:
            instance = super().update(instance, validated_data)
            EmployeeExtraInfo.objects.update(value=datas)
        return instance
    def to_representation(self, instance):
        dict_data = super().to_representation(instance)
        extra_info = EmployeeExtraInfo.objects.filter(employee=instance).first()
        if extra_info:
            value = json.loads(extra_info.value)
            value = {self.custom_attribute[k]: v for k, v in value.items() if self.custom_attribute.get(k)}
            dict_data.update(value)
        return dict_data
    def save(self, *args, **kwagrs):
        cache.set('emp_change_flag', 1)
        return super(EmployeeCreateSerializer, self).save(*args, **kwagrs)
    class Meta:
        model = Employee
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'nickname', 'device_password', 'card_no', 'department', 'position', 'hire_date', 'gender', 'birthday', 'verify_mode', 'emp_type', 'contact_tel', 'office_tel', 'mobile', 'national', 'city', 'address', 'postcode', 'email', 'enroll_sn', 'ssn', 'religion', 'dev_privilege', 'self_password', 'flow_role', 'area', 'app_status', 'app_role']
        extra_kwargs = {'department': {'required': True, 'allow_null': False, 'help_text': 'Department ForeignKey'}, 'area': {'help_text': 'ManyToManyField'}, 'hire_date': {'help_text': 'Default today'}, 'verify_mode': {'help_text': ''}, 'emp_type': {'help_text': ';'.join([str(i) for i in db_const.EMPTYPE_CHOICES])}, 'dev_privilege': {'help_text': ';'.join([str(i) for i in db_const.APP_STATUS])}, 'app_status': {'help_text': ';'.join([str(i) for i in db_const.APP_ROLE])}}
class EmployeeEditSerializer(serializers.ModelSerializer):
    def validate(self, attrs):
        if attrs.get('self_password') is not None and (not attrs['self_password'].startswith('pbkdf2_')):
                attrs['self_password'] = make_password(attrs['self_password'])
        attrs['update_time'] = datetime.datetime.now()
        attrs['enroll_sn'] = ''
        if attrs.get('card_no'):
            emp = Employee.objects.filter(card_no=attrs['card_no']).exclude(id=self.instance.id).first()
            if emp:
                raise serializers.ValidationError({'Update Failed': 'Duplicate card number with {emp}'.format(emp=emp.emp_code)})
        if not settings.ENABLE_WDMS and getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
                dept, area_list, company = (attrs.get('department'), attrs.get('area'), attrs.get('company'))
                if dept.company!= company:
                    raise serializers.ValidationError({'Update Failed': 'Mismatched company pk and deparment pk'})
                else:
                    for area in area_list:
                        if area.company!= company:
                            raise serializers.ValidationError({'Update Failed': 'Mismatched company pk and area pk'})
        return attrs
    def save(self, *args, **kwagrs):
        cache.set('emp_change_flag', 1)
        return super(EmployeeEditSerializer, self).save(*args, **kwagrs)
    def to_representation(self, instance):
        dict_data = super().to_representation(instance)
        extra_info = EmployeeExtraInfo.objects.filter(employee=instance).first()
        if extra_info:
            value = json.loads(extra_info.value)
            value = {self.custom_attribute[k]: v for k, v in value.items() if self.custom_attribute.get(k)}
            dict_data.update(value)
        return dict_data
    def update(self, instance, validated_data):
        instance = super().update(instance, validated_data)
        datas = {}
        for k, v in self.custom_attribute.items():
            data = self.validated_data.get(v, None)
            if data:
                datas[k] = data
            if v in validated_data:
                self.validated_data.pop(v)
        datas = json.dumps(datas)
        EmployeeExtraInfo.objects.update_or_create(employee=instance, defaults={'value': datas})
        return instance
    def get_fields(self):
        data_dict = super().get_fields()
        custom_fields = EmployeeCustomAttribute.objects.filter(enable=True).values('id', 'attr_name')
        self.custom_attribute = {str(i['id']): i['attr_name'] for i in custom_fields}
        for k, v in self.custom_attribute.items():
            data_dict[v] = serializers.CharField(allow_blank=True, allow_null=True, max_length=128, required=False)
        return data_dict
    class Meta:
        model = Employee
        fields = ['emp_code', 'first_name', 'last_name', 'nickname', 'device_password', 'card_no', 'department', 'position', 'hire_date', 'gender', 'birthday', 'verify_mode', 'emp_type', 'contact_tel', 'office_tel', 'mobile', 'national', 'city', 'address', 'postcode', 'email', 'enroll_sn', 'ssn', 'religion', 'dev_privilege', 'self_password', 'flow_role', 'area', 'app_status', 'app_role']
        extra_kwargs = {'emp_code': {'read_only': True}}
class EmployeeBatchSerializer(serializers.Serializer):
    employees = serializers.ListField(child=serializers.IntegerField())
    def validate_employees(self, employees):
        employees = list(set(employees))
        for employee in employees:
            if not Employee.objects.filter(id=employee).exists():
                raise serializers.ValidationError({'employees': 'Invalid pk \"%s\" - object does not exist.' % employee})
        return employees
class EmployeeAdjustDepartmentSerializer(EmployeeBatchSerializer):
    department = serializers.IntegerField()
    def validate_department(self, department):
        if not Department.objects.filter(id=department).exists():
            raise serializers.ValidationError({'department': 'Invalid pk \"%s\" - object does not exist.' % department})
        else:
            return department
class EmployeeAdjustPositionSerializer(EmployeeBatchSerializer):
    position = serializers.IntegerField()
    def validate_position(self, position):
        if not Position.objects.filter(id=position).exists():
            raise serializers.ValidationError({'position': 'Invalid pk \"%s\" - object does not exist.' % position})
        else:
            return position
class EmployeeAdjustAreaSerializer(EmployeeBatchSerializer):
    areas = serializers.ListField(child=serializers.IntegerField())
    def validate_areas(self, areas):
        areas = list(set(areas))
        for area in areas:
            if not Area.objects.filter(id=area).exists():
                raise serializers.ValidationError({'areas': 'Invalid pk \"%s\" - object does not exist.' % area})
        return areas
class EmployeeAdjustEmptypeSerializer(EmployeeBatchSerializer):
    emp_type = serializers.ChoiceField(choices=db_const.EMPTYPE_CHOICES, help_text=';'.join([str(choice) for choice in db_const.EMPTYPE_CHOICES]))
class EmployeeAdjustResignSerializer(EmployeeBatchSerializer):
    resign_date = serializers.DateField()
    resign_type = serializers.ChoiceField(choices=db_const.LEAVETYPE)
    reason = serializers.CharField()
    disableatt = serializers.BooleanField()
    def validate_employees(self, employees):
        employees = list(set(employees))
        for employee in employees:
            if not Employee.objects.filter(id=employee).exists():
                raise serializers.ValidationError({'employees': 'Invalid pk \"%s\" - object does not exist.' % employee})
            else:
                if Resign.objects.filter(employee_id=employee).exists():
                    raise serializers.ValidationError({'employees': 'Employee \"%s\" exist in resign.' % employee})
        return employees
class EmployeeDelbiotemplateSerializer(EmployeeBatchSerializer):
    finger_print = serializers.BooleanField(default=False)
    face = serializers.BooleanField(default=False)
    finger_vein = serializers.BooleanField(default=False)
    palm = serializers.BooleanField(default=False)
class EmployeeResyncToDeviceSerializer(EmployeeBatchSerializer):
    # return None
    pass
class ApprovalApplierSerializer(serializers.ModelSerializer):
    e_department = serializers.CharField(source='department.dept_name')
    e_position = serializers.CharField(source='position.position_name', allow_null=True)
    class Meta:
        model = Employee
        fields = ('emp_code', 'first_name', 'last_name', 'e_department', 'e_position')
class ApprovalApproverAndNotifier(serializers.ModelSerializer):
    r_emp_code = serializers.CharField(source='emp_code')
    r_first_name = serializers.CharField(source='first_name')
    r_last_name = serializers.CharField(source='last_name')
    r_department = serializers.CharField(source='department.dept_name')
    r_position = serializers.CharField(source='position.position_name', allow_null=True)
    class Meta:
        model = Employee
        fields = ('r_emp_code', 'r_first_name', 'r_last_name', 'r_department', 'r_position')
class DeviceRelatedSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = ('emp_code', 'first_name', 'last_name', 'enroll_sn', 'card_no', 'dev_privilege', 'verify_mode')
class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'company_code', 'company_name']
class WDMSEmployeeSerializer(EmployeeSerializer):
    company = CompanySerializer()
    class Meta:
        model = Employee
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'nickname', 'format_name', 'photo', 'device_password', 'card_no', 'company', 'department', 'area', 'position', 'hire_date', 'gender', 'birthday', 'verify_mode', 'emp_type', 'contact_tel', 'office_tel', 'mobile', 'national', 'city', 'address', 'postcode', 'email', 'enroll_sn', 'ssn', 'religion', 'attemployee', 'dev_privilege', 'app_status', 'app_role', 'update_time', 'fingerprint', 'face', 'palm', 'vl_face']
class WDMSEmployeeCreateSerializer(EmployeeCreateSerializer):
    def validate(self, attrs):
        sub_attrs = super().validate(attrs)
        dept, area_list, company = (sub_attrs.get('department'), sub_attrs.get('area'), sub_attrs.get('company'))
        if dept.company!= company:
            raise serializers.ValidationError({'Create Failed': 'Mismatched company pk and deparment pk'})
        else:
            for area in area_list:
                if area.company!= company:
                    raise serializers.ValidationError({'Create Failed': 'Mismatched company pk and area pk'})
            return sub_attrs
    class Meta:
        model = Employee
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'nickname', 'device_password', 'card_no', 'department', 'position', 'hire_date', 'gender', 'birthday', 'verify_mode', 'emp_type', 'contact_tel', 'office_tel', 'mobile', 'national', 'city', 'address', 'postcode', 'email', 'enroll_sn', 'ssn', 'religion', 'dev_privilege', 'self_password', 'flow_role', 'area', 'company', 'app_status', 'app_role']
        extra_kwargs = {'department': {'required': True, 'allow_null': False, 'help_text': 'Department ForeignKey'}, 'area': {'help_text': 'ManyToManyField'}, 'company': {'required': False, 'allow_null': False, 'help_text': 'Company ForeignKey'}, 'hire_date': {'help_text': 'Default today'}, 'verify_mode': {'help_text': ''}, 'emp_type': {'help_text': ';'.join([str(i) for i in db_const.EMPTYPE_CHOICES])}, 'dev_privilege': {'help_text': ';'.join([str(i) for i in db_const.APP_STATUS])}, 'app_status': {'help_text': ';'.join([str(i) for i in db_const.APP_ROLE])}}
class WDMSEmployeeEditSerializer(EmployeeEditSerializer):
    def validate(self, attrs):
        sub_attrs = super().validate(attrs)
        dept, area_list, company = (sub_attrs.get('department'), sub_attrs.get('area'), sub_attrs.get('company'))
        if dept.company!= company:
            raise serializers.ValidationError({'Create Failed': 'Mismatched company pk and deparment pk'})
        else:
            for area in area_list:
                if area.company!= company:
                    raise serializers.ValidationError({'Create Failed': 'Mismatched company pk and area pk'})
            return sub_attrs
    class Meta:
        model = Employee
        fields = ['emp_code', 'first_name', 'last_name', 'nickname', 'device_password', 'card_no', 'department', 'position', 'hire_date', 'gender', 'birthday', 'verify_mode', 'emp_type', 'contact_tel', 'office_tel', 'mobile', 'national', 'city', 'address', 'postcode', 'email', 'enroll_sn', 'ssn', 'religion', 'dev_privilege', 'self_password', 'flow_role', 'area', 'company', 'app_status', 'app_role']
        extra_kwargs = {'emp_code': {'read_only': True}}
class WDMSEmployeeAdjustDepartmentSerializer(EmployeeAdjustDepartmentSerializer):
    def validate_department(self, department):
        dept = Department.objects.get(id=super().validate_department(department))
        emps_list = self.initial_data.get('employees')
        emps = Employee.objects.filter(id__in=emps_list)
        for emp in emps:
            if emp.company!= dept.company:
                raise serializers.ValidationError({'Adjust Failed': 'Invalid department pk \"%s\" - object does not belong to current employee company.' % dept.pk})
        return department
class WDMSEmployeeAdjustAreaSerializer(EmployeeAdjustAreaSerializer):
    def validate_areas(self, areas):
        tmp_areas = Area.objects.filter(id__in=super().validate_areas(areas))
        emps_list = self.initial_data.get('employees')
        emps = Employee.objects.filter(id__in=emps_list)
        for emp in emps:
            for area in tmp_areas:
                if emp.company!= area.company:
                    raise serializers.ValidationError({'Adjust Failed': 'Invalid area pk \"%s\" - object does not belong to current employee company.' % area.pk})
        return areas
class WDMSEmployeeAdjustPositionSerializer(EmployeeAdjustPositionSerializer):
    def validate_position(self, position):
        pson = Position.objects.get(id=super().validate_position(position))
        emps_list = self.initial_data.get('employees')
        emps = Employee.objects.filter(id__in=emps_list)
        for emp in emps:
            if emp.company!= pson.company:
                raise serializers.ValidationError({'Adjust Failed': 'Invalid department pk \"%s\" - object does not belong to current employee company.' % pson.pk})
        return position