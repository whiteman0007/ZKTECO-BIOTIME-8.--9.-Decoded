# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0008_auto_20220106_1103.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('personnel', '0007_auto_20211201_1602')]
    operations = [migrations.AlterField(model_name='employee', name='emp_code_digit', field=models.BigIntegerField(blank=True, null=True, verbose_name='emp_field_employeeCode'))]