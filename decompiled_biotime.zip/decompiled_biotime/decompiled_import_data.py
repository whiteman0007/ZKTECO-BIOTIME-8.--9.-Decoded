# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\import_data.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import types
import codecs
from datetime import datetime
import xlrd
from django.db import IntegrityError
from django.db import connection
from django.db.models.fields import AutoField
from django.utils.translation import gettext_lazy as _
from xlrd import xldate_as_tuple
from mysite.admin.utils import get_model
class ImportData(object):
    def __init__(self, req, input_name='import_data', app_label=None, model_name=None):
        """初始化基础类"""
        self.input_name = 'import_data'
        self.valid_format = ['xls', 'csv', 'txt']
        self.request = req
        self.head = None
        self.records = []
        self.format = None
        self.upload_file = None
        self.app_label = None
        self.model_name = model_name
        self.model_cls = None
        self.error_info = []
        self.valid_head_indexs = []
        self.valid_model_fields = []
        self.other_fields = []
        self.calculate_fields_verbose = []
        self.calculate_fields_index = {}
        self.must_fields = []
        self.current_dbtype = 'sqlserver_ado'
        self.input_name = input_name
        self.need_read_data = True
        self.need_update_old_record = self.request.POST['import_type']
        self.sql_batch_cnts = 80
        if self.need_update_old_record == '0':
            self.need_update_old_record = False
        else:
            self.need_update_old_record = bool(self.need_update_old_record)
        if app_label and model_name:
            self.model_cls = get_model(app_label, model_name)
        else:
            self.error_info.append('%s' % _('module_parameter_error'))
        self.task_id = self.request.POST.get('task_id', 'unknown')
    def validate_format(self):
        """验证文件格式,True标示验证成功，False标示验证失败"""
        ret = True
        if self.request.FILES:
            f = self.request.FILES['import_file']
            f_format = str(f).split('.')
            format_list = ['txt', 'xls', 'csv', 'xlsx']
            if f_format[(-1)].lower() not in format_list:
                self.error_info.append('%s' % _('invalid_file_format'))
            else:
                try:
                    format_list.index(str(f_format[(-1)].lower()))
                    self.format = f_format[(-1)].lower()
                    self.upload_file = f
                except:
                    ret = False
                    self.error_info.append('%s' % _('invalid_file_format'))
        else:
            ret = False
            self.error_info.append('%s' % _('please_select_file'))
        return ret
    def get_file_data(self):
        """得到文件的头部数据和记录"""
        ret = True
        if self.format == 'xls':
            ret = self.xls_read()
        if self.format == 'txt':
            ret = self.txt_read()
        if self.format == 'csv':
            ret = self.csv_read()
        if self.format == 'xlsx':
            ret = self.xls_read()
        return ret
    def check_must_fields(self):
        if self.must_fields:
            for e in self.must_fields:
                flag = False
                for elem in self.head:
                    if elem == e:
                        flag = True
                        break
                if flag:
                    flag = False
                else:
                    self.error_info.append('%(nd)s' % {'nd': _('the_%(index)s_field_is_requird') % {'index': e}})
                    return False
        return True
    def xls_read(self):
        # irreducible cflow, using cdg fallback
        """读xls数据"""
        fd = self.upload_file.read()
        book = xlrd.open_workbook(file_contents=fd)
            except Exception as e:
                    import traceback
                    traceback.print_exc()
                    self.error_info.append('%s' % _('invalid_file_format:%(index)s') % {'index': e})
                        return
                            self.upload_file.close()
                if book.nsheets!= 1:
                    self.error_info.append('%s' % _('file_sheet_shoulb_be_one'))
                    return False
                else:
                    sh = book.sheet_by_index(0)
                    sh_data = []
                    if sh.nrows < 2:
                        self.error_info.append('%s' % _('file_data_must_be_more_than_two'))
                        return False
                    else:
                        for i in range(sh.nrows):
                            row = []
                            for j in range(sh.ncols):
                                ctype = sh.cell(i, j).ctype
                                v = sh.cell_value(rowx=i, colx=j)
                                if ctype == 2 and v % 1 == 0:
                                    v = int(v)
                                else:
                                    if ctype == 3:
                                        date = datetime(*xldate_as_tuple(v, 0))
                                        v = date.strftime('%Y-%m-%d')
                                    else:
                                        if ctype == 4:
                                            v = True if v == 1 else False
                                if type(v) in (int, float):
                                    v = int(v)
                                row.append('%s' % v)
                            if i == 0:
                                self.head = row
                                self.mapping_model()
                                if not self.valid_head_indexs:
                                    self.error_info.append('%s' % _('no_matched_fields'))
                                    return False
                                else:
                                    ret = self.check_must_fields()
                                    if not ret:
                                        return False
                            else:
                                sh_data.append(row)
                        self.records = sh_data
                        return True
    def simple_read(self, split_char=['\t', ',']):
        # irreducible cflow, using cdg fallback
        """默认txt,csv只支持\t隔开,这个可以根据自己的需要自己重写"""
        records = []
        all_data = self.upload_file.read().strip()
        if not isinstance(all_data, str):
            try:
                all_data = all_data.decode('utf-8-sig')
            except:
                all_data = all_data.decode('gb18030')
        if not all_data:
            self.error_info.append('%s' % _('file_data_cannot_be_empty'))
                return
                self.upload_file.close()
            rows = all_data.split('\r\n')
            if len(rows) < 2:
                self.error_info.append('%s' % _('file_data_must_be_more_than_two'))
                    return False
                for index in range(len(rows)):
                        if rows[index].find(split_char[1])!= (-1):
                            split_str = split_char[1]
                        else:
                            split_str = split_char[0]
                        row_list = rows[index].strip().split(split_str)
                        if index == 0:
                            self.head = [e.strip() for e in rows[index].strip(str(codecs.BOM_UTF8)).split(split_str)]
                            self.mapping_model()
                            ret = self.check_must_fields()
                            if not ret:
                                    self.upload_file.close()
                            records.append(row_list)
                        self.records = records
                        return True
    def txt_read(self):
        """读txt文件"""
        return self.simple_read()
    def csv_read(self):
        """读csv文件"""
        return self.simple_read()
    def insert_data(self):
        # irreducible cflow, using cdg fallback
        from mysite import settings
        if 'mysql' in settings.DATABASE_ENGINE:
            self.current_dbtype = 'mysql'
            return self.mysql_insert()
            if 'sqlserver_ado' in connection.__module__:
                self.current_dbtype = 'sqlserver_ado'
                return self.sqlserver_insert()
                if 'oracle' in connection.__module__:
                    self.current_dbtype = 'oracle'
                    return self.oracle_insert()
                    if 'postgresql_psycopg2' in connection.__module__:
                        self.current_dbtype = 'postgresql_psycopg2'
                        return self.postgresql_insert()
                        self.current_dbtype = 'postgresql_psycopg2'
                        return self.postgresql_insert()
                except Exception as e:
                        import traceback
                        traceback.print_exc()
                        self.error_info.append('%s' % _('there_was_a_database_error_when_importing_please_check_the_validity_of_the_data'))
                            return False
    def get_db_value(self, tmp_field, tmp_value):
        """分析字段和值，得到正确的数据库值"""
        if not tmp_value:
            if tmp_value in (True, False):
                tmp_value = '%s' % int(tmp_value)
            else:
                dfvalue = tmp_field.get_default()
                if dfvalue!= None:
                    tmp_value = '%s' % dfvalue
                else:
                    tmp_value = None
        else:
            tmp_value = '%s' % tmp_value
        return tmp_value
    def get_oracle_db_value(self, tmp_field, tmp_value):
        """分析字段和值，得到正确的数据库值"""
        if not tmp_value:
            if tmp_value in (True, False):
                tmp_value = '%s' % int(tmp_value)
            else:
                dfvalue = tmp_field.get_default()
                if dfvalue!= None:
                    tmp_value = '%s' % dfvalue
                else:
                    tmp_value = None
        else:
            tmp_value = '%s' % tmp_value
        return tmp_value
    def mapping_model(self):
        """找到模型对象的字段对应导入文件中的头的列序号"""
        valid_head_indexs = []
        valid_model_fields = []
        fields = self.model_cls._meta.fields
        other_fields = []
        calculate_fields_index = {}
        for index in range(len(self.head)):
            head_elem = self.head[index].strip()
            if head_elem in self.calculate_fields_verbose and head_elem not in calculate_fields_index:
                    calculate_fields_index[head_elem] = index
            for f in fields:
                if not isinstance(f, AutoField):
                    verbose_name = '%s' % f.verbose_name
                    if verbose_name == head_elem:
                        valid_head_indexs.append(index)
                        valid_model_fields.append(f)
        for f in fields:
            if f not in valid_model_fields and (not isinstance(f, AutoField)):
                    other_fields.append(f)
        self.valid_head_indexs = valid_head_indexs
        self.valid_model_fields = valid_model_fields
        self.other_fields = other_fields
        self.calculate_fields_index = calculate_fields_index
        if self.valid_head_indexs:
            return True
        else:
            return False
    def before_insert(self):
        """插入前的准备,提供给特殊处理"""
        return True
    def records_analysis(self, record_dict):
        """分析插入的数据"""
        return True
    def postgresql_insert(self):
        """sqlserver 数据插入"""
        model_table = self.model_cls._meta.db_table
        v_f_db_names = [e.get_attname_column()[1] for e in self.valid_model_fields]
        o_f_db_names = [e.get_attname_column()[1] for e in self.other_fields]
        cursor = connection.cursor()
        count_head = len(self.head)
        sql_list = []
        for row in self.records:
            row_fields_select = {}
            calculate_dict = {}
            count_v = 0
            for index in range(count_head):
                for k, v in list(self.calculate_fields_index.items()):
                    if v == index:
                        calculate_dict[k] = row[index]
                if index in self.valid_head_indexs:
                    tmp_value = row[index]
                    tmp_field = self.valid_model_fields[count_v]
                    if tmp_field.choices:
                        tv = [e[0] for e in tmp_field.choices if e[1] == tmp_value]
                        if tv:
                            tmp_value = tv[0]
                    key = v_f_db_names[count_v]
                    value = self.get_db_value(tmp_field, tmp_value)
                    if key == 'badgenumber' and (not value):
                        break
                    else:
                        key = '\"' + v_f_db_names[count_v] + '\"'
                        row_fields_select[key] = value
                        count_v = count_v + 1
            count_o = 0
            for f in self.other_fields:
                default_value = f.get_default()
                if default_value == None:
                    default_value = None
                else:
                    if default_value in (True, False):
                        default_value = '%s' % int(default_value)
                    else:
                        default_value = '%s' % default_value
                key = '\"' + o_f_db_names[count_o] + '\"'
                row_fields_select[key] = default_value
                count_o = count_o + 1
            row_fields_select = self.process_row(row_fields_select, calculate_dict)
            sql_list.append(row_fields_select)
            if len(sql_list) == self.sql_batch_cnts:
                cursor = connection.cursor()
                try:
                    self.exe_sqlserver(cursor, model_table, sql_list)
                    cursor.close()
                except:
                    pass
                sql_list = []
        if sql_list:
            try:
                cursor = connection.cursor()
                self.exe_sqlserver(cursor, model_table, sql_list)
                cursor.close()
            except:
                pass
        try:
            connection._commit()
        except:
            return None
    def sqlserver_insert(self):
        """sqlserver 数据插入"""
        model_table = self.model_cls._meta.db_table
        v_f_db_names = [e.get_attname_column()[1] for e in self.valid_model_fields]
        o_f_db_names = [e.get_attname_column()[1] for e in self.other_fields]
        cursor = connection.cursor()
        count_head = len(self.head)
        sql_list = []
        for row in self.records:
            row_fields_select = {}
            calculate_dict = {}
            count_v = 0
            for index in range(count_head):
                for k, v in list(self.calculate_fields_index.items()):
                    if v == index:
                        calculate_dict[k] = row[index]
                if index in self.valid_head_indexs:
                    tmp_value = row[index]
                    tmp_field = self.valid_model_fields[count_v]
                    if tmp_field.choices:
                        tv = [e[0] for e in tmp_field.choices if e[1] == tmp_value]
                        if tv:
                            tmp_value = tv[0]
                    key = v_f_db_names[count_v]
                    value = self.get_db_value(tmp_field, tmp_value)
                    if key == 'badgenumber' and (not value):
                        break
                    else:
                        row_fields_select[key] = value
                        count_v = count_v + 1
            count_o = 0
            for f in self.other_fields:
                default_value = f.get_default()
                if default_value == None:
                    default_value = None
                else:
                    if default_value in (True, False):
                        default_value = '%s' % int(default_value)
                    else:
                        default_value = '%s' % default_value
                key = o_f_db_names[count_o]
                row_fields_select[key] = default_value
                count_o = count_o + 1
            row_fields_select = self.process_row(row_fields_select, calculate_dict)
            sql_list.append(row_fields_select)
            if len(sql_list) == self.sql_batch_cnts:
                self.exe_sqlserver(cursor, model_table, sql_list)
                sql_list = []
        if sql_list:
            self.exe_sqlserver(cursor, model_table, sql_list)
        try:
            connection._commit()
        except:
            return None
    def exe_sqlserver(self, cursor, model_table, sql_list):
        """当批量插入报错后，改为一条一条插入"""
        if get_option('SECURITY_AND_ZKECO') and model_table == 'userinfo':
            INSERT_SQL = 'SET IDENTITY_INSERT userinfo ON;INSERT INTO %(table)s ( %(fields)s ) VALUES ( %(row)s );SET IDENTITY_INSERT userinfo OFF'
        else:
            INSERT_SQL = 'INSERT INTO %(table)s ( %(fields)s ) VALUES ( %(row)s )'
        UPDATE_SQL = 'UPDATE  %(table)s SET %(fields_value)s WHERE %(condition)s'
        update_records = []
        insert_records = sql_list
        ret = {'INSERT_SQL': INSERT_SQL, 'UPDATE_SQL': UPDATE_SQL, 'update_records': update_records, 'insert_records': insert_records, 'sql_list': sql_list, 'model_table': model_table, 'update_old_record': self.need_update_old_record}
        self.records_analysis(ret)
        if ret['insert_records']:
            temp_insert_records = []
            params = []
            multi_sql_params = []
            for record in ret['insert_records']:
                field_count = len(list(record.keys()))
                sql_param = ''
                for i in range(field_count):
                    sql_param += '%s,'
                sql_param = sql_param[:(-1)]
                insert_sql = INSERT_SQL % {'table': model_table, 'fields': ','.join(list(record.keys())), 'row': sql_param}
                param = [v for v in list(record.values())]
                params += param
                multi_sql_params.append(param)
                temp_insert_records.append(insert_sql)
            try:
                insert_sql = ';'.join(temp_insert_records)
                params = tuple(params)
                cursor.execute(insert_sql, params)
            except IntegrityError:
                for i, sql in enumerate(temp_insert_records):
                    try:
                        if multi_sql_params and multi_sql_params[i]:
                                cursor.execute(sql, multi_sql_params[i])
                    except:
                        pass
        if self.need_update_old_record and ret['update_records'] and ret['update_records'][0]:
                    update_records = ret['update_records'] and ret['update_records'][0]
                    params = ret['update_records'] and ret['update_records'][1]
                    multi_params = ret['update_records'] and ret['update_records'][2]
                    try:
                        update_sql = ';'.join(update_records)
                        params = tuple(params)
                        cursor.execute(update_sql, params)
                    except IntegrityError:
                        for i, sql in enumerate(update_records):
                            try:
                                if multi_params and multi_params[i]:
                                        cursor.execute(sql, multi_params[i])
                            except:
                                continue
    def mysql_insert(self):
        """mysql 数据插入"""
        model_table = self.model_cls._meta.db_table
        v_f_db_names = [e.get_attname_column()[1] for e in self.valid_model_fields]
        o_f_db_names = [e.get_attname_column()[1] for e in self.other_fields]
        count_head = len(self.head)
        sql_list = []
        calculate_dict = {}
        insert_keys = []
        for row in self.records:
            row_fields_select = {}
            count_v = 0
            for index in range(count_head):
                for k, v in list(self.calculate_fields_index.items()):
                    if v == index:
                        calculate_dict[k] = row[index]
                if index in self.valid_head_indexs:
                    tmp_value = row[index]
                    tmp_field = self.valid_model_fields[count_v]
                    if tmp_field.choices:
                        tv = [e[0] for e in tmp_field.choices if e[1] == tmp_value]
                        if tv:
                            tmp_value = tv[0]
                    key = v_f_db_names[count_v]
                    value = self.get_db_value(tmp_field, tmp_value)
                    row_fields_select[key] = value
                    count_v = count_v + 1
            count_o = 0
            for f in self.other_fields:
                default_value = f.get_default()
                if default_value == None or default_value == '':
                    default_value = None
                else:
                    if default_value in (True, False):
                        default_value = '%s' % int(default_value)
                    else:
                        default_value = '%s' % default_value
                key = o_f_db_names[count_o]
                row_fields_select[key] = default_value
                count_o = count_o + 1
            row_fields_select = self.process_row(row_fields_select, calculate_dict)
            sql_list.append(row_fields_select)
            if not insert_keys:
                insert_keys = ','.join(list(row_fields_select.keys()))
            if len(sql_list) > 200:
                cursor = connection.cursor()
                self.exe_mysql(cursor, model_table, sql_list)
                cursor.close()
                sql_list = []
        if sql_list:
            cursor = connection.cursor()
            self.exe_mysql(cursor, model_table, sql_list)
            cursor.close()
        try:
            connection._commit()
        except:
            return None
    def exe_mysql(self, cursor, model_table, sql_list):
        """当批量插入报错后，改为一条一条插入"""
        INSERT_SQL = 'INSERT INTO %(table)s ( %(fields)s ) VALUES ( %(row)s )'
        UPDATE_SQL = 'UPDATE  %(table)s SET %(fields_value)s WHERE %(condition)s'
        update_records = []
        insert_records = sql_list
        ret = {'INSERT_SQL': INSERT_SQL, 'UPDATE_SQL': UPDATE_SQL, 'update_records': update_records, 'insert_records': insert_records, 'sql_list': sql_list, 'model_table': model_table, 'update_old_record': self.need_update_old_record}
        self.records_analysis(ret)
        if ret['insert_records']:
            temp_insert_records = []
            params = []
            multi_sql_params = []
            for record in ret['insert_records']:
                field_count = len(list(record.keys()))
                sql_param = ''
                for i in range(field_count):
                    sql_param += '%s,'
                sql_param = sql_param[:(-1)]
                insert_sql = INSERT_SQL % {'table': model_table, 'fields': ','.join(list(record.keys())), 'row': sql_param}
                param = [v for v in list(record.values())]
                params += param
                multi_sql_params.append(param)
                temp_insert_records.append(insert_sql)
            try:
                insert_sql = ';'.join(temp_insert_records)
                params = tuple(params)
                cursor.execute(insert_sql, params)
            except IntegrityError:
                for i, sql in enumerate(temp_insert_records):
                    try:
                        if multi_sql_params and multi_sql_params[i]:
                                cursor.execute(sql, multi_sql_params[i])
                    except:
                        pass
        if self.need_update_old_record and ret['update_records'] and ret['update_records'][0]:
                    update_records = ret['update_records'] and ret['update_records'][0]
                    params = ret['update_records'] and ret['update_records'][1]
                    multi_params = ret['update_records'] and ret['update_records'][2]
                    try:
                        update_sql = ';'.join(update_records)
                        params = tuple(params)
                        cursor.execute(update_sql, params)
                    except IntegrityError:
                        for i, sql in enumerate(update_records):
                            try:
                                if multi_params and multi_params[i]:
                                        cursor.execute(sql, multi_params[i])
                            except:
                                continue
    def oracle_insert(self):
        """oracle 数据插入"""
        model_table = self.model_cls._meta.db_table
        v_f_db_names = [e.get_attname_column()[1] for e in self.valid_model_fields]
        o_f_db_names = [e.get_attname_column()[1] for e in self.other_fields]
        count_head = len(self.head)
        sql_list = []
        calculate_dict = {}
        insert_keys = []
        for row in self.records:
            row_fields_select = {}
            count_v = 0
            for index in range(count_head):
                for k, v in list(self.calculate_fields_index.items()):
                    if v == index:
                        calculate_dict[k] = row[index]
                if index in self.valid_head_indexs:
                    tmp_value = row[index]
                    tmp_field = self.valid_model_fields[count_v]
                    if tmp_field.choices:
                        tv = [e[0] for e in tmp_field.choices if e[1] == tmp_value]
                        if tv:
                            tmp_value = tv[0]
                    key = v_f_db_names[count_v]
                    value = self.get_oracle_db_value(tmp_field, tmp_value)
                    row_fields_select[key] = '%s' % value
                    count_v = count_v + 1
            count_o = 0
            for f in self.other_fields:
                default_value = f.get_default()
                if default_value == None:
                    default_value = None
                else:
                    if default_value in (True, False):
                        default_value = '%s' % int(default_value)
                    else:
                        default_value = '%s' % default_value
                key = o_f_db_names[count_o]
                row_fields_select[key] = default_value
                count_o = count_o + 1
            row_fields_select = self.process_row(row_fields_select, calculate_dict)
            sql_list.append(row_fields_select)
            if not insert_keys:
                insert_keys = ','.join(list(row_fields_select.keys()))
            if len(sql_list) > 200:
                cursor = connection.cursor()
                self.exe_oracle(cursor, model_table, sql_list)
                cursor.close()
                sql_list = []
        if sql_list:
            cursor = connection.cursor()
            self.exe_oracle(cursor, model_table, sql_list)
            cursor.close()
        try:
            connection._commit()
        except:
            return None
    def exe_oracle(self, cursor, model_table, sql_list):
        """当批量插入报错后，改为一条一条插入"""
        INSERT_SQL = 'INSERT INTO %(table)s ( %(fields)s ) VALUES ( %(row)s )'
        UPDATE_SQL = 'UPDATE  %(table)s SET %(fields_value)s WHERE %(condition)s'
        update_records = []
        insert_records = sql_list
        ret = {'INSERT_SQL': INSERT_SQL, 'UPDATE_SQL': UPDATE_SQL, 'update_records': update_records, 'insert_records': insert_records, 'sql_list': sql_list, 'model_table': model_table, 'update_old_record': self.need_update_old_record}
        self.records_analysis(ret)
        if ret['insert_records']:
            temp_insert_records = []
            params = []
            multi_sql_params = []
            for record in ret['insert_records']:
                field_count = len(list(record.keys()))
                sql_param = ''
                for i in range(field_count):
                    sql_param += '%s,'
                sql_param = sql_param[:(-1)]
                insert_sql = INSERT_SQL % {'table': model_table, 'fields': ','.join(list(record.keys())), 'row': sql_param}
                param = [v for v in list(record.values())]
                params += param
                multi_sql_params.append(tuple(param))
                temp_insert_records.append(insert_sql)
            try:
                cursor.executemany(insert_sql, multi_sql_params)
            except IntegrityError:
                for i, sql in enumerate(temp_insert_records):
                    try:
                        if multi_sql_params and multi_sql_params[i]:
                                cursor.execute(sql, multi_sql_params[i])
                    except:
                        pass
        if not self.need_update_old_record or ret['update_records']:
                if ret['update_records'][0]:
                    update_records = ret['update_records'] and ret['update_records'][0]
                    params = ret['update_records'] and ret['update_records'][1]
                    multi_params = ret['update_records'] and ret['update_records'][2]
                    try:
                        update_sql = ret['update_records'][0][0]
                        cursor.executemany(update_sql, multi_params)
                    except IntegrityError:
                        for i, sql in enumerate(update_records):
                            try:
                                if multi_params and multi_params[i]:
                                        cursor.execute(sql, multi_params[i])
                            except:
                                continue
    def after_insert(self):
        """插入之后"""
        return True
    def process_row(self, row_data, calculate_dict):
        """特殊情况给开发人员提供的接口"""
        return row_data
    def postgresql(self):
        """postgresql 数据插入"""
        return
    def exe_import_data(self):
        """导入默认流程,成功返回True,不成功返回False,错误信息存储在error_info列表中"""
        if self.error_info:
            return False
        else:
            if self.need_read_data:
                self.validate_format()
                if self.error_info:
                    return False
                else:
                    self.get_file_data()
                    if self.error_info:
                        return False
            self.before_insert()
            if self.error_info:
                return False
            else:
                self.insert_data()
                if self.error_info:
                    return False
                else:
                    self.after_insert()
                    if self.error_info:
                        return False