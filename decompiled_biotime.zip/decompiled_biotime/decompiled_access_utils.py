# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\tools\\access_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import base64
import datetime
import json
from django.conf import settings
def fill_buffer(buf: bytes, size: int=16):
    missing_padding = len(buf) % size
    res = buf
    if missing_padding!= 0:
        res += b'\x00' * (size - missing_padding)
    return res
def aes_encrypt(content: str | bytes) -> str:
    """"""
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
    if isinstance(content, bytes):
        buf = content
    else:
        buf = bytes(str(content), 'utf-8')
    cipher = AES.new(settings.ACCESS_AES_PASSWORD, AES.MODE_CBC, settings.ACCESS_AES_IV)
    cipher_text = str(base64.urlsafe_b64encode(cipher.encrypt(pad(buf, 16))), encoding='utf-8')
    return cipher_text
def aes_decrypt(content: str) -> str:
    """"""
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    if not isinstance(content, str):
        return '{}'
    else:
        buf = base64.urlsafe_b64decode(content)
        cipher = AES.new(settings.ACCESS_AES_PASSWORD, AES.MODE_CBC, settings.ACCESS_AES_IV)
        plain_text = str(unpad(cipher.decrypt(buf), 16), encoding='utf-8')
        return plain_text
def get_access_token(dic: dict, valid_time: float=None) -> str:
    """\n    :param dic: dict object\n    :param valid_time: minutes ,if is None using settings.ACCESS_AES_EXPIRE_TIME\n    :return: string\n    """
    if not isinstance(dic, dict):
        return ''
    else:
        minutes = valid_time if valid_time is not None else getattr(settings, 'ACCESS_AES_EXPIRE_TIME', 60.0)
        dic.update({'t': int((datetime.datetime.utcnow() + datetime.timedelta(minutes=minutes)).timestamp())})
        return settings.ACCESS_AES_PREFIX + aes_encrypt(json.dumps(dic))
def decode_access_token(access_token: str) -> (bool, dict):
    if not access_token:
        return (True, {})
    else:
        access_token = access_token[len(settings.ACCESS_AES_PREFIX):]
        res = json.loads(aes_decrypt(access_token))
        return (datetime.datetime.utcnow() <= datetime.datetime.fromtimestamp(res.get('t', datetime.datetime.utcnow().timestamp())), res)