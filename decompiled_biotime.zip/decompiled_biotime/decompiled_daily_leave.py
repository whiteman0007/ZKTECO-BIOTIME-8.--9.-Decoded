# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\daily_leave.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.utils.translation import gettext_lazy as _
from django.db.models import Q
from mysite.att.api import fields
from mysite.att.api.base_serializers import EmployeePayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.api.utils_class import SumPayCodeDuration
from mysite.att.models import PayloadPayCode
from mysite.att.models.model_paycode import PayCode, LEAVE
class DailyLeaveSerializer(EmployeePayCodeRelatedReportModelSerializer):
    att_date = fields.DateField(label=_('report_column_attendanceDate'))
    weekday = fields.WeekdayField(label=_('report_column_attendanceWeekday'))
    class Meta:
        model = PayloadPayCode
        fields = ('id', 'emp_id', 'emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday', 'company_code', 'company_name')
class DailyLeaveFilter(ReportGenericFilter):
    class Meta:
        model = PayloadPayCode
        fields = ['employees', 'departments', 'start_date', 'end_date']
class DailyLeaveViewSet(ReportUserGenericViewSet):
    model = PayloadPayCode
    queryset = PayloadPayCode.objects.filter(pay_code__code_type=LEAVE).filter(duration__gt=0)
    filterset_class = DailyLeaveFilter
    serializer_dict = {'list': DailyLeaveSerializer, 'export': DailyLeaveSerializer}
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.filter(code_type=LEAVE).order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def annotate_queryset(self, queryset):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            ordering = ['emp__emp_code_digit', 'emp__emp_code', 'att_date']
        else:
            ordering = ['emp__emp_code', 'att_date']
        queryset = queryset.values('emp_id', 'emp__emp_code', 'emp__first_name', 'emp__last_name', 'emp__nickname', 'emp__gender', 'emp__department__dept_code', 'emp__department__dept_name', 'emp__position__position_code', 'emp__position__position_name', 'att_date', 'week', 'weekday', 'emp__emp_code_digit', 'emp__company__company_code', 'emp__company__company_name').order_by(*ordering)
        values = {}
        for pay_code in self.pay_codes:
            self.summary_fields.append('paycode_{index}'.format(index=pay_code['id']))
            values['paycode_{index}'.format(index=pay_code['id'])] = SumPayCodeDuration(pay_code)
        queryset = queryset.annotate(**values)
        return queryset
    def get_file_title(self):
        return _('att.menus.reports.dailyLeave')