# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\core\\comm.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from mysite.core.zkcmdproc import appendDevCmd, zk_delete_data, zk_set_user_data
__all__ = ['check', 'reboot', 'push_cmd', 'delete_users_data', 'delete_user_data', 'sync_users_all_data']
def check(dev):
    appendDevCmd(dev, 'CHECK')
def reboot(dev):
    appendDevCmd(dev, 'REBOOT')
def info(dev):
    appendDevCmd(dev, 'INFO')
def push_cmd(dev, cmd, cursor=None, cmd_time=None):
    """\n    Push command to the queue of device command\n    :param dev: terminal instance\n    :param cmd: terminal command\n    :param cursor:\n    :param cmd_time:  create time of terminal command\n    :return:\n    """
    appendDevCmd(dev, cmd, cursor, cmd_time)
def delete_users_data(dev, pins):
    """\n    Delete batch employee\'s data from device\n    :param dev:     terminal instance\n    :param pins:    employee code list\n    :return:\n    """
    if dev and pins:
            for pin in pins:
                delete_user_data(dev, pin)
def delete_user_data(dev, pin):
    """\n    Delete employee\'s data from device\n    :param dev:     terminal instance\n    :param pin:    employee code\n    :return:\n    """
    zk_delete_data(dev, pin, 'user')
def delete_user_from_all_device(emp):
    from mysite.iclock.models import Terminal
    areas = emp.area.all()
    devs = Terminal.objects.filter(area__in=areas)
    pin = emp.pin()
    for dev in devs:
        delete_user_data(dev, pin)
def sync_users_all_data(dev, emps, active_async=True):
    """\n    Sync the employees information & all biometric template\n    :param dev:     terminal instance\n    :param emps:    employee instance list\n    :param active_async:    employee instance list\n    :return:\n    """
    if dev and emps:
            zk_set_user_data(dev, emps, cmdTime=None, is_finger=1, is_face=1, is_pic=1, is_pv=1, is_fv=1, is_biophoto=1, active_async=active_async)