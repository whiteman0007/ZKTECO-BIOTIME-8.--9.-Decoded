# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\admin\\emp_payroll_profile_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:11 UTC (1750673051)

from mysite import admin
from mysite.payroll.models.model_emp_payroll_profile import EmpPayrollProfile
from mysite.admin.kernel import ZKModelAdmin
from mysite.payroll.forms import PayrollProfileForm
from mysite.personnel.admin.employee_admin_mixins import EmployeeExtMixin
@admin.register(EmpPayrollProfile)
class EmpPayrollProfileAdmin(ZKModelAdmin, EmployeeExtMixin):
    list_display_fixed = ['id', 'emp_code', 'first_name', 'last_name', 'department', 'payment_mode', 'payment_type', 'bank_name', 'bank_account', 'agent_id', 'agent_account']
    list_filter = ('employee__emp_code', 'employee__first_name', 'employee__last_name', 'payment_mode', 'bank_name', 'bank_account', 'agent_id', 'agent_account', 'employee__department__dept_code', 'employee__department__dept_name', 'employee__area__area_code', 'employee__area__area_name')
    hidden_fields_fixed = []
    sort_fields = ()
    cache_keys = ()
    actions = []
    actions_disabled = ['GeneralActionNew', 'GeneralActionDelete']
    form = PayrollProfileForm
    @property
    def list_display(self):
        return self.get_ext_list_display()
    @property
    def hidden_fields(self):
        return self.get_ext_hidden_fields()
    def get_ordering(self, request):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            return ('employee__emp_code_digit', 'employee__emp_code')
        else:
            return ('employee__emp_code',)
    def get_queryset(self, request):
        qs = super(EmpPayrollProfileAdmin, self).get_queryset(request)
        qs = qs.select_related('employee', 'employee__department')
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                qs = qs.filter(employee__department__in=request.user.auth_dept.all())
            if request.user.auth_area.exists():
                qs = qs.filter(employee__area__in=request.user.auth_area.all()).distinct()
            if request.user.assign_company:
                qs = qs.filter(employee__company_id=request.user.assign_company)
        return qs
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return ['employee']
        else:
            return []