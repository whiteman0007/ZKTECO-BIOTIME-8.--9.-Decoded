# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\dbutils_pool.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

global _dbManager
import datetime
from django.conf import settings
from DBUtils.PooledDB import PooledDB
args = (2, 10, 30, 100, True, 0, None)
HOST = ''
PORT = ''
CHARSET = 'utf8'
conn_args = {}
db_cfg = settings.DATABASES['default']
USER = db_cfg['USER'] if db_cfg.get('USER') else ''
PASSWORD = db_cfg['PASSWORD'] if db_cfg.get('PASSWORD') else ''
NAME = db_cfg['NAME'] if db_cfg.get('NAME') else ''
if db_cfg['ENGINE'] == 'sql_server.pyodbc':
    from sql_server.pyodbc import pyodbc as pyDB
    from sql_server.pyodbc.pyodbc import OperationalError, InternalError, ProgrammingError
    HOST = db_cfg['HOST'].replace('\\\\', '\\') if db_cfg.get('HOST') else '127.0.0.1'
    PORT = db_cfg['PORT'] if db_cfg.get('PORT') else 1433
    if PORT and PORT not in ['1433', 1433, '']:
            HOST = '%s:%s' % (HOST, PORT)
            PORT = ''
    conn_args = {'host': '%s' % HOST, 'user': '%s' % USER, 'charset': '%s' % CHARSET, 'password': '%s' % PASSWORD, 'database': '%s' % NAME, 'port': PORT}
else:
    if db_cfg['ENGINE'] == 'django.db.backends.mysql':
        import MySQLdb as pyDB
        from MySQLdb import OperationalError, InternalError, ProgrammingError
        HOST = db_cfg['HOST'] if db_cfg.get('HOST') else '127.0.0.1'
        PORT = db_cfg['PORT'] if db_cfg.get('PORT') else 3306
        conn_args = {'host': '%s' % HOST, 'user': '%s' % USER, 'charset': '%s' % CHARSET, 'passwd': '%s' % PASSWORD, 'db': '%s' % NAME, 'port': PORT}
    else:
        if db_cfg['ENGINE'] == 'django.db.backends.oracle':
            import cx_Oracle as pyDB
            from cx_Oracle import OperationalError, InternalError, ProgrammingError
            HOST = db_cfg['HOST'] if db_cfg.get('HOST') else '127.0.0.1'
            PORT = db_cfg['PORT'] if db_cfg.get('PORT') else 1521
            CONN_STR = pyDB.makedsn(HOST, PORT, NAME)
            conn_args = {'user': '%s' % USER, 'password': '%s' % PASSWORD, 'dsn': '%s' % CONN_STR}
        else:
            if db_cfg['ENGINE'] == 'django.db.backends.postgresql_psycopg2':
                import psycopg2 as pyDB
                from psycopg2 import OperationalError, InternalError, ProgrammingError
                HOST = db_cfg['HOST'] if db_cfg.get('HOST') else '127.0.0.1'
                PORT = db_cfg['PORT'] if db_cfg.get('PORT') else 5432
                conn_args = {'host': '%s' % HOST, 'user': '%s' % USER, 'password': '%s' % PASSWORD, 'database': '%s' % NAME, 'port': PORT}
            else:
                if db_cfg['ENGINE'] == 'django_postgrespool':
                    import psycopg2 as pyDB
                    from psycopg2 import OperationalError, InternalError, ProgrammingError
                    HOST = db_cfg['HOST'] if db_cfg.get('HOST') else '127.0.0.1'
                    PORT = db_cfg['PORT'] if db_cfg.get('PORT') else 5432
                    conn_args = {'host': '%s' % HOST, 'user': '%s' % USER, 'password': '%s' % PASSWORD, 'database': '%s' % NAME, 'port': PORT}
class DbManager:
    def __init__(self):
        try:
            self._pool = PooledDB(pyDB, *args, **conn_args)
        except Exception as e:
            print(('The parameters for DBUtils is:', conn_args))
            print('=============> DBUtils Exception:')
            raise e
    def _getConn(self):
        return self._pool.connection()
_dbManager = DbManager()
def getConn():
    """ get database connection """
    return _dbManager._getConn()
def _reConn():
    # irreducible cflow, using cdg fallback
    """ reconnect database """
    global _dbManager
    re = False
    try:
        _dbManager = DbManager()
        re = True
    except Exception:
        import traceback
        traceback.print_exc()
        return re
def reConn():
    print('%s: now try to reconnect Database!' % datetime.datetime.now())
    flag = _reConn()
    if flag:
        print('%s: reconnect databases success ! ' % datetime.datetime.now())
    else:
        print('%s: reconnect databases failed ! ' % datetime.datetime.now())