# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\api_request_log_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:08 UTC (1750672988)

from rest_framework_tracking.models import APIRequestLog
from rest_framework import status
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from mysite import admin
from mysite.admin.kernel import ZKModelAdmin
@admin.register(APIRequestLog)
class APIRequestLogAdmin(ZKModelAdmin):
    list_display = ('request_user', 'request_time', 'request_path', 'request_view_method', 'request_remote_addr', 'request_host', 'request_status_code', 'request_response_ms', 'request_errors')
    hidden_fields = ('request_host', 'request_response', 'request_errors')
    sort_fields = ('-requested_at',)
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def request_user(self, obj):
        return obj.username_persistent
    request_user.short_description = _('APIRequestLog.fields.requestUser')
    def request_time(self, obj):
        return obj.requested_at
    request_time.short_description = _('APIRequestLog.fields.requestTime')
    def request_path(self, obj):
        return obj.path
    request_path.short_description = _('APIRequestLog.fields.path')
    def request_view(self, obj):
        return obj.view
    request_view.short_description = _('APIRequestLog.fields.view')
    def request_view_method(self, obj):
        return obj.view_method
    request_view_method.short_description = _('APIRequestLog.fields.viewMethod')
    def request_remote_addr(self, obj):
        return obj.remote_addr
    request_remote_addr.short_description = _('APIRequestLog.fields.remoteAddr')
    def request_host(self, obj):
        return obj.host
    request_host.short_description = _('APIRequestLog.fields.host')
    def request_query_params(self, obj):
        return obj.query_params
    request_query_params.short_description = _('APIRequestLog.fields.queryParams')
    def request_data(self, obj):
        return obj.data
    request_data.short_description = _('APIRequestLog.fields.data')
    def request_status_code(self, obj):
        color = '#545454'
        status_code = obj.status_code
        if status_code in (status.HTTP_200_OK, status.HTTP_201_CREATED):
            color = '#238E23'
        else:
            if status_code in (status.HTTP_404_NOT_FOUND, status.HTTP_500_INTERNAL_SERVER_ERROR):
                color = '#FF0000'
            else:
                if status_code in [status.HTTP_401_UNAUTHORIZED, status.HTTP_405_METHOD_NOT_ALLOWED, status.HTTP_403_FORBIDDEN]:
                    color = '#D9D919'
        return '<div style=\'width:80px;height:26px;background-color:{};color:#fff;text-align:center\'>{}</div>'.format(color, status_code)
    request_status_code.short_description = _('APIRequestLog.fields.statusCode')
    def request_response_ms(self, obj):
        return '{} ms'.format(obj.response_ms)
    request_response_ms.short_description = _('APIRequestLog.fields.responseMS')
    def request_response(self, obj):
        return obj.response
    request_response.short_description = _('APIRequestLog.fields.response')
    def request_errors(self, obj):
        return obj.errors
    request_errors.short_description = _('APIRequestLog.fields.errors')