# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\company_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

from django.conf import settings
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.base.threadlocals import get_current_user
from mysite.personnel import widgets
from mysite.personnel.models import Company
from mysite.personnel.utils import get_default_company
class CompanyField4ActionForm(forms.ZKActionForm):
    company = forms.ModelChoiceField(queryset=Company.objects.all(), label=_('area.field.company'), required=True, initial=get_default_company(), widget=widgets.CompanyRadioSelect(attrs={'onchange': True}))
    def __init__(self, *args, **kwargs):
        super(CompanyField4ActionForm, self).__init__(*args, **kwargs)
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            user = getattr(self.request, 'user', get_current_user())
            if user and (not user.is_superuser) and user.assign_company:
                self.fields['company'].initial = user.assign_company
                self.fields['company'].widget = forms.ZKHiddenInput()
            else:
                self.fields['company'].initial = get_default_company()
        else:
            self.fields['company'].required = False
            self.fields['company'].widget = forms.ZKHiddenInput()
class CompanyField4ModelForm(ModelForm):
    company = forms.ModelChoiceField(queryset=Company.objects.all(), label=_('area.field.company'), required=False, widget=widgets.CompanyRadioSelect(attrs={'onchange': True}))
    def __init__(self, *args, **kwargs):
        super(CompanyField4ModelForm, self).__init__(*args, **kwargs)
        self.fields['company'].initial = get_default_company()
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            try:
                req = kwargs.pop('initial').pop('request')
                user = req.user
            except:
                user = get_current_user()
            if user and (not user.is_superuser) and user.assign_company:
                        self.fields['company'].initial = Company.objects.filter(id=user.assign_company).first()
                        self.fields['company'].widget = forms.ZKHiddenInput()
        else:
            self.fields['company'].widget = forms.ZKHiddenInput()
class CompanyField4ModelChangeForm(ModelForm):
    company_name = forms.CharField(label=_('company.field.name'), disabled=True, required=False)
    def __init__(self, *args, **kwargs):
        super(CompanyField4ModelChangeForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['company_name'].initial = str(self.instance.company)
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            try:
                req = kwargs.pop('initial').pop('request')
                self.user = req.user
            except:
                self.user = get_current_user()
            if self.user and (not self.user.is_superuser) and self.user.assign_company:
                        self.fields['company_name'].widget = forms.ZKHiddenInput()
        else:
            self.fields['company_name'].widget = forms.ZKHiddenInput()