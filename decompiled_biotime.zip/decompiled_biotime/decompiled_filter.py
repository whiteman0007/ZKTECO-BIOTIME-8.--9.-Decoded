# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\filter.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

from django.utils.translation import gettext_lazy as _
from mysite.admin.xadmin.filters import SimpleListFilter
from mysite.personnel.db_const import APP_STATUS
class EnableTaskListFilter(SimpleListFilter):
    title = _('autoImportTask.fields.enable')
    parameter_name = 'enable'
    def lookups(self, request, model_admin):
        return APP_STATUS
    def queryset(self, request, qs):
        if self.value():
            qs = qs.filter(enable=self.value()).distinct()
        return qs