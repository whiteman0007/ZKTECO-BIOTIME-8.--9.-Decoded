# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\base_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.api.serializers.utils import EmployeeExtraInfoSerializer
from mysite.att.api.fields import PayCodeDecimalField, PayCodeIntegerField, PayCodeDecimalColorfulField, PayCodeIntegerColorfulField, TimeCardPayCodeDecimalField, TimeCardPayCodeDecimalColorfulField, TimeCardPayCodeIntegerColorfulField, TimeCardPayCodeIntegerField
from mysite.att.models.model_paycode import WORKDAY, HOUR, MINUTE
from mysite.att import const
class TimeCardPayCodeAttCodeSerializerMixin:
    @property
    def att_codes(self):
        if not hasattr(self, '_att_codes'):
            self._att_codes = []
        return self._att_codes
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = []
        return self._pay_codes
    def add_att_code_fields(self, fields):
        for att_code in self.att_codes:
            if att_code['display_format'] in (WORKDAY, HOUR):
                fields[att_code['code']] = TimeCardPayCodeDecimalField(att_code, label=att_code['alias'], max_digits=8, decimal_places=1, source='time_card.payload', allow_null=True)
            else:
                fields[att_code['code']] = TimeCardPayCodeIntegerField(att_code, label=att_code['alias'], source='time_card.payload', allow_null=True)
    def add_pay_code_fields(self, fields):
        for pay_code in self.pay_codes:
            if pay_code['display_format'] in (WORKDAY, HOUR):
                fields['paycode_{index}'.format(index=str(pay_code['id']))] = TimeCardPayCodeDecimalField(pay_code, label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), max_digits=8, decimal_places=1, source='time_card.payload', allow_null=True)
            else:
                fields['paycode_{index}'.format(index=str(pay_code['id']))] = TimeCardPayCodeIntegerField(pay_code, label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), source='time_card.payload', allow_null=True)
class PayCodeAttCodeSerializerMixin:
    @property
    def att_codes(self):
        if not hasattr(self, '_att_codes'):
            self._att_codes = []
        return self._att_codes
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = []
        return self._pay_codes
    def add_att_code_fields(self, fields):
        for att_code in self.att_codes:
            if att_code['display_format'] in [WORKDAY, HOUR, MINUTE]:
                fields[att_code['code']] = serializers.DecimalField(label=att_code['alias'], max_digits=8, decimal_places=1, allow_null=True)
            else:
                fields[att_code['code']] = PayCodeIntegerField(att_code, label=att_code['alias'], allow_null=True)
    def add_pay_code_fields(self, fields):
        for pay_code in self.pay_codes:
            if pay_code['display_format'] in [WORKDAY, HOUR, MINUTE]:
                fields['paycode_{index}'.format(index=str(pay_code['id']))] = serializers.DecimalField(label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), max_digits=8, decimal_places=1, allow_null=True)
            else:
                fields['paycode_{index}'.format(index=str(pay_code['id']))] = PayCodeIntegerField(pay_code, label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), allow_null=True)
class ColorfulPayCodeAttCodeSerializerMixin:
    colorful = False
    dec_field_map = {True: PayCodeDecimalColorfulField, False: PayCodeDecimalField}
    int_field_map = {True: PayCodeIntegerColorfulField, False: PayCodeIntegerField}
    @property
    def att_codes(self):
        if not hasattr(self, '_att_codes'):
            self._att_codes = []
        return self._att_codes
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = []
        return self._pay_codes
    def add_att_code_fields(self, fields):
        colorful = bool(self.colorful)
        for att_code in self.att_codes:
            if att_code['display_format'] in (WORKDAY, HOUR):
                fields[att_code['code']] = self.dec_field_map.get(colorful)(att_code, label=_(att_code['alias']), max_digits=8, decimal_places=1, default='')
            else:
                fields[att_code['code']] = self.int_field_map.get(colorful)(att_code, label=_(att_code['alias']), default='')
    def add_pay_code_fields(self, fields):
        colorful = bool(self.colorful)
        for pay_code in self.pay_codes:
            field_name = 'paycode_{index}'.format(index=str(pay_code['id']))
            if pay_code['display_format'] in (WORKDAY, HOUR):
                fields[field_name] = self.dec_field_map.get(colorful)(pay_code, label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), max_digits=8, decimal_places=1, default='')
            else:
                fields[field_name] = self.int_field_map.get(colorful)(pay_code, label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), default='')
class ColorfulTimeCardPayCodeAttCodeSerializerMixin:
    colorful = False
    dec_field_map = {True: TimeCardPayCodeDecimalColorfulField, False: TimeCardPayCodeDecimalField}
    int_field_map = {True: TimeCardPayCodeIntegerColorfulField, False: TimeCardPayCodeIntegerField}
    @property
    def att_codes(self):
        if not hasattr(self, '_att_codes'):
            self._att_codes = []
        return self._att_codes
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = []
        return self._pay_codes
    def add_att_code_fields(self, fields):
        colorful = bool(self.colorful)
        for att_code in self.att_codes:
            if att_code['display_format'] in (WORKDAY, HOUR):
                fields[att_code['code']] = self.dec_field_map.get(colorful)(att_code, label=att_code['alias'], max_digits=8, decimal_places=1, source='payload', default='')
            else:
                fields[att_code['code']] = self.int_field_map.get(colorful)(att_code, label=att_code['alias'], source='payload', default='')
    def add_pay_code_fields(self, fields):
        colorful = bool(self.colorful)
        for pay_code in self.pay_codes:
            field_name = 'paycode_{index}'.format(index=str(pay_code['id']))
            if pay_code['display_format'] in (WORKDAY, HOUR):
                fields[field_name] = self.dec_field_map.get(colorful)(pay_code, label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), max_digits=8, decimal_places=1, source='payload', default='')
            else:
                fields[field_name] = self.int_field_map.get(colorful)(pay_code, label='{name}({unit})'.format(name=pay_code['name'], unit=const.PAYCODE_FORMAT_DICT.get(pay_code['display_format'], 'H')), source='payload', default='')
class PayCodeRelatedReportModelSerializer(serializers.ModelSerializer, ColorfulPayCodeAttCodeSerializerMixin):
    colorful = False
    def __init__(self, *args, **kwargs):
        view = kwargs['context']['view']
        if view:
            att_codes = getattr(view, 'att_codes')
            if att_codes is not None:
                self._att_codes = att_codes
            pay_codes = getattr(view, 'pay_codes')
            if pay_codes is not None:
                self._pay_codes = pay_codes
        super(PayCodeRelatedReportModelSerializer, self).__init__(*args, **kwargs)
    def get_fields(self):
        fields = super(PayCodeRelatedReportModelSerializer, self).get_fields()
        self.add_att_code_fields(fields)
        self.add_pay_code_fields(fields)
        return fields
class TimeCardPayCodeRelatedReportModelSerializer(serializers.ModelSerializer, ColorfulTimeCardPayCodeAttCodeSerializerMixin):
    colorful = False
    def __init__(self, *args, **kwargs):
        view = kwargs['context']['view']
        if view:
            att_codes = getattr(view, 'att_codes')
            if att_codes is not None:
                self._att_codes = att_codes
            pay_codes = getattr(view, 'pay_codes')
            if pay_codes is not None:
                self._pay_codes = pay_codes
        super(TimeCardPayCodeRelatedReportModelSerializer, self).__init__(*args, **kwargs)
    def get_fields(self):
        fields = super(TimeCardPayCodeRelatedReportModelSerializer, self).get_fields()
        self.add_att_code_fields(fields)
        self.add_pay_code_fields(fields)
        return fields
class EmployeeTimeCardPayCodeRelatedReportModelSerializer(serializers.ModelSerializer, EmployeeExtraInfoSerializer, TimeCardPayCodeAttCodeSerializerMixin):
    emp_code = serializers.CharField(label=_('report_column_empCode'), source='emp.emp_code', allow_null=True)
    first_name = serializers.CharField(label=_('report_column_firstName'), source='emp.first_name', allow_null=True)
    last_name = serializers.CharField(label=_('report_column_lastName'), source='emp.last_name', allow_null=True)
    nick_name = serializers.CharField(label=_('report_column_nickName'), source='emp.nickname', allow_null=True)
    gender = serializers.CharField(label=_('report_column_gender'), source='emp.gender', allow_null=True)
    company_code = serializers.CharField(label=_('company.field.code'), source='emp.company.company_code', allow_null=True)
    company_name = serializers.CharField(label=_('company.field.name'), source='emp.company.company_name', allow_null=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='emp.department.dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='emp.department.dept_name', allow_null=True)
    position_code = serializers.CharField(label=_('report_column_positionCode'), source='emp.position.position_code', allow_null=True)
    position_name = serializers.CharField(label=_('report_column_positionName'), source='emp.position.position_name', allow_null=True)
    def __init__(self, *args, **kwargs):
        view = kwargs['context']['view']
        if view:
            att_codes = getattr(view, 'att_codes')
            if att_codes is not None:
                self._att_codes = att_codes
            pay_codes = getattr(view, 'pay_codes')
            if pay_codes is not None:
                self._pay_codes = pay_codes
        super(EmployeeTimeCardPayCodeRelatedReportModelSerializer, self).__init__(*args, **kwargs)
    def get_fields(self):
        fields = super(EmployeeTimeCardPayCodeRelatedReportModelSerializer, self).get_fields()
        self.add_emp_extra_info_fields(fields)
        self.add_att_code_fields(fields)
        self.add_pay_code_fields(fields)
        return fields
class EmployeePayCodeRelatedReportModelSerializer(serializers.ModelSerializer, EmployeeExtraInfoSerializer, PayCodeAttCodeSerializerMixin):
    emp_code = serializers.CharField(label=_('report_column_empCode'), source='emp__emp_code', allow_null=True)
    first_name = serializers.CharField(label=_('report_column_firstName'), source='emp__first_name', allow_null=True)
    last_name = serializers.CharField(label=_('report_column_lastName'), source='emp__last_name', allow_null=True)
    nick_name = serializers.CharField(label=_('report_column_nickName'), source='emp__nickname', allow_null=True)
    gender = serializers.CharField(label=_('report_column_gender'), source='emp__gender', allow_null=True)
    company_code = serializers.CharField(label=_('company.field.code'), source='emp__company__company_code', allow_null=True)
    company_name = serializers.CharField(label=_('company.field.name'), source='emp__company__company_name', allow_null=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='emp__department__dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='emp__department__dept_name', allow_null=True)
    position_code = serializers.CharField(label=_('report_column_positionCode'), source='emp__position__position_code', allow_null=True)
    position_name = serializers.CharField(label=_('report_column_positionName'), source='emp__position__position_name', allow_null=True)
    def __init__(self, *args, **kwargs):
        view = kwargs['context']['view']
        if view:
            att_codes = getattr(view, 'att_codes')
            if att_codes is not None:
                self._att_codes = att_codes
            pay_codes = getattr(view, 'pay_codes')
            if pay_codes is not None:
                self._pay_codes = pay_codes
        super(EmployeePayCodeRelatedReportModelSerializer, self).__init__(*args, **kwargs)
    def get_fields(self):
        fields = super(EmployeePayCodeRelatedReportModelSerializer, self).get_fields()
        self.add_emp_extra_info_fields(fields)
        self.add_att_code_fields(fields)
        self.add_pay_code_fields(fields)
        return fields
class TransactionShowEmployeeExtraInfoSerializer(serializers.ModelSerializer, EmployeeExtraInfoSerializer):
    def __init__(self, *args, **kwargs):
        super(TransactionShowEmployeeExtraInfoSerializer, self).__init__(*args, **kwargs)
    def get_fields(self):
        fields = super(TransactionShowEmployeeExtraInfoSerializer, self).get_fields()
        self.add_emp_extra_info_fields(fields)
        return fields