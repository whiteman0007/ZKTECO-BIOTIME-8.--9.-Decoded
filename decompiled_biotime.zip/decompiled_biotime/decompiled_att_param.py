# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\att_param.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

def get_att_rule():
    import json
    from django.core.cache import cache
    cache_key = 'att_rule'
    att_rule_cache = cache.get(cache_key, None)
    if att_rule_cache:
        att_rule_cache = json.loads(att_rule_cache)
        return dict(att_rule_cache)
    else:
        att_rule = {}
        att_param = get_att_param()
        report_param = get_report_param()
        att_rule.update(att_param)
        att_rule.update(report_param)
        cache.set(cache_key, json.dumps(att_rule), 604800)
        return att_rule
def get_att_param():
    """\n    Get global rule settings as dictionary\n    """
    import json
    from mysite.att.models.model_attrule import AttRule
    att_param = AttRule.objects.filter(param_name='global_att_rule')[0]
    ret = json.loads(att_param.param_value)
    return ret
def get_report_param():
    """\n    Get report parameter items\n    """
    import json
    from mysite.att.models import AttReportSetting
    from mysite.base import const
    from mysite.base.models import SystemSetting
    obj = AttReportSetting.objects.first()
    if not obj:
        return {}
    else:
        val = {'filter_by_hire_date': obj.filter_by_hire_date, 'resign_emp': obj.resign_emp, 'short_date': obj.short_date, 'short_time': obj.short_time, 'auto_calculate': obj.auto_calculate}
        instance = SystemSetting.objects.filter(name='punch_state').first()
        if not instance:
            val.update({'func_keys': {func_key['value']: {'value': func_key['value'], 'name': str(func_key['alias'])} for func_key in const.PUNCH_STATES}})
        else:
            func_keys = json.loads(instance.value)
            val.update({'func_keys': {func_key['value']: func_key for func_key in func_keys}})
        return val