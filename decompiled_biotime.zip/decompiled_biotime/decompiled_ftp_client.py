# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\tools\\ftpclient\\ftp_client.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import fnmatch
from ftplib import FTP, error_perm, error_temp
from io import BytesIO, IOBase
from logging import getLogger
from os import listdir, makedirs
from os.path import basename, dirname, isdir, isfile, join
from time import sleep
from .client_base import FTPClientBase, FTPClientBaseError
logger = getLogger('ftp_client.ftp')
class FTPClientError(FTPClientBaseError):
    # return None
    pass
class FTPClient(FTPClientBase):
    ftp = None
    def connect(self):
        logger.info('Openning FTP connection to %s', self.host)
        self.ftp = FTP()
        self.ftp.connect(self.host, self.port, timeout=5)
        self.ftp.login(user=self.user, passwd=self.passwd)
    def disconnect(self):
        if self.ftp:
            self.ftp.quit()
    def listdir(self, path):
        return [basename(dir_path) for dir_path in self.ftp.nlst(path)]
    def file_glob(self, path):
        dir_name = dirname(path)
        if self.exists(dir_name):
            return fnmatch.filter(self.ftp.nlst(dir_name), path)
        else:
            return []
    def open(self, path, mode='r'):
        return FTPFile(self.ftp, path, mode).open()
    def mkdir(self, dir_path):
        try:
            self.ftp.nlst(dir_path)
        except (error_temp, error_perm):
            try:
                self.mkdir(dirname(dir_path.rstrip('/')))
            except error_perm:
                logger.warning('failed to create a parent directory')
            self.ftp.mkd(dir_path.rstrip('/'))
    def delete(self, path):
        # irreducible cflow, using cdg fallback
        is_file = True
        self.ftp.size(path)
            except error_perm:
                if not self.exists(path):
                    return
                    is_file = False
                        if is_file:
                            self.ftp.delete(path)
                            return
                        else:
                            for sub_path in self.ftp.nlst(path):
                                is_file = True
                                try:
                                    self.ftp.size(sub_path)
                                except error_perm:
                                    is_file = False
                                if is_file:
                                    logger.debug('deleting file: %s', path)
                                    self.ftp.delete(sub_path)
                                else:
                                    self.delete(sub_path)
                            self.ftp.rmd(path)
    def download_tree(self, src, dst):
        for sub_path in self.ftp.nlst(src):
            is_file = True
            try:
                self.ftp.size(sub_path)
            except error_perm:
                is_file = False
            if is_file:
                filename = basename(sub_path)
                file_path = join(dst, filename)
                makedirs(dst, exist_ok=True)
                self.download_file(sub_path, file_path)
            else:
                makedirs(dst, exist_ok=True)
                self.download_tree(sub_path, join(dst, basename(sub_path)))
    def upload_tree(self, src, dst):
        if isfile(src):
            self.upload_file(src, dst)
        else:
            if isdir(src):
                self.mkdir(dst)
                for sub_path in listdir(src):
                    full_sub_path = join(src, sub_path)
                    self.upload_tree(full_sub_path, '/'.join((dst, sub_path)))
            else:
                raise FTPClientError('FTP client supports only files and directories on upload operation')
    def download_file(self, src, dst):
        logger.info('Downloading File from FTP: %s --> %s' % (src, dst))
        if dst.endswith('/') or isdir(dst):
            dst = join(dst, basename(src))
        with open(dst, 'wb') as dst_file:
            self.ftp.retrbinary('RETR {}'.format(src), dst_file.write)
    def upload_file(self, src, dst):
        logger.info('Uploading File to FTP: %s --> %s' % (src, dst))
        with open(src, 'rb') as src_file:
            self.ftp.storbinary('STOR {}'.format(dst), src_file)
    def exists(self, path):
        try:
            self.ftp.nlst(path)
        except (error_temp, error_perm):
            return False
        else:
            return True
    def file_size(self, path, bytes_magnitude=1):
        """\n        :param bytes_magnitude: 1-bytes, 2-Kb, 3-Mb, 4-Gb\n        """
        return self.ftp.size(path) / 1024 ** bytes_magnitude
class FTPFile(IOBase):
    def __init__(self, ftp, path, mode):
        self.ftp = ftp
        self.path = path
        self.mode = mode[:(-1)] if mode.endswith('b') else mode
        self.b = BytesIO()
        self.read = self.b.read
        self.seek = self.b.seek
        self.readline = self.b.readline
        self.readlines = self.b.readlines
        self.fileno = self.b.fileno
        self.truncate = self.b.truncate
        super(FTPFile, self).__init__()
    def open(self):
        if self.mode == 'w':
            self.ftp.storbinary('STOR {}'.format(self.path), BytesIO())
        if self.mode == 'r':
            self.ftp.retrbinary('RETR {}'.format(self.path), self.b.write)
            self.b.seek(0)
        return self
    def write(self, data_chunk):
        if self.mode in ['w', 'a']:
            self.ftp.storbinary('APPE {}'.format(self.path), BytesIO(data_chunk if isinstance(data_chunk, bytes) else data_chunk.encode()))
        else:
            raise Exception('File mode must be \"w\" or \"a\" to write data, not \"{}\"'.format(self.mode))
    def __enter__(self):
        self.open()
        return self
    def __exit__(self, *args):
        return