# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\visitor\\migrations\\0003_reservation_email.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:28 UTC (1750702768)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('visitor', '0002_reservation_visitor_visitorconfig_visitorlog')]
    operations = [migrations.AddField(model_name='reservation', name='email', field=models.EmailField(blank=True, max_length=50, null=True, verbose_name='visitor.field.email'))]