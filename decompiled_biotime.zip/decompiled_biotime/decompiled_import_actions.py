# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\import_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.core.cache import cache
from django.utils.translation import gettext_lazy as _, get_language
from django.conf import settings
from mysite import admin
from mysite.admin import forms
from mysite.personnel import db_const
class ImportForm(forms.ZKActionForm):
    import_file = forms.FileField(label=_('dataImport_field_file'), help_text=_('data_import_fileHelpTxt'))
    import_type = forms.ChoiceField(label=_('date_import_labelExistingData'), choices=db_const.IMPORT_TYPE)
    template_lng = forms.ChoiceField(label=_('userProfile_itemLabel_language'), choices=())
    auto_approve = forms.BooleanField(label=_('leave.fields.autoApproved'), initial=False, required=False)
    def __init__(self, *args, **kwargs):
        super(ImportForm, self).__init__(*args, **kwargs)
        self.fields['template_lng'].choices = settings.LANGUAGES
        self.fields['template_lng'].initial = get_language
class Import(admin.ZKModelAction):
    verbose_name = _('dataImport_action_import')
    help_txt = _('dataImport_action_import')
    short_description = _('dataImport_action_import')
    action_form = ImportForm
    async_progress = True
    use_asgi = True
    def action(self, *args, **kwargs):
        from mysite.tools.request_utils import PickleRequest
        from mysite.base.tasks import async_progress_task_wapper
        if self.request.method == 'POST':
            request = PickleRequest(self.request)
            data = self.valid_form.cleaned_data
            data.update({'overwrite': data.get('import_type', 0)})
            call_info = {'type': 'admin', 'model': self.admin.model, 'func': 'data_import', 'lng': self.request.LANGUAGE_CODE, 'delay': True if settings.ASYN_IMPORT_DATA else False}
            task = async_progress_task_wapper(call_info, request, **data)
            return task