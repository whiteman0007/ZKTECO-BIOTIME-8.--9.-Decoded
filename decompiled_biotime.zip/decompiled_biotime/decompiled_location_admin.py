# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\admin\\location_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from mysite import admin
from mysite.admin import forms
from django.utils.translation import gettext_lazy as _
from mysite.mobile.models.model_location import GPSLocation
from django.forms import ModelForm, ValidationError
class GPSLocationForm(ModelForm):
    alias = forms.CharField(label=_('gpsLocation.fields.alias'))
    location = forms.CharField(label=_('gpsLocation.fields.location'))
    longitude = forms.FloatField(label=_('gpsLocation.fields.longitude'), widget=forms.widgets.ZKNumberInput(attrs={'placeholder': 'x.xxxxxx'}))
    latitude = forms.FloatField(label=_('gpsLocation.fields.latitude'), widget=forms.widgets.ZKNumberInput(attrs={'placeholder': 'x.xxxxxx'}))
    def clean(self):
        cleaned_data = super(GPSLocationForm, self).clean()
        latitude = cleaned_data.get('latitude', None)
        if latitude and abs(latitude) > 90:
            raise ValidationError(_('gps_latitude_invalid_range'))
        else:
            longitude = cleaned_data.get('longitude', None)
            if longitude and abs(longitude) > 180:
                raise ValidationError(_('gps_longitude_invalid_range'))
            else:
                return cleaned_data
    class Meta:
        model = GPSLocation
        fields = ('alias', 'location', 'longitude', 'latitude')
@admin.register(GPSLocation)
class GPSLocationAdmin(admin.ZKModelAdmin):
    list_display = ('alias', 'location', 'longitude', 'latitude')
    list_filter = ('alias', 'location', 'longitude', 'latitude')
    form = GPSLocationForm
    add_form = GPSLocationForm