# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\group_summary.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.db.models import Sum, Count, Case, When, Value, IntegerField
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.api.base_serializers import PayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.serializers import NoneSerializer
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.api.utils_class import SumPayCodeDuration
from mysite.att.models import PayloadPayCode
from mysite.att.models.model_paycode import PayCode, LATE_IN, EARLY_OUT, ABSENT
class GroupSummarySerializer(PayCodeRelatedReportModelSerializer):
    group_code = serializers.CharField(label=_('attGroup.fields.code'), source='emp__attemployee__group__code', allow_null=True)
    group_name = serializers.CharField(label=_('attGroup.fields.name'), source='emp__attemployee__group__name', allow_null=True)
    total_emp = serializers.IntegerField(label=_('report_column_employeeCount'), source='emp_count')
    total_late_times = serializers.IntegerField(label=_('report_column_lateDuration'), source='sum_late_times')
    total_early_leave_times = serializers.IntegerField(label=_('report_column_earlyLeaveDuration'), source='sum_early_leave_times')
    total_absent_times = serializers.IntegerField(label=_('report_column_absentDuration'), source='sum_absent_times')
    class Meta:
        model = PayloadPayCode
        fields = ('group_code', 'group_name', 'total_emp', 'total_late_times', 'total_early_leave_times', 'total_absent_times')
class GroupSummaryViewSet(ReportUserGenericViewSet):
    model = PayloadPayCode
    queryset = PayloadPayCode.objects.all().select_related()
    filterset_class = ReportGenericFilter
    serializer_dict = {'list': GroupSummarySerializer, 'export': GroupSummarySerializer}
    def __init__(self, *args, **kwargs):
        self.summary_fields = ['total_emp', 'total_late_times', 'total_early_leave_times', 'total_absent_times']
        super(GroupSummaryViewSet, self).__init__(*args, **kwargs)
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.all().order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)
    def get_file_title(self):
        return _('att.menus.reports.groupSummary')
    def annotate_queryset(self, queryset):
        queryset = queryset.values('emp__attemployee__group_id', 'emp__attemployee__group__code', 'emp__attemployee__group__name').order_by('emp__attemployee__group_id')
        values = {'emp_count': Count('emp', distinct=True), 'sum_late_times': Sum(Case(When(pay_code__fixed_code=LATE_IN, duration__gt=0, then=Value(1))), output_field=IntegerField()), 'sum_early_leave_times': Sum(Case(When(pay_code__fixed_code=EARLY_OUT, duration__gt=0, then=Value(1))), output_field=IntegerField()), 'sum_absent_times': Sum(Case(When(pay_code__fixed_code=ABSENT, duration__gt=0, then=Value(1))), output_field=IntegerField())}
        if self.pay_codes:
            for pay_code in self.pay_codes:
                self.summary_fields.append('paycode_{index}'.format(index=pay_code['id']))
                values['paycode_{index}'.format(index=pay_code['id'])] = SumPayCodeDuration(pay_code)
            queryset = queryset.annotate(**values)
        return queryset