# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\dashboard.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:11 UTC (1750672991)

import datetime
import hashlib
import itertools
import json
import logging
import operator
import os
from django.urls import re_path
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.http.response import HttpResponse
from django.template.response import TemplateResponse
from django.utils.encoding import force_str
from django.utils.translation import gettext_lazy as _
from django.utils import translation
from mysite._utils import getattr_ex
from mysite.admin.decorators import inject_default_context
def filter_conditions(request, dept_key, area_key, company_key):
    emp_filters = {}
    user = request.user
    if not user.is_superuser:
        if dept_key and user.auth_dept.exists():
                emp_filters[dept_key] = user.auth_dept.all()
        if area_key and user.auth_area.exists():
                emp_filters[area_key] = user.auth_area.all()
        if company_key and user.assign_company:
                emp_filters[company_key] = user.assign_company
    filter_departments = request.POST.getlist('departments', [])
    filter_areas = request.POST.getlist('areas', [])
    if dept_key and filter_departments:
            emp_filters[dept_key] = filter_departments
    if area_key and filter_areas:
            emp_filters[area_key] = filter_areas
    return emp_filters
def filter_conditions_ws(user, dept_key, area_key, company_key, params: dict):
    emp_filters = {}
    user = user
    if not user.is_superuser:
        if dept_key and user.auth_dept.exists():
                emp_filters[dept_key] = user.auth_dept.all()
        if area_key and user.auth_area.exists():
                emp_filters[area_key] = user.auth_area.all()
        if company_key and user.assign_company:
                emp_filters[company_key] = user.assign_company
    filter_departments = params.get('departments', [])
    filter_areas = params.get('areas', [])
    if dept_key and filter_departments:
            emp_filters[dept_key] = filter_departments
    if area_key and filter_areas:
            emp_filters[area_key] = filter_areas
    return emp_filters
def get_filter_cache_key(filter, dept_key, area_key, company_key, prefix='', extra_dict=None, lng='en'):
    key_strs = []
    if dept_key in filter:
        dept_list = []
        for i in filter[dept_key]:
            if not i:
                continue
            else:
                if isinstance(i, int):
                    dept_list.append(str(i))
                else:
                    if isinstance(i, str):
                        dept_list.append(i)
                    else:
                        value = getattr(i, 'id', None)
                        if value:
                            dept_list.append(str(value))
        if dept_list:
            dept_list.sort()
            key_strs.append('dept_ids:' + '-'.join(dept_list))
    if area_key in filter:
        area_list = []
        for i in filter[area_key]:
            if not i:
                continue
            else:
                if isinstance(i, int):
                    area_list.append(str(i))
                else:
                    if isinstance(i, str):
                        area_list.append(i)
                    else:
                        value = getattr(i, 'id', None)
                        if value:
                            area_list.append(str(value))
        if area_list:
            area_list.sort()
            key_strs.append('area_ids:' + '-'.join(area_list))
    if company_key in filter:
        company_list = []
        i = filter[company_key]
        if i:
            if isinstance(i, int):
                company_list.append(str(i))
            else:
                if isinstance(i, str):
                    company_list.append(i)
                else:
                    value = getattr(i, 'id', None)
                    if value:
                        company_list.append(str(value))
        if company_list:
            company_list.sort()
            key_strs.append('company:' + '-'.join(company_list))
    if extra_dict is not None:
        keys = list(extra_dict.keys())
        keys.sort()
        for key in keys:
            key_strs.append('%s:%s' % (key, extra_dict[key]))
    key_strs.append('lng:%s' % lng)
    key_str = ''.join(key_strs)
    m = hashlib.md5()
    m.update(bytes(key_str, 'utf8'))
    return prefix + m.hexdigest()
@login_required
def transaction_part(request, message, is_websocket):
    import time
    from django.db.models import Case, When, Value, CharField
    from django.db.models.functions import Cast
    from django.conf import settings
    from mysite.iclock.models import Transaction
    from mysite.base.utils import get_punch_states
    from mysite.personnel.models import Employee
    state = dict(get_punch_states())
    if is_websocket:
        bp = int(message['bp']) if int(message['bp']) else 0
    else:
        bp = int(request.POST.get('bp', 0))
    now = datetime.datetime.now()
    user = request.user
    next_day = now + datetime.timedelta(days=1)
    queryset = Transaction.objects.filter(pk__gt=bp, punch_time__range=[now.date(), next_day.date()]).order_by('-punch_time')
    if user.is_employee:
        queryset = queryset.filter(emp=user)
    else:
        filters = {}
        if not user.is_superuser:
            if user.auth_dept.exists():
                filters['emp__department__in'] = request.user.auth_dept.all()
            if user.auth_area.exists():
                employees = Employee.objects.filter(area__in=user.auth_area.all())
                filters['emp__in'] = employees
            if user.assign_company:
                filters['emp__company'] = request.user.assign_company
            queryset = queryset.filter(**filters).exclude(emp=None)
    if not queryset.exists():
        _message = json.dumps({'data': [], 'score': bp})
        return _message
    else:
        if settings.DATABASE_ENGINE == 'oracle':
            queryset = queryset.annotate(pin=Cast('emp__emp_code', output_field=CharField(max_length=50)), emp_name=Cast('emp__first_name', output_field=CharField(max_length=50)), location=Case(When(terminal_sn__isnull=False, then='terminal_alias'), output_field=CharField(max_length=50)), icon=Case(When(terminal_sn__isnull=False, then=Value('/media/images/device.png')), output_field=CharField(max_length=50)))
        else:
            queryset = queryset.annotate(pin=Cast('emp__emp_code', output_field=CharField(max_length=50)), emp_name=Cast('emp__first_name', output_field=CharField(max_length=50)), location=Case(When(gps_location__isnull=False, then='gps_location'), When(terminal_sn__isnull=False, then='terminal_alias'), output_field=CharField(max_length=50)), icon=Case(When(gps_location__isnull=False, then=Value('/media/images/location.png')), When(terminal_sn__isnull=False, then=Value('/media/images/device.png')), output_field=CharField(max_length=50)))
        queryset = queryset.values('id', 'pin', 'emp_name', 'punch_time', 'punch_state', 'gps_location', 'terminal_sn', 'terminal_alias', 'location', 'icon', 'is_mask', 'temperature', 'emp__company__id')
        data = queryset[:50]
        logs = []
        score = bp
        stamp = int(time.time())
        from mysite.tools.access_utils import get_access_token
        for t in data:
            punch_time = t['punch_time'].strftime('%H:%M:%S')
            photo = capture = ''
            filename = '{0}.jpg'.format(t['pin'])
            _photo = 'photo/' + filename
            if getattr_ex(settings, 'MULTI_COMPANY', False):
                _photo = 'photo/{0}/{1}.jpg'.format(t['emp__company__id'], t['pin'])
            access_token = get_access_token({'n': filename, 'p': _photo})
            if settings.ENABLE_ENCRYPT_PHOTO:
                if os.path.exists(os.path.join(settings.AUTH_FILE_ROOT, _photo)):
                    photo = '/auth_files/' + access_token
            else:
                if os.path.exists(os.path.join(settings.ADDITION_FILE_ROOT, _photo)):
                    photo = '/files/' + access_token
            t.update({'month': t['punch_time'].strftime('%Y%m'), 'datetime': t['punch_time'].strftime('%Y%m%d%H%M%S'), 'terminal_sn': t['terminal_sn'].replace(':', '-')})
            _capture = 'upload/{month}/{terminal_sn}/{datetime}-{pin}.jpg'.format(**t)
            if os.path.exists(os.path.join(settings.ADDITION_FILE_ROOT, _capture)):
                capture = '/files/{0}'.format(_capture)
            punch_state = t['punch_state']
            if t['temperature'] == 255:
                temperature = _('transaction.temperatureOpts.unknown')
            else:
                temperature = t['temperature']
            logs.append((t['id'], t['pin'], t['emp_name'] or '', punch_time, force_str(state.get(punch_state, punch_state)), capture, photo, t['location'] or '', t['icon'] or '', t['is_mask'], str(temperature)))
            score = max([score, t['id']])
        _message = json.dumps({'data': logs, 'score': score})
        return _message
def transaction_part_ws(user, message: dict, max_pk=999999999):
    import time
    from django.db.models import Case, When, Value, CharField
    from django.db.models.functions import Cast
    from django.conf import settings
    from mysite.iclock.models import Transaction
    from mysite.base.utils import get_punch_states
    from mysite.personnel.models import Employee
    state = dict(get_punch_states())
    bp = message.get('bp', 0)
    bp = bp if bp else 0
    now = datetime.datetime.now()
    user = user
    next_day = now + datetime.timedelta(days=1)
    queryset = Transaction.objects.filter(pk__gt=bp, pk__lte=max_pk, punch_time__range=[now.date(), next_day.date()]).order_by('-punch_time')
    if user.is_employee:
        queryset = queryset.filter(emp=user)
    else:
        filters = {}
        if not user.is_superuser:
            if user.auth_dept.exists():
                filters['emp__department__in'] = user.auth_dept.all()
            if user.auth_area.exists():
                employees = Employee.objects.filter(area__in=user.auth_area.all())
                filters['emp__in'] = employees
            if user.assign_company:
                filters['emp__company'] = user.assign_company
            queryset = queryset.filter(**filters).exclude(emp=None)
    if not queryset.exists():
        _message = json.dumps({'data': [], 'score': bp})
        return (_message, bp)
    else:
        if settings.DATABASE_ENGINE == 'oracle':
            queryset = queryset.annotate(pin=Cast('emp__emp_code', output_field=CharField(max_length=50)), emp_name=Cast('emp__first_name', output_field=CharField(max_length=50)), location=Case(When(terminal_sn__isnull=False, then='terminal_alias'), output_field=CharField(max_length=50)), icon=Case(When(terminal_sn__isnull=False, then=Value('/media/images/device.png')), output_field=CharField(max_length=50)))
        else:
            queryset = queryset.annotate(pin=Cast('emp__emp_code', output_field=CharField(max_length=50)), emp_name=Cast('emp__first_name', output_field=CharField(max_length=50)), location=Case(When(gps_location__isnull=False, then='gps_location'), When(terminal_sn__isnull=False, then='terminal_alias'), output_field=CharField(max_length=50)), icon=Case(When(gps_location__isnull=False, then=Value('/media/images/location.png')), When(terminal_sn__isnull=False, then=Value('/media/images/device.png')), output_field=CharField(max_length=50)))
        queryset = queryset.values('id', 'pin', 'emp_name', 'punch_time', 'punch_state', 'gps_location', 'terminal_sn', 'terminal_alias', 'location', 'icon', 'is_mask', 'temperature', 'emp__company__id')
        data = queryset[:50]
        logs = []
        score = bp
        stamp = int(time.time())
        from mysite.tools.access_utils import get_access_token
        for t in data:
            punch_time = t['punch_time'].strftime('%H:%M:%S')
            photo = capture = ''
            filename = '{0}.jpg'.format(t['pin'])
            _photo = 'photo/' + filename
            if getattr_ex(settings, 'MULTI_COMPANY', False):
                _photo = 'photo/{0}/{1}.jpg'.format(t['emp__company__id'], t['pin'])
            access_token = get_access_token({'n': filename, 'p': _photo})
            if settings.ENABLE_ENCRYPT_PHOTO:
                if os.path.exists(os.path.join(settings.AUTH_FILE_ROOT, _photo)):
                    photo = '/auth_files/' + access_token
            else:
                if os.path.exists(os.path.join(settings.ADDITION_FILE_ROOT, _photo)):
                    photo = '/files/' + access_token
            t.update({'month': t['punch_time'].strftime('%Y%m'), 'datetime': t['punch_time'].strftime('%Y%m%d%H%M%S'), 'terminal_sn': t['terminal_sn'].replace(':', '-')})
            _capture = 'upload/{month}/{terminal_sn}/{datetime}-{pin}.jpg'.format(**t)
            if os.path.exists(os.path.join(settings.ADDITION_FILE_ROOT, _capture)):
                capture = '/files/{0}'.format(_capture)
            punch_state = t['punch_state']
            if t['temperature'] == 255:
                temperature = _('transaction.temperatureOpts.unknown')
            else:
                temperature = t['temperature']
            logs.append((t['id'], t['pin'], t['emp_name'] or '', punch_time, force_str(state.get(punch_state, punch_state)), capture, photo, t['location'] or '', t['icon'] or '', t['is_mask'], str(temperature)))
            score = max([score, t['id']])
        _message = json.dumps({'data': logs, 'score': score})
        return (_message, score)
@login_required
def leave_part(request):
    from django.db.models import CharField, Q
    from django.db.models.functions import Cast
    from mysite.att.models import Leave
    today = datetime.datetime.now().date()
    user = request.user
    queryset = Leave.objects.filter(Q(start_time__date__gte=today) | Q(end_time__date__gte=today)).filter(approval_status=2).order_by('start_time')
    if user.is_employee:
        queryset = queryset.filter(employee=user)
    else:
        filters = {}
        if request.user.auth_dept.exists():
            filters['employee__department__in'] = request.user.auth_dept.all()
        if request.user.auth_area.exists():
            filters['employee__area__in'] = request.user.auth_area.all()
        if request.user.assign_company:
            filters['employee__company'] = request.user.assign_company
        queryset = queryset.filter(**filters).exclude(employee=None)
        if not request.user.is_superuser:
            queryset = queryset.distinct()
    if not queryset.count():
        _message = json.dumps({'data': [], 'score': '0'})
        return _message
    else:
        queryset = queryset.annotate(pin=Cast('employee__emp_code', output_field=CharField(max_length=50)), emp_name=Cast('employee__first_name', output_field=CharField(max_length=50)), dept_name=Cast('employee__department__dept_name', output_field=CharField(max_length=50)))
        queryset = queryset.values('id', 'pin', 'emp_name', 'start_time', 'end_time', 'dept_name', 'employee__company_id')
        data = queryset[:50]
        logs = []
        logs.append((str(_('emp_field_employeeCode')), str(_('emp_field_firstName')), str(_('employee_field_department')), str(_('Time Range')), ''))
        score = 0
        for t in data:
            start_time = str(t['start_time'])
            end_time = str(t['end_time'])
            dept = t['dept_name']
            logs.append((t['pin'], t['emp_name'] or '', dept, start_time, end_time))
            score = max([score, t['id']])
        _message = json.dumps({'data': logs, 'score': score})
        return _message
def monitor_part(request):
    import json
    from django.core.cache import cache
    from mysite.base import tasks
    if request.user.is_superuser:
        cache_key = 'dashboard_monitor_superuser'
    else:
        cache_key = 'dashboard_monitor_user_{id}'.format(id=request.user.id)
    payload = cache.get(cache_key, None) or {}
    if not cache.get(cache_key + '_exists'):
        cache.set(cache_key + '_exists', True, 60)
        tasks.dashboard_request.delay(request.user, cache_key)
    dataset = payload.get('dataset', {})
    response = {'title': {'text': '{title}'.format(title=_('dashboard_real_time_monitor'))}, 'legend': {'data': ['{legend}'.format(legend=_('symbol_p'))]}, 'xAxis': {'data': dataset.get('heads', [])}, 'series': [{'name': '{legend}'.format(legend=_('symbol_p')), 'data': dataset.get('payload', [])}]}
    _message = json.dumps(response)
    return _message
def monitor_part_ws(user):
    import json
    from django.core.cache import cache
    from mysite.base import tasks
    if user.is_superuser:
        cache_key = 'dashboard_monitor_superuser'
    else:
        cache_key = 'dashboard_monitor_user_{id}'.format(id=user.id)
    payload = cache.get(cache_key, None) or {}
    if not cache.get(cache_key + '_exists'):
        cache.set(cache_key + '_exists', True, 60)
        tasks.dashboard_request.delay(user, cache_key)
    dataset = payload.get('dataset', {})
    response = {'title': {'text': '{title}'.format(title=_('dashboard_real_time_monitor'))}, 'legend': {'data': ['{legend}'.format(legend=_('symbol_p'))]}, 'xAxis': {'data': dataset.get('heads', [])}, 'series': [{'name': '{legend}'.format(legend=_('symbol_p')), 'data': dataset.get('payload', [])}]}
    _message = json.dumps(response)
    return _message
@login_required
def realtime_punch(request):
    _message = transaction_part(request, '', False)
    return HttpResponse(_message)
@login_required
def view_leave(request):
    _message = leave_part(request)
    return HttpResponse(_message)
@login_required
def dashboard_realtime_monitor(request):
    if request.method == 'POST':
        _message = monitor_part(request)
        return HttpResponse(_message)
    else:
        return None
@login_required
def calc_present_part(request):
    from django.db.models import Sum, Case, When, Value, IntegerField
    from mysite.att.models import PayloadPayCode, PayCode
    now = datetime.datetime.now()
    payload_qs = PayloadPayCode.objects.all()
    filters = filter_conditions(request, 'emp__department__in', 'emp__area__in', 'emp__company')
    cache_key = None
    try:
        lng = request.LANGUAGE_CODE if request.LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'department__in', 'area__in', 'emp__company', 'calc_present_chart')
    except:
        logging.getLogger('mysite').exception('calc_present_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    filters.update({'att_date': now.date()})
    payload_qs = payload_qs.filter(**filters)
    payload_qs = payload_qs.values('emp_id', 'time_card_id').order_by('emp_id').annotate(present_dec=Sum(Case(When(pay_code=PayCode.regular(), duration__gt=0, then=Value(8)), default=Value(0)), output_field=IntegerField()), late_dec=Sum(Case(When(pay_code=PayCode.late_in(), duration__gt=0, then=Value(4)), default=Value(0)), output_field=IntegerField()), early_dec=Sum(Case(When(pay_code=PayCode.early_out(), duration__gt=0, then=Value(1)), default=Value(0)), output_field=IntegerField()), absent_dec=Sum(Case(When(pay_code=PayCode.absent(), duration__gt=0, then=Value(1)), default=Value(0)), output_field=IntegerField()))
    NORMAL_KEY, ABSENT_KEY = (int('1000', 2), int('0001', 2))
    LATE_KEY, EARLY_KEY, LATE_EARLY_KEY = (int('1100', 2), int('1010', 2), int('1110', 2))
    data_dict = {NORMAL_KEY: 0, LATE_KEY: 0, EARLY_KEY: 0, LATE_EARLY_KEY: 0, ABSENT_KEY: 0}
    for i in payload_qs:
        _sum = i['present_dec'] + i['late_dec'] + i['early_dec'] + i['absent_dec']
        if _sum == 0:
            continue
        else:
            if _sum == 2:
                _sum = EARLY_KEY
            if _sum == 4:
                _sum = LATE_KEY
            if _sum == 6:
                _sum = LATE_EARLY_KEY
            if _sum in data_dict:
                data_dict[_sum] += 1
            else:
                data_dict[_sum] = 1
    data = {'title': {'text': '%s' % _('chart_present')}, 'legend': {'orient': 'vertical', 'x': 'left', 'y': 'bottom', 'data': ['%s' % _('dashboard.present.normal'), '%s' % _('dashboard.present.absence'), '%s' % _('dashboard.present.late'), '%s' % _('dashboard.present.early_leave'), '%s' % _('dashboard.present.late&early_leave')]}, 'series': [{'name': '', 'center': ['60%', '50%'], 'data': [{'value': data_dict[NORMAL_KEY], 'name': '%s' % _('dashboard.present.late')}, {'value': data_dict[EARLY_KEY], 'name': '%s' % _('dashboard.present.early_leave')}, {'value': data_dict[
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
def calc_present_part_ws(user, params: dict, cookies: dict):
    from django.db.models import Sum, Case, When, Value, IntegerField
    from mysite.att.models import PayloadPayCode, PayCode
    now = datetime.datetime.now()
    payload_qs = PayloadPayCode.objects.all()
    filters = filter_conditions_ws(user, 'emp__department__in', 'emp__area__in', 'emp__company', params=params)
    cache_key = None
    LANGUAGE_CODE = cookies.get('django_language', 'en')
    try:
        lng = LANGUAGE_CODE if LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'department__in', 'area__in', 'emp__company', 'calc_present_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('calc_present_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if LANGUAGE_CODE and translation.check_for_language(LANGUAGE_CODE):
            translation.activate(LANGUAGE_CODE)
    filters.update({'att_date': now.date()})
    payload_qs = payload_qs.filter(**filters)
    payload_qs = payload_qs.values('emp_id', 'time_card_id').order_by('emp_id').annotate(present_dec=Sum(Case(When(pay_code=PayCode.regular(), duration__gt=0, then=Value(8)), default=Value(0)), output_field=IntegerField()), late_dec=Sum(Case(When(pay_code=PayCode.late_in(), duration__gt=0, then=Value(4)), default=Value(0)), output_field=IntegerField()), early_dec=Sum(Case(When(pay_code=PayCode.early_out(), duration__gt=0, then=Value(1)), default=Value(0)), output_field=IntegerField()), absent_dec=Sum(Case(When(pay_code=PayCode.absent(), duration__gt=0, then=Value(1)), default=Value(0)), output_field=IntegerField()))
    NORMAL_KEY, ABSENT_KEY = (int('1000', 2), int('0001', 2))
    LATE_KEY, EARLY_KEY, LATE_EARLY_KEY = (int('1100', 2), int('1010', 2), int('1110', 2))
    data_dict = {NORMAL_KEY: 0, LATE_KEY: 0, EARLY_KEY: 0, LATE_EARLY_KEY: 0, ABSENT_KEY: 0}
    for i in payload_qs:
        _sum = i['present_dec'] + i['late_dec'] + i['early_dec'] + i['absent_dec']
        if _sum == 0:
            continue
        else:
            if _sum == 2:
                _sum = EARLY_KEY
            if _sum == 4:
                _sum = LATE_KEY
            if _sum == 6:
                _sum = LATE_EARLY_KEY
            if _sum in data_dict:
                data_dict[_sum] += 1
            else:
                data_dict[_sum] = 1
    data = {'title': {'text': '%s' % _('chart_present')}, 'legend': {'orient': 'vertical', 'x': 'left', 'y': 'bottom', 'data': ['%s' % _('dashboard.present.normal'), '%s' % _('dashboard.present.absence'), '%s' % _('dashboard.present.late'), '%s' % _('dashboard.present.early_leave'), '%s' % _('dashboard.present.late&early_leave')]}, 'series': [{'name': '', 'center': ['60%', '50%'], 'data': [{'value': data_dict[NORMAL_KEY], 'name': '%s' % _('dashboard.present.late')}, {'value': data_dict[EARLY_KEY], 'name': '%s' % _('dashboard.present.early_leave')}, {'value': data_dict[
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
@login_required
def calc_present_chart(request):
    if request.method == 'POST':
        _message = calc_present_part(request)
        return HttpResponse(_message)
    else:
        return None
@login_required
def punch_present_part(request):
    from mysite.personnel.models import Employee
    from mysite.iclock.models import Transaction
    now = datetime.datetime.now()
    next_day = now + datetime.timedelta(days=1)
    emp_queryset = Employee.objects.all()
    queryset = Transaction.objects.all().filter(punch_time__range=[now.date(), next_day.date()])
    filters = filter_conditions(request, 'department__in', 'area__in', 'company')
    cache_key = None
    try:
        lng = request.LANGUAGE_CODE if request.LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'department__in', 'area__in', 'company', 'punch_present_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('punch_present_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if filters:
        emp_queryset = emp_queryset.filter(**filters)
        emp_queryset = emp_queryset.distinct()
    queryset = queryset.filter(emp__in=emp_queryset)
    queryset = queryset.values('emp_code').distinct().order_by('emp_code')
    present = queryset.count()
    total = emp_queryset.count()
    data = {'title': {'text': '%s' % _('chart_present')}, 'legend': {'data': ['%s' % _('dashboard.present.present'), '%s' % _('dashboard.present.absent')]}, 'series': [{'name': '', 'center': ['50%', '50%'], 'data': [{'value': present, 'name': '%s' % _('dashboard.present.present')}, {'value': total - present, 'name': '%s' % _('dashboard.present.absent')}]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
def punch_present_part_ws(user, params: dict, cookies: dict):
    from mysite.personnel.models import Employee
    from mysite.iclock.models import Transaction
    now = datetime.datetime.now()
    next_day = now + datetime.timedelta(days=1)
    emp_queryset = Employee.objects.all()
    queryset = Transaction.objects.all().filter(punch_time__range=[now.date(), next_day.date()])
    filters = filter_conditions_ws(user, 'department__in', 'area__in', 'company', params=params)
    cache_key = None
    LANGUAGE_CODE = cookies.get('django_language', 'en')
    try:
        lng = LANGUAGE_CODE if LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'department__in', 'area__in', 'company', 'punch_present_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('punch_present_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if LANGUAGE_CODE and translation.check_for_language(LANGUAGE_CODE):
            translation.activate(LANGUAGE_CODE)
    if filters:
        emp_queryset = emp_queryset.filter(**filters)
        emp_queryset = emp_queryset.distinct()
    queryset = queryset.filter(emp__in=emp_queryset)
    queryset = queryset.values('emp_code').distinct().order_by('emp_code')
    present = queryset.count()
    total = emp_queryset.count()
    data = {'title': {'text': '%s' % _('chart_present')}, 'legend': {'data': ['%s' % _('dashboard.present.present'), '%s' % _('dashboard.present.absent')]}, 'series': [{'name': '', 'center': ['50%', '50%'], 'data': [{'value': present, 'name': '%s' % _('dashboard.present.present')}, {'value': total - present, 'name': '%s' % _('dashboard.present.absent')}]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
@login_required
def punch_present_chart(request):
    if request.method == 'POST':
        _message = punch_present_part(request)
        return HttpResponse(_message)
    else:
        return None
@login_required
def device_status_part(request):
    from mysite.iclock.models import Terminal
    from mysite.iclock import const
    user = request.user
    online = offline = unauthorized = 0
    qs = Terminal.objects.all()
    filters = filter_conditions(request, None, 'area__in', 'area__company')
    cache_key = None
    try:
        lng = request.LANGUAGE_CODE if request.LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, None, 'area__in', 'area__company', 'device_status_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('device_status_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if filters:
        qs = qs.filter(**filters)
    for obj in qs:
        state = obj.getDynState()
        if obj.area.is_default:
            unauthorized += 1
        else:
            if state == const.TERMINAL_OFFLINE:
                offline += 1
            else:
                online += 1
    data = {'title': {'text': '%s' % _('dashboard.device_status')}, 'legend': {'data': ['%s' % _('dashboard.device_status.online'), '%s' % _('dashboard.device_status.offline'), '%s' % _('dashboard.device_status.unauthorized')]}, 'series': [{'data': [{'value': online, 'name': '%s' % _('dashboard.device_status.online')}, {'value': offline, 'name': '%s' % _('dashboard.device_status.offline')}, {'value': unauthorized, 'name': '%s' % _('dashboard.device_status.unauthorized')}]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
def device_status_part_ws(user, params: dict, cookies: dict):
    from mysite.iclock.models import Terminal
    from mysite.iclock import const
    user = user
    online = offline = unauthorized = 0
    qs = Terminal.objects.all()
    filters = filter_conditions_ws(user, None, 'area__in', 'area__company', params=params)
    cache_key = None
    LANGUAGE_CODE = cookies.get('django_language', 'en')
    try:
        lng = LANGUAGE_CODE if LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, None, 'area__in', 'area__company', 'device_status_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('device_status_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if LANGUAGE_CODE and translation.check_for_language(LANGUAGE_CODE):
            translation.activate(LANGUAGE_CODE)
    if filters:
        qs = qs.filter(**filters)
    for obj in qs:
        state = obj.getDynState()
        if obj.area.is_default:
            unauthorized += 1
        else:
            if state == const.TERMINAL_OFFLINE:
                offline += 1
            else:
                online += 1
    data = {'title': {'text': '%s' % _('dashboard.device_status')}, 'legend': {'data': ['%s' % _('dashboard.device_status.online'), '%s' % _('dashboard.device_status.offline'), '%s' % _('dashboard.device_status.unauthorized')]}, 'series': [{'data': [{'value': online, 'name': '%s' % _('dashboard.device_status.online')}, {'value': offline, 'name': '%s' % _('dashboard.device_status.offline')}, {'value': unauthorized, 'name': '%s' % _('dashboard.device_status.unauthorized')}]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
@login_required
def device_status_chart(request):
    if request.method == 'POST':
        _message = device_status_part(request)
        return HttpResponse(_message)
    else:
        return None
@login_required
def punch_dept_att_part(request):
    from django.db.models import Count, Max
    from mysite.personnel.models import Employee
    now = datetime.datetime.now()
    next_day = now + datetime.timedelta(days=1)
    emp_queryset = Employee.objects.all()
    filters = filter_conditions(request, 'department__in', None, 'company')
    cache_key = None
    try:
        lng = request.LANGUAGE_CODE if request.LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'department__in', None, 'company', 'punch_dept_att_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('punch_dept_att_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if filters:
        emp_queryset = emp_queryset.filter(**filters)
    dept_emp_qs = emp_queryset.values('department_id', 'department__dept_code', 'department__dept_name').order_by('department_id').annotate(total=Count('id'))
    data_list = []
    punch_emp_qs = emp_queryset.values('emp_code', 'department_id').order_by('department_id').annotate(last=Max('transaction__punch_time')).filter(last__range=[now.date(), next_day.date()])
    punch_emp_dict = {key: list(items) for key, items in itertools.groupby(punch_emp_qs, operator.itemgetter('department_id'))}
    for dept in dept_emp_qs:
        xaxis_name = '{0} {1}'.format(dept['department__dept_code'], dept['department__dept_name'])
        dept_punch_count = len(punch_emp_dict.get(dept['department_id'], []))
        data_list.append({'xaxis_name': xaxis_name, 'value': round(dept_punch_count / dept['total'] * 100, 2)})
    data_list = sorted(data_list, key=operator.itemgetter('value'), reverse=True)
    data = {'title': {'text': '%s' % _('dashboard.department_attendance_statistics')}, 'xAxis': {'data': [i['xaxis_name'] for i in data_list]}, 'series': [{'data': [format(i['value'], '.2f') for i in data_list]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
def punch_dept_att_part_ws(user, params: dict, cookies: dict):
    from django.db.models import Count, Max
    from mysite.personnel.models import Employee
    now = datetime.datetime.now()
    next_day = now + datetime.timedelta(days=1)
    emp_queryset = Employee.objects.all()
    filters = filter_conditions_ws(user, 'department__in', None, 'company', params=params)
    cache_key = None
    LANGUAGE_CODE = cookies.get('django_language', 'en')
    try:
        lng = LANGUAGE_CODE if LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'department__in', None, 'company', 'punch_dept_att_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('punch_dept_att_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if LANGUAGE_CODE and translation.check_for_language(LANGUAGE_CODE):
            translation.activate(LANGUAGE_CODE)
    if filters:
        emp_queryset = emp_queryset.filter(**filters)
    dept_emp_qs = emp_queryset.values('department_id', 'department__dept_code', 'department__dept_name').order_by('department_id').annotate(total=Count('id'))
    data_list = []
    punch_emp_qs = emp_queryset.values('emp_code', 'department_id').order_by('department_id').annotate(last=Max('transaction__punch_time')).filter(last__range=[now.date(), next_day.date()])
    punch_emp_dict = {key: list(items) for key, items in itertools.groupby(punch_emp_qs, operator.itemgetter('department_id'))}
    for dept in dept_emp_qs:
        xaxis_name = '{0} {1}'.format(dept['department__dept_code'], dept['department__dept_name'])
        dept_punch_count = len(punch_emp_dict.get(dept['department_id'], []))
        data_list.append({'xaxis_name': xaxis_name, 'value': round(dept_punch_count / dept['total'] * 100, 2)})
    data_list = sorted(data_list, key=operator.itemgetter('value'), reverse=True)
    data = {'title': {'text': '%s' % _('dashboard.department_attendance_statistics')}, 'xAxis': {'data': [i['xaxis_name'] for i in data_list]}, 'series': [{'data': [format(i['value'], '.2f') for i in data_list]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
@login_required
def punch_dept_att_chart(request):
    if request.method == 'POST':
        _message = punch_dept_att_part(request)
        return HttpResponse(_message)
    else:
        return None
@login_required
def calc_dept_att_part(request):
    from django.db.models import F, Case, When, Sum, Value, IntegerField
    from mysite.att.models import PayloadPayCode, PayCode
    now = datetime.datetime.now()
    payload_qs = PayloadPayCode.objects.filter(att_date=now.date())
    filters = filter_conditions(request, 'emp__department__in', None, 'emp__company')
    cache_key = None
    try:
        lng = request.LANGUAGE_CODE if request.LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'emp__department__in', None, 'emp__company', 'calc_dept_att_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('calc_dept_att_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if filters:
        payload_qs = payload_qs.filter(**filters)
    payload_qs = payload_qs.values(dept_id=F('emp__department_id'), dept_code=F('emp__department__dept_code'), dept_name=F('emp__department__dept_name')).order_by('emp__department_id').annotate(present_count=Sum(Case(When(pay_code=PayCode.regular(), duration__gt=0, then=Value(1)), default=Value(0), output_field=IntegerField(), distinct=True)), total_count=Sum(Case(When(pay_code=PayCode.regular(), then=Value(1)), default=Value(0), output_field=IntegerField(), distinct=True)))
    dept_dict = {key: list(items) for key, items in itertools.groupby(payload_qs, operator.itemgetter('dept_id'))}
    data_list = []
    for key in dept_dict:
        _items = dept_dict[key]
        dept_total_emp = len(_items)
        dept_code = _items[0].get('dept_code', '')
        dept_name = _items[0].get('dept_name', '')
        total_shifts = sum([i['total_count'] for i in _items])
        present_shifts = sum([i['present_count'] for i in _items])
        xaxis_name = '{0} {1}'.format(dept_code, dept_name)
        data_list.append({'xaxis_name': xaxis_name, 'value': round(present_shifts / total_shifts * 100, 2) if total_shifts else 0})
    data_list = sorted(data_list, key=operator.itemgetter('value'), reverse=True)
    data = {'title': {'text': '%s' % _('dashboard.department_attendance_statistics')}, 'xAxis': {'data': [i['xaxis_name'] for i in data_list]}, 'series': [{'data': [format(i['value'], '.2f') for i in data_list]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
def calc_dept_att_part_ws(user, params: dict, cookies: dict):
    from django.db.models import F, Case, When, Sum, Value, IntegerField
    from mysite.att.models import PayloadPayCode, PayCode
    now = datetime.datetime.now()
    payload_qs = PayloadPayCode.objects.filter(att_date=now.date())
    filters = filter_conditions_ws(user, 'emp__department__in', None, 'emp__company', params=params)
    cache_key = None
    LANGUAGE_CODE = cookies.get('django_language', 'en')
    try:
        lng = LANGUAGE_CODE if LANGUAGE_CODE else 'en'
        cache_key = get_filter_cache_key(filters, 'emp__department__in', None, 'emp__company', 'calc_dept_att_chart', lng=lng)
    except:
        logging.getLogger('mysite').exception('calc_dept_att_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if LANGUAGE_CODE and translation.check_for_language(LANGUAGE_CODE):
            translation.activate(LANGUAGE_CODE)
    if filters:
        payload_qs = payload_qs.filter(**filters)
    payload_qs = payload_qs.values(dept_id=F('emp__department_id'), dept_code=F('emp__department__dept_code'), dept_name=F('emp__department__dept_name')).order_by('emp__department_id').annotate(present_count=Sum(Case(When(pay_code=PayCode.regular(), duration__gt=0, then=Value(1)), default=Value(0), output_field=IntegerField(), distinct=True)), total_count=Sum(Case(When(pay_code=PayCode.regular(), then=Value(1)), default=Value(0), output_field=IntegerField(), distinct=True)))
    dept_dict = {key: list(items) for key, items in itertools.groupby(payload_qs, operator.itemgetter('dept_id'))}
    data_list = []
    for key in dept_dict:
        _items = dept_dict[key]
        dept_total_emp = len(_items)
        dept_code = _items[0].get('dept_code', '')
        dept_name = _items[0].get('dept_name', '')
        total_shifts = sum([i['total_count'] for i in _items])
        present_shifts = sum([i['present_count'] for i in _items])
        xaxis_name = '{0} {1}'.format(dept_code, dept_name)
        data_list.append({'xaxis_name': xaxis_name, 'value': round(present_shifts / total_shifts * 100, 2) if total_shifts else 0})
    data_list = sorted(data_list, key=operator.itemgetter('value'), reverse=True)
    data = {'title': {'text': '%s' % _('dashboard.department_attendance_statistics')}, 'xAxis': {'data': [i['xaxis_name'] for i in data_list]}, 'series': [{'data': [format(i['value'], '.2f') for i in data_list]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
@login_required
def calc_dept_att_chart(request):
    if request.method == 'POST':
        _message = calc_dept_att_part(request)
        return HttpResponse(_message)
    else:
        return None
@login_required
def montly_summary_part(request):
    import calendar
    from django.db.models import F, Case, When, Sum, Value, DecimalField
    from mysite.att.models import PayloadPayCode
    from mysite.att.models.model_paycode import REGULAR, OVERTIME
    from mysite.personnel.models import Department
    time_period = request.POST.get('time_period', None)
    if time_period:
        _time_period = json.loads(time_period)
        period_start = datetime.datetime.strptime(_time_period['start_date'], '%Y-%m-%d')
        period_end = datetime.datetime.strptime(_time_period['end_date'], '%Y-%m-%d')
    else:
        today = datetime.datetime.now()
        period_start = datetime.datetime(today.year, today.month, 1)
        month_days = calendar.monthrange(today.year, today.month)[1]
        period_end = datetime.datetime(today.year, today.month, month_days)
    payload_qs = PayloadPayCode.objects.filter(att_date__range=[period_start.date(), period_end.date()])
    dept_qs = Department.objects.all()
    filters = filter_conditions(request, 'id__in', None, 'company')
    cache_key = None
    try:
        lng = request.LANGUAGE_CODE if request.LANGUAGE_CODE else 'en'
        extra_dict = {'start_date': period_start.strftime('%Y-%m-%d'), 'end_date': period_end.strftime('%Y-%m-%d')}
        cache_key = get_filter_cache_key(filters, 'id__in', None, 'company', 'montly_summary_chart', extra_dict, lng=lng)
    except:
        logging.getLogger('mysite').exception('montly_summary_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if filters:
        dept_qs = dept_qs.filter(**filters)
        payload_qs = payload_qs.filter(emp__department__in=dept_qs)
    payload_qs = payload_qs.values(dept_id=F('emp__department__id')).order_by('emp__department__id').annotate(total_hrs=Sum(Case(When(pay_code__fixed_code=REGULAR, then='hours'), default=Value(0), output_field=DecimalField())), total_ot=Sum(Case(When(pay_code__code_type=OVERTIME, then='hours'), default=Value(0), output_field=DecimalField())))
    dept_qs = dept_qs.values('id', 'dept_code', 'dept_name').order_by('id')
    dept_dict = {item['id']: item for item in dept_qs}
    data_list = []
    for item in payload_qs:
        _dept_item = dept_dict[item['dept_id']]
        xaxis_name = '{0} {1}'.format(_dept_item['dept_code'], _dept_item['dept_name'])
        data_list.append({'xaxis_name': xaxis_name, 'total_worked_hrs': format(item['total_hrs'], '.2f'), 'total_ot': format(item['total_ot'], '.2f'), 'total_all': item['total_hrs'] + item['total_ot']})
    data_list = sorted(data_list, key=operator.itemgetter('total_all'), reverse=True)
    data = {'legend': {'data': ['%s' % _('dashboard.monthly_summary.total_worked_hrs'), '%s' % _('dashboard.monthly_summary.total_overtime')]}, 'xAxis': {'data': [i['xaxis_name'] for i in data_list]}, 'series': [{'name': '%s' % _('dashboard.monthly_summary.total_worked_hrs'), 'type': 'bar', 'data': [i['total_ot'] for i in data_list]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
def montly_summary_part_ws(user, params: dict, cookies: dict):
    import calendar
    from django.db.models import F, Case, When, Sum, Value, DecimalField
    from mysite.att.models import PayloadPayCode
    from mysite.att.models.model_paycode import REGULAR, OVERTIME
    from mysite.personnel.models import Department
    time_period = params.get('time_period', None)
    if time_period:
        _time_period = json.loads(time_period)
        period_start = datetime.datetime.strptime(_time_period['start_date'], '%Y-%m-%d')
        period_end = datetime.datetime.strptime(_time_period['end_date'], '%Y-%m-%d')
    else:
        today = datetime.datetime.now()
        period_start = datetime.datetime(today.year, today.month, 1)
        month_days = calendar.monthrange(today.year, today.month)[1]
        period_end = datetime.datetime(today.year, today.month, month_days)
    payload_qs = PayloadPayCode.objects.filter(att_date__range=[period_start.date(), period_end.date()])
    dept_qs = Department.objects.all()
    filters = filter_conditions_ws(user, 'id__in', None, 'company', params=params)
    cache_key = None
    LANGUAGE_CODE = cookies.get('django_language', 'en')
    try:
        lng = LANGUAGE_CODE if LANGUAGE_CODE else 'en'
        extra_dict = {'start_date': period_start.strftime('%Y-%m-%d'), 'end_date': period_end.strftime('%Y-%m-%d')}
        cache_key = get_filter_cache_key(filters, 'id__in', None, 'company', 'montly_summary_chart', extra_dict, lng=lng)
    except:
        logging.getLogger('mysite').exception('montly_summary_chart')
    if cache_key:
        cache_data = cache.get(cache_key)
        if cache_data:
            return json.dumps(cache_data)
    if LANGUAGE_CODE and translation.check_for_language(LANGUAGE_CODE):
            translation.activate(LANGUAGE_CODE)
    if filters:
        dept_qs = dept_qs.filter(**filters)
        payload_qs = payload_qs.filter(emp__department__in=dept_qs)
    payload_qs = payload_qs.values(dept_id=F('emp__department__id')).order_by('emp__department__id').annotate(total_hrs=Sum(Case(When(pay_code__fixed_code=REGULAR, then='hours'), default=Value(0), output_field=DecimalField())), total_ot=Sum(Case(When(pay_code__code_type=OVERTIME, then='hours'), default=Value(0), output_field=DecimalField())))
    dept_qs = dept_qs.values('id', 'dept_code', 'dept_name').order_by('id')
    dept_dict = {item['id']: item for item in dept_qs}
    data_list = []
    for item in payload_qs:
        _dept_item = dept_dict[item['dept_id']]
        xaxis_name = '{0} {1}'.format(_dept_item['dept_code'], _dept_item['dept_name'])
        data_list.append({'xaxis_name': xaxis_name, 'total_worked_hrs': format(item['total_hrs'], '.2f'), 'total_ot': format(item['total_ot'], '.2f'), 'total_all': item['total_hrs'] + item['total_ot']})
    data_list = sorted(data_list, key=operator.itemgetter('total_all'), reverse=True)
    data = {'legend': {'data': ['%s' % _('dashboard.monthly_summary.total_worked_hrs'), '%s' % _('dashboard.monthly_summary.total_overtime')]}, 'xAxis': {'data': [i['xaxis_name'] for i in data_list]}, 'series': [{'name': '%s' % _('dashboard.monthly_summary.total_worked_hrs'), 'type': 'bar', 'data': [i['total_ot'] for i in data_list]}]}
    if cache_key:
        cache.set(cache_key, data, 60)
    return json.dumps(data)
@login_required
def montly_summary_chart(request):
    if request.method == 'POST':
        _message = montly_summary_part(request)
        return HttpResponse(_message)
    else:
        return None
@login_required
def dashboard_daily_punch_count(request):
    from mysite.iclock.models import Transaction
    from mysite.personnel.models import Employee
    now = datetime.datetime.now()
    start_date = now - datetime.timedelta(days=30)
    queryset = Transaction.objects.filter(punch_time__date__range=(start_date.date(), now.date()))
    emp_qs = Employee.all_objects.all()
    filters = filter_conditions(request, 'department__in', 'area__in', 'company')
    if filters:
        emp_qs = emp_qs.filter(**filters).distinct()
    queryset = queryset.filter(emp__in=emp_qs)
    queryset = queryset.values('punch_time').order_by('punch_time')
    daily_att_count_dict = {}
    while start_date <= now:
        date = start_date.strftime('%Y-%m-%d')
        daily_att_count_dict[date] = 0
        start_date += datetime.timedelta(days=1)
    for r in queryset:
        date = r['punch_time'].strftime('%Y-%m-%d')
        if daily_att_count_dict.get(date):
            daily_att_count_dict[date] += 1
        else:
            daily_att_count_dict[date] = 1
    data = {'title': {'text': force_str(_('dashboard.att_count')), 'subtext': force_str(_('dashboard.att_count.month'))}, 'legend': {'data': [force_str(_('dashboard.att_count.quantity'))]}, 'xAxis': {'data': list(daily_att_count_dict.keys())}, 'series': [{'name': '%s' % _('dashboard.att_count.quantity'), 'data': list(daily_att_count_dict.values())}]}
    return HttpResponse(json.dumps(data))
@login_required
def my_work_hours(request):
    from django.db.models import Case, When, Sum, Value, DecimalField
    from mysite.att.models import PayloadPayCode
    from mysite.att.calc_new import get_employee_policy
    from mysite.att.models.model_paycode import REGULAR, OVERTIME
    from mysite.base.utils import get_start_of_week
    employee = request.user
    period_choice = int(request.GET.get('period', 1))
    today = datetime.datetime.now()
    period_end = today.date()
    period_start = period_end
    if period_choice == 2:
        policy = get_employee_policy(employee)
        start_of_week = policy.start_of_week
        if start_of_week == 7:
            start_of_week = get_start_of_week()
        delta = today.isoweekday() - (start_of_week + 1)
        period_start = today - datetime.timedelta(days=delta % 7)
    else:
        if period_choice == 3:
            period_start = today.replace(day=1)
    payload_qs = PayloadPayCode.objects.filter(emp=employee, att_date__range=[period_start, period_end])
    payload_qs = payload_qs.values('emp_id').order_by('emp__emp_code').annotate(total_hrs=Sum(Case(When(pay_code__fixed_code=REGULAR, then='hours'), default=Value(0), output_field=DecimalField())), total_ot=Sum(Case(When(pay_code__code_type=OVERTIME, then='hours'), default=Value(0), output_field=DecimalField())))
    data = ['0.00', '0.00']
    for i in payload_qs:
        data[0] = format(i['total_hrs'], '.2f')
        data[1] = format(i['total_ot'], '.2f')
    data = {'xAxis': {'data': ['%s' % _('dashboard.my_work_hours.total_worked_hrs'), '%s' % _('dashboard.my_work_hours.total_overtime')]}, 'series': {'data': [data[0], data[1]]}}
    return HttpResponse(json.dumps(data))
@inject_default_context('stamp')
def normal_by_calc(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'normal_by_calc', 'data_url': '/base/api/dailyCalcNormal/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_by_calc.html', context)
@inject_default_context('stamp')
def late_by_calc(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'late_by_calc', 'data_url': '/base/api/dailyCalcLate/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_by_calc.html', context)
@inject_default_context('stamp')
def early_leave_by_calc(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'early_leave_by_calc', 'data_url': '/base/api/dailyCalcEarly/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_by_calc.html', context)
@inject_default_context('stamp')
def late_early_by_calc(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'late_early_by_calc', 'data_url': '/base/api/dailyCalcLateEarly/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_by_calc.html', context)
@inject_default_context('stamp')
def absence_by_calc(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'absence_by_calc', 'data_url': '/base/api/dailyCalcAbsence/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_by_calc.html', context)
@inject_default_context('stamp')
def absent_by_punch(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'absent_by_punch', 'data_url': '/base/api/dailyAbsent/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/absent_by_punch.html', context)
@inject_default_context('stamp')
def present_by_punch(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'present_by_punch', 'data_url': '/base/api/dailyPresent/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/present_by_punch.html', context)
@inject_default_context('stamp')
def online_device(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'online_device', 'data_url': '/base/api/deviceStatus/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_of_device.html', context)
@inject_default_context('stamp')
def offline_device(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'online_device', 'data_url': '/base/api/deviceStatus/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_of_device.html', context)
@inject_default_context('stamp')
def unauthorized_device(request, context=None):
    query_params = request.META.get('QUERY_STRING')
    context = {'report_name': 'online_device', 'data_url': '/base/api/deviceStatus/', 'query_params': query_params}
    return TemplateResponse(request, 'dashboard/reports_of_device.html', context)
@inject_default_context('stamp')
def todo_list(request, context=None):
    return TemplateResponse(request, 'dashboard/todo_list.html', context)
@inject_default_context('stamp')
def my_time_schedule(request, context=None):
    context = {'emp_pk': ''}
    if hasattr(request.user, 'is_employee') and request.user.is_employee:
            context = {'emp_pk': request.user.pk}
    return TemplateResponse(request, 'dashboard/my_time_schedule.html', context)
@inject_default_context('stamp')
def my_leave_summary(request, context=None):
    context = {'emp_pk': ''}
    if hasattr(request.user, 'is_employee') and request.user.is_employee:
            context = {'emp_pk': request.user.pk}
    return TemplateResponse(request, 'dashboard/my_leave_summary.html', context)
@login_required
def get_dashboard_area_tree(request):
    from mysite.personnel.models import Area
    template_name = 'dashboard/organization_tree.html'
    tree_name = request.POST.get('tree_name', '')
    model_name = request.POST.get('model_name', '')
    checked_vaules = request.POST.getlist('checked_data', [])
    queryset = Area.objects.all()
    if not request.user.is_superuser and request.user.auth_area.exists():
            queryset = request.user.auth_area.all()
    if not request.user.is_superuser and request.user.assign_company:
            queryset = queryset.filter(company=request.user.assign_company)
    objs = queryset.values_list('id', 'area_name', 'parent_area_id')
    nodes = [(obj[0], obj[1], obj[2] or 0, str(obj[0]) in checked_vaules) for obj in objs]
    node_data = [dict(zip(('id', 'name', 'pId', 'checked'), node)) for node in nodes]
    widget = {'name': tree_name, 'label': _('psnl_model_area'), 'attrs': {'model': model_name, 'data': force_str(json.dumps(node_data))}}
    return TemplateResponse(request, template_name, {'widget': widget})
@login_required
def get_dashboard_department_tree(request):
    from mysite.personnel.models import Department
    template_name = 'dashboard/organization_tree.html'
    tree_name = request.POST.get('tree_name', '')
    model_name = request.POST.get('model_name', '')
    checked_vaules = request.POST.getlist('checked_data', [])
    queryset = Department.objects.all()
    if not request.user.is_superuser and request.user.auth_dept.exists():
            queryset = request.user.auth_dept.all()
    if not request.user.is_superuser and request.user.assign_company:
            queryset = queryset.filter(company=request.user.assign_company)
    objs = queryset.values_list('id', 'dept_name', 'parent_dept_id')
    nodes = [(obj[0], obj[1], obj[2] or 0, str(obj[0]) in checked_vaules) for obj in objs]
    node_data = [dict(zip(('id', 'name', 'pId', 'checked'), node)) for node in nodes]
    widget = {'name': tree_name, 'label': _('psnl_model_department'), 'attrs': {'model': model_name, 'data': force_str(json.dumps(node_data))}}
    return TemplateResponse(request, template_name, {'widget': widget})
def dashboard_time_period(request, context=None):
    time_period = request.POST.get('time_period', None)
    if time_period:
        _time_period = json.loads(time_period)
        context = {'period_type': _time_period['period_type'], 'period_start': _time_period['start_date'], 'period_end': _time_period['end_date']}
    return TemplateResponse(request, 'dashboard/time_period.html', {'context': context})
@re_path('^realtime_punch/$', realtime_punch, name='realtime_punch')
@re_path('^view_leave/$', view_leave, name='view_leave')
@re_path('^calc_present_chart/$', calc_present_chart, name='calc_present_chart')
@re_path('^normal_by_calc/$', normal_by_calc, name='normal_by_calc')
@re_path('^late_by_calc/$', late_by_calc, name='late_by_calc')
urlpatterns = [re_path('^early_leave_by_calc/$', early_leave_by_calc, name='early_leave_by_calc'), re_path('^late_early_by_calc/$', late_early_by_calc, name='late_early_by_calc'), re_path('^absence_by_calc/$', absence_by_calc, name='absence_by_calc'), re_path('^punch_present_chart/$', punch_present_chart, name='punch_present_chart'), re_path('^absent_by_punch/$', absent_by_punch, name='absent_by_punch'), re_path('^present_by_punch/$', present_by_punch, name='present_by_punch'), re_path('^device_status_chart/$', device_status_chart, name='device_status_chart'), re_path('^online_device/$', online_device, name='online_device'), re_path('dashboard_online_device', ^offline_device/$, name='^offline_device/$'), re_path('offline_device', dashboard_offline_device, name='dashboard_offline_device'), re_path('^unauthorized_device/$', unauthorized_device, name='unauthorized_device'), re_path('dashboard_unauthorized_device', ^punch_dept_att_chart/$, name='dashboard_unauthorized_device'), re_path('punch_dept_att_chart', ^calc_dept_att_chart/$, name='calc_dept_att_chart'), re_path('^montly_summary_chart/$', montly_summary_chart, name='montly_summary_chart'), re_path