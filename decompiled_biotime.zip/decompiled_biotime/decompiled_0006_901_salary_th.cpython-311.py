# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\payroll\\migrations\\0006_901_salary_th.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:06 UTC (1750702746)

from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
import mysite.base.models.modelless
class Migration(migrations.Migration):
    dependencies = [('base', '0011_901_backup_db_encrypt'), ('personnel', '0012_901_attr_type_change'), ('payroll', '0005_auto_20221202_1852')]
    default = [('EmpExpenseExemption', 'id', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField', 'AutoField',