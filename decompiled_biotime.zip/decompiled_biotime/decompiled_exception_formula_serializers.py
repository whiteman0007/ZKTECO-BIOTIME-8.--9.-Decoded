# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\api\\serializers\\exception_formula_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from rest_framework import serializers
from mysite.payroll.models import ExceptionFormula
class ExceptionFormulaSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExceptionFormula
        fields = ['id', 'name', 'pay_code', 'formula', 'remark']
class ExceptionFormulaExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExceptionFormula
        fields = ['id', 'name', 'pay_code', 'formula', 'remark']