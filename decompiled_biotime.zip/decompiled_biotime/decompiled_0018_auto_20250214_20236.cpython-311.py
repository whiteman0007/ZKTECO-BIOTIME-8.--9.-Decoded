# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0018_auto_20250214_20236.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0017_pro_903_2024090600')]
    operations = [migrations.AlterField(model_name='payloadtimecard', name='work_day', field=models.DecimalField(decimal_places=1, default=1.0, max_digits=4, verbose_name='report.columns.workDay'))]