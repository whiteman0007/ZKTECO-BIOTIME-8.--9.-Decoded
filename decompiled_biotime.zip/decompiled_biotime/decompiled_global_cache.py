# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\global_cache.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

from django.core.cache import cache
class CacheData(object):
    def __init__(self, key):
        self.key = key
        self.value = None
    def action_init(self):
        self.get()
    def refresh(self):
        """refresh cache"""
        m_data = self.predata()
        cache.set(self.key, m_data, 604800)
        return m_data
    def get(self):
        """get data"""
        m_data = cache.get(self.key)
        if m_data:
            self.value = m_data
            return m_data
        else:
            self.value = self.refresh()
            return self.value
    data = property(get)
    def predata(self):
        """prepare data"""
        return ''
class AttRule(CacheData):
    def __init__(self):
        super(AttRule, self).__init__('C_ATT_RULE')
    def predata(self):
        from mysite.att.att_param import get_att_rule
        return get_att_rule()
C_ATT_RULE = AttRule()
class WorkCodeCache(CacheData):
    def __init__(self):
        super(WorkCodeCache, self).__init__('CACHE_WORKCODE')
    def predata(self):
        from mysite.iclock.models.model_workcode import TerminalWorkCode
        objs = TerminalWorkCode.objects.all().values('id', 'alias')
        choices = []
        if objs:
            choices = [{'code': obj['id'], 'name': obj['alias']} for obj in objs]
        return choices
CACHE_WORKCODE = WorkCodeCache()