# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\data_import\\import_manuallog.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
from django.utils.translation import gettext_lazy as _
from mysite.accounts.models import MyUser
from mysite.att.data_import.import_base import DataImportBase
from mysite.att.models import ManualLog
from mysite.att.models_choices import PUNCH_STATES
from mysite.ep.db_const import TEMP_UNIT
from mysite.ep.models import EPSetup
from mysite.personnel.models import Employee
from mysite.iclock.models import TerminalWorkCode
class ImportManualLogData(object):
    """\n    1. Read data from import file.\n    2. Verify data get cleaned data.\n    3. Saving data to database.\n    """
    def __init__(self, request, import_file, overwrite, request_user):
        self.import_file = import_file
        self.overwrite = overwrite
        self.row_recodes = []
        self.clean_recodes = []
        self.must_fields = [_('manualLog_field_employee'), _('manualLog_field_punchTime'), _('manualLog_field_punchState'), _('manualLog_field_workCode'), _('manualLog_field_applyReason')]
        self.error_info = []
        self.request_user = request_user
        if isinstance(request_user, MyUser):
            self.is_staff = False
        else:
            assert isinstance(request_user, Employee), 'request_user, not MyUser or Employee'
            self.is_staff = True
    def exe_import_data(self):
        from mysite.tools.file_utils import FileReader
        self.row_recodes = FileReader(import_file=self.import_file, must_fields=self.must_fields).dict_read()
        result = self.clean_data()
        if result is False or self.error_info:
            raise Exception(','.join(self.error_info))
        else:
            if False:
                pass
            result = self.data_insert()
            if result is False or self.error_info:
                raise Exception(','.join(self.error_info))
    def clean_data(self):
        from mysite.personnel.models import Employee
        if self.error_info:
            return False
        else:
            PUNCH_STATES_DICT = {i[1]: i[0] for i in PUNCH_STATES}
            for recode in self.row_recodes:
                data = {}
                data['employee'] = str(recode.get(_('manualLog_field_employee')))
                data['punch_time'] = recode.get(_('manualLog_field_punchTime'))
                data['punch_state'] = recode.get(_('manualLog_field_punchState'))
                data['work_code'] = recode.get(_('manualLog_field_workCode'))
                data['apply_reason'] = recode.get(_('manualLog_field_applyReason'))
                data['index'] = recode.get('index')
                if data['employee'] is None or data['employee'] == '':
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_is_empty') % {'index': recode['index']})
                else:
                    if self.is_staff and data['employee']!= self.request_user.emp_code:
                            self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_is_not_itself') % {'index': recode['index']})
                    emp = Employee.objects.filter(emp_code=data['employee']).first()
                    if emp:
                        data['employee'] = emp
                    else:
                        self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_does_not_exists') % {'index': recode['index']})
                if data['punch_time'] is None or data['punch_time'] == '':
                    self.error_info.append(_('error_data_on_row(%(index)s)__the_punch_time_is_empty') % {'index': recode['index']})
                else:
                    if not isinstance(data['punch_time'], datetime.datetime):
                        try:
                            data['punch_time'] = datetime.datetime.strptime(data['punch_time'], '%Y-%m-%d %H:%M:%S')
                        except Exception:
                            self.error_info.append(_('error_data_on_row(%(index)s)_the_format_of_punch_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': recode['index']})
                        if data['punch_time'] > datetime.datetime.now():
                            self.error_info.append(_('manual_log_time_greater_now'))
                if data['punch_state'] is None or data['punch_state'] == '':
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_punch_state_is_empty') % {'index': recode['index']})
                else:
                    if data['punch_state'] not in PUNCH_STATES_DICT:
                        self.error_info.append(str(_('error_data_on_row(%(index)s)') % {'index': recode['index']}) + ', ' + str(_('manualLog_field_punchState')))
                    else:
                        data['punch_state'] = PUNCH_STATES_DICT[data['punch_state']]
                if self.error_info:
                    return False
                else:
                    self.clean_recodes.append(data)
            return True
    def data_insert(self):
        if self.error_info:
            return False
        else:
            for data in self.clean_recodes:
                obj = ManualLog.objects.filter(employee=data['employee'], punch_time=data['punch_time']).first()
                if obj is None:
                    obj = ManualLog(employee=data['employee'], punch_time=data['punch_time'])
                else:
                    if self.overwrite is False:
                        continue
                    else:
                        if self.overwrite is True and self.is_staff is True and (not obj.is_all_pending):
                                    continue
                try:
                    obj.apply_reason = data['apply_reason']
                    obj.punch_state = data['punch_state']
                    obj.work_code = data['work_code']
                    obj.save()
                    if self.is_staff is False and obj.is_pending:
                            obj.do_approve(self.request_user, '')
                except Exception as e:
                    self.error_info.append(str(_('error_data_on_row(%(index)s)') % {'index': data['index']}) + ', ' + str(e))
                    return False
            return True
class ManualLogImport(DataImportBase):
    punch_states = {}
    def init_required_fields(self):
        from mysite.base.utils import get_punch_states
        punch_states = get_punch_states()
        self.required_fields = [_('emp_field_employeeCode'), _('manualLog_field_punchTime'), _('manualLog_field_punchState'), _('manualLog_field_workCode'), _('manualLog_field_applyReason')]
        self.punch_states = {i[1]: i[0] for i in punch_states}
    def clean_row(self, index, row):
        emp_code = row.get(_('emp_field_employeeCode'), None)
        work_code = row.get(_('manualLog_field_workCode'), None)
        reason = row.get(_('manualLog_field_applyReason'), None)
        if not emp_code:
            self.errors.append(_('error_data_on_row(%(index)s)_the_employee_code_is_empty') % {'index': index + 1})
            return
        else:
            employee = Employee.objects.filter(emp_code=emp_code).first()
            if not employee:
                self.errors.append(_('error_data_on_row(%(index)s)_the_employee_code_does_not_exists') % {'index': index + 1})
                return
            else:
                punch_time = row.get(_('manualLog_field_punchTime'), None)
                if not punch_time:
                    self.errors.append(_('error_data_on_row(%(index)s)__the_punch_time_is_empty') % {'index': index + 1})
                    return
                else:
                    if not isinstance(punch_time, datetime.datetime):
                        try:
                            punch_time = datetime.datetime.strptime(punch_time, '%Y-%m-%d %H:%M:%S')
                        except Exception as e:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_format_of_punch_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': index + 1})
                            return None
                    if punch_time > datetime.datetime.now():
                        self.errors.append(_('manual_log_time_greater_now'))
                        return
                    else:
                        punch_state = row.get(_('manualLog_field_punchState'), None)
                        if not punch_state:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_punch_state_is_empty') % {'index': index + 1})
                            return
                        else:
                            if punch_state not in self.punch_states:
                                self.errors.append(str(_('error_data_on_row(%(index)s)') % {'index': index + 1}) + ', ' + str(_('manualLog_field_punchState')))
                                return
                            else:
                                punch_state = self.punch_states[punch_state]
                                if work_code:
                                    work_code = TerminalWorkCode.objects.filter(code=work_code).first()
                                    if not work_code:
                                        self.errors.append(_('error_data_on_row(%(index)s)_the_work_code_does_not_exists') % {'index': index + 1})
                                        return
                                return {'employee': employee, 'punch_time': punch_time, 'punch_state': punch_state, 'work_code': work_code, 'apply_reason': reason}
    def save(self, index, row):
        from mysite.workflow.models_choices import PENDING
        user = self.request.user
        if self.overwrite:
            obj = ManualLog.objects.filter(employee=row['employee'], punch_time=row['punch_time'], approval_status=PENDING).first()
            if obj:
                obj.punch_time = row['punch_time']
                obj.punch_state = row['punch_state']
                obj.work_code = row['work_code']
                obj.apply_reason = row['apply_reason']
                obj.save(force_update=True)
                if self.auto_approve:
                    obj.do_approve(user, _('common.fields.autoApproved'))
                return obj
        try:
            obj = ManualLog(**row)
            obj.save(force_insert=True)
            if self.auto_approve:
                obj.do_approve(user, _('common.fields.autoApproved'))
            return obj
        except Exception as e:
            self.errors.append(str(e))