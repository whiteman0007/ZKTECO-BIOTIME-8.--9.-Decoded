# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\actions\\add_privilege_action.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.core.cache import cache
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.acc import models_choices
from mysite.acc.models import AccPrivilege, AccGroups, AccTimezone
from mysite.admin import forms
from mysite.admin.action import ActionHandleError
class AdjustEmployeePrivilegeForm(forms.ZKActionForm):
    emp = forms.AreaPrivilegeEmployeeManyToManyField(label=_('accPrivilege_field_employee'), required=False)
    group = forms.ModelChoiceField(label=_('accPrivilege_field_group'), queryset=AccGroups.objects.all())
    timezone1 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone1'), queryset=AccTimezone.objects.all())
    timezone2 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone2'), queryset=AccTimezone.objects.all(), required=False)
    timezone3 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone3'), queryset=AccTimezone.objects.all(), required=False)
    is_group_timezone = forms.ChoiceField(label=_('accPrivilege_field_useGroupTimezone'), choices=models_choices.TIME_PERIOD_MODE, initial=1)
    is_group_verifycode = forms.ChoiceField(label=_('accPrivilege_field_useGroupVerifyCode'), choices=models_choices.TIME_PERIOD_MODE, initial=1)
    verify_mode = forms.ChoiceField(label=_('accPrivilege_field_verifyMode'), choices=models_choices.VERIFICATION, initial=(-1))
    current_area = forms.CharField(required=False, max_length=20)
    def __init__(self, *args, **kwargs):
        super(AdjustEmployeePrivilegeForm, self).__init__(*args, **kwargs)
        if self.request and self.request.method == 'GET':
            current_area = self.request.GET.get('current_area', 1)
        else:
            if self.request and self.request.method == 'POST':
                current_area = self.request.POST.get('current_area', 1)
            else:
                current_area = args[0].get('current_area', 1)
        self.fields['current_area'].initial = current_area
        self.fields['group'].queryset = AccGroups.objects.filter(area_id=current_area)
        timezones = AccTimezone.objects.filter(area_id=current_area)
        self.fields['timezone1'].queryset = timezones
        self.fields['timezone2'].queryset = timezones
        self.fields['timezone3'].queryset = timezones
    class Meta:
        model = AccPrivilege
        fields = '__all__'
class AdjustEmployeePrivilege(admin.ZKModelAction):
    verbose_name = _('accPrivilege_action_adjust')
    help_txt = _('accPrivilege_action_adjustHelpTxt')
    short_description = _('accPrivilege_action_adjustDescription')
    action_form = AdjustEmployeePrivilegeForm
    def action(self, *args, **kwargs):
        employees = self.request.POST.getlist('employee')
        group = self.request.POST.get('group', 0)
        is_group_timezone = self.request.POST.get('is_group_timezone', 1)
        current_area = self.request.POST.get('current_area', 1)
        timezone1 = self.request.POST.get('timezone1', 0)
        timezone2 = self.request.POST.get('timezone2', 0)
        timezone3 = self.request.POST.get('timezone3', 0)
        is_group_verifycode = self.request.POST.get('is_group_verifycode', 1)
        verify_mode = self.request.POST.get('verify_mode', 0)
        if not employees:
            raise ActionHandleError(_('select_none_employee'))
        else:
            if not is_group_timezone and (not timezone1) and (not timezone2) and (not timezone3):
                raise ActionHandleError(_('select_none_timezone'))
            else:
                for emp in employees:
                    privilege = AccPrivilege()
                    privilege.area_id = current_area
                    privilege.employee_id = emp
                    privilege.is_group_timezone = int(is_group_timezone)
                    privilege.is_group_verifycode = int(is_group_verifycode)
                    privilege.group_id = int(group)
                    privilege.verify_mode = int(verify_mode)
                    if timezone1:
                        timezone = AccTimezone.objects.filter(id=int(timezone1)).first()
                        privilege.timezone1 = timezone.timezone_no if timezone else 0
                    else:
                        privilege.timezone1 = 0
                    if timezone2:
                        timezone = AccTimezone.objects.filter(id=int(timezone2)).first()
                        privilege.timezone2 = timezone.timezone_no if timezone else 0
                    else:
                        privilege.timezone2 = 0
                    if timezone3:
                        timezone = AccTimezone.objects.filter(id=int(timezone3)).first()
                        privilege.timezone3 = timezone.timezone_no if timezone else 0
                    else:
                        privilege.timezone3 = 0
                    privilege.save()