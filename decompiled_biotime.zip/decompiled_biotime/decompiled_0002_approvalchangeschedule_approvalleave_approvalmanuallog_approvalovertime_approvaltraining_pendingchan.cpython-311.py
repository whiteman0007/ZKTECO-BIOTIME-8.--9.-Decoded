# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\staff\\migrations\\0002_approvalchangeschedule_approvalleave_approvalmanuallog_approvalovertime_approvaltraining_pendingchan.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:12 UTC (1750702752)

from __future__ import unicode_literals
from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('att', '0010_auto_20220106_1103'), ('staff', '0001_initial')]
    operations = [migrations.CreateModel(name='ApprovalChangeSchedule', fields=[], options={'proxy': True, 'default_permissions': (), 'indexes': []}, bases=('att.changeschedule',)), migrations.CreateModel(name='ApprovalLeave', fields=[], options={'proxy': True, 'default_permissions': (), 'indexes': []}, bases=('att.leave',)), migrations.CreateModel(name='ApprovalTraining', fields={'proxy': True, 'default_permissions': (), 'indexes': []}, options=('att.manuallog',)), migrations.CreateModel(name='PendingManuallog', fields={'proxy': [], 'default_permissions': True, 'indexes': (), 'indexes': []}, options=('att.overtime',)), migrations.CreateModel(name='PendingOverTime', fields={'proxy': True, 'default_permissions': ()