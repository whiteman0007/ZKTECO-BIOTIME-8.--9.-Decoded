# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\actions\\autoexporttask_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:03 UTC (1750672983)

import datetime
from collections.abc import Iterable
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
from mysite.base.const import FILTER_FILED
def transaction_auto_export(dt_now, start, end, tasks, query_field=None, progress_recorder=None, manually=False):
    from mysite.base.api.serializers import AutoExportTaskOptionExecutableSerializer
    from mysite.iclock.auto_export import auto_export_transaction_executor
    if not isinstance(tasks, Iterable):
        tasks = [tasks]
    for t in tasks:
        serializer = AutoExportTaskOptionExecutableSerializer(data=t.get_options())
        serializer.is_valid()
        options = serializer.validated_data
        auto_export_transaction_executor(options, start, end, dt_now, query_field=query_field, manually=manually)
class ManualExportForm(forms.ZKActionForm):
    manual_start = forms.DateTimeField(label=_('autoExport_manualExport_startDate'), required=True)
    manual_end = forms.DateTimeField(label=_('autoExport_manualExport_endDate'), required=True)
    query_field = forms.ChoiceField(label=_('autoExport_manualExport_queryField'), required=True, choices=FILTER_FILED)
class ManualExport(ZKModelAction):
    batch_select = True
    verbose_name = _('autoExport_task_action_manualExport')
    short_description = _('autoExport_task_action_manualExport_description')
    help_txt = _('autoExport_task_action_manualExport_help_txt')
    action_form = ManualExportForm
    async_progress = True
    def action(self, *args, **kwargs):
        from mysite.base.tasks import async_progress_task_wapper
        cleaned_data = self.valid_form.cleaned_data
        dt_now = datetime.datetime.now()
        call_info = {'type': 'func', 'func': transaction_auto_export, 'lng': self.request.LANGUAGE_CODE}
        task = async_progress_task_wapper(call_info, dt_now, cleaned_data['manual_start'], cleaned_data['manual_end'], list(self.objects), cleaned_data['query_field'], manually=True)
        return task