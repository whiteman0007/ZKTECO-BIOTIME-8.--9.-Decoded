# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0005_auto_20210908_1006.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:12 UTC (1750702692)

from __future__ import unicode_literals
from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('accounts', '0004_auto_20201229_0852')]
    operations = [migrations.AlterModelOptions(name='adminbiodata', options={'verbose_name': 'iclock_model_bioData', 'verbose_name_plural': 'iclock_model_bioData'})]