# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\global_date_setting_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
class GlobalDateSettingViewMixin:
    @action(methods=['get', 'post'], url_path='global_date_setting', detail=False)
    def global_date_setting(self, request, *args, **kwargs):
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='global_date_setting').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        else:
            serializer = serializers.GlobalDateSettingUpdateSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj = SystemSetting.objects.filter(name='global_date_setting').first()
            if not obj:
                obj = SystemSetting(name='global_date_setting')
            obj.value = json.dumps(data)
            obj.save()
            return Response(data)