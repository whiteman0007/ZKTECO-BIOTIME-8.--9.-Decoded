# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0013_alter_area_area_name_alter_certification_cert_name_and_more.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('personnel', '0012_901_attr_type_change')]
    operations = [migrations.AlterField(model_name='area', name='area_name', field=models.CharField(max_length=100, verbose_name='area_field_name')), migrations.AlterField(model_name='certification', name='cert_name', field=models.CharField(max_length=100, unique=True, verbose_name='certification_field_name')), migrations.AlterField(model_name='department', name='dept_name', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='emp_field_firstName')), migrations.AlterField(model_name='employee', name='last_name', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='emp_field_lastName')), migrations.AlterField(model_name='employee', name='nickname', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='emp_field_localizedName'))]