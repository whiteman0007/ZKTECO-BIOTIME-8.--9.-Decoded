# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\leavebalance_summary_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

import string
from django.db.models import Q
from mysite.att.api.report_views.leave_balance_summary import LeaveBalanceSummarySerializer, LeaveBalanceSummaryViewSet
from mysite.att.report.base import ReportAdminBase
from mysite.att.report.const import REPORT_COLUMNS_TITLE
from mysite.att.report.decorators import report_register
from django.utils.translation import gettext_lazy as _
from mysite.att.models.model_paycode import PayCode, LEAVE
from mysite.att import const
@report_register()
class LeaveBalanceSummaryAdmin(ReportAdminBase):
    model_name = 'leaveBalanceSummaryReport'
    view_name = 'leave_balance_summary_report'
    template = 'att/report_new/leavebalancesummaryreport.html'
    api_view = LeaveBalanceSummaryViewSet
    serializer = LeaveBalanceSummarySerializer
    data_source = '/att/api/leaveBalanceSummaryReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'leave_group_name')
    hidden_fields = ('company_code', 'last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = 'emp_code'
    colspan_list = ('sum_total_leave_day_paycode', 'sum_leave_day_paycode', 'sum_remain_leave_day_paycode', 'sum_exceed_leave_day_paycode')
    rowspan = 2
    colspan = 1
    def get_layui_cols(self, export_heads=None):
        cols = super(LeaveBalanceSummaryAdmin, self).get_layui_cols()
        if export_heads:
            cols = [i for i in cols if i['field'] in export_heads]
        for cols_i in cols:
            cols_i['rowspan'] = self.rowspan
            cols_i['colspan'] = self.colspan
        cols_colspan = []
        cols_rowspan = [cols]
        codes = PayCode.objects.filter(code_type=LEAVE).order_by('display_order').values('id', 'name', 'is_display', 'fixed_code')
        self.pay_codes = codes
        for code in codes:
            sub_count = 0
            for colspan_i in self.colspan_list:
                if code['fixed_code'] == const.CPL and colspan_i == 'sum_exceed_leave_day_paycode':
                        continue
                field_name = '%(colspan_name)s_%(id)s' % {'colspan_name': colspan_i, 'id': code['id']}
                if export_heads and field_name not in export_heads:
                        continue
                sub_count += 1
                cols_colspan.append({'field': field_name, 'colspan': 1, 'rowspan': 1, 'title': str(REPORT_COLUMNS_TITLE.get(colspan_i, colspan_i)), 'hide': self.bool_value(not code['is_display'])})
            if sub_count:
                title = code['name']
                if code['fixed_code'] == const.CPL:
                    title = '{title}({unit})'.format(title=title, unit=_('time.units.hour'))
                else:
                    title = '{title}({unit})'.format(title=title, unit=_('time.units.day'))
                cols.append({'title': title, 'colspan': sub_count, 'rowspan': 1, 'hide': self.bool_value(not code['is_display'])})
        cols_rowspan.append(cols_colspan)
        return cols_rowspan
    def user_defined_cols(self, list_display, hidden_fields):
        """\n        Return final api fields, including dispaly and hidden fields.\n        """
        cols = self.get_layui_cols()
        if hidden_fields is None:
            hidden_fields = list(self.hidden_fields)
            if 'emp_code' in self.list_display:
                hidden_fields.extend(self.get_emp_ext_fields())
        for row in cols:
            for item in row:
                if 'field' in item and item['field'] in hidden_fields:
                        item['hide'] = 1
        return cols
    def get_layui_cols_for_export_xls(self, source_headers):
        cols = super(LeaveBalanceSummaryAdmin, self).get_layui_cols()
        cols_rowspan = []
        codes = self.pay_codes
        x, y = (0, 0)
        for i, header_i in enumerate(cols):
            if header_i.get('field') in source_headers:
                start_xy, end_xy = ((x, y), (x, y + 1))
                x += 1
                cols_rowspan.append({'start_xy': start_xy, 'end_xy': end_xy, 'name': header_i['title']})
        for code in codes:
            rel_x = 0
            for colspan_i in self.colspan_list:
                if code['fixed_code'] == const.CPL and colspan_i == 'sum_exceed_leave_day_paycode':
                        continue
                field_name = '%s_%s' % (colspan_i, code['id'])
                if field_name not in source_headers:
                    continue
                else:
                    start_xy = (x + rel_x, y + 1)
                    end_xy = (x + rel_x, y + 1)
                    cols_rowspan.append({'start_xy': start_xy, 'end_xy': end_xy, 'name': str(REPORT_COLUMNS_TITLE.get(colspan_i, colspan_i))})
                    rel_x += 1
            if rel_x == 0:
                continue
            else:
                start_xy = (x, y)
                x += rel_x
                end_xy = (x - 1, y)
                title = code['name']
                if code['fixed_code'] == const.CPL:
                    title = '{title}({unit})'.format(title=title, unit=_('time.units.hour'))
                else:
                    title = '{title}({unit})'.format(title=title, unit=_('time.units.day'))
                cols_rowspan.append({'start_xy': start_xy, 'end_xy': end_xy, 'name': title})
        return cols_rowspan
    def get_layui_cols_for_export(self):
        cols = super(LeaveBalanceSummaryAdmin, self).get_layui_cols()
        export_headers = []
        for cols_i in cols:
            if cols_i.get('field', None):
                export_headers.append(cols_i.get('field'))
        codes = self.pay_codes
        for code in codes:
            for colspan_i in self.colspan_list:
                if code['fixed_code'] == const.CPL and colspan_i == 'sum_exceed_leave_day_paycode':
                        continue
                export_headers.append('%(colspan_name)s_%(id)s' % {'colspan_name': colspan_i, 'id': code['id']})
        return export_headers
    def filter_queryset(self, queryset):
        employees = self.kwargs.get('employees', None)
        if employees:
            queryset = queryset.filter(id__in=employees)
        return queryset
    def get_serializer(self, *args, **kwargs):
        super(LeaveBalanceSummaryAdmin, self).get_serializer(*args, **kwargs)
        self._data_view.year = kwargs.get('year', None)
        return self._data_view.get_serializer(*args, **kwargs)
    def get_serialize_data(self):
        queryset = self.get_queryset()
        queryset = self.filter_queryset(queryset)
        queryset = self.annotate_queryset(queryset)
        serializer = self.get_serializer(queryset, many=True)
        return serializer.data