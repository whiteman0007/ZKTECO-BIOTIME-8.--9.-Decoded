# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\forms\\acc_group_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:49 UTC (1750672969)

from django.core.cache import cache
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.acc.models import AccGroups, AccTimezone
from mysite.admin import forms
from mysite.personnel.models import Area
class AccGroupForm(ModelForm):
    area = forms.ModelChoiceField(label=_('accPrivilege_field_area'), queryset=Area.objects.all(), disabled=True)
    group_no = forms.IntegerField(label=_('accGroup_field_no'), max_value=99, min_value=1)
    timezone1 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone1'), queryset=AccTimezone.objects.all())
    timezone2 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone2'), queryset=AccTimezone.objects.all(), required=False)
    timezone3 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone3'), queryset=AccTimezone.objects.all(), required=False)
    class Meta:
        model = AccGroups
        fields = ('area', 'group_no', 'group_name', 'timezone1', 'timezone2', 'timezone3', 'is_include_holiday', 'verify_mode')
    def __init__(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        super(AccGroupForm, self).__init__(*args, **kwargs)
        try:
            request = kwargs.get('initial', None)
            current_area = 1
            if request:
                current_area = request['request'].GET.get('current_area', 1)
            if args and args[0]['area']:
                    current_area = args[0]['area']
            timezones = AccTimezone.objects.filter(area_id=current_area)
            self.fields['timezone1'].queryset = timezones
            self.fields['timezone2'].queryset = timezones
            self.fields['timezone3'].queryset = timezones
            if self.instance and self.instance.pk:
                    self.fields['group_no'].disabled = True
            self.fields['area'].initial = current_area
        except Exception:
            pass
        if self.instance.pk and self.instance.timezone1:
                self.initial['timezone1'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone1).first().id
        if self.instance.pk and self.instance.timezone2:
                self.initial['timezone2'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone2).first().id
        if self.instance.pk and self.instance.timezone3:
                self.initial['timezone3'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone3).first().id
                    except Exception as e:
                            return None
    def clean(self):
        cleaned_data = super(AccGroupForm, self).clean()
        if 'timezone1' in cleaned_data and cleaned_data['timezone1']:
            cleaned_data['timezone1'] = cleaned_data['timezone1'].timezone_no
        else:
            cleaned_data['timezone1'] = 0
        if cleaned_data['timezone2']:
            cleaned_data['timezone2'] = cleaned_data['timezone2'].timezone_no
        else:
            cleaned_data['timezone2'] = 0
        if cleaned_data['timezone3']:
            cleaned_data['timezone3'] = cleaned_data['timezone3'].timezone_no
        else:
            cleaned_data['timezone3'] = 0
        return cleaned_data
class AccGroupEditForm(ModelForm):
    area = forms.ModelChoiceField(label=_('accPrivilege_field_area'), queryset=Area.objects.all(), disabled=True)
    group_no = forms.IntegerField(label=_('accGroup_field_no'), max_value=99, min_value=1, disabled=True)
    timezone1 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone1'), queryset=AccTimezone.objects.all())
    timezone2 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone2'), queryset=AccTimezone.objects.all(), required=False)
    timezone3 = forms.ModelChoiceField(label=_('accPrivilege_field_timezone3'), queryset=AccTimezone.objects.all(), required=False)
    class Meta:
        model = AccGroups
        fields = ('area', 'group_no', 'group_name', 'timezone1', 'timezone2', 'timezone3', 'is_include_holiday', 'verify_mode')
    def __init__(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        super(AccGroupEditForm, self).__init__(*args, **kwargs)
        try:
            timezones = AccTimezone.objects.filter(area_id=self.instance.area_id)
            self.fields['timezone1'].queryset = timezones
            self.fields['timezone2'].queryset = timezones
            self.fields['timezone3'].queryset = timezones
            if self.instance and self.instance.pk:
                    self.fields['group_no'].disabled = True
            self.fields['area'].initial = self.instance.area_id
        except Exception:
            pass
        if self.instance.pk and self.instance.timezone1:
                self.initial['timezone1'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone1).first().id
        if self.instance.pk and self.instance.timezone2:
                self.initial['timezone2'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone2).first().id
        if self.instance.pk and self.instance.timezone3:
                self.initial['timezone3'] = AccTimezone.objects.filter(area=self.instance.area, timezone_no=self.instance.timezone3).first().id
                    except Exception as e:
                            return None
    def clean(self):
        cleaned_data = super(AccGroupEditForm, self).clean()
        if 'timezone1' in cleaned_data and cleaned_data['timezone1']:
            cleaned_data['timezone1'] = cleaned_data['timezone1'].timezone_no
        else:
            cleaned_data['timezone1'] = 0
        if cleaned_data['timezone2']:
            cleaned_data['timezone2'] = cleaned_data['timezone2'].timezone_no
        else:
            cleaned_data['timezone2'] = 0
        if cleaned_data['timezone3']:
            cleaned_data['timezone3'] = cleaned_data['timezone3'].timezone_no
        else:
            cleaned_data['timezone3'] = 0
        return cleaned_data