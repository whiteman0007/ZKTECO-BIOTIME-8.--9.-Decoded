# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\meeting\\admin\\meetingentity_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:04 UTC (1750673044)

import json
import datetime
from django.forms.widgets import HiddenInput
from django.forms import ModelForm, ModelMultipleChoiceField, ValidationError
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.admin.action import ActionTuple
from mysite.admin.kernel import ZKModelAdmin
from mysite.meeting.actions import AddMeetingAttender, MeetingCalculation, SyncMeeting2Device
from mysite.meeting.models import MeetingEntity, MeetingRoom
from mysite.meeting import choices, const
from mysite.personnel.forms.fields import EmployeeSearchChoiceField
from mysite.personnel.models import Employee
from mysite.personnel.widgets import AttenderManyToManyMiddleWidget
from mysite.workflow.actions import Approve, Revoke, Reject
from mysite.workflow.models_choices import REVOKE
from mysite.base.models import ZoomSetting
class MeetingEntityCreationForm(ModelForm):
    employee = EmployeeSearchChoiceField(label=_('meetingEntity.fields.applier'))
    content = forms.CharField(label=_('meetingEntity.fields.content'), required=False)
    apply_reason = forms.CharField(label=_('meetingEntity.fields.purpose'), required=False)
    room = forms.ModelChoiceField(queryset=MeetingRoom.objects.get_queryset(), required=False)
    attender = ModelMultipleChoiceField(label=_('meetingEntity.fields.attender'), queryset=Employee.objects.get_queryset(), required=False, widget=AttenderManyToManyMiddleWidget())
    view_date = forms.DateField(label=_('View Date'), initial=datetime.datetime.now)
    host_video = forms.BooleanField(label=_('zoomMeeting.fields.isHostVideo'), initial=False, required=False)
    participant_video = forms.BooleanField(label=_('zoomMeeting.fields.isParticipantVideo'), initial=False, required=False)
    enable_waiting_room = forms.BooleanField(label=_('zoomMeeting.fields.enableWaitingRoom'), initial=False, required=False)
    jbh_anytime = forms.BooleanField(label=_('zoomMeeting.fields.isJoinBeforeHostAnytime'), initial=False, required=False)
    mute_upon_entry = forms.BooleanField(label=_('zoomMeeting.fields.isMuteUponEntry'), initial=False, required=False)
    auto_recording = forms.ChoiceField(label=_('zoomMeeting.fields.autoRecording'), initial=const.ZOOM_AUTORECORDING_DISABLED, choices=choices.ZOOM_AUTORECORDING_CHOICES)
    preferences = forms.CharField(label=_('meetingEntity.fields.preferences'), required=False)
    auto_approve = forms.BooleanField(label=_('common.fields.autoApproved'), initial=True, required=False)
    zoom = forms.ModelChoiceField(queryset=ZoomSetting.objects.filter(zoom_enable=True), required=True)
    def __init__(self, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        self.permission = APPROVAL_APPROVE_PERMISSION.get('meetingentity')
        super(MeetingEntityCreationForm, self).__init__(*args, **kwargs)
        instance = kwargs.get('instance', None)
        initial = kwargs.get('initial', None)
        if instance:
            self.fields['view_date'].initial = instance.meeting_date
        if initial:
            request = initial.get('request')
            if not request.user.has_perm(self.permission):
                self.fields['auto_approve'].widget = HiddenInput()
                self.fields['auto_approve'].initial = False
        else:
            self.fields['auto_approve'].widget = HiddenInput()
            self.fields['auto_approve'].initial = False
        zooms = ZoomSetting.objects.filter(zoom_enable=True)
        if not zooms:
            self.fields['zoom'].required = False
            self.fields['enable_virtual'].widget = HiddenInput()
            self.fields['enable_virtual'].initial = False
            self.fields['preferences'].initial = ''
            self.initial['preferences'] = ''
        else:
            self.fields['zoom'].initial = zooms.first()
    def clean(self):
        cleaned_data = super(MeetingEntityCreationForm, self).clean()
        room = cleaned_data.get('room', None)
        attender = cleaned_data.get('attender', None)
        enable_virtual = cleaned_data.get('enable_virtual', False)
        if not attender:
            raise ValidationError(_('meetingEntity.save.error.missAttender'), code='-1')
        else:
            if not enable_virtual and (not room):
                raise ValidationError(_('meetingEntity.save.error.missRoom'), code='-1')
            else:
                if room and room.capacity < attender.count():
                    raise ValidationError(_('meetingEntity.save.error.roomCapacity'), code='-1')
                else:
                    preferences = {key: cleaned_data.get(key, '') for key in cleaned_data.keys() if key in const.ZOOM_PREFERENCES}
                    cleaned_data['preferences'] = json.dumps(preferences)
                    return cleaned_data
    def save(self, commit=True):
        if self.changed_data and self.instance.approval_status == REVOKE:
                self.instance.reset = True
        super(MeetingEntityCreationForm, self).save(commit)
        return self.instance
    class Meta:
        model = MeetingEntity
        fields = ('alias', 'content', 'start_time', 'end_time', 'employee', 'apply_reason', 'room', 'attender', 'in_required', 'in_start', 'in_end', 'out_required', 'out_start', 'out_end', 'view_date', 'time_zone', 'enable_virtual', 'host_video', 'participant_video', 'enable_waiting_room', 'jbh_anytime', 'mute_upon_entry', 'auto_recording')
@admin.register(MeetingEntity)
class MeetingEntityAdmin(ZKModelAdmin):
    list_display = ('alias', 'content', 'meeting_date', 'time_zone', 'meeting_period', 'attender_quantity', 'room', 'apply_reason', 'apply_time', 'workflow_engine', 'start_host_link', 'invitation_link', 'zoom', 'applier', 'emp_photo', 'approval_status', 'approver', 'approval_remark', 'approval_time', 'last_approver')
    list_filter = ('alias', 'meeting_date', 'start_time', 'end_time', 'room', 'apply_reason')
    hidden_fields = ('approval_remark', 'approval_time', 'last_approver', 'workflow_engine')
    sort_fields = ('-start_time',)
    non_display_fields = ('color',)
    form = MeetingEntityCreationForm
    actions = (MeetingCalculation,)
    action_sets = (ActionTuple(_('workflow.actionGroup.approval'), (Approve, Revoke, Reject)), ActionTuple(_('meetingEntity.actionGroup.operating'), (AddMeetingAttender, SyncMeeting2Device)))
    def attender_quantity(self, obj):
        capacity = '-'
        if obj.room:
            capacity = obj.room.capacity
        return '{used}/{capacity}'.format(used=obj.attender.count(), capacity=capacity)
    attender_quantity.short_description = _('meetingEntity.fields.attender')
    def applier(self, obj):
        if not obj.employee:
            return ''
        else:
            return obj.employee.first_name or obj.employee.emp_code
    applier.short_description = _('meetingEntity.fields.applier')
    def meeting_period(self, obj):
        return '{start}~{end}'.format(start=obj.start_time.time(), end=obj.end_time.time())
    meeting_period.short_description = _('meetingEntity.fields.meetingPeriod')
    def start_host_link(self, obj):
        if obj.link_data:
            link_data = json.loads(obj.link_data)
            return link_data.get('start_url', '')
        else:
            return ''
    start_host_link.short_description = _('meetingEntity.fields.startHost')
    def invitation_link(self, obj):
        return obj.get_invitation_link()
    invitation_link.short_description = _('meetingEntity.fields.shareInvitation')
    def get_queryset(self, request):
        queryset = super(MeetingEntityAdmin, self).get_queryset(request)
        queryset = queryset.select_related('employee')
        return queryset
    def save_model(self, request, obj, form, change):
        obj._user = request.user
        obj._permission = form.permission
        auto_approve = form.cleaned_data.get('auto_approve', False)
        super().save_model(request, obj, form, change)
        if change or (auto_approve and obj._user.has_perm(obj._permission)):
                    obj.do_approve(obj._user, _('common.fields.autoApproved'))