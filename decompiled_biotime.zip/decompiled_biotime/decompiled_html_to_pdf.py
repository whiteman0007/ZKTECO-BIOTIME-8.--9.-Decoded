# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\tools\\html_to_pdf.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import os
import datetime
import time
import pdfkit
from django.http.response import HttpResponse
from urllib.parse import quote
from django.conf import settings
from mysite.tools.export_utils.utils import encryption_pdf
EXPORT_FOLDER = 'reports'
EXPORT_ROOT = os.path.join(settings.ADDITION_FILE_ROOT, EXPORT_FOLDER)
DEFAULT_PATH = os.path.join(EXPORT_ROOT, 'export.pdf')
class HTMLToPDF:
    def __init__(self, html, save_path=None, extra_options=None):
        self.save_path = DEFAULT_PATH
        self.html = ''
        self.options = {'page-size': 'A4', 'margin-top': '0.6in', 'margin-right': '0.6in', 'margin-bottom': '0.6in', 'margin-left': '0.6in', 'encoding': 'UTF-8', 'quiet': '', 'disable-external-links': '', 'disable-internal-links': '', 'disable-javascript': ''}
        self.html = html
        self.save_path = save_path if save_path else self.save_path
        for key in extra_options:
            self.options[key] = extra_options[key]
    def save(self, save_path=None, password=None):
        # irreducible cflow, using cdg fallback
        self.save_path = save_path if save_path else self.save_path
        temp_name = 'tmp_{stamp}.pdf'.format(stamp=int(round(time.time() * 1000000)))
        temp_dir = os.path.split(self.save_path)[0]
        temp_path = os.path.join(temp_dir, temp_name)
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)
        pdfkit.from_string(self.html, temp_path, options=self.options)
        os.rename(temp_path, self.save_path)
        if password:
            encryption_pdf(self.save_path, password)
                except Exception as e:
                        print(('rename error', e))
    def return_response(self, save_path=None, password=None):
        self.save_path = save_path if save_path else self.save_path
        temp_name = 'tmp_{stamp}.pdf'.format(stamp=int(round(time.time() * 1000000)))
        temp_dir = os.path.split(self.save_path)[0]
        temp_path = os.path.join(temp_dir, temp_name)
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)
        pdfkit.from_string(self.html, temp_path, options=self.options)
        try:
            os.rename(temp_path, self.save_path)
            if password:
                encryption_pdf(self.save_path, password)
            temp_path = self.save_path
        except Exception as e:
            print(('rename error', e))
        def readFile(fn, buf_size=262144):
            f = open(fn, 'rb')
            while True:
                c = f.read(buf_size)
                if c:
                    yield c
                else:
                    f.close()
        response = HttpResponse(readFile(temp_path), content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename=%s' % quote(os.path.split(self.save_path)[1])
        return response