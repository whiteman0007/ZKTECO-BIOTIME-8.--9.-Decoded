# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\ep\\api\\views\\configuration.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:32 UTC (1750673012)

from rest_framework import mixins
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import action
from mysite.ep.api.utils_class import BasicUserGenericViewSet
from mysite.ep.models import EPSetup
from mysite.ep.api.serializers import EPSetupSerializer
class EPSetupViewSet(mixins.UpdateModelMixin, BasicUserGenericViewSet):
    model = EPSetup
    queryset = EPSetup.objects.get_queryset()
    serializer_class = EPSetupSerializer
    @action(methods=['get'], detail=False)
    def get_default_configuration(self, request, *args, **kwargs):
        config = self.model.objects.filter(is_default=True).first()
        data = self.serializer_class(instance=config).data
        return Response(data)
    @action(methods=['patch'], detail=False)
    def update_default_configuration(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        try:
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj, created = self.model.objects.update_or_create(is_default=True, defaults=data)
            return Response(self.serializer_class(instance=obj).data)
        except Exception as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)