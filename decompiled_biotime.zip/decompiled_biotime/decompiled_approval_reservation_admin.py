# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff_visitor\\admin\\approval_reservation_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:36 UTC (1750673076)

from mysite import admin
from mysite.admin.kernel import ZKModelAdmin
from mysite.personnel import fields
from mysite.personnel import widgets
from mysite.staff_visitor.models import ApprovalReservation
from mysite.utils import get_staff_workflow_instance
from mysite.visitor import actions
@admin.register(ApprovalReservation)
class ApprovalReservationAdmin(ZKModelAdmin):
    """\n    Admin Class for Staff Visitor\n    """
    show_full_result_count = False
    list_display = ('id', 'vis_first_name', 'vis_last_name', 'cert_type', 'cert_no', 'employee', 'visit_reason', 'visit_date', 'visit_quantity', 'workflow_engine', 'approval_status', 'approval_remark', 'approval_time', 'last_approver', 'color', 'apply_time', 'emp_photo')
    list_filter = ('vis_first_name', 'cert_type__cert_name', 'cert_no', 'vis_last_name', 'gender', 'visit_date', 'employee__emp_code', 'approval_status')
    list_display_params = {'__all__': {'width': '150'}}
    sort_fields = ('vis_first_name', 'vis_last_name', 'cert_type', 'cert_no', 'gender', 'visit_date')
    ordering = ('-id',)
    pk_ordering = ''
    actions = [actions.Approve, actions.Reject]
    formfield_overrides = {fields.DepartmentForeignKey: {'widget': widgets.DepartmentRadioSelect}}
    hidden_fields = ('emp_photo',)
    non_display_fields = ('color',)
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(ApprovalReservationAdmin, self).get_form(request, obj, **defaults)
    def get_queryset(self, request):
        queryset = ApprovalReservation.objects.all()
        queryset = get_staff_workflow_instance(request, queryset)
        return queryset
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False