# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\actions\\door_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.utils.translation import gettext_lazy as _
from django.forms import ValidationError
from mysite import admin
from mysite.acc import models_choices
from mysite.acc.utils import ac_unalarm, ac_unlock
from mysite.admin import forms
class OpenDoor(admin.ZKModelAction):
    verbose_name = _('door_action_open')
    help_txt = _('door_action_openHelpText')
    short_description = _('door_action_openDescription')
    batch_select = True
    confirmation = _('are_you_sure_to_unlock_the_selected_terminal')
    def action(self, *args, **kwargs):
        for obj in self.objects:
            ac_unlock(obj)
class CancelAlarm(admin.ZKModelAction):
    verbose_name = _('door_action_cancelAlarm')
    help_txt = _('door_action_cancelAlarmHelpText')
    short_description = _('door_action_cancelAlarmDescription')
    batch_select = True
    confirmation = _('are_you_sure_to_unalarm_the_selected_terminal')
    def action(self, *args, **kwargs):
        for obj in self.objects:
            ac_unalarm(obj)
class AccTerminalOptionForm(forms.ZKActionForm):
    door_lock_delay = forms.IntegerField(label=_('accTerminal_field_doorLockDelay'), initial=5, min_value=0, max_value=10, help_text=_('accTerminal_field_doorLockDelayHelpText'))
    door_sensor_delay = forms.IntegerField(label=_('accTerminal_field_doorSensorDelay'), initial=15, min_value=1, max_value=255, help_text=_('accTerminal_field_doorSensorDelayHelpText'))
    door_sensor_type = forms.ChoiceField(label=_('accTerminal_field_doorSensorType'), initial=1, choices=models_choices.DOOR_SENSOR_TYPE)
    door_alarm_delay = forms.IntegerField(label=_('accTerminal_field_doorAlarmDelay'), initial=1, min_value=0, max_value=999, help_text=_('accTerminal_field_doorAlarmDelayHelpText'))
    retry_times = forms.ChoiceField(label=_('accTerminal_field_retryTimesToAlarm'), initial=0, choices=models_choices.RETRY_TIMES_TO_ALARM)
    valid_holiday = forms.BooleanField(label=_('accTerminal_field_validHoliday'), initial=True, required=False)
    nc_time_period = forms.IntegerField(label=_('accTerminal_field_normalCloseTimePeriod'), initial=0, min_value=0, max_value=50, help_text=_('accTerminal_field_normalCloseTimePeriodHelpText'))
    no_time_period = forms.IntegerField(label=_('accTerminal_field_normalOpenTimePeriod'), initial=0, min_value=0, max_value=50, help_text=_('accTerminal_field_normalOpenTimePeriodHelpText'))
    speaker_alarm = forms.BooleanField(label=_('accTerminal_field_speakerAlarm'), initial=True, required=False)
    duress_fun_on = forms.BooleanField(label=_('accTerminal_field_duressFunOn'), initial=True, required=False)
    alarm_1_1 = forms.BooleanField(label=_('accTerminal_field_alarmOn11Match'), initial=True, required=False)
    alarm_1_n = forms.BooleanField(label=_('accTerminal_field_alarmOn1nMatch'), initial=True, required=False)
    alarm_password = forms.BooleanField(label=_('accTerminal_field_alarmOnPassword'), initial=True, required=False)
    duress_alarm_delay = forms.IntegerField(label=_('accTerminal_field_duressAlarmDelay'), initial=10, min_value=0, max_value=999, help_text=_('accTerminal_field_duressAlarmDelayHelpText'))
    anti_passback_mode = forms.ChoiceField(label=_('accTerminal_field_antiPassBackMode'), initial=0, choices=models_choices.ANTI_PASSBACK_MODE)
    anti_door_direction = forms.ChoiceField(label=_('accTerminal_field_antiDoorDirection'), initial=0, choices=models_choices.DOOR_DIRECTION)
    verify_mode_485 = forms.ChoiceField(label=_('accTerminal_field_verifyMode485'), initial=0, choices=models_choices.VERIFICATION485)
    def clean(self):
        cleaned_data = super(AccTerminalOptionForm, self).clean()
        door_lock_delay = cleaned_data.get('door_lock_delay', 0)
        door_sensor_delay = cleaned_data.get('door_sensor_delay', 0)
        door_alarm_delay = cleaned_data.get('door_alarm_delay', 0)
        duress_alarm_delay = cleaned_data.get('duress_alarm_delay', 0)
        nc_time_period = cleaned_data.get('nc_time_period', 0)
        no_time_period = cleaned_data.get('no_time_period', 0)
        if door_lock_delay < 0 or door_lock_delay > 10:
            message = '{0} for {1}'.format(_('please_input_a_valid_number'), _('accTerminal_field_doorLockDelay'))
            return ValidationError(message)
        else:
            if door_sensor_delay < 1 or door_sensor_delay > 255:
                message = '{0} for {1}'.format(_('please_input_a_valid_number'), _('accTerminal_field_doorSensorDelay'))
                return ValidationError(message)
            else:
                if door_alarm_delay < 0 or door_alarm_delay > 999:
                    message = '{0} for {1}'.format(_('please_input_a_valid_number'), _('accTerminal_field_doorAlarmDelay'))
                    return ValidationError(message)
                else:
                    if duress_alarm_delay < 0 or duress_alarm_delay > 999:
                        message = '{0} for {1}'.format(_('please_input_a_valid_number'), _('accTerminal_field_duressAlarmDelay'))
                        return ValidationError(message)
                    else:
                        if nc_time_period < 0 or nc_time_period > 50:
                            message = '{0} for {1}'.format(_('please_input_a_valid_number'), _('accTerminal_field_normalCloseTimePeriod'))
                            return ValidationError(message)
                        else:
                            if no_time_period < 0 or no_time_period > 50:
                                message = '{0} for {1}'.format(_('please_input_a_valid_number'), _('accTerminal_field_normalOpenTimePeriod'))
                                return ValidationError(message)
class SetParameter(admin.ZKModelAction):
    verbose_name = _('door_action_setParameter')
    help_txt = _('door_action_setParameterHelpText')
    short_description = _('door_action_setParameterDescription')
    batch_select = True
    action_form = AccTerminalOptionForm
    def action(self, *args, **kwargs):
        form = AccTerminalOptionForm(self.request.POST)
        if form.is_valid():
            for obj in self.objects:
                update_fields = []
                for k, v in list(form.cleaned_data.items()):
                    if getattr(obj, k, None)!= v:
                        setattr(obj, k, v)
                        update_fields.append(k)
                obj.save(update_fields=update_fields)