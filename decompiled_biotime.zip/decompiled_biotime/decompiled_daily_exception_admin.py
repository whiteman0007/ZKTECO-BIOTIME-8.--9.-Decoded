# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\daily_exception_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import DailyExceptionViewSet
from mysite.att.api.report_views.daily_exception import DailyExceptionSerializer
@report_register()
class DailyExceptionAdmin(ReportAdminBase):
    model_name = 'dailyExceptionReport'
    view_name = 'daily_exception'
    template = 'att/report_new/daily_exception.html'
    api_view = DailyExceptionViewSet
    serializer = DailyExceptionSerializer
    data_source = '/att/api/dailyExceptionReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday', 'time_table_alias', 'clock_in', 'clock_out', 'description')
    hidden_fields = ('company_code', 'last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = ('emp_code', 'dept_name', 'att_date')