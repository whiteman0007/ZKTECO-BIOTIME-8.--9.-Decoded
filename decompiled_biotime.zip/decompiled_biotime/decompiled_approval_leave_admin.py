# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff\\admin\\approval_leave_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:31 UTC (1750673071)

from mysite import admin, config
from mysite.att.actions import Reject
from mysite.staff.actions import StaffApproveLeave
from mysite.staff.models import ApprovalLeave
from mysite.utils import get_staff_workflow_instance
from django.utils.translation import gettext_lazy as _
@admin.register(ApprovalLeave)
class ApprovalLeaveAdmin(admin.ZKModelAdmin):
    list_display = ('emp_code', 'first_name', 'last_name', 'department', 'position', 'emp_photo', 'pay_code', 'start_time', 'end_time', 'apply_time', 'apply_reason', 'approval_status', 'last_approver', 'attachment_url')
    list_filter = config.EMPLOYEE_LIST_FILTER + ('pay_code__code', 'pay_code__name', 'start_time', 'end_time', 'approval_status')
    hidden_fields = ('emp_photo', 'last_name', 'last_approver', 'attachment_url')
    non_display_fields = ('color',)
    ordering = ('-id',)
    actions = [StaffApproveLeave, Reject]
    def attachment_url(self, obj):
        if obj.attachment:
            return '/files/' + str(obj.attachment)
        else:
            return ''
    attachment_url.short_description = _('common_field_attachment')
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        # irreducible cflow, using cdg fallback
        from django.db.models import Q
        from mysite.workflow.models import NodeInstance
        from mysite.workflow.models_choices import PENDING
        queryset = super(ApprovalLeaveAdmin, self).get_queryset(request)
        node_qs = NodeInstance.get_permission_qs(request.user)
        ids = node_qs.values_list('workflow_instance_id', flat=True)
        extra_qs = queryset.filter(workflow_engine__isnull=True)
        extra_qs = extra_qs.filter(Q(employee__department__dept_manager=request.user, employee__superior__isnull=True) | Q(employee__superior=request.user))
        extra_ids = extra_qs.values_list('id', flat=True)
        nodes = set(node_qs.values_list('id', flat=True))
        new_ids = []
        for each in queryset.filter(id__in=ids):
            node = each.get_nodeinstance_qs(user=request.user)[0]
            if node and node.id in nodes:
                if not each.leave_day:
                    new_ids.append(each.id)
                    if not node.workflow_node.from_day and (not node.workflow_node.to_day):
                        new_ids.append(each.id)
                        if each.leave_day > node.workflow_node.from_day:
                            new_ids.append(each.id)
        if new_ids:
            queryset = queryset.filter(Q(id__in=new_ids) | Q(id__in=extra_ids, approval_status=PENDING))
        else:
            queryset = queryset.filter(Q(id__in=ids) | Q(id__in=extra_ids, approval_status=PENDING))
        return queryset