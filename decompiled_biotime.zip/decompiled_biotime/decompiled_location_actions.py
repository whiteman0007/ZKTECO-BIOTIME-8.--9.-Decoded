# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\mobile\\actions\\location_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from django.utils.translation import gettext_lazy as _
from mysite.mobile.models.model_location import GPSLocation
from mysite import admin
from mysite.admin import forms
from django.forms import ModelForm
class AddGPSLocationForm(ModelForm):
    location = forms.CharField(label=_('gpsLocation.fields.location'))
    longitude = forms.FloatField(label=_('gpsLocation.fields.longitude'), widget=forms.widgets.ZKNumberInput(attrs={'placeholder': 'x.xxxxxx'}))
    latitude = forms.FloatField(label=_('gpsLocation.fields.latitude'), widget=forms.widgets.ZKNumberInput(attrs={'placeholder': 'x.xxxxxx'}))
    class Meta:
        model = GPSLocation
        fields = ('location', 'longitude', 'latitude')
class AddGPSLocation(admin.ZKModelAction):
    verbose_name = _('mobile_action_publicNotice')
    help_text = _('mobile_action_publicNoticeHelpTxt')
    short_description = _('mobile_action_publicNoticeDescription')
    action_form = AddGPSLocationForm