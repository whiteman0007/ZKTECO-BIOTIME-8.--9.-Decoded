# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\area_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

import copy
from celery_progress.backend import AbstractProgressRecorder
from django.conf import settings
from django.core.cache import cache
from django.forms import ModelForm, ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite import config
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.admin.action import ActionHandleError
from mysite.admin.kernel import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.personnel import actions, db_const, widgets, fields
from mysite.personnel.admin.company_admin import CompanyField4ModelForm, CompanyField4ModelChangeForm
from mysite.personnel.import_data import ImportData
from mysite.personnel.models import Area
from mysite.tools.progress_utils import progress_protected
from mysite.utils import progress_record
class AreaCreationForm(CompanyField4ModelForm):
    area_code = forms.CharField(label=_('area_field_code'), max_length=db_const.MAX_AREA_CODE)
    area_name = forms.CharField(label=_('area_field_name'), max_length=db_const.MAX_AREA_NAME)
    parent_area = ModelChoiceField(queryset=Area.objects.all(), label=_('area_field_parentArea'), widget=widgets.AreaRadioSelect, required=False)
    def __init__(self, *args, **kwargs):
        super(AreaCreationForm, self).__init__(*args, **kwargs)
        try:
            objs = Area.objects.values('area_code')
            codes = [int(i['area_code']) for i in objs if i['area_code'].isdigit()]
            self.fields['area_code'].initial = str(max(codes) + 1 if codes else 1)
        except Exception:
            return None
    class Meta:
        model = Area
        fields = ('company', 'area_code', 'area_name', 'parent_area')
class AreaChangeForm(CompanyField4ModelChangeForm):
    area_code = forms.CharField(label=_('area_field_code'), max_length=db_const.MAX_AREA_CODE, required=False, disabled=True)
    area_name = forms.CharField(label=_('area_field_name'), max_length=db_const.MAX_AREA_NAME)
    parent_area = ModelChoiceField(queryset=Area.objects, label=_('area_field_parentArea'), widget=widgets.AreaRadioSelect, required=False)
    def __init__(self, *args, **kwargs):
        super(AreaChangeForm, self).__init__(*args, **kwargs)
        if self.instance and getattr_ex(settings, 'MULTI_COMPANY', False):
                try:
                    self.fields['parent_area'].company_belong = self.instance.company_id
                except:
                    return
    class Meta:
        model = Area
        fields = ('area_code', 'area_name', 'parent_area')
class AreaAdmin(ZKModelAdmin):
    actions = [actions.Import, actions.SetArea]
    list_display = ('id', 'area_code', 'area_name', 'parent_area') + config.WDMS_LIST_DISPLAY + ('device_count', 'employee_count', 'resign_employee_count')
    add_form = AreaCreationForm
    form = AreaChangeForm
    list_filter = ('area_code', 'area_name') + config.WDMS_LIST_FILTER
    sort_fields = ('area_code', 'area_name', 'employee_count', 'device_count')
    cache_keys = ('area_tree_nodes', 'area-parent_area-tree', 'area-parent_area-map')
    formfield_overrides = {fields.CompanyForeignKey: {'widget': widgets.CompanyRadioSelect(attrs={'onchange': True, 'change_params': {'onchange_field': 'parent_area', 'onchange_field_model': 'area', 'onchange_api_name': 'area_name', 'input_type': 'radio', 'onchange_parent_name': 'parent_area', 'filter_field': 'company', 'contact_name': 'company'}})}}
    def company_code(self, obj):
        if obj.company:
            return obj.company.company_code
        else:
            return ''
    company_code.short_description = _('company.field.code')
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(AreaAdmin, self).get_form(request, obj, **defaults)
    @progress_protected
    def dataimport(self, request):
        obj_import = ImportAreaData(req=request, input_name='import_data', app_label=self.opts.app_label, model_name=self.opts.model_name)
        obj_import.exe_import_data()
        ret_error = obj_import.error_info
        if ret_error:
            raise ActionHandleError(';'.join(ret_error))
    def data_import(self, request, **kwargs):
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ImportAreaData(request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        process.exe_import_data()
        if process.error_info:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.error_info[0]
    def get_queryset(self, request):
        qs = super(AreaAdmin, self).get_queryset(request)
        if request.user.is_employee:
            return qs.filter(company=request.user.company)
        else:
            if request.user.is_superuser or not request.user.auth_area.exists():
                qs = super(AreaAdmin, self).get_queryset(request)
            else:
                qs = request.user.auth_area.all()
            if not request.user.is_superuser and request.user.assign_company:
                    qs = qs.filter(company=request.user.assign_company)
            return qs.select_related('parent_area')
    @staticmethod
    def initial_data():
        from mysite.admin.models import STATUS_VALID
        areas = Area.objects.all()
        if areas.count() == 0:
            Area(area_code='1', area_name='%s' % _('area_name_defaultValue'), is_default=True, company_id=1).save()
        else:
            for area in areas:
                area.employee_count = area.employee_set.filter(status=STATUS_VALID).count()
                area.device_count = area.terminal_set.all().count()
                area.save()
class ImportAreaData(ImportData):
    progress_recorder = None
    total = 0
    current = 0
    def __init__(self, req, input_name='import_data', app_label=None, model_name=None, **kwargs):
        from django.utils.translation import activate
        lng = kwargs.pop('template_lng', None)
        if lng:
            activate(lng)
        super(ImportAreaData, self).__init__(req, input_name, app_label, model_name)
        self.progress_recorder = kwargs.pop('progress_recorder', None)
        self.stamp = None
        self.calculate_fields_verbose = ['%s' % _('area_field_parentArea')]
        self.must_fields = ['%s' % _('area_field_code'), '%s' % _('area_field_name'), '%s' % _('area_field_parentArea')]
        self.exist_codes = []
        self.aCode = None
        self.aName = None
        self.paCode = None
    def is_valid_record(self, elem, records, store):
        check_list = [elem]
        while check_list:
            check_item = check_list.pop()
            store.insert(0, check_item)
            for e in records:
                try:
                    parent_code = check_item[self.paCode]
                except Exception:
                    parent_code = ''
                parent_code = parent_code and parent_code.strip() or ''
                a_code = e[self.aCode]
                a_code = a_code and a_code.strip() or ''
                if a_code and parent_code == a_code:
                        if e in store:
                            return False
                        else:
                            check_list.append(e)
        return True
    def before_insert(self):
        for index in range(len(self.head)):
            e = self.head[index]
            if e == '%s' % _('area_field_code'):
                self.aCode = index
            if e == '%s' % _('area_field_name'):
                self.aName = index
            if e == '%s' % _('area_field_parentArea'):
                self.paCode = index
        max_len = max(self.aCode, self.aName, self.paCode)
        all_records = copy.deepcopy(self.records)
        exist_data = Area.objects.filter(company_id=self.company_id).values_list('area_code', 'area_name', 'parent_area__area_code')
        new_codes = [e[self.aCode] for e in all_records]
        self.exist_codes = [e[0] for e in exist_data]
        for i, c in enumerate(self.exist_codes):
            if c not in new_codes:
                db_data = exist_data[i]
                data = [''] * (max_len + 1)
                data[self.aCode] = db_data[0]
                data[self.aName] = db_data[1] or ''
                data[self.paCode] = db_data[2] or ''
                all_records.append(data)
        a_level = {}
        self.total = len(self.records)
        for index, elem in enumerate(self.records):
            self.current = index
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.dataVerification'))
            index += 1
            a_code = elem[self.aCode]
            a_name = elem[self.aName]
            parent_code = elem[self.paCode]
            if not a_code:
                self.error_info.append(_('error_data_on_row(%(index)s)_area_code_is_empty') % {'index': index})
            else:
                if len(a_code) > db_const.MAX_AREA_CODE:
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_length_of_area_code_maximum_is_%(length)s') % {'index': index, 'length': db_const.MAX_AREA_CODE})
            if not a_name:
                self.error_info.append(_('the_%(index)s_rows_area_name_can_not_be_empty') % {'index': index})
            else:
                if len(a_name) > db_const.MAX_AREA_NAME:
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_length_of_area_name_maximum is %(length)s') % {'index': index, 'length': db_const.MAX_AREA_NAME})
            if parent_code and len(parent_code) > db_const.MAX_AREA_CODE:
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_length_of_parent_area_code_maximum_is_%(length)s') % {'index': index, 'length': db_const.MAX_AREA_CODE})
            store = []
            if not self.is_valid_record(elem, all_records, store):
                self.error_info.append(_('the_%(index)s_rows_of_data_can_not_be_set_higher_authorities_to_%(index_name)s_sector_or_sub-sector_of_its_own') % {'index': index, 'index_name': a_name})
                return False
            else:
                for c, v in enumerate(store):
                    key = '%s' % c
                    areas = a_level.get(key, [])
                    if v not in areas:
                        areas.append(v)
                    a_level[key] = areas
        items = list(a_level.items())
        self.records = items
        self.task_progress.set(percentage=50)
        return True
    def records_analysis(self, insert_area):
        return
    def data_insert(self):
        head_len = len(self.head)
        calculate_dict = {}
        overwrite = self.need_update_old_record
        count = 0
        for level, areas in self.records:
            for index, area in enumerate(areas):
                self.current = count
                progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
                count += 1
                row_fields_select = {}
                code = area[self.aCode]
                if code not in self.exist_codes or overwrite:
                    for index in range(head_len):
                        for k, v in list(self.calculate_fields_index.items()):
                            if v == index:
                                calculate_dict[k] = area[index]
                        if index in self.valid_head_indexs:
                            tmp_value = area[index]
                            f_index = self.valid_head_indexs.index(index)
                            tmp_field = self.valid_model_fields[f_index]
                            if tmp_field.choices:
                                tv = [e[0] for e in tmp_field.choices if e[1] == tmp_value]
                                if tv:
                                    tmp_value = tv[0]
                            key = tmp_field.attname
                            value = self.get_db_value(tmp_field, tmp_value)
                            row_fields_select[key] = value
                    row_data = self.process_row(row_fields_select, calculate_dict)
                    try:
                        objs = Area.objects.filter(area_code=code, company_id=self.company_id)
                        if objs:
                            obj = objs[0]
                            for k, v in list(row_data.items()):
                                setattr(obj, k, v)
                        else:
                            obj = Area(**row_data)
                        obj.company_id = self.company_id
                        obj.save()
                        if settings.ENABLE_ACC and obj.acctimezone_set.all().count == 0:
                                obj.save_default_access_data()
                    except Exception as e:
                        self.error_info.append(str(e))
                        import traceback
                        traceback.print_exc()
            for k in getattr(AreaAdmin, 'cache_keys', []):
                cache.delete(k)
    def sqlserver_insert(self):
        self.data_insert()
    def mysql_insert(self):
        self.data_insert()
    def oracle_insert(self):
        self.data_insert()
    def postgresql_insert(self):
        self.data_insert()
    def after_insert(self):
        progress_record(self.progress_recorder, self.total, self.total, _('importProgress.status.finished'))
    def process_row(self, row_data, calculate_dict):
        row_data = super().process_row(row_data, calculate_dict)
        key = '%s' % _('area_field_parentArea')
        parent_code = str(calculate_dict.get(key, ''))
        if parent_code:
            parent = Area.objects.filter(area_code=parent_code, company_id=self.company_id)
            if not parent:
                obj = Area(area_code=parent_code, area_name=parent_code, company_id=self.company_id)
                obj.save()
            else:
                obj = parent[0]
            row_data['parent_area_id'] = obj.pk
        return row_data
zk_site.register(Area, AreaAdmin)