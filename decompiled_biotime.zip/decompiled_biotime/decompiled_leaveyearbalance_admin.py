# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\leaveyearbalance_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from mysite import admin
from mysite.att.models import LeaveYearBalance
@admin.register(LeaveYearBalance)
class LeaveyearbalanceAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'year', 'entitlement_days', 'leave_day', 'pre_balance', 'employee_id', 'get_leave_type', 'pay_code_id')
    def get_leave_type(self, obj):
        return obj.leave_type