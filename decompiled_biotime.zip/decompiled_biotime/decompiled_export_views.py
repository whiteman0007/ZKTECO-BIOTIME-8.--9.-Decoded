# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\asgi_views\\export_views.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import json
from django.conf import settings
from mysite.asgi_views.basic_views import BasicExportActionConsumer
from mysite.personnel.admin import EmployeeAdmin
class EmployeeUSBDataExportConsumer(BasicExportActionConsumer, EmployeeAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Employee
        self.model = Employee
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def get_export_data(self, *args, **kwargs):
        """"""
        return ([], 0)
    async def save_data(self, *args, **kwargs):
        """"""
        from asgiref.sync import sync_to_async
        from mysite.personnel.export_usb_data import ExportUSBData
        process = await sync_to_async(ExportUSBData, thread_sensitive=False)(self.request, **kwargs)
        await sync_to_async(process.usb_data_export, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process:
            if hasattr(process, 'error_info') and len(process.error_info) > 0:
                    self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return ''
class EmployeePayslipExportConsumer(BasicExportActionConsumer):
    """\n\n    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.payroll.models import PayrollPayload
        self.model = PayrollPayload
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def get_export_data(self, *args, **kwargs):
        """"""
        return ([], 0)
    async def check_params(self) -> tuple:
        request = self.request
        def get_payload(pid: int):
            from mysite.payroll.models import PayrollPayload
            return PayrollPayload.objects.filter(id=pid).first()
        slip_id = int(request.GET.get('slip_id', '0'))
        from channels.db import database_sync_to_async
        payload = await database_sync_to_async(get_payload, thread_sensitive=False)(slip_id)
        if not payload:
            from django.utils.translation import gettext_lazy as _
            return (False, str(_('You may recalculate the salary calculation so you have to refresh the page.')))
        else:
            self.params['payload'] = payload
            return (True, '')
    async def export2file(self, *args, **kwargs):
        from mysite.payroll.models import PayrollPayload
        from channels.db import database_sync_to_async
        payload = self.params['payload']
        params = await database_sync_to_async(self.generate_data, thread_sensitive=False)(payload)
        params['emp_id'] = payload.employee_id
        params['calc_date'] = payload.calc_time
        params['progress_recorder'] = self.send_event
        from asgiref.sync import sync_to_async
        from mysite.payroll.views.report_calculator_TH import generate_slip
        file = await sync_to_async(generate_slip, thread_sensitive=False)(self.request, **params)
        from django.utils.translation import gettext_lazy as _
        self.send_event(event_name='progressMessage', progress_total=1, progress_value=1, progress_message=str(_('exportProgress.status.finished')))
        return file
    def generate_data(self, payload):
        from mysite.payroll.models import PayrollPayload
        from mysite.payroll.views.report_calculator_TH import get_total_social_sercurity_per_year, get_increase_formula_name_dict, get_increase_detail_dict, get_extra_deduction_dict, get_extra_increase_dict, get_deduction_formula_name_dict, get_other_deduction_dict
        payload = payload
        social_security_deduction_per_year = get_total_social_sercurity_per_year(payload.employee_id, payload.calc_time)
        increase_formula_name_dict = get_increase_formula_name_dict(payload)
        extra_deduction_dict_result = get_extra_deduction_dict(payload.employee_id, payload.calc_time, payload.calc_end_time)
        other_deduction_dict = get_other_deduction_dict(payload)
        deduction_detail_dict = get_deduction_formula_name_dict(payload)
        extra_increase_dict_result = get_extra_increase_dict(payload.employee_id, payload.calc_time, payload.calc_end_time)
        increase_detail_dict = get_increase_detail_dict(payload)
        params = {'Basic Salary': payload.basic_salary, 'total_salary': payload.total_salary, 'total_deduction': payload.total_deduction, 'social_security_deduction': payload.social_security_deduction if payload.social_security_deduction else 0, 'deduction_detail_dict': {**dict(other_deduction_dict), **dict(deduction_detail_dict), **extra_deduction_dict_result}, 'increase_detail_dict': {**dict(increase_detail_dict), **extra_increase_dict_result}, 'net_pay': payload.net_pay, 'social_security_deduction_per_year': round(social_security_deduction_per_year, 2), 'total_income_per_year': round(payload.total_income_per_year, 2) if payload.total_income_per_year else 0.0, 'increase_formula_name_dict': dict(increase_formula_name_dict), 'tax_deduction': payload.tax_deduction if payload.tax_deduction else 0, 'total_tax_deduction_per_year': payload.total_tax_deduction_per_year if payload.total_tax_deduction_per_year else 0}
        return params