# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\daily_multiple_break_paring.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.db.models import Max, Case, When, Value, Sum
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.api.utils_class import IsNotUser, IsAuthenticated
from mysite.att.api import fields
from mysite.att.api.base_serializers import EmployeePayCodeRelatedReportModelSerializer
from mysite.att.api.fields import TotalIntegerField
from mysite.att.api.filters import ReportGenericFilter, StaffReportListFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.models import PayloadParing, AttCode
from mysite.att.models.model_paycode import WORKDAY
from mysite.att.models.model_payload import PARING_TYPE, BREAK_TIME
class DailyMultipleBreakParingSerializer(EmployeePayCodeRelatedReportModelSerializer):
    data_type = serializers.SerializerMethodField(label=_('report.columns.dataType'))
    att_date = fields.DateField(label=_('report_column_attendanceDate'))
    weekday = fields.WeekdayField(label=_('report_column_attendanceWeekday'))
    def get_data_type(self, obj):
        return dict(PARING_TYPE).get(obj['data_type'], '')
    def __init__(self, *args, **kwargs):
        super(DailyMultipleBreakParingSerializer, self).__init__(*args, **kwargs)
        view = kwargs['context']['view']
        total_hrs = AttCode.cache_data('total_hrs')
        total_hrs = dict(zip(('display_format', 'min_val', 'round_off'), (total_hrs.display_format, total_hrs.min_val, total_hrs.round_off)))
        from mysite.base.utils import get_short_time_format
        short_time_format = get_short_time_format()
        if total_hrs['display_format'] == WORKDAY:
            self.fields['total_time'] = serializers.DecimalField(label=_('report_column_summaryTotalTimeDuration'), max_digits=8, decimal_places=1, allow_null=True, source='total_all')
        else:
            self.fields['total_time'] = TotalIntegerField(pay_code=total_hrs, label=_('report_column_summaryTotalTimeDuration'), source='total_all')
        for i in range(view.max_index):
            self.fields['clock_in{index}'.format(index=i)] = serializers.DateTimeField(label=_('report_column_breakOutTime'), source='in{index}'.format(index=i), allow_null=True, format=short_time_format)
            self.fields['clock_out{index}'.format(index=i)] = serializers.DateTimeField(label=_('report_column_breakInTime'), source='out{index}'.format(index=i), allow_null=True, format=short_time_format)
            if total_hrs['display_format'] == WORKDAY:
                self.fields['total_time{index}'.format(index=i)] = serializers.DecimalField(label=_('report_column_totalTimeDuration'), max_digits=8, decimal_places=1, allow_null=True, source='total{index}'.format(index=i))
            else:
                self.fields['total_time{index}'.format(index=i)] = TotalIntegerField(pay_code=total_hrs, label=_('report_column_totalTimeDuration'), source='total{index}'.format(index=i))
    class Meta:
        model = PayloadParing
        fields = ('emp_id', 'emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'dept_code', 'dept_name', 'position_code', 'position_name', 'data_type', 'att_date', 'weekday', 'company_code', 'company_name')
class DailyMultipleBreakParingFilter(ReportGenericFilter):
    class Meta:
        model = PayloadParing
        fields = ['employees', 'departments', 'start_date', 'end_date']
class DailyMultipleBreakParingViewSet(ReportUserGenericViewSet):
    model = PayloadParing
    queryset = PayloadParing.objects.get_queryset().filter(data_type=BREAK_TIME, time_card__emp__isnull=False).order_by('emp', 'att_date')
    filterset_class = DailyMultipleBreakParingFilter
    serializer_dict = {'list': DailyMultipleBreakParingSerializer, 'export': DailyMultipleBreakParingSerializer, 'period_count': DailyMultipleBreakParingSerializer}
    max_index = 1
    def __init__(self, *args, **kwargs):
        super(DailyMultipleBreakParingViewSet, self).__init__(*args, **kwargs)
        self.summary_fields = ['total_time']
    def get_max_index(self, queryset):
        self.max_index = queryset.aggregate(Max('data_index')).get('data_index__max') or 1
    def annotate_queryset(self, queryset):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            ordering = ['emp__emp_code_digit', 'emp__emp_code', 'att_date']
        else:
            ordering = ['emp__emp_code', 'att_date']
        total_hrs = AttCode.cache_data('total_hrs')
        queryset = queryset.values('emp_id', 'emp__emp_code', 'emp__first_name', 'emp__last_name', 'emp__nickname', 'emp__gender', 'emp__department__dept_code', 'emp__department__dept_name', 'emp__position__position_code', 'emp__position__position_name', 'att_date', 'weekday', 'data_type', 'emp__emp_code_digit', 'emp__company__company_code', 'emp__company__company_name').order_by(*ordering)
        if total_hrs.display_format == WORKDAY:
            queryset = queryset.annotate(total_all=Sum('workday'))
        else:
            queryset = queryset.annotate(total_all=Sum('duration'))
        params = {}
        for i in range(self.max_index):
            in_key = 'in{index}'.format(index=i)
            out_key = 'out{index}'.format(index=i)
            total_key = 'total{index}'.format(index=i)
            params[in_key] = Max(Case(When(data_index=i + 1, then='in_time')))
            params[out_key] = Max(Case(When(data_index=i + 1, then='out_time')))
            if total_hrs.display_format == WORKDAY:
                params[total_key] = Max(Case(When(data_index=i + 1, then='workday'), default=Value(0)))
            else:
                params[total_key] = Max(Case(When(data_index=i + 1, then='duration'), default=Value(0)))
        queryset = queryset.annotate(**params)
        return queryset
    def get_export_queryset(self):
        queryset = self.filter_queryset(self.get_queryset())
        self.get_max_index(queryset)
        queryset = self.annotate_queryset(queryset)
        return queryset
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        self.get_max_index(queryset)
        queryset = self.annotate_queryset(queryset)
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        else:
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
    def get_file_title(self):
        return _('att.menus.reports.multipleBreakTime')
    @action(methods=['get'], detail=False)
    def period_count(self, request):
        import json
        from django.http import HttpResponse
        queryset = self.filter_queryset(self.get_queryset())
        self.get_max_index(queryset)
        response = HttpResponse(json.dumps({'code': 0, 'data': self.max_index}))
        return response
class StaffDailyMultipleBreakParingFilter(StaffReportListFilter):
    class Meta:
        model = PayloadParing
        fields = ['emp']
class StaffDailyMultipleBreakParingViewSet(DailyMultipleBreakParingViewSet):
    filterset_class = StaffDailyMultipleBreakParingFilter
    permission_classes = [IsAuthenticated, IsNotUser]