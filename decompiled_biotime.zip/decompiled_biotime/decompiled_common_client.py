# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\tools\\ftpclient\\common_client.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import os
from django.conf import settings
from .client_base import FTPClientBase
from .ftp_client import FTPClient
from .sftp_client import SFTPClient
from mysite.tools.encryption_utils import aes_decrypt
class CommonFTPClient(FTPClientBase):
    client = None
    def __init__(self, conn_info):
        is_dict = isinstance(conn_info, dict)
        if is_dict:
            self.is_sftp = conn_info.get('is_sftp', False)
        else:
            self.is_sftp = getattr(conn_info, 'is_sftp', False)
        info_list = ['hostname', 'port', 'username', 'password']
        if self.is_sftp:
            info_list.append('key_filename')
        key_dict = {'hostname': 'host', 'port': 'port', 'username': 'user_name', 'password': 'user_password', 'key_filename': 'user_key'}
        conn_params = {}
        for key in info_list:
            if is_dict:
                setattr(self, key, conn_info.get(key_dict[key], None))
            else:
                setattr(self, key, getattr(conn_info, key_dict[key], None))
            conn_params[key] = getattr(self, key)
        try:
            conn_params['password'] = aes_decrypt(conn_params['password'])
        except Exception:
            pass
        if self.is_sftp:
            if conn_params['key_filename']:
                keys_dir = os.path.join(settings.ADDITION_FILE_ROOT, 'id_rsa_keys')
                key_name = '%s-%s-%s' % (self.hostname.replace('.', '_'), self.port, self.username)
                key_path = os.path.join(keys_dir, key_name)
                conn_params['key_filename'] = key_path
            else:
                conn_params['key_filename'] = None
            self.client = SFTPClient(**conn_params)
        else:
            self.client = FTPClient(**conn_params)
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.disconnect()
    def connect(self):
        self.client.connect()
    def disconnect(self):
        self.client.disconnect()
    def copy_tree(self, src, dst, copy_type='auto'):
        self.client.copy_tree(src, dst, copy_type='auto')
    def download_tree(self, src, dst):
        self.client.download_tree(src, dst)
    def upload_tree(self, src, dst):
        self.client.upload_tree(src, dst)
    def copy_file(self, src, dst, copy_type='auto'):
        self.client.copy_file(src, dst, copy_type='auto')
    def download_file(self, src, dst):
        self.client.download_file(src, dst)
    def upload_file(self, src, dst):
        self.client.upload_file(src, dst)
    def delete(self, path):
        self.client.delete(path)
    def mkdir(self, dir_path):
        self.client.mkdir(dir_path)
    def exists(self, path):
        return self.client.exists(path)
    def listdir(self, path):
        return self.client.listdir(path)