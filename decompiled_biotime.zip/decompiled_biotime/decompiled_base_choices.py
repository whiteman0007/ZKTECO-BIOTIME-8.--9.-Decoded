# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base_choices.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from django.utils.translation import gettext_lazy as _
BOOLEAN_YES = 1
BOOLEAN_NO = 0
BOOLEANS = ((BOOLEAN_NO, _('boolean_option_no')), (BOOLEAN_YES, _('boolean_option_yes')))
PUNCH_STATE = (('I', _('transaction_punchState_checkIn')), ('O', _('transaction_punchState_checkOut')), ('0', _('transaction_punchState_checkIn')), ('1', _('transaction_punchState_checkOut')), ('2', _('transaction_punchState_breakOut')), ('3', _('transaction_punchState_breakIn')), ('4', _('transaction_punchState_overtimeIn')), ('5', _('transaction_punchState_overtimeOut')), ('255', _('transaction_punchState_noStatus')))