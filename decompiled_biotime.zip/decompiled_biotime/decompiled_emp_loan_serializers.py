# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\api\\serializers\\emp_loan_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from rest_framework import serializers
from mysite.payroll.models import EmpLoan
class EmpLoanSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmpLoan
        fields = ['id', 'employee', 'emp_code', 'first_name', 'last_name', 'department', 'loan_amount', 'loan_time', 'loan_clean_time', 'refund_cycle', 'per_cycle_refund', 'remark']
class EmpLoanExportSerializer(serializers.ModelSerializer):
    refund_cycle = serializers.CharField(source='get_refund_cycle_display')
    class Meta:
        model = EmpLoan
        fields = ['emp_code', 'first_name', 'last_name', 'department', 'loan_amount', 'loan_time', 'loan_clean_time', 'refund_cycle', 'per_cycle_refund', 'remark']