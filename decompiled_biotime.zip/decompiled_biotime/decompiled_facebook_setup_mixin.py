# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\facebook_setup_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from mysite.base.messenger import MessengerNotify
from mysite.att.models import GroupPolicy
class FacebookViewMixin:
    @action(methods=['get', 'post'], url_path='facebook_setup', detail=False)
    def facebook_setup(self, request, *args, **kwargs):
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='facebook_setup').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        else:
            serializer = serializers.FacebookSetupSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj = SystemSetting.objects.filter(name='facebook_setup').first()
            if not obj:
                obj = SystemSetting(name='facebook_setup')
            obj.value = json.dumps(data)
            obj.save()
            return Response(data)
    @action(methods=['post'], detail=False)
    def test_facebook_connection(self, request, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        serializer = serializers.FacebookConnectionSetupSerializer(data=request.data)
        serializer.is_valid()
        if not settings.MESSENGER:
            return Response({'detail': _('messenger_function_disable')})
            policy = GroupPolicy.objects.first()
            if policy.bot_uid:
                notify = MessengerNotify()
                notify.send(policy, 'This is a test message!', 4)
            return Response({'detail': 'Success'})
                except Exception as e:
                        return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)