# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\accounts\\models\\admin_biodata.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:52 UTC (1750672972)

from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.admin.models import BaseModel
from mysite.accounts import const
class AdminBioData(BaseModel):
    admin = models.ForeignKey('accounts.MyUser', on_delete=models.CASCADE)
    bio_tmp = models.TextField(_('adminBioData.fields.template'))
    bio_no = models.IntegerField(_('adminBioData.fields.index'), default=0, null=True)
    bio_index = models.IntegerField(_('adminBioData.fields.templateIndex'), default=0, null=True)
    bio_type = models.IntegerField(_('adminBioData.fields.type'))
    major_ver = models.CharField(_('adminBioData.fields.majorVer'), max_length=const.CHAR_MAJOR_VER)
    minor_ver = models.CharField(_('adminBioData.fields.minorVer'), max_length=const.CHAR_MINOR_VER, null=True)
    bio_format = models.IntegerField(_('adminBioData.fields.format'), default=0, null=True)
    valid = models.BooleanField(_('adminBioData.fields.valid'), default=True)
    duress = models.BooleanField(_('adminBioData.fields.duress'), default=False)
    class Meta:
        app_label = 'accounts'
        verbose_name = _('iclock_model_bioData')
        verbose_name_plural = verbose_name