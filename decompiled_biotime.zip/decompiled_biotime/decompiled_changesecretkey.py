# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\management\\commands\\changesecretkey.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:21 UTC (1750673001)

import datetime
import os.path
from django.conf import settings
from django.core.management.base import BaseCommand
class Command(BaseCommand):
    help = 'A tool for configuring a private encryption key'
    def handle(self, *args, **options):
        selection = ''
        while selection not in ['0', '1', '2']:
            selection = input('\n            Please select options below:\n            0) Quit\n            1) Change secret key of file access\n            2) Change secret key of configuration\n            ')
        if selection == '0':
            return 0
        else:
            if selection == '1':
                old_key, new_key = generate_new_access_secret_key()
                if not old_key or not new_key:
                    print('Failed to generate new secret key')
                    return (-1)
                else:
                    change_access_secret_key(old_key, new_key)
            else:
                if selection == '2':
                    old_key, new_key = generate_new_config_secret_key()
                    if not old_key or not new_key:
                        print('Failed to generate new secret key')
                        return (-1)
                    else:
                        change_config_secret_key(old_key, new_key)
                else:
                    print('Unimplemented operation!')
def get_random_str(len: int=24) -> str:
    """"""
    import random
    import string
    res = ''.join((random.choice(string.ascii_letters + string.digits + string.punctuation) for _ in range(len)))
    return res
def generate_new_access_secret_key() -> tuple[str, str]:
    """"""
    old_key = getattr(settings, 'ACCESS_AES_PASSWORD', '')
    if isinstance(old_key, bytes):
        old_key = str(old_key, 'utf8')
    new_key = get_random_str()
    return (old_key, new_key)
def generate_new_config_secret_key() -> tuple[str, str]:
    """"""
    old_key = getattr(settings, 'CONFIG_AES_PASSWORD', '')
    if isinstance(old_key, bytes):
        old_key = str(old_key, 'utf8')
    new_key = get_random_str()
    return (old_key, new_key)
def backup_secret_key(name: str, old_key, new_key) -> int:
    """0 user canceled;1 backup success; other less then 0,backup failed"""
    selection = ''
    while selection not in ['y', 'n', 'Y', 'N']:
        selection = input(f'\n            {name} will change from {old_key} to {new_key}\n            Please confirm the proceeds again, Y/N?\n            ')
    if selection in ['n', 'N']:
        return 0
    else:
        path = getattr(settings, 'DATABASE_BACKUP_PATH', '')
        if not path:
            return (-1)
        else:
            path = os.path.join(path, 'secretkey')
            if not os.path.exists(path):
                os.makedirs(path)
            file = os.path.join(path, 'keys.dat')
            with open(file, 'a+', encoding='utf8') as f:
                date = datetime.datetime.now()
                f.write(f'{date} {name} {old_key} -> {new_key}\n')
            print(f'Old key backup to {file}, you can restore from this file.')
            return 1
def change_access_secret_key(old_key, new_key):
    """"""
    from configparser import RawConfigParser
    res = backup_secret_key('ACCESS_AES_PASSWORD', old_key, new_key)
    if res <= 0:
        return
    else:
        CONFIG_FILE = getattr(settings, 'CONFIG_FILE', None)
        CONFIG_FILE_NAME = getattr(settings, 'CONFIG_FILE_NAME', None)
        with open(CONFIG_FILE_NAME, 'w') as f:
            CONFIG_FILE.set('SYS', 'ACCESS_AES_PASSWORD', new_key)
            CONFIG_FILE.write(f)
        print('Please restart program to apply new secret key')
def change_config_secret_key(old_key, new_key):
    """"""
    from configparser import RawConfigParser
    res = backup_secret_key('CONFIG_AES_PASSWORD', old_key, new_key)
    if res <= 0:
        return
    else:
        from mysite.base.models import SecurityPolicy
        SecurityPolicy.change_secret_key(old_key, new_key)
        from mysite.base.models import SftpSetting
        SftpSetting.change_secret_key(old_key, new_key)
        from mysite.base.models import ZoomSetting
        ZoomSetting.change_secret_key(old_key, new_key)
        from mysite.base.models import SystemSetting
        SystemSetting.change_secret_key(old_key, new_key)
        CONFIG_FILE = getattr(settings, 'CONFIG_FILE', None)
        CONFIG_FILE_NAME = getattr(settings, 'CONFIG_FILE_NAME', None)
        with open(CONFIG_FILE_NAME, 'w') as f:
            CONFIG_FILE.set('SYS', 'CONFIG_AES_PASSWORD', new_key)
            CONFIG_FILE.write(f)
        print('Please restart program to apply new secret key')