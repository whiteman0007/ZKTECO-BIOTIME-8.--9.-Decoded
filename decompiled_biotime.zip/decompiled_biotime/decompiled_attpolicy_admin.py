# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\attpolicy_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from mysite import admin
from mysite.att.models import AttPolicy
@admin.register(AttPolicy)
class AttPolicyAdmin(admin.ZKModelAdmin):
    @staticmethod
    def initial_data():
        if AttPolicy.objects.all().count() == 0:
            AttPolicy().save()
    def has_add_permission(self, request):
        return False