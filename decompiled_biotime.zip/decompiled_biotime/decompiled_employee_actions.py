# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\actions\\employee_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

import datetime
import json
from django import forms as django_forms
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.iclock.models import DeviceEmployee
from mysite.iclock.models.model_biodata import BioData
from mysite.personnel import widgets, db_const
from mysite.personnel.models import Area
class DeviceEmployeeChangeForm(ModelForm):
    emp_code = forms.CharField(label=_('emp_field_employeeCode'), required=False, disabled=True)
    enroll_sn = forms.CharField(label=_('emp_field_enrollSN'), required=False, disabled=True)
    first_name = forms.CharField(label=_('emp_field_firstName'), required=False)
    last_name = forms.CharField(label=_('emp_field_lastName'), required=False)
    card_no = forms.CharField(label=_('emp_field_cardNumber'), required=False)
    device_password = forms.CharField(label=_('emp_field_devicePassword'), required=False)
    dev_privilege = forms.TypedChoiceField(label=_('emp_field_devicePrivilege'), coerce=lambda x: int(x), initial=0, choices=db_const.PRIV_CHOICES)
    verify_mode = forms.TypedChoiceField(label=_('emp_field_verifyMode'), coerce=lambda x: int(x), initial=0, choices=db_const.VERIFICATION)
    def save(self, commit=True):
        from mysite.iclock.models import Terminal
        from mysite.iclock.utils import getDevice
        from mysite.core.zkcmdproc import zk_set_user_data
        instance = super(DeviceEmployeeChangeForm, self).save(commit)
        changed_data = self.changed_data
        if not changed_data:
            return instance
        else:
            sns = Terminal.objects.filter(area__in=instance.area.all()).values_list('sn', flat=True)
            for sn in sns:
                dev = getDevice(sn)
                zk_set_user_data(dev, [instance])
            return instance
    class Meta:
        model = DeviceEmployee
        fields = ('emp_code', 'enroll_sn', 'first_name', 'last_name', 'card_no', 'dev_privilege', 'verify_mode', 'device_password')
class DeviceSelectForm(forms.ZKActionForm):
    dev = forms.ChoiceField(label=_('reUploadFromDevice_field_device'), required=True, initial=1, choices=((1, _('dataRange_option_all')), (0, _('dataRange_option_specified'))))
    sn = forms.TextField(label=_('reUploadFromDevice_field_deviceSN'), empty_value='', required=False, help_text=_('eUploadFromDevice_field_deviceSNHelpTxt'))
class ReSync2Device(admin.ZKModelAction):
    batch_select = True
    verbose_name = _('employee_action_resynchronize2Device')
    help_txt = _('employee_action_resynchronize2Device')
    short_description = _('employee_action_resynchronize2Device')
    action_form = DeviceSelectForm
    def action(self, *args, **kwargs):
        from django.core.cache import cache
        from mysite.core.zkcmdproc import zk_set_all_data
        from mysite.iclock.utils import getDevice
        from mysite.iclock.comm.utils import get_data_sync_mode
        from mysite.iclock import choices
        from mysite.iclock.models import Terminal
        from mysite.iclock.tasks import upload_data2device
        data = self.valid_form.cleaned_data
        if int(data.get('dev', '1')) == 1:
            sync_mode = get_data_sync_mode()
            if sync_mode in [choices.MANUAL]:
                kwargs = {'active_async': False, 'cmdTime': None, 'is_finger': 1, 'is_face': 1, 'is_pic': 1, 'is_pv': 1, 'is_fv': 1, 'is_vpv': 1, 'is_biophoto': 1}
                for emp in self.objects:
                    devs = Terminal.objects.filter(area__in=emp.area.all())
                    for dev in devs:
                        upload_data2device(dev, [emp], **kwargs)
            else:
                self.objects.update(update_time=datetime.datetime.now(), enroll_sn='')
                cache.set('emp_change_flag', 1)
        else:
            sns = list(filter(None, data.get('sn', '').split(',')))
            for sn in sns:
                dev = getDevice(sn)
                zk_set_all_data(dev, 'userinfo', self.objects)
class ReUpload(admin.ZKModelAction):
    """\n    Re upload user from device under user\'s area\n    """
    batch_select = True
    verbose_name = _('employee_action_reUploadFromDevice')
    help_txt = _('employee_action_reUploadFromDevice')
    short_description = _('employee_action_reUploadFromDevice')
    action_form = DeviceSelectForm
    def action(self, dev, sn):
        from mysite.iclock.models import Terminal
        from mysite.utils import saveCmd
        for emp in self.objects:
            cmd = 'DATA QUERY USERINFO PIN={pin}'.format(pin=emp.emp_code)
            if dev and int(dev):
                devs = Terminal.objects.filter(area__in=emp.area.all()).values_list('id', flat=True)
            else:
                sn = [_f for _f in sn.split(',') if _f]
                devs = Terminal.objects.filter(sn__in=[x.strip() for x in sn]).values_list('id', flat=True)
            for dev in devs:
                saveCmd(dev, cmd)
class BioDataSelectForm(forms.ZKActionForm):
    fp = forms.BooleanField(label=_('bio_templateType_fingerprint'), initial=False, required=False)
    face = forms.BooleanField(label=_('bio_templateType_face'), initial=False, required=False)
    fv = forms.BooleanField(label=_('bio_templateType_fingerVein'), initial=False, required=False)
    pv = forms.BooleanField(label=_('bio_templateType_palm'), initial=False, required=False)
    vlf = forms.BooleanField(label=_('permission_verboseName_psnlBioPhoto'), initial=False, required=False)
class DeleteBioData(admin.ZKModelAction):
    batch_select = True
    verbose_name = _('delete_biometric_templates')
    help_txt = _('delete_biometric_templates')
    short_description = _('delete_biometric_templates')
    action_form = BioDataSelectForm
    def action(self, *args, **kwargs):
        from mysite.iclock import const
        data = self.valid_form.cleaned_data
        bio_types = []
        if data.get('fp', False):
            bio_types.append(str(const.bioFinger))
        if data.get('face', False):
            bio_types.append(str(const.bioFace))
        if data.get('fv', False):
            bio_types.append(str(const.bioVein))
        if data.get('pv', False):
            bio_types.append(str(const.bioHand))
            bio_types.append(str(const.bioPalmVL))
        if data.get('vlf', False):
            bio_types.append(str(const.bioFaceVL))
        if bio_types:
            for obj in self.objects:
                obj.delete_emp_dev(bio_types)
                obj.delete_db_biodata(bio_types)
                obj.delete_db_file_biophoto(bio_types)
class AreaTransferForm(forms.ZKActionForm):
    policy = forms.ChoiceField(label=_('terminal.fields.transferPolicy'), choices=((1, _('terminal.policyOpts.append')), (2, _('terminal.policyOpts.reset'))))
    area = django_forms.ModelMultipleChoiceField(label=_('emp_field_area'), queryset=Area.objects.all(), widget=widgets.AreaSelectMultiple)
class AreaTransfer(admin.ZKModelAction):
    from mysite.personnel.actions.personnel_actions import AdjustAreaForm
    batch_select = True
    verbose_name = _('employee_action_transferArea')
    help_txt = _('employee_action_transferArea')
    short_description = _('employee_action_transferArea')
    action_form = AdjustAreaForm
    def action(self, *args, **kwargs):
        from mysite.personnel.models.model_company import Company
        data = self.valid_form.cleaned_data
        areas = data.get('area', None)
        if not areas:
            raise Exception('{error}'.format(error=_('employee_actionError_areaIsRequired')))
        else:
            for obj in self.objects:
                policy = int(data.get('policy', 1))
                if obj.company_id!= int(kwargs['company']):
                    policy = 0
                    adjust2company = Company.objects.filter(id=kwargs['company']).first()
                    obj.company = adjust2company
                    obj.department = adjust2company.department_set.first()
                    obj.position = adjust2company.position_set.first()
                if policy == 1:
                    for area in areas:
                        obj.area.add(area)
                else:
                    obj.area.set(areas)
class EnrollFingerprintForm(forms.ZKActionForm):
    fpCount = forms.IntegerField(label=_('employee.fields.registeredFPQuantity'), required=False, initial=0, disabled=True, prefix='v10', suffix='<a id=\"fpRegister\" href=\"javascript:void(0);\" onclick=\"submitRegister()\">{btn}</a>'.format(btn=_('employee.fieldBtn.enroll')))
    fp_type = forms.CharField(required=False, initial='')
    fps = forms.CharField(required=False, initial='')
    templates = forms.CharField(required=False, initial='')
    dur_fps = forms.CharField(required=False, initial='')
    del_fps = forms.CharField(required=False, initial='')
    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instances', None)
        super(EnrollFingerprintForm, self).__init__(*args, **kwargs)
        if instance:
            instance = instance[0]
            fps = instance.biodata_set.filter(bio_type=1).values_list('bio_no', 'bio_tmp', 'valid', 'duress', 'major_ver')
            initial_data = {'fpCount': len(fps), 'fps': ','.join(map(str, [fp[0] for fp in fps if fp[3]])), 'dur_fps': ','.join(map(str, [fp[0] for fp in fps if fp[3]]))}
            if fps:
                templates = []
                for fp in fps:
                    template = {'no': fp[0], 'version': fp[4], 'template': fp[1]}
                    templates.append(template)
                initial_data['templates'] = json.dumps(templates)
            self.initial.update(initial_data)
class EnrollFingerprint(admin.ZKModelAction):
    unique_object_required = True
    verbose_name = _('deviceEmployee.actions.enrollFingerprint')
    help_txt = _('deviceEmployee.actions.enrollFingerprint')
    short_description = _('deviceEmployee.actions.enrollFingerprint')
    action_form = EnrollFingerprintForm
    def context(self):
        print(self.objects)
        return {}
    def action(self, *args, **kwargs):
        # irreducible cflow, using cdg fallback
        import re
        instance = self.objects
        templates = kwargs.get('templates', None)
        templates = json.loads(templates)
        del_fps = kwargs.get('del_fps', None)
        self.instance = instance[0]
        if templates and instance:
            instance = instance[0]
            for tem in templates:
                if not tem or not tem['template']:
                    continue
                fid = tem['no']
                ftmp = tem['template']
                version = tem['version']
                rex = re.search('(?P<major_ver>\\d+).?(?P<minor_ver>\\d*)', version)
                if rex and int(rex.group('major_ver')) > 0:
                    major_ver, minor_ver = (rex.group('major_ver'), rex.group('minor_ver') or '0')
                    fp = self.instance.biodata_set.filter(bio_no__exact=fid, major_ver=major_ver, minor_ver=minor_ver, bio_type=1).first()
                    if not fp:
                        fp = BioData(employee=instance, bio_no=fid, major_ver=major_ver, minor_ver=minor_ver, bio_type=1, bio_tmp=ftmp, update_time=datetime.datetime.now()).save()
                        fp.bio_tmp = ftmp
                        fp.upload_time = datetime.datetime.now()
                        fp.save()
        if del_fps:
            del_fps = del_fps.split(',')
            if del_fps:
                _del_fps = self.instance.biodata_set.filter(bio_type=1, bio_no__in=del_fps)
                _del_fps.delete()
                self.remove_from_device(del_fps)
    def remove_from_device(self, fps):
        from mysite.utils import saveCmd, DevIdentity_ex
        from mysite.iclock.models import Terminal
        devs = Terminal.objects.filter(area__in=self.instance.area.filter(is_default=False))
        pin = self.instance.pin()
        for dev in devs:
            if DevIdentity_ex(dev.push_protocol, '2.2.14'):
                _cmd = 'DATA DELETE FINGERTMP PIN={pin}\tFID={fid}'
            else:
                _cmd = 'DATA DEL_FP PIN={pin}\tFID={fid}'
            for fp in fps:
                cmd = _cmd.format(pin=pin, fid=fp)
                saveCmd(dev, cmd)
class EnrollPalmForm(forms.ZKActionForm):
    palmCount = forms.IntegerField(label=_('employee.fields.registeredPalmQuantity'), required=False, initial=0, disabled=True, prefix='v8', suffix='<a id=\"palmRegister\" href=\"javascript:void(0);\" onclick=\"\">{btn}</a>'.format(btn=_('employee.fieldBtn.enroll')))
    palms = forms.CharField(required=False, initial='')
    palm_template = forms.CharField(required=False, initial='')
    del_palm = forms.CharField(required=False, initial='')
    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instances', None)
        super(EnrollPalmForm, self).__init__(*args, **kwargs)
        if instance:
            instance = instance[0]
            palms = instance.biodata_set.filter(bio_type=8).values_list('bio_no', 'bio_tmp', 'valid')
            initial_data = {'palmCount': len(palms), 'palms': ','.join(map(str, [palm[0] for palm in palms])), 'palm_template': ','.join(map(str, [palm[1] for palm in palms]))}
            self.initial.update(initial_data)
class EnrollPalm(admin.ZKModelAction):
    unique_object_required = True
    verbose_name = _('deviceEmployee.actions.enrollPalm')
    help_txt = _('deviceEmployee.actions.enrollPalm')
    short_description = _('deviceEmployee.actions.enrollPalm')
    action_form = EnrollPalmForm
    def action(self, *args, **kwargs):
        instance = self.objects
        palm_template = kwargs.get('palm_template', None)
        palm_id = kwargs.get('palms', None)
        del_palm = kwargs.get('del_palm', None)
        self.instance = instance[0]
        if palm_template and palm_id:
                palm = self.instance.biodata_set.filter(bio_type=8, major_ver='12', bio_no__exact=palm_id).first()
                if not palm:
                    palm = BioData(employee=self.instance, bio_no=palm_id, major_ver='12', bio_type=8, bio_tmp=palm_template, update_time=datetime.datetime.now()).save()
                else:
                    palm.bio_tmp = palm_template
                    palm.upload_time = datetime.datetime.now()
                    palm.save()
        if del_palm == '0':
            _palms = self.instance.biodata_set.filter(bio_type=8, bio_no=del_palm)
            _palms.delete()
            self.remove_palm_from_device(del_palm)
    def remove_palm_from_device(self, palm):
        from mysite.utils import saveCmd, DevIdentity_ex
        from mysite.iclock.models import Terminal
        devs = Terminal.objects.filter(area__in=self.instance.area.filter(is_default=False))
        pin = self.instance.pin()
        for dev in devs:
            if DevIdentity_ex(dev.push_protocol, '2.2.14'):
                _cmd = 'DATA DELETE PALMTMP PIN={pin}\tPID={palmid}'
            else:
                _cmd = 'DATA DEL_PALM PIN={pin}\tPID={palmid}'
            cmd = _cmd.format(pin=pin, palmid=palm)
            saveCmd(dev.id, cmd)
class EnrollFacePhotoForm(forms.ZKActionForm):
    faceCount = forms.IntegerField(label=_('employee.fields.registeredFaceQuantity'), required=False, initial=0, disabled=True, prefix='v12', suffix='<a id=\"faceRegister\" href=\"javascript:void(0);\" onclick=\"submitFaceRegister()\">{btn}</a>'.format(btn=_('employee.fieldBtn.enroll')))
    face = forms.CharField(required=False, initial='')
    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instances', None)
        super(EnrollFacePhotoForm, self).__init__(*args, **kwargs)
        if instance:
            instance = instance[0]
            initial_data = {'faceCount': instance.biophoto_set.count()}
            self.initial.update(initial_data)
class EnrollFacePhoto(admin.ZKModelAction):
    unique_object_required = True
    verbose_name = _('deviceEmployee.actions.enrollFacePhoto')
    help_txt = _('deviceEmployee.actions.enrollFacePhoto')
    short_description = _('deviceEmployee.actions.enrollFacePhoto')
    action_form = EnrollFacePhotoForm
    def action(self, *args, **kwargs):
        from mysite.utils import save_bio_photo
        instance = self.objects
        self.instance = instance[0]
        face = kwargs.get('face', None)
        if not face:
            return
        else:
            try:
                save_bio_photo(self.instance, face, approval_state=1, overwrite=True)
            except:
                from mysite.admin.exceptions import AdminRuntimeWarning
                raise AdminRuntimeWarning(_('face.register.error.no.face.found'))