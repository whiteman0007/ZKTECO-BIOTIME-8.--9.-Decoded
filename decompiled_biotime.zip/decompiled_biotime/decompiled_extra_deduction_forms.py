# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\forms\\extra_deduction_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from django.conf import settings
from django.utils.translation import gettext_lazy as _
from mysite._utils import getattr_ex
from mysite.admin import forms, ZKModelAction
from mysite.payroll import db_const as c
from mysite.payroll.models import ExtraDeduction, SpecialPayment
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.personnel.widgets import EmployeeManyToManyMiddleWidget
from mysite.utils import get_dt4mssql
class ExtraDeductionCreationForm(forms.ZKActionForm):
    employee = forms.EmployeeManyToManyField(label=_('model_employee'), required=False, widget=EmployeeManyToManyMiddleWidget)
    amount = forms.FloatField(label=_('extraDeduction_field_amount'), required=True)
    issued_time = forms.DateTimeField(label=_('extraDeduction_field_issuedTime'), required=True)
    remark = forms.TextField(label=_('extraDeduction_field_remark'), max_length=c.MAX_LENTH_REMARK, required=False)
    special_type = forms.ModelChoiceField(queryset=SpecialPayment.objects.all(), initial=None, blank=True, label=_('specialPayment_field_name'), required=False)
    def clean(self):
        cleand_data = super(ExtraDeductionCreationForm, self).clean()
        return cleand_data
    def save(self, *args, **kwargs):
        import datetime
        from mysite.personnel.models import Employee
        emps = self.data.getlist('employee', None)
        issued_time = kwargs.get('issued_time', '')
        special_type_instance = None
        if getattr_ex(settings, 'THAILAND', False):
            if self.data.get('special_type')!= '':
                special_type_instance = SpecialPayment.objects.filter(id=int(self.data.get('special_type'))).get()
        if 'employee' in kwargs:
            kwargs.pop('employee')
        if emps and issued_time:
                messages = []
                for emp in emps:
                    employee = Employee.objects.filter(id=emp).first()
                    if isinstance(issued_time, str):
                        issued_time = datetime.datetime.strptime(issued_time, '%Y-%m-%d %H:%M:%S').date()
                    if employee and get_dt4mssql(employee.hire_date, 1) > issued_time:
                            messages.append(_('leave_time_invalid_range_hiredate') % employee)
                            continue
                    kwargs.update({'employee_id': emp, 'special_type': special_type_instance})
                    print(('#kwargs:', kwargs))
                    ExtraDeduction(**kwargs).save()
                if messages:
                    raise AdminRuntimeWarning('.'.join(messages))
class AddExtraDeductionAction(ZKModelAction):
    verbose_name = _('payroll_action_addExtraDeduction')
    help_text = _('payroll_action_addExtraDeduction')
    short_description = _('payroll_action_addExtraDeduction')
    action_form = ExtraDeductionCreationForm
    def action(self, *args, **kwargs):
        emps = self.request.POST.getlist('employee')
        message = ''
        if emps:
            form = ExtraDeductionCreationForm(self.request.POST)
            form.save(self, *args, **kwargs)
        else:
            message = _('select_employee')
        if message:
            raise AdminRuntimeWarning(message)