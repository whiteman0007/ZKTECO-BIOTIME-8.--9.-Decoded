# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\const.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

from django.conf import settings
from django.utils.translation import gettext_lazy as _
CACHE_PREFIX = 'paycode_'
NORMAL, OVERTIME, LEAVE, EXCEPTION, TRAINING, WORKCODE = (1, 2, 3, 4, 5, 6)
NONE_ROUND, ROUND_OFF, ROUND_UP, ROUND_DOWN = (0, 1, 2, 3)
REGULAR, LATE_IN, EARLY_OUT, ABSENT, CP, CPL = (1, 2, 3, 4, 5, 6)
NONE_FORMAT, MINUTE, HOUR, WORKDAY, HOUR_MINUTE = (0, 1, 2, 3, 4)
NT, OT15, OT20, PPH10, PPH20, OT1, OT2, OT3 = (1, 2, 3, 4, 5, 6, 7, 8)
ATT_CODE_CACHE_PREFIX = 'attcode_'
CODE_DURATION = 'duration'
CODE_DUTY_DURATION = 'duty_duration'
CODE_TOTAL_HRS = 'total_hrs'
CODE_WORKED_HRS = 'worked_hrs'
CODE_ACTUAL_WORKED = 'actual_worked'
CODE_BREAK_DURATION = 'break_duration'
CODE_BREAK_TOTAL_HRS = 'break_total_hrs'
CODE_BREAK_HRS = 'break_hrs'
CODE_ACTUAL_BREAK = 'actual_break'
CODE_APPROVAL_HRS = 'approval_hrs'
CODE_EARLY_IN = 'early_in'
CODE_LATE_OUT = 'late_out'
CODE_UNSCHEDULE = 'unschedule'
CODE_REMAINING = 'remaining'
CODE_TOTAL_OT = 'total_ot'
CODE_RULE_TOTAL_OT = 'rule_total_ot'
CODE_TOTAL_LEAVE = 'total_leave'
CODE_DAY_OFF = 'day_off'
CODE_WEEKEND = 'weekend'
CODE_HOLIDAY = 'holiday'
att_code_dict = {'duration': CODE_DURATION, 'duty_duration': CODE_DUTY_DURATION, 'total_hrs': CODE_TOTAL_HRS, 'worked_hrs': CODE_WORKED_HRS, 'actual_worked': CODE_ACTUAL_WORKED, 'break_duration': CODE_BREAK_DURATION, 'break_total_hrs': CODE_BREAK_TOTAL_HRS, 'break_hrs': CODE_BREAK_HRS, 'actual_break': CODE_ACTUAL_BREAK, 'approval_hrs': CODE_APPROVAL_HRS, 'early_in': CODE_EARLY_IN, 'late_out': CODE_LATE_OUT, 'unschedule': CODE_UNSCHEDULE, 'remaining': CODE_REMAINING, 'total_ot': CODE_TOTAL_OT, 'rule_total_ot': CODE_RULE_TOTAL_OT, 'total_leave': CODE_TOTAL_LEAVE, **{'day_off': CODE_DAY_OFF, 'weekend': CODE_WEEKEND, 'holiday': CODE_HOLIDAY}}
PAYCODE_FORMAT_DICT = {MINUTE: 'M', HOUR: 'H', WORKDAY: 'D', HOUR_MINUTE: 'HH:MM'}
CODE_TYPE_CHOICES = [(NORMAL, _('payCode.codeType.normal')), (OVERTIME, _('payCode.codeType.overtime')), (LEAVE, _('payCode.codeType.leave')), (EXCEPTION, _('payCode.codeType.exception')), (TRAINING, _('payCode.codeType.training'))]
if settings.WORKCODE_SETTING:
    CODE_TYPE_CHOICES.append((WORKCODE, _('menu_device_terminalWorkCode')))