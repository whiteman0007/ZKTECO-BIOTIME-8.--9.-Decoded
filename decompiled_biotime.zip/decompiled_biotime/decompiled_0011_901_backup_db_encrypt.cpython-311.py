# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0011_901_backup_db_encrypt.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('base', '0010_901_zoomsetting')]
    operations = [migrations.AddField(model_name='securitypolicy', name='backup_encryption', field=models.BooleanField(default=True, verbose_name='securityPolicy.fields.exportEncryption')), migrations.AddField(model_name='securitypolicy', name='backup_encryption_password', field=models.CharField(blank=True, max_length=128, null=True, verbose_name='Password'))]