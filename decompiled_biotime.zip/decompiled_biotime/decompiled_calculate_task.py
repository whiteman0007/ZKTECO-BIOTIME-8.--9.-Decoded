# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\models\\calculate_task.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:59 UTC (1750672979)

from django.db import models
from mysite.att.db_const import APP_LABEL
from django.db.models import signals
from django.dispatch.dispatcher import receiver
from mysite.personnel.models import Employee, Resign
class CalculateTask(models.Model):
    emp = models.IntegerField(default=0)
    start_date = models.DateTimeField(db_index=True)
    end_date = models.DateTimeField(db_index=True)
    event = models.CharField(max_length=128, null=True)
    class Meta:
        app_label = APP_LABEL
@receiver(signals.post_delete, sender=Employee)
def delete_employee(sender, instance, **kwargs):
    CalculateTask.objects.filter(emp=instance.id).delete()
@receiver(signals.post_save, sender=Resign)
def employee_resign(sender, instance, created, **kwargs):
    if created:
        CalculateTask.objects.filter(emp=instance.employee.id).delete()