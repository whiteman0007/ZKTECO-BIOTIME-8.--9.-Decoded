# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\_utils\\colorama\\ansitowin32.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

import re
import sys
import os
from .ansi import AnsiFore, AnsiBack, AnsiStyle, Style
from .winterm import WinTerm, WinColor, WinStyle
from .win32 import windll, winapi_test
winterm = None
if windll is not None:
    winterm = WinTerm()
def is_stream_closed(stream):
    return not hasattr(stream, 'closed') or stream.closed
def is_a_tty(stream):
    return hasattr(stream, 'isatty') and stream.isatty()
class StreamWrapper(object):
    """\n    Wraps a stream (such as stdout), acting as a transparent proxy for all\n    attribute access apart from method \'write()\', which is delegated to our\n    Converter instance.\n    """
    def __init__(self, wrapped, converter):
        self.__wrapped = wrapped
        self.__convertor = converter
    def __getattr__(self, name):
        return getattr(self.__wrapped, name)
    def write(self, text):
        self.__convertor.write(text)
class AnsiToWin32(object):
    """\n    Implements a \'write()\' method which, on Windows, will strip ANSI character\n    sequences from the text, and if outputting to a tty, will convert them into\n    win32 function calls.\n    """
    ANSI_CSI_RE = re.compile('?\\[((?:\\d|;)*)([a-zA-Z])?')
    ANSI_OSC_RE = re.compile('?\\]((?:.|;)*?)(\a)?')
    def __init__(self, wrapped, convert=None, strip=None, autoreset=False):
        self.wrapped = wrapped
        self.autoreset = autoreset
        self.stream = StreamWrapper(wrapped, self)
        on_windows = os.name == 'nt'
        conversion_supported = on_windows and winapi_test()
        if strip is None:
            strip = conversion_supported or (not is_stream_closed(wrapped) and (not is_a_tty(wrapped)))
        self.strip = strip
        if convert is None:
            convert = conversion_supported and (not is_stream_closed(wrapped)) and is_a_tty(wrapped)
        self.convert = convert
        self.win32_calls = self.get_win32_calls()
        self.on_stderr = self.wrapped is sys.stderr
    def should_wrap(self):
        """\n        True if this class is actually needed. If false, then the output\n        stream will not be affected, nor will win32 calls be issued, so\n        wrapping stdout is not actually required. This will generally be\n        False on non-Windows platforms, unless optional functionality like\n        autoreset has been requested using kwargs to init()\n        """
        return self.convert or self.strip or self.autoreset
    def get_win32_calls(self):
        if self.convert and winterm:
            return {AnsiStyle.RESET_ALL: (winterm.reset_all,), AnsiStyle.BRIGHT: (winterm.style, WinStyle.BRIGHT), AnsiStyle.DIM: (winterm.style, WinStyle.NORMAL), AnsiFore.BLACK: (winterm.fore, WinColor.BLACK), AnsiFore.BLUE: (winterm.fore, WinColor.GREEN), AnsiFore.MAGENTA: (winterm.fore, WinColor.CYAN, True), AnsiFore.WHITE: (winterm.fore, WinColor.BLACK), AnsiFore.RESET: (winterm.fore, WinColor.GREEN), AnsiFore.LIGHTBLACK_EX: (winterm.fore, WinColor.BLACK, True), AnsiFore.BLUE: (winterm.fore, WinColor.BLUE), AnsiFore.MAGENTA: (winterm.fore, WinColor.MAGENTA), AnsiFore.CYAN: (winterm.fore, WinColor.CYAN, True), AnsiFore.WHITE: (winterm.fore, WinColor.GREY), AnsiFore.RESET: (winterm.fore, WinColor.GREY), AnsiFore.LIGHTBLACK_EX: (winterm.fore, WinColor
        else:
            return dict()
    def write(self, text):
        if self.strip or self.convert:
            self.write_and_convert(text)
        else:
            self.wrapped.write(text)
            self.wrapped.flush()
        if self.autoreset:
            self.reset_all()
    def reset_all(self):
        if self.convert:
            self.call_win32('m', (0,))
        else:
            if self.strip or not is_stream_closed(self.wrapped):
                    self.wrapped.write(Style.RESET_ALL)
    def write_and_convert(self, text):
        """\n        Write the given text to our wrapped stream, stripping any ANSI\n        sequences from the text, and optionally converting them into win32\n        calls.\n        """
        cursor = 0
        text = self.convert_osc(text)
        for match in self.ANSI_CSI_RE.finditer(text):
            start, end = match.span()
            self.write_plain_text(text, cursor, start)
            self.convert_ansi(*match.groups())
            cursor = end
        self.write_plain_text(text, cursor, len(text))
    def write_plain_text(self, text, start, end):
        if start < end:
            self.wrapped.write(text[start:end])
            self.wrapped.flush()
    def convert_ansi(self, paramstring, command):
        if self.convert:
            params = self.extract_params(command, paramstring)
            self.call_win32(command, params)
    def extract_params(self, command, paramstring):
        if command in 'Hf':
            params = tuple((int(p) if len(p)!= 0 else 1 for p in paramstring.split(';')))
            while len(params) < 2:
                params = params + (1,)
        else:
            params = tuple((int(p) for p in paramstring.split(';') if len(p)!= 0))
            if len(params) == 0:
                if command in 'JKm':
                    params = (0,)
                else:
                    if command in 'ABCD':
                        params = (1,)
        return params
    def call_win32(self, command, params):
        if command == 'm':
            for param in params:
                if param in self.win32_calls:
                    func_args = self.win32_calls[param]
                    func = func_args[0]
                    args = func_args[1:]
                    kwargs = dict(on_stderr=self.on_stderr)
                    func(*args, **kwargs)
        else:
            if command in 'J':
                winterm.erase_screen(params[0], on_stderr=self.on_stderr)
            else:
                if command in 'K':
                    winterm.erase_line(params[0], on_stderr=self.on_stderr)
                else:
                    if command in 'Hf':
                        winterm.set_cursor_position(params, on_stderr=self.on_stderr)
                    else:
                        if command in 'ABCD':
                            n = params[0]
                            x, y = {'A': (0, -n), 'B': (0, n), 'C': (n, 0), 'D': (-n, 0)}[command]
                            winterm.cursor_adjust(x, y, on_stderr=self.on_stderr)
    def convert_osc(self, text):
        for match in self.ANSI_OSC_RE.finditer(text):
            start, end = match.span()
            text = text[:start] + text[end:]
            paramstring, command = match.groups()
            if command in '\a':
                params = paramstring.split(';')
                if params[0] in '02':
                    winterm.set_title(params[1])
        return text