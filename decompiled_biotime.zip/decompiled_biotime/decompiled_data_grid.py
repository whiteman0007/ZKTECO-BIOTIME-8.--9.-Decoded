# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\data_grid.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

from django.utils.translation import gettext_lazy as _
from django.core.paginator import Paginator
from collections.abc import Iterable
__author__ = 'Arvin'
class GridViewBase(object):
    verbose_name = None
    menu_index = None
    template = 'main-layout.html'
    visible = True
    hide_list = None
    model = None
    heads = None
    grid = None
    search_form = None
    request = None
    def __init__(self, request, model=None, model_admin=None):
        self.request = request
        self.admin = model_admin
        if model:
            self.model = model
            self.template = '{0}_data.html'.format(model.__name__.lower())
    def set_search_form(self):
        cls = self.model
        if not hasattr(cls, 'Admin'):
            return
        else:
            if not hasattr(cls.Admin, 'query_fields'):
                return
    def data_set(self):
        import json
        from django.db.models import CharField
        from django.core.exceptions import FieldDoesNotExist
        from django.shortcuts import render
        from django.template import loader
        post_args = dict()
        for k, v in list(self.request.POST.items()):
            if k!= 'key':
                continue
            else:
                post_args.update(json.loads(v))
        try:
            page_num = int(self.request.POST.get('page', 1))
        except TypeError as e:
            page_num = 1
        try:
            page_size = int(self.request.POST.get('limit', 20))
        except TypeError as e:
            page_size = 20
        cls = self.model
        if cls is not None:
            pass
        qs = cls.objects.all().order_by(*cls._meta.ordering)
        if post_args:
            all_keys = list(post_args.keys())
            for field in all_keys:
                try:
                    model_field = cls._meta.get_field(field)
                except (FieldDoesNotExist, AttributeError) as e:
                    pass
                else:
                    if isinstance(model_field, CharField):
                        post_args['{}__icontains'.format(field)] = post_args.pop(field)
            qs = qs.filter(**post_args)
        paginator = Paginator(qs, page_size)
        total = paginator.count
        page = paginator.page(page_num)
        rows = []
        for index, record in enumerate(page.object_list.values(*self.admin._list_display), start=1):
            record.update(hash=index)
            rows.append(record)
        context = {'code': 0, 'msg': '', 'count': total, 'data': rows}
        return context