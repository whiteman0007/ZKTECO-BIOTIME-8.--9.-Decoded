# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\meeting\\api\\report\\meeting_room_scheduled.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:05 UTC (1750673045)

import django_filters
from django.utils.translation import gettext_lazy as _
from rest_framework import mixins, serializers
from rest_framework.response import Response
from mysite.meeting.api.serializers import NoneSerializer
from mysite.meeting.api.utils_class import UserLayUIGenericViewSet
from mysite.meeting.models import MeetingEntity
class MeetingRoomScheduledSerializer(serializers.ModelSerializer):
    room_code = serializers.CharField(label=_('report.columns.meetingRoomCode'), source='room.code')
    room_name = serializers.CharField(label=_('report.columns.meetingRoomAlias'), source='room.alias')
    meeting_name = serializers.CharField(label=_('report.columns.meetingName'), source='alias')
    meeting_content = serializers.CharField(label=_('report.columns.meetingContent'), source='content')
    meeting_date = serializers.SerializerMethodField(label=_('report.columns.meetingDate'))
    meeting_start = serializers.SerializerMethodField(label=_('report.columns.meetingStartTime'))
    meeting_end = serializers.SerializerMethodField(label=_('report.columns.meetingEndTime'))
    def get_meeting_date(self, obj):
        return obj.start_time.date()
    def get_meeting_start(self, obj):
        return obj.start_time.time()
    def get_meeting_end(self, obj):
        return obj.end_time.time()
    class Meta:
        model = MeetingEntity
        fields = ('id', 'room_code', 'room_name', 'meeting_name', 'meeting_content', 'meeting_date', 'meeting_start', 'meeting_end')
class MeetingRoomScheduledFilter(django_filters.rest_framework.FilterSet):
    meeting_room = django_filters.CharFilter(method='meeting_room_filter')
    start_date = django_filters.DateFilter(field_name='meeting_date', lookup_expr='gte')
    end_date = django_filters.DateFilter(field_name='meeting_date', lookup_expr='lte')
    def meeting_room_filter(self, queryset, name, value):
        if not value:
            return queryset
        else:
            try:
                rooms = map(int, value.split(','))
                queryset = queryset.filter(room__in=rooms)
            except Exception as e:
                pass
            return queryset
class MeetingRoomScheduledViewSet(mixins.ListModelMixin, UserLayUIGenericViewSet):
    model = MeetingEntity
    queryset = MeetingEntity.objects.get_queryset().order_by('room__code')
    serializer_dict = {'list': MeetingRoomScheduledSerializer, 'export': MeetingRoomScheduledSerializer}
    filterset_class = MeetingRoomScheduledFilter
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)
    def get_queryset(self):
        from mysite.workflow import models_choices as mc
        queryset = super(MeetingRoomScheduledViewSet, self).get_queryset()
        queryset = queryset.filter(room__isnull=False, approval_status=mc.APPROVED).select_related('room')
        return queryset
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        else:
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)