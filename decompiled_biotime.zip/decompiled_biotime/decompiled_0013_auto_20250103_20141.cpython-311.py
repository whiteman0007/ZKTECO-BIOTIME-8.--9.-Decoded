# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0013_auto_20250103_20141.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:14 UTC (1750702694)

from django.db import migrations, models
import django.utils.timezone
class Migration(migrations.Migration):
    dependencies = [('accounts', '0012_auto_20241212_20114')]
    operations = [migrations.CreateModel(name='PasswordResetKey', fields=[('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('encrypt_key', models.CharField(default='', max_length=32, verbose_name='password_reset_fields_encryptKey')), ('encrypt_iv', models.CharField(default='', max_length=64, verbose_name='password_reset_fields_encryptTime')), ('encrypt_email', models.CharField(default='', max_length=64, verbose_name='password_reset_fields_requestTime')), ('user_key', models.CharField(blank=True, max_length=125, verbose_name='password_reset_fields_userKey')), ('applied_time', models.DateTimeField(blank=True, null=True, verbose_name='password_reset_fields_appliedTime'))])]