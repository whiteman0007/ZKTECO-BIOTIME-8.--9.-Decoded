# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\acc\\api\\serializers\\accgroups_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from rest_framework import serializers
from mysite.acc.models.model_acc_groups import AccGroups, AccTimezone
from mysite.att.api.serializers import util_serializers
class AccGroupsSerializer(serializers.ModelSerializer):
    area_name = serializers.CharField(source='area.area_name')
    timezone_1 = serializers.SerializerMethodField()
    timezone_2 = serializers.SerializerMethodField()
    timezone_3 = serializers.SerializerMethodField()
    def get_timezone_1(self, obj):
        timezone = AccTimezone.objects.filter(area=obj.area, timezone_no=obj.timezone1).first()
        return timezone.id if timezone else 0
    def get_timezone_2(self, obj):
        timezone = AccTimezone.objects.filter(area=obj.area, timezone_no=obj.timezone2).first()
        return timezone.id if timezone else 0
    def get_timezone_3(self, obj):
        timezone = AccTimezone.objects.filter(area=obj.area, timezone_no=obj.timezone3).first()
        return timezone.id if timezone else 0
    class Meta:
        model = AccGroups
        fields = ['id', 'area_name', 'group_no', 'group_name', 'verify_mode', 'timezone1', 'timezone2', 'timezone3', 'is_include_holiday', 'timezone_1', 'timezone_2', 'timezone_3']
class AccGroupsExportSerializer(serializers.ModelSerializer):
    area_name = serializers.CharField(source='area.area_name')
    verify_mode = serializers.CharField(source='get_verify_mode_display')
    is_include_holiday = serializers.CharField(source='get_is_include_holiday_display')
    class Meta:
        model = AccGroups
        fields = ['id', 'area_name', 'group_no', 'group_name', 'verify_mode', 'timezone1', 'timezone2', 'timezone3', 'is_include_holiday']
class AccGroupsCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccGroups
        fields = '__all__'
class AccGroupsEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccGroups
        fields = '__all__'
class AccGroupsActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AccGroups
        action_type_choices = (('delete', 'delete'),)