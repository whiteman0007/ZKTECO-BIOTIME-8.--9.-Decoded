# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\admin\\exception_formula_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:11 UTC (1750673051)

from mysite import admin
from mysite.payroll.models import ExceptionFormula
from mysite.admin.kernel import ZKModelAdmin
from mysite.payroll.forms import AddExceptionFormulaForm
from django.utils.translation import gettext_lazy as _
@admin.register(ExceptionFormula)
class ExceptionFormulaAdmin(ZKModelAdmin):
    actions = []
    list_display = ('id', 'name', 'pay_code', 'formula', 'remark')
    list_filter = ('name', 'pay_code', 'formula', 'remark')
    sort_fields = ()
    cache_keys = ()
    form = AddExceptionFormulaForm
    @staticmethod
    def initial_data():
        count = ExceptionFormula.objects.count()
        if not count:
            from mysite.att.admin import PayCodeAdmin
            from mysite.att.models import PayCode
            from mysite.admin import zk_site
            PayCodeAdmin(PayCode, zk_site).initial_data()
            _e = PayCode.objects.filter(code='E').first()
            _l = PayCode.objects.filter(code='L').first()
            if _e:
                ExceptionFormula(**{'name': str(_('payCode.default.earlyOut')), 'pay_code': _e, 'formula': '((({Basic Salary}/30)/8)/60)*{E}'}).save(force_insert=True)
            if _l:
                ExceptionFormula(**{'name': str(_('payCode.default.lateIn')), 'pay_code': _l, 'formula': '(({Basic Salary}/30)/8)/60*{L}'}).save(force_insert=True)