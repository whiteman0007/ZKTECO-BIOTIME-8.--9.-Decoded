# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\cache_key.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:35 UTC (1750673015)

"""\nTerminal\n"""
TERMINAL_WITHOUT_CMD = '%s_nocmd_device_%s'
TERMINAL_CMD = 'device_{sn}_cmds'
TERMINAL_CMD_HEART = 'cmd_detect_{sn}'
TERMINAL_CACHE = 'iclock_%s'
TERMINAL_CACHE_LAST_ACTIVITY = 'iclock_la_%s'
TERMINAL_CACHE_PREVIOUS = 'iclock_old_%s'
TERMINAL_SAVE_TAG = 'iclock_la_%s'
BIODATA_TEMPLATE = '%s_TMP_%s_%s'
USER_PHOTO_CACHE = 'user_photo_{dev}_{pin}'
TERMINAL_TOTAL = 'device_total'
VISITORBIODATA_TEMPLATE = '%s_VISTMP_%s_%s'
TERMINAL_MANUAL_SYNC_RUNNING = 'manual_sync_{sn}'