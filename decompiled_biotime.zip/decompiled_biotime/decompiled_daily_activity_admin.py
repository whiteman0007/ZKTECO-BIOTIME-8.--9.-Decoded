# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\daily_activity_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import DailyActivityViewSet
from mysite.att.api.report_views.daily_activity import DailyActivitySerializer
@report_register()
class DailyActivityAdmin(ReportAdminBase):
    model_name = 'dailyActivityReport'
    view_name = 'daily_activity'
    template = 'att/report_new/daily_activity.html'
    api_view = DailyActivityViewSet
    serializer = DailyActivitySerializer
    data_source = '/att/api/dailyActivityReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday')
    hidden_fields = ('company_code', 'last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = ('emp_code', 'att_date')
    add_paycode_column = True