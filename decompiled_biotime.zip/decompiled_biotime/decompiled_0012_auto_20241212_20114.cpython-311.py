# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0012_auto_20241212_20114.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:14 UTC (1750702694)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('accounts', '0011_903_emoloyee_noticifation')]
    operations = [migrations.AddField(model_name='myuser', name='password_reset', field=models.DateTimeField(blank=True, editable=False, null=True, verbose_name='emp_field_passwordReset'))]