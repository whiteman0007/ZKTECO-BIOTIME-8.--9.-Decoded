# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\forms\\auto_att_export_task_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

import json
import os.path
import six
from django.forms import ModelForm, ValidationError
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att.models import ReportTemplate
from mysite.base import db_const, const
from mysite.base.db_const import WEEKDAY
from mysite.base.models import AutoAttExportTask, SftpSetting
MONTHLY = [(x, x) for x in range(1, 32, 1)]
regex = '^[^\\\\/:\\*\\?\"<>\\|]+$'
class AutoAttExportTaskCreationForm(ModelForm):
    task_code = forms.CharField(label=_('autoAttExportTask_field_code'), initial='1', disabled=True)
    task_name = forms.CharField(label=_('autoAttExportTask_field_name'), initial='T1')
    file_prefix = forms.CharField(label=_('autoExport_task_filePrefix'), required=True, initial='{report_template}_{cur_date}')
    file_date = forms.ChoiceField(label=_('autoExport.macros.curDate'), required=False, choices=const.HUMAN_FILE_SHORT_DATE, initial=12)
    file_time = forms.ChoiceField(label=_('autoExport.macros.curTime'), required=False, choices=const.HUMAN_FILE_SHORT_TIME, initial=11)
    report_type = forms.ChoiceField(label=_('autoExport_task_report_type'), choices=db_const.REPORT_GROUP, initial=db_const.TOTAL_TIME_CARD_REPORT)
    report_template = forms.ModelChoiceField(label=_('autoExport_task_report_template'), queryset=ReportTemplate.objects.get_queryset(), required=True)
    contains_heads = forms.BooleanField(label=_('autoExport_task_contains_heads'), required=False)
    export_period = forms.ChoiceField(label=_('autoExport_task_period'), initial=const.PREVIOUS_PERIOD, choices=const.EXPORT_PERIOD)
    export_policy = forms.ChoiceField(label=_('autoExport_task_export_by'), choices=const.EXPORT_POLICES)
    export_format = forms.ChoiceField(label=_('autoExport_task_exportFormat'), initial=const.FORMAT_XLS, choices=const.REPORT_FILE_FORMAT, help_text=_('autoExport_reportFormat_helpTxt'))
    export_encryption_type = forms.ChoiceField(label=_('securityPolicy.fields.exportEncryption'), choices=const.EXPORT_ENCRYPTION_TYPE, required=False)
    export_encryption_password = forms.PasswordField(label=_('Password'), required=False)
    frequency = forms.ChoiceField(label=_('autoExport_task_frequency'), initial=const.DAILY, choices=const.EXPORT_FREQUENCY)
    month_day = forms.ChoiceField(label=_('autoExport.fields.monthDay'), initial=1, choices=MONTHLY)
    week_day = forms.ChoiceField(label=_('autoExport.fields.weekday'), initial=1, choices=WEEKDAY)
    day = forms.ChoiceField(label=_('autoExport_task_exportDay'), initial=1, choices=((1, 1),))
    export_interval = forms.IntegerField(label=_('autoExport_task_interval'), initial=0, unit=_('timeInterval_field_workTimeDurationHelpTxt'), min_value=0)
    export_time = forms.CharField(label=_('autoExport_task_exportTime'), initial='00:01', unit=_('HH:mm'))
    export_email = forms.CharField(label=_('autoExport_task_exportEmail'), required=False)
    export_path = forms.CharField(label=_('autoExport_task_exportPath'), initial='AutoAttExport', required=False)
    ftp_server = forms.ModelChoiceField(label=_('autoExport_task_ftpServer'), queryset=SftpSetting.objects.get_queryset(), required=False)
    ftp_path = forms.CharField(label=_('autoExport_task_ftpPath'), required=False)
    def __init__(self, *args, **kwargs):
        super(AutoAttExportTaskCreationForm, self).__init__(*args, **kwargs)
        if kwargs.get('instance', None):
            self.initial.update(self.instance.get_options())
        else:
            codes = AutoAttExportTask.objects.all().values_list('task_code', flat=True)
            codes = list(map(int, filter(lambda x: x.isnumeric(), codes)))
            if codes:
                code = max(codes) + 1
                self.initial.update({'task_code': code, 'task_name': 'T{0}'.format(code)})
    def clean_export_encryption_password(self):
        encryption_password = self.cleaned_data.get('export_encryption_password', '')
        encryption_type = int(self.cleaned_data.get('export_encryption_type', 0))
        if encryption_type and encryption_type!= const.ENCRYPTION_SELF_PASSWORD:
                encryption_password = ''
        return encryption_password
    def clean_ftp_path(self):
        temp_ftp_path = self.cleaned_data.get('ftp_path', '')
        if temp_ftp_path:
            temp = ['..', '~/', '/、', '\\、', '..、', './']
            for stemp in temp:
                if stemp in temp_ftp_path:
                    raise ValidationError(_('database.backup.error.invalidPath'), code='-1')
        return temp_ftp_path
    def clean(self):
        # irreducible cflow, using cdg fallback
        from mysite.base.api.serializers import AutoExportReportOptionSerializer
        cleaned_data = super(AutoAttExportTaskCreationForm, self).clean()
        serializer = AutoExportReportOptionSerializer(data=cleaned_data)
        serializer.is_valid()
        if serializer.errors:
            for k, v in serializer.errors.items():
                raise ValidationError(','.join(map(six.text_type, v)))
                cleaned_data['params'] = json.dumps(serializer.validated_data)
                return cleaned_data
    class Meta:
        model = AutoAttExportTask
        fields = ('task_code', 'task_name', 'file_date', 'file_time', 'contains_heads', 'export_format', 'export_encryption_type', 'export_encryption_password', 'frequency', 'month_day', 'report_type', 'enable', 'report_template', 'week_day', 'day', 'export_interval', 'export_time', 'export_email', 'ftp_server', 'export_policy', 'export_period', 'ftp_path', 'file_prefix', 'export_path', 'params')