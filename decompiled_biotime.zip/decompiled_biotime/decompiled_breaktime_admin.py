# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\breaktime_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import datetime
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.att.models import BreakTime
from mysite.att.forms import BreakTimeForm
from mysite.utils import get_dt4mssql
@admin.register(BreakTime)
class BreakTimeAdmin(admin.ZKModelAdmin):
    def break_in_time(self, obj):
        break_out = datetime.datetime.strptime('2000-01-01 {time}'.format(time=get_dt4mssql(obj.period_start, 2)), '%Y-%m-%d %H:%M:%S')
        break_in = break_out + datetime.timedelta(minutes=obj.end_margin)
        days = (break_in.date() - break_out.date()).days
        if days > 0:
            return '{out}<sup>+{days}</sup>'.format(out=break_in.strftime('%H:%M:%S'), days=days)
        else:
            return '{out}'.format(out=break_in.strftime('%H:%M:%S'))
    break_in_time.short_description = _('breakTime_field_endTime')
    list_display = ('id', 'alias', 'period_start', 'break_in_time', 'duration', 'calc_type')
    list_filter = ('alias', 'period_start', 'calc_type')
    form = BreakTimeForm
    def get_queryset(self, request):
        qs = super(BreakTimeAdmin, self).get_queryset(request)
        if request.user.is_employee:
            qs = qs.filter(company=request.user.company)
        else:
            if not request.user.is_superuser and request.user.assign_company:
                    qs = qs.filter(company=request.user.assign_company)
        return qs