# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\payroll\\migrations\\0007_extradeduction_special_type_and_more.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:06 UTC (1750702746)

from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('payroll', '0006_901_salary_th')]
    operations = [migrations.AddField(model_name='extradeduction', name='special_type', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='payroll.specialpayment', verbose_name='extraDeduction_field_specialType')), migrations.AddField(model_name='extraincrease', name='special_type', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='payroll.specialpayment', verbose_name='extraIncrease_field_specialType'))]