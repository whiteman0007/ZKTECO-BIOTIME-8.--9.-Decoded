# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\admin\\dispatchers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:52 UTC (1750672972)

class ZKDispatcher(object):
    def __init__(self):
        self._registry = {}
        self._weights = {}
    def take(self, publisher_or_iterable, subscriber, weight=1):
        """\n        Register the plug to publisher, when trigger will run each plugs\n        :param publisher_or_iterable: publisher name or list/tuple/set\n        :param subscriber: subscriber\n        :param weight: weight to define the running order\n        :return:\n        """
        if not callable(subscriber):
            raise Exception('Invalid Function')
        else:
            if isinstance(publisher_or_iterable, str):
                publisher_or_iterable = [publisher_or_iterable]
            for publisher in publisher_or_iterable:
                subscribers = self.get_subscribers(publisher)
                if subscriber in subscribers:
                    raise Exception('Duplicate Function')
                else:
                    weights = self.get_weights(publisher)
                    subscribers.append(subscriber)
                    weights.append(weight)
                    weights, subscribers = zip(*sorted(zip(weights, subscribers), key=lambda x: x[0]))
                    self._registry[publisher] = list(subscribers)
                    self._weights[publisher] = list(weights)
    def get_weights(self, publisher):
        return self._weights.get(publisher, [])
    def get_subscribers(self, publisher):
        return self._registry.get(publisher, [])
class PermissionDispatcher(object):
    def __init__(self):
        self._registry = []
    def register(self, item_or_iterable):
        from collections.abc import Iterable
        if not isinstance(item_or_iterable, Iterable):
            item_or_iterable = [item_or_iterable]
        self._registry.extend(item_or_iterable)
    def get_permissions(self):
        return self._registry
permissions = PermissionDispatcher()
zk_dispatcher = ZKDispatcher()