# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\ep\\admin\\eptransaction_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

import os
from django.conf import settings
from django.forms import ModelForm, ModelChoiceField
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _
from mysite import admin, config
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.ep.models import EPTransaction
from mysite.ep.utils import temperature_converted_with_unit, check_abnormal_temperature
from mysite.iclock.models import Terminal
from mysite.personnel.models import Employee
from mysite.iclock.filter import CompanyFilter
BASE_DIR = settings.BASE_DIR
class EPTransactionChangeForm(ModelForm):
    emp = ModelChoiceField(queryset=Employee.objects, label=_('epTransaction.fields.employee'), disabled=True)
    terminal = ModelChoiceField(queryset=Terminal.objects, label=_('epTransaction.fields.device'), required=False, disabled=True)
    check_date = forms.DateField(label=_('epTransaction.fields.checkDate'))
    check_time = forms.TimeField(label=_('epTransaction.fields.checkTime'))
    temperature = forms.DecimalField(label=_('epTransaction.fields.temperature'), decimal_places=1, max_digits=4)
    is_mask = forms.BooleanField(label=_('epTransaction.fields.isMask'), required=False)
    class Meta:
        model = EPTransaction
        fields = '__all__'
@admin.register(EPTransaction)
class EPTransactionAdmin(admin.ZKModelAdmin):
    list_display = ('employee_code', 'employee_first_name', 'employee_last_name') + config.WDMS_LIST_DISPLAY + ('employee_department', 'employee_position', 'check_date', 'check_time', 'capture_img', 'converted_temperature', 'converted_is_mask', 'area', 'terminal_sn', 'device_alias', 'upload_time')
    ordering = ('-upload_time',)
    sort_fields = ('emp__emp_code', 'check_date', 'check_time', 'upload_time', 'temperature')
    list_filter = ('emp__emp_code', 'emp__first_name', 'check_date', 'check_time', 'temperature', 'is_mask', 'source', 'terminal_sn', 'terminal__alias', 'upload_time')
    calculated_filter = (CompanyFilter,) if getattr_ex(settings, 'MULTI_COMPANY', False) else ()
    img_filed = ['capture']
    form = EPTransactionChangeForm
    def employee_code(self, obj):
        return obj.emp_code
    employee_code.short_description = _('epTransaction.fields.employeeCode')
    def employee_first_name(self, obj):
        from mysite.visitor.models import Visitor
        name = ''
        if obj.emp:
            name = obj.emp.first_name
        else:
            visitor = Visitor.objects.filter(visitor_code=obj.emp_code).first()
            if visitor:
                name = visitor.first_name
        return name
    employee_first_name.short_description = _('epTransaction.fields.firstName')
    def employee_last_name(self, obj):
        from mysite.visitor.models import Visitor
        name = ''
        if obj.emp:
            name = obj.emp.last_name
        else:
            visitor = Visitor.objects.filter(visitor_code=obj.emp_code).first()
            if visitor:
                name = visitor.last_name
        return name
    employee_last_name.short_description = _('epTransaction.fields.lastName')
    def employee_department(self, obj):
        return obj.emp.department.dept_name
    employee_department.short_description = _('epTransaction.fields.department')
    def employee_position(self, obj):
        return obj.emp.position.position_name
    employee_position.short_description = _('epTransaction.fields.position')
    def device_alias(self, obj):
        return obj.terminal.alias
    device_alias.short_description = _('epTransaction.fields.deviceAlias')
    def converted_temperature(self, obj):
        temperature = obj.temperature
        converted_temperature = temperature_converted_with_unit(temperature)
        if not check_abnormal_temperature(temperature):
            return converted_temperature
        else:
            return format_html('<span style=\"color: #ff0000;\">{0}</span>', converted_temperature)
    converted_temperature.short_description = _('epTransaction.fields.temperature')
    converted_temperature.allow_tags = True
    def converted_is_mask(self, obj):
        if not obj.is_mask:
            return format_html('<span style=\"color: #ffa500;\">{0}</span>', obj.get_is_mask_display())
        else:
            return obj.get_is_mask_display()
    converted_is_mask.short_description = _('epTransaction.fields.isMask')
    converted_is_mask.allow_tags = True
    def capture_img(self, obj):
        emp_code = obj.emp_code or '0'
        fn = '{stamp}-{code}.jpg'.format(stamp=obj.check_datetime.strftime('%Y%m%d%H%M%S'), code=emp_code)
        folders = ('upload', obj.check_date.strftime('%Y%m'), obj.terminal_sn, fn)
        fp = os.path.join(settings.ADDITION_FILE_ROOT, os.path.sep.join(folders))
        if not os.path.isfile(fp):
            return '/files/nophoto.jpg'
        else:
            return '/files/{path}'.format(path='/'.join(folders))
    capture_img.short_description = _('epTransaction.fields.capture')
    def has_delete_permission(self, request, obj=None):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_add_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        qs = super(EPTransactionAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                qs = qs.filter(emp__department__in=request.user.auth_dept.all())
            if request.user.auth_area.exists():
                qs = qs.filter(emp__area__in=request.user.auth_area.all()).distinct()
        qs = qs.select_related('emp', 'terminal')
        return qs