# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\holiday_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import datetime
import copy
from django.utils.translation import gettext_lazy as _
from django import forms as django_forms
from django.forms import ModelForm, ValidationError
from django.db.models import Q, F, DateField, ExpressionWrapper
from django.conf import settings
from mysite import admin
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.personnel.models import Department
from mysite.att import db_const
from mysite.att.models import Holiday, AttGroup
from mysite.personnel import fields, widgets
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.att.fields import PayCodeModelChoiceField
from mysite.att.widgets import AttGroupSelectMultiple
class DepartmentHolidayForm(forms.ZKActionForm):
    alias = forms.CharField(label=_('holiday_field_alias'), max_length=db_const.MAX_HOLIDAY_ALIAS)
    start_date = forms.DateField(label=_('holiday_field_startDate'), initial=datetime.datetime.now())
    duration_day = forms.IntegerField(label=_('holiday_field_duration'), initial=1, unit=_('time.units.day'))
    department = django_forms.ModelMultipleChoiceField(queryset=Department.objects.all(), label=_('holiday_field_department'), widget=widgets.DepartmentSelectMultiple, required=False)
    att_group = django_forms.ModelMultipleChoiceField(queryset=AttGroup.objects.all(), label=_('groupPolicy.fields.group'), widget=AttGroupSelectMultiple, required=False)
    enable_ot_rule = forms.BooleanField(label=_('holiday.fields.enableOvertimeRule'), initial=False, required=False)
    t1_pay_code = PayCodeModelChoiceField(label=_('holiday.fields.payCode'), required=False)
    t1_hrs_from = forms.DecimalField(label=_('holiday.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, required=False, unit=_('time.units.hour'))
    t1_hrs_to = forms.DecimalField(label=_('holiday.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, required=False, unit=_('time.units.hour'))
    t2_pay_code = PayCodeModelChoiceField(label=_('holiday.fields.payCode'), required=False)
    t2_hrs_from = forms.DecimalField(label=_('holiday.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, required=False, unit=_('time.units.hour'))
    t2_hrs_to = forms.DecimalField(label=_('holiday.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, required=False, unit=_('time.units.hour'))
    t3_pay_code = PayCodeModelChoiceField(label=_('holiday.fields.payCode'), required=False)
    t3_hrs_from = forms.DecimalField(label=_('holiday.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, required=False, unit=_('time.units.hour'))
    t3_hrs_to = forms.DecimalField(label=_('holiday.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, required=False, unit=_('time.units.hour'))
    color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    def __init__(self, *args, **kwargs):
        super(DepartmentHolidayForm, self).__init__(*args, **kwargs)
        if getattr_ex(settings, 'MULTI_COMPANY_EXT', False) and self.request and (not self.request.user.is_superuser) and self.request.user.assign_company:
                        self.fields['department'].company_belong = self.request.user.assign_company
                        self.fields['att_group'].company_belong = self.request.user.assign_company
class DepartmentHolidayChangeForm(ModelForm):
    alias = forms.CharField(label=_('holiday_field_alias'), max_length=db_const.MAX_HOLIDAY_ALIAS)
    start_date = forms.DateField(label=_('holiday_field_startDate'), initial=datetime.datetime.now())
    duration_day = forms.IntegerField(label=_('holiday_field_duration'), initial=1, unit=_('time.units.day'))
    end_date = forms.DateField(label=_('holiday_field_endDate'), initial=datetime.datetime.now(), required=False)
    dept = forms.CharField(label=_('holiday_field_department'), disabled=True, required=False)
    group = forms.CharField(label=_('groupPolicy.fields.group'), disabled=True, required=False)
    enable_ot_rule = forms.BooleanField(label=_('holiday.fields.enableOvertimeRule'), initial=False, required=False)
    t1_pay_code = PayCodeModelChoiceField(label=_('holiday.fields.payCode'), required=False)
    t1_hrs_from = forms.DecimalField(label=_('holiday.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t1_hrs_to = forms.DecimalField(label=_('holiday.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t2_pay_code = PayCodeModelChoiceField(label=_('holiday.fields.payCode'), required=False)
    t2_hrs_from = forms.DecimalField(label=_('holiday.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t2_hrs_to = forms.DecimalField(label=_('holiday.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t3_pay_code = PayCodeModelChoiceField(label=_('holiday.fields.payCode'), required=False)
    t3_hrs_from = forms.DecimalField(label=_('holiday.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t3_hrs_to = forms.DecimalField(label=_('holiday.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    def __init__(self, *args, **kwargs):
        from mysite.att.models.model_overtime_policy import OvertimePolicy
        super(DepartmentHolidayChangeForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['dept'].initial = str(self.instance.department)
            self.fields['group'].initial = str(self.instance.att_group)
            rules = OvertimePolicy.objects.filter(master=self.instance.ot_rule).values('mode', 'hrs_from', 'hrs_to', 'pay_code')
            for rule in rules:
                self.fields['t{lv}_pay_code'.format(lv=rule['mode'])].initial = rule['pay_code']
                self.fields['t{lv}_hrs_from'.format(lv=rule['mode'])].initial = rule['hrs_from']
                self.fields['t{lv}_hrs_to'.format(lv=rule['mode'])].initial = rule['hrs_to']
    def save(self, commit=True):
        from mysite.att.models.model_overtime_policy import OvertimePolicy, OT_LV1, OT_LV2, OT_LV3
        instance = super(DepartmentHolidayChangeForm, self).save(commit)
        for i, mode in enumerate([OT_LV1, OT_LV2, OT_LV3]):
            otp = OvertimePolicy.objects.filter(master=instance.ot_rule, mode=mode).first()
            if otp:
                otp.hrs_from = self.cleaned_data['t%s_hrs_from' % (i + 1)]
                otp.hrs_to = self.cleaned_data['t%s_hrs_to' % (i + 1)]
                otp.pay_code = self.cleaned_data['t%s_pay_code' % (i + 1)]
                otp.save()
        instance.end_date = instance.start_date + datetime.timedelta(days=instance.duration_day - 1)
        return instance
    class Meta:
        model = Holiday
        fields = ('alias', 'dept', 'start_date', 'duration_day', 'group', 'end_date')
class AddDepartmentHoliday(admin.ZKModelAction):
    verbose_name = _('holiday_action_addDepartmentHoliday')
    short_description = _('holiday_action_addDepartmentHolidayDescription')
    help_txt = _('holiday_action_addDepartmentHolidayHelpTxt')
    action_form = DepartmentHolidayForm
    def action(self, alias, start_date, duration_day, department, enable_ot_rule, t1_pay_code, t1_hrs_from, t1_hrs_to, t2_pay_code, t2_hrs_from, t2_hrs_to, t3_pay_code, t3_hrs_from, t3_hrs_to, att_group, color_setting):
        import uuid
        from mysite.att.models.model_overtime_policy import OvertimePolicy, OT_LV1, OT_LV2, OT_LV3
        depts = self.request.POST.getlist('department', None)
        att_groups = self.request.POST.getlist('att_group', None)
        new_start = datetime.datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = new_start + datetime.timedelta(int(duration_day) - 1)
        queryset = Holiday.objects.exclude(Q(start_date__gt=end_date) | Q(end_date__lt=start_date))
        if att_groups:
            queryset = queryset.filter(Q(att_group__isnull=True, department__isnull=True) | Q(att_group__in=att_groups))
        if depts:
            queryset = queryset.filter(Q(att_group__isnull=True, department__isnull=True) | Q(department__in=depts))
        if not att_groups and (not depts):
                queryset = queryset.filter(department=None)
        if queryset.count():
            message = _('holiday_duration_invalid')
            raise AdminRuntimeWarning(message)
        else:
            kwargs = {'alias': alias, 'start_date': start_date, 'duration_day': duration_day, 'end_date': end_date, 'enable_ot_rule': bool(enable_ot_rule), 'ot_rule': uuid.uuid4().hex, 'color_setting': color_setting}
            rules = []
            if att_groups:
                holidays = []
                for group in att_groups:
                    key = uuid.uuid4().hex
                    _kwargs = copy.deepcopy(kwargs)
                    _kwargs.update({'att_group_id': group, 'ot_rule': key})
                    holiday = Holiday(**_kwargs)
                    holidays.append(holiday)
                    rules.append(OvertimePolicy(master=key, mode=OT_LV1, hrs_from=t1_hrs_from, hrs_to=t1_hrs_to, pay_code_id=t1_pay_code or None))
                    rules.append(OvertimePolicy(master=key, mode=OT_LV2, hrs_from=t2_hrs_from, hrs_to=t2_hrs_to, pay_code_id=t2_pay_code or None))
                    rules.append(OvertimePolicy(master=key, mode=OT_LV3, hrs_from=t3_hrs_from, hrs_to=t3_hrs_to, pay_code_id=t3_pay_code or None))
                Holiday.objects.bulk_create(holidays)
            if depts:
                holidays = []
                for dept in depts:
                    key = uuid.uuid4().hex
                    _kwargs = copy.deepcopy(kwargs)
                    _kwargs.update({'department_id': dept, 'ot_rule': key})
                    holiday = Holiday(**_kwargs)
                    holidays.append(holiday)
                    rules.append(OvertimePolicy(master=key, mode=OT_LV1, hrs_from=t1_hrs_from, hrs_to=t1_hrs_to, pay_code_id=t1_pay_code or None))
                    rules.append(OvertimePolicy(master=key, mode=OT_LV2, hrs_from=t2_hrs_from, hrs_to=t2_hrs_to, pay_code_id=t2_pay_code or None))
                    rules.append(OvertimePolicy(master=key, mode=OT_LV3, hrs_from=t3_hrs_from, hrs_to=t3_hrs_to, pay_code_id=t3_pay_code or None))
                Holiday.objects.bulk_create(holidays)
            if not att_groups and (not depts):
                    Holiday(**kwargs).save(force_insert=True)
                    rules.append(OvertimePolicy(master=kwargs['ot_rule'], mode=OT_LV1, hrs_from=t1_hrs_from, hrs_to=t1_hrs_to, pay_code_id=t1_pay_code or None))
                    rules.append(OvertimePolicy(master=kwargs['ot_rule'], mode=OT_LV2, hrs_from=t2_hrs_from, hrs_to=t2_hrs_to, pay_code_id=t2_pay_code or None))
                    rules.append(OvertimePolicy(master=kwargs['ot_rule'], mode=OT_LV3, hrs_from=t3_hrs_from, hrs_to=t3_hrs_to, pay_code_id=t3_pay_code or None))
            from django.conf import settings
            if settings.DATABASE_ENGINE == 'oracle':
                for r in rules:
                    r.save()
                return None
            else:
                OvertimePolicy.objects.bulk_create(rules)
@admin.register(Holiday)
class HolidayAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'alias', 'start_date', 'duration_day', 'enable_ot_rule', 'department', 'att_group', 'color_setting')
    list_filter = ('alias', 'department__dept_code', 'department__dept_name')
    actions = (AddDepartmentHoliday,)
    form = DepartmentHolidayChangeForm
    formfield_overrides = {fields.DepartmentForeignKey: {'widget': widgets.DepartmentRadioSelect}}
    @staticmethod
    def initial_data():
        from django.db.models import F
        start_date = F('start_date')
        existed_holidays = Holiday.objects.filter(end_date__lt=start_date)
        for holiday in existed_holidays:
            holiday.end_date = holiday.start_date + datetime.timedelta(days=holiday.duration_day - 1)
            holiday.save()
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        query_set = super(HolidayAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_dept.exists():
                query_set = query_set.filter(Q(department__in=request.user.auth_dept.all()) | Q(department=None))
        return query_set