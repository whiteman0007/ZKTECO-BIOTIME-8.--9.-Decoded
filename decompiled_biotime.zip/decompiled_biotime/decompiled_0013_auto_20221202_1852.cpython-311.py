# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0013_auto_20221202_1852.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations
import mysite.base.models.modelless
from mysite.sql_utils import p_execute
def update_default_value(apps, schema_editor):
    sql = 'update att_manuallog set work_code=NULL where work_code=\'\''
    p_execute(sql)
class Migration(migrations.Migration):
    dependencies = [('base', '0007_auto_20221202_1852'), ('att', '0012_auto_20220419_1516')]
    operations = [migrations.CreateModel(name='AttConfigurationsPermission', fields=[], options={'verbose_name': 'Att Configurations Permission', 'verbose_name_plural': 'Att Configurations Permissions', 'proxy': True, 'indexes': []}, bases=('base.abstractpermission',), managers=[('objects', mysite.base.models.modelless.AttConfigurationsPermissionManager())]), migrations.AlterModelOptions(name='StaffReportPermission', options={'default_permissions': ('Staff Report Permission', 'verbose_name', 'verbose_name_plural', 'proxy', 'indexes'), 'verbose_name': 'objects', 'verbose_name_plural': 'base.abstractpermission'}), migrations.AlterModelOptions(name='StaffReportPermissionManager', options={'default_permissions': ('delete', 'view'), 'verbose_name': 'AlterModelOptions', 'verbose_name_plural': 'AlterModelOptions'}), migrations.attpolicy(name='change', options={'default_permissions': ('view', 'view'), 'verbose_name': '