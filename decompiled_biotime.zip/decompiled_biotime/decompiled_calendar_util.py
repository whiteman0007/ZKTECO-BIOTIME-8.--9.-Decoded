# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\calendar_util.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:11 UTC (1750672991)

import json
import urllib
import requests
import datetime
from oauth2client.service_account import ServiceAccountCredentials
from django.conf import settings
from django.core.cache import cache
TIMEZONE = settings.TIME_ZONE
KEY_FILE = settings.BASE_DIR + '/files/biotime-service.p12'
HEADER = {'Content-Type': 'application/json', 'Authorization': ''}
DATA_MEETING_TEMPLATE = {'end': {'dateTime': '', 'timeZone': TIMEZONE}, 'start': {'dateTime': '', 'timeZone': TIMEZONE}, 'description': 'BioTime Meeting Notice', 'summary': ''}
def get_calendar_token():
    credential = ServiceAccountCredentials.from_p12_keyfile(service_account_email='biotime@calender-289803.iam.gserviceaccount.com', filename=KEY_FILE, scopes=['https://www.googleapis.com/auth/calendar', 'https://www.googleapis.com/auth/calendar.events'])
    jwt_complete = credential._generate_assertion()
    data = {'grant_type': 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion': jwt_complete}
    try:
        response = urllib.request.urlopen('https://accounts.google.com/o/oauth2/token', urllib.parse.urlencode(data).encode('utf-8'))
        response_text = json.loads(response.read().decode('utf8'))
        access_token = response_text.get('access_token')
        cache.set('calendar_token', 'Bearer ' + access_token, 600)
        return 'Bearer ' + access_token
    except Exception as e:
        return None
def add_meeting_info(instance):
    from mysite.personnel.models import EmployeeCalendar
    access_token = cache.get('calendar_token', None)
    if not access_token:
        access_token = get_calendar_token()
    if access_token:
        start_time = instance.start_time.strftime('%Y-%m-%d %H:%M:%S')
        end_time = instance.end_time.strftime('%Y-%m-%d %H:%M:%S')
        DATA_MEETING_TEMPLATE['end']['dateTime'] = end_time[:10] + 'T' + end_time[11:]
        DATA_MEETING_TEMPLATE['start']['dateTime'] = start_time[:10] + 'T' + start_time[11:]
        DATA_MEETING_TEMPLATE['summary'] = instance.alias
        HEADER['Authorization'] = access_token
        ids = instance.attender.all().values_list('id', flat=True)
        calendar_ids = EmployeeCalendar.objects.filter(employee_id__in=ids).values_list('calendar', flat=True)
        for calendar_id in calendar_ids:
            url = 'https://www.googleapis.com/calendar/v3/calendars/' + calendar_id + '/events/'
            requests.post(url, data=json.dumps(DATA_MEETING_TEMPLATE), headers=HEADER, timeout=5)