# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\payroll\\migrations\\0005_auto_20221202_1852.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:06 UTC (1750702746)

from __future__ import unicode_literals
from django.db import migrations
import mysite.base.models.modelless
class Migration(migrations.Migration):
    dependencies = [('base', '0007_auto_20221202_1852'), ('payroll', '0004_auto_20210908_1006')]
    operations = [migrations.CreateModel(name='StaffPayrollReportPermission', fields=[], options={'verbose_name': 'Staff Payroll Report Permission', 'verbose_name_plural': 'Staff Payroll Report Permission', 'proxy': True, 'indexes': []}, bases=('base.abstractpermission',), managers=[('objects', mysite.base.models.modelless.StaffPayrollReportPermissionManager())]), migrations.AlterModelOptions(name='emppayrollprofile', options={'default_permissions': ('change', 'view'), 'verbose_name': 'payroll_model_empPayrollProfile', 'verbose_name_plural': 'payroll_model_empPayrollProfile'})]