# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\admin\\exceptions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:52 UTC (1750672972)

class AdminRuntimeWarning(RuntimeWarning):
    # return None
    pass