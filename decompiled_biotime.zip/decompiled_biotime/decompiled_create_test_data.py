# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\management\\commands\\create_test_data.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:23 UTC (1750673063)

import datetime
import random
from django.core.management.base import BaseCommand
from mysite.personnel.models.model_area import Area
from mysite.personnel.models.model_department import Department
from mysite.personnel.models.model_employee import Employee
from mysite.iclock.models.model_transaction import Transaction, Terminal
from mysite.att.models.model_breaktime import BreakTime
from mysite.att.models.model_timeinterval import TimeInterval
from mysite.att.models.model_attshift import AttShift
from mysite.att.models.model_shiftdetail import ShiftDetail
from mysite.att.models.model_attschedule import AttSchedule
from mysite.payroll.models import EmpPayrollProfile, OvertimeFormula, ExceptionFormula, LeaveFormula, IncreasementFormula, DeductionFormula, SalaryStructure
class Command(BaseCommand):
    help = 'insert test data to databases'
    def handle(self, *args, **options):
        create_test_data()
        print('OK')
def create_test_data():
    create_payroll_data()
def create_payroll_data():
    create_emp_payroll_profile()
    create_formula()
    create_salary_structure()
def create_department(count=5):
    depts = Department.objects.all().exclude(id=1)
    if depts:
        depts.delete()
    for i in range(1, 1 + count):
        try:
            dept = Department()
            dept.dept_code = 100000 + i
            dept.dept_name = 'dept_' + str(i)
            dept.save()
            print(('save dept:', dept))
        except Exception as e:
            print(('save error:', e))
def create_area(count=5):
    area_list = Area.objects.all().values_list('area_code', flat=True)
    for i in range(1, 1 + count):
        area_code = 100000 + i
        if area_code not in area_list:
            try:
                area = Area()
                area.area_code = area_code
                area.area_name = 'area_' + str(i)
                area.save()
                print(('save area:', area))
            except Exception as e:
                print(('save error:', e))
def create_employee(count=1000):
    dept_list = list(Department.objects.all())
    area_list = list(Area.objects.all())
    emp_code_set = {i[0] for i in Employee.objects.values_list('emp_code')}
    id_set = {i[0] for i in Employee.objects.values_list('id')}
    dt_now = datetime.datetime.now()
    hire_date = dt_now - datetime.timedelta(days=100)
    insert_list = []
    insert_list_area = []
    ThroughModel = Employee.area.through
    for i in range(1, 1 + count):
        if i in id_set:
            continue
        else:
            try:
                emp_code = str(100000 + i)
                if emp_code not in emp_code_set:
                    emp = Employee(id=i)
                    emp.emp_code = emp_code
                    emp.emp_name = 'emp_' + str(emp_code)
                    emp.hire_date = datetime.datetime(hire_date.year, hire_date.month, hire_date.day)
                    emp.department = random.choice(dept_list)
                    insert_list.append(emp)
                    t = ThroughModel(id=i, employee_id=i, area_id=random.choice(area_list).id)
                    insert_list_area.append(t)
                    print(('save emp:', emp))
                else:
                    print(('pass emp:', emp_code))
            except Exception as e:
                print(('save error:', e))
    Employee.objects.bulk_create(insert_list)
    ThroughModel.objects.bulk_create(insert_list_area)
def create_device(count=100):
    area_list = list(Area.objects.all())
    sn_set = {i[0] for i in Terminal.objects.values_list('sn')}
    insert_list = []
    for i in range(3, 1 + count):
        try:
            sn = str(100000000 + i)
            alias = str(100000000 + i)
            if sn not in sn_set:
                d = Terminal(id=i)
                d.sn = sn
                d.alias = alias
                d.emp_name = 'device_' + str(sn)
                d.ip_address = '127.0.0.1'
                d.area = random.choice(area_list)
                insert_list.append(d)
                print(('save device:', d))
            else:
                print(('pass device:', sn))
        except Exception as e:
            print(('save error:', e))
    Terminal.objects.bulk_create(insert_list)
def create_transactions(emp_count=100, day=10):
    dt_now = datetime.datetime.now()
    t1 = datetime.datetime(dt_now.year, dt_now.month, dt_now.day, 9, dt_now.minute)
    t2 = datetime.datetime(dt_now.year, dt_now.month, dt_now.day, 21, dt_now.minute)
    insert_list = []
    for i in range(1, 1 + emp_count):
        print(('save emp transaction:', 100000 + i))
        for j in range(day):
            tran = Transaction()
            tran.emp_code = 100000 + i
            tran.verify_type = 1
            t_time = t1 - datetime.timedelta(days=j)
            tran.punch_time = t_time
            tran.upload_time = t_time
            tran.sync_status = 1
            tran.punch_state = 0
            tran.emp_id = i
            insert_list.append(tran)
            tran = Transaction()
            tran.emp_code = 100000 + i
            tran.verify_type = 1
            t_time = t2 - datetime.timedelta(days=j, hours=4)
            tran.punch_time = t_time
            tran.upload_time = t_time
            tran.sync_status = 1
            tran.punch_state = 1
            tran.emp_id = i
            insert_list.append(tran)
            tran = Transaction()
            tran.emp_code = 100000 + i
            tran.verify_type = 1
            t_time = t2 - datetime.timedelta(days=j)
            tran.punch_time = t_time
            tran.upload_time = t_time
            tran.sync_status = 1
            tran.punch_state = 1
            tran.emp_id = i
            insert_list.append(tran)
    Transaction.objects.bulk_create(insert_list)
def create_break_time():
    try:
        bk = BreakTime()
        bk.alias = 'test_break_time'
        bk.period_start = datetime.time(hour=12)
        bk.period_end = datetime.time(hour=13, minute=30)
        bk.save()
        print(('save break_time:', bk))
    except Exception as e:
        print(('save break_time:', e))
def create_time_table():
    try:
        tt = TimeInterval()
        tt.alias = 'time_table_1'
        tt.in_time = datetime.time(hour=9, minute=0)
        tt.duration = 480
        tt.save()
        print(('save time_table:', tt))
    except Exception as e:
        print(('save time_table:', e))
    try:
        tt = TimeInterval()
        tt.alias = 'time_table_2'
        tt.in_time = datetime.time(hour=8, minute=0)
        tt.duration = 480
        tt.save()
        tt.save()
        print(('save time_table:', tt))
    except Exception as e:
        print(('save time_table:', e))
def create_shift():
    try:
        s = AttShift()
        s.alias = 'test_shift_0'
        s.auto_shift = True
        s.save()
        s = AttShift()
        s.alias = 'test_shift_1'
        s.auto_shift = False
        s.save()
        s = AttShift()
        s.alias = 'test_shift_2'
        s.auto_shift = False
        s.save()
        print('save test_shift success')
    except Exception as e:
        print(('save test_shift error:', e))
def create_shift_detail():
    shift = AttShift.objects.all()[0]
    time_interval = list(TimeInterval.objects.all())
    for day_index in range(1, 6):
        try:
            sd = ShiftDetail()
            sd.day_index = day_index
            sd.shift = shift
            sd.time_interval = time_interval[0]
            sd.in_time = sd.time_interval.in_time
            sd.out_time = sd.time_interval.in_time + sd.time_interval.duration
            sd.save()
            print('save shift_detail success')
        except Exception as e:
            print(('save shift_detail error:', e))
def create_attschedule(days=100):
    shift = AttShift.objects.all()[0]
    employees = Employee.objects.all()
    dt_now = datetime.datetime.now()
    dt_start = dt_now - datetime.timedelta(days=days)
    dt_end = dt_now + datetime.timedelta(days=days)
    AttSchedule.objects.filter(start_date__gte=dt_start, end_date__lte=dt_end).delete()
    for each_emp in employees:
        try:
            a_s = AttSchedule()
            a_s.employee = each_emp
            a_s.shift = shift
            a_s.start_date = datetime.date(year=dt_start.year, month=dt_start.month, day=dt_start.day)
            a_s.end_date = datetime.date(year=dt_end.year, month=dt_end.month, day=dt_end.day)
            a_s.save()
            print(('save emp attschedule success:', each_emp.emp_code))
        except Exception as e:
            print(('save attschedule error:', e))
def create_emp_payroll_profile():
    emp_payroll = EmpPayrollProfile.objects.all()
    employees = Employee.objects.all()
    print(emp_payroll.count())
    for emp in employees:
        print(('save emp payroll profile:', emp.emp_code))
        if not emp_payroll.filter(employee=emp).exists():
            e = EmpPayrollProfile()
            e.employee = emp
            e.ssn = 'test ssn'
            e.payment_mode = 1
            e.payment_type = 1
            e.bank_name = 'test bank name'
            e.bank_account = 'test bank account'
            e.agent_id = 'test agent id'
            e.agent_account = 'test agent account'
            e.save()
            print('ok')
def create_formula():
    from mysite.att.models.model_paycode import PayCode, LEAVE, OVERTIME, EXCEPTION
    exception_pay_codes = PayCode.objects.filter(code_type=EXCEPTION)
    leave_pay_codes = PayCode.objects.filter(code_type=LEAVE)
    overtime_pay_codes = PayCode.objects.filter(code_type=OVERTIME)
    for pay_code in overtime_pay_codes:
        if not OvertimeFormula.objects.filter(name=pay_code.name).exists():
            o = OvertimeFormula()
            o.name = pay_code.name
            o.formula = '{Basic Salary}/{Required Work}*{%s}' % pay_code.code
            o.pay_code = pay_code
            o.save()
    for pay_code in exception_pay_codes:
        if not OvertimeFormula.objects.filter(name=pay_code.name).exists():
            o = ExceptionFormula()
            o.name = pay_code.name
            o.formula = '{Basic Salary}/{Required Work}*{%s}' % pay_code.code
            o.pay_code = pay_code
            o.save()
    for pay_code in leave_pay_codes:
        if not OvertimeFormula.objects.filter(name=pay_code.name).exists():
            o = LeaveFormula()
            o.name = pay_code.name
            o.formula = '{Basic Salary}/{Required Work}*{%s}' % pay_code.code
            o.pay_code = pay_code
            o.save()
    if not IncreasementFormula.objects.all().exists():
        i = IncreasementFormula()
        i.name = 'Meal increase'
        i.formula = '{Schedule Days}*50'
        i.save()
    if not DeductionFormula.objects.all().exists():
        i = DeductionFormula()
        i.name = 'Social security deduction'
        i.formula = '500'
        i.save()
def create_salary_structure():
    salary_structur = SalaryStructure.objects.all()
    employees = Employee.objects.all()
    for emp in employees:
        print(('save emp salary_structure:', emp.emp_code))
        if not salary_structur.filter(employee=emp).exists():
            s = SalaryStructure()
            s.employee = emp
            s.salary_amount = 10000
            s.effective_date = datetime.datetime.now()
            s.save()
            s.overtimeformula = [i.id for i in OvertimeFormula.objects.all()]
            s.exceptionformula = [i.id for i in ExceptionFormula.objects.all()]
            s.leaveformula = [i.id for i in LeaveFormula.objects.all()]
            s.increasementformula = [i.id for i in IncreasementFormula.objects.all()]
            s.deductionformula = [i.id for i in DeductionFormula.objects.all()]
            s.save()