# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\emp_summary_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import EmployeeSummaryViewSet
from mysite.att.api.report_views.employee_summary import EmployeeSummarySerializer
@report_register()
class EmpSummaryAdmin(ReportAdminBase):
    model_name = 'empSummaryReport'
    view_name = 'emp_summary_report'
    template = 'att/report_new/employeesummaryreport.html'
    api_view = EmployeeSummaryViewSet
    serializer = EmployeeSummarySerializer
    data_source = '/att/api/empSummaryReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name')
    hidden_fields = ('last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = ('emp_code',)
    add_paycode_column = True