# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\dashboard_calc_late.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import datetime
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from rest_framework import mixins
from mysite._utils import getattr_ex
from mysite.att.api import fields
from mysite.att.api.serializers import NoneSerializer
from mysite.att.api.utils_class import SumPayCodeDuration
from mysite.base.api.utils_class import DashboardEmployeePayCodeRelatedModelSerializer, UserLayUIGenericViewSet
from mysite.base.api.filters import EmployeeRelatedFilter
from mysite.att.models import PayloadTimeCard
from mysite.att.models.model_paycode import PayCode, REGULAR, LATE_IN, EARLY_OUT, ABSENT
class DailyCalcLateSerializer(DashboardEmployeePayCodeRelatedModelSerializer):
    check_in = fields.TimeField(label=_('report.columns.checkIn'))
    check_out = fields.TimeField(label=_('report.columns.checkOut'))
    clock_in = fields.TimeField(label=_('report.columns.clockIn'))
    clock_out = fields.TimeField(label=_('report.columns.clockOut'))
    class Meta:
        model = PayloadTimeCard
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'nick_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'check_in', 'check_out', 'clock_in', 'clock_out')
class DailyCalcLateViewSet(mixins.ListModelMixin, UserLayUIGenericViewSet):
    model = PayloadTimeCard
    queryset = PayloadTimeCard.objects.get_queryset().order_by('emp', 'att_date', 'clock_in', 'check_in')
    filterset_class = EmployeeRelatedFilter
    serializer_dict = {'list': DailyCalcLateSerializer}
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.filter(fixed_code__in=(REGULAR, LATE_IN, EARLY_OUT)).order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def get_queryset(self):
        from django.db.models import Q
        from django.contrib.auth import get_user_model
        queryset = super(DailyCalcLateViewSet, self).get_queryset()
        now = datetime.datetime.now()
        filters = {'att_date': now.date()}
        distinct = False
        if isinstance(self.request.user, get_user_model()) and (not self.request.user.is_superuser):
                if self.request.user.auth_dept.exists():
                    filters['emp__department__in'] = self.request.user.auth_dept.all()
                if self.request.user.auth_area.exists():
                    distinct = True
                    filters['emp__area__in'] = self.request.user.auth_area.all()
                if self.request.user.assign_company:
                    filters['emp__company'] = self.request.user.assign_company
        queryset = queryset.filter(**filters)
        if distinct:
            queryset = queryset.distinct()
        return queryset
    def annotate_queryset(self, queryset):
        queryset = queryset.values('id', 'emp__emp_code', 'emp__first_name', 'emp__last_name', 'emp__nickname', 'emp__gender', 'emp__department__dept_code', 'emp__department__dept_name', 'emp__position__position_code', 'emp__position__position_name', 'check_in', 'check_out', 'clock_in', 'clock_out').order_by('emp__emp_code', 'clock_in', 'check_in')
        values = {}
        if self.pay_codes:
            for pay_code in self.pay_codes:
                values['paycode_{index}'.format(index=pay_code['id'])] = SumPayCodeDuration(pay_code, fk='payloadpaycode', distinct=True)
        if values:
            queryset = queryset.annotate(**values)
        if getattr_ex(settings, 'THAILAND', False):
            late = '{code}__gt'.format(code='paycode_{index}'.format(index=PayCode.late_in().id))
            queryset = queryset.filter(**{late: 0})
            return queryset
        else:
            late = '{code}__gt'.format(code='paycode_{index}'.format(index=PayCode.late_in().id))
            early = '{code}__exact'.format(code='paycode_{index}'.format(index=PayCode.early_out().id))
            queryset = queryset.filter(**{late: 0, early: 0})
            return queryset
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        queryset = self.annotate_queryset(queryset)
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        else:
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)