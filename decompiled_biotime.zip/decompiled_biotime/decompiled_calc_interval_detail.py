# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\calc_new\\calc_interval_detail.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import collections
import datetime
from mysite.att import const
from mysite.att.calc_new.punch_match import punch_time_for_break, filter_transaction_start, filter_transaction_end, filter_pairs_transaction
from mysite.att.calc_new.utils import cache_data
from mysite.att.models import BreakTime, OvertimePolicy, TimeInterval
from mysite.att.models.model_overtime_policy import OT_LV3, OT_LV2, OT_LV1, EARLY_IN, LATE_OUT
from mysite.att import models_choices as mc
from mysite.utils import get_dt4mssql
def calc_each_break(cur_date, transaction, break_obj, leaves):
    # irreducible cflow, using cdg fallback
    """Calc break and update leaves[i][\'break_overlap\']\n\n    Args:\n        cur_date: datetime.date\n        transaction: [dict, ...], calc date relevant transaction\n        break_obj: Break obj\n        leaves: list, calc date relevant leaves\n\n    Returns:\n        break_data: dict, calc break result\n    """
    break_data = {}
    start, end, trans_start, trans_end = punch_time_for_break(cur_date, transaction, break_obj)
    calc_start = trans_start['punch_time'] if trans_start else start
    calc_end = trans_end['punch_time'] if trans_end else end
    for i, leave in enumerate(leaves):
        if leave['end_time'] <= start:
            continue
        if leave['start_time'] <= start < leave['end_time'] <= end:
                start = leave['end_time']
                leaves[i]['break_overlap'] += int((leave['end_time'] - start).total_seconds()) // 60
                if leave['start_time'] <= start < end <= leave['end_time']:
                        leaves[i]['break_overlap'] += break_obj.duration
                        if start <= leave['start_time'] < leave['end_time'] <= end:
                                leaves[i]['break_overlap'] += int((leave['end_time'] - leave['start_time']).total_seconds()) // 60
                                if start <= leave['start_time'] < end <= leave['end_time']:
                                        end = leave['start_time']
                                        leaves[i]['break_overlap'] += int((end - leave['start_time']).total_seconds()) // 60
                                        if leave['start_time'] >= end:
                                            break
    break_data['break_out'] = calc_start
    break_data['break_in'] = calc_end
    break_data['early_in'] = 0
    break_data['late_in'] = 0
    break_data['early_in_pay_code'] = break_obj.profit_code_id
    break_data['late_in_pay_code'] = break_obj.loss_code_id
    break_data['duration'] = break_obj.duration
    break_data['trans_start'] = trans_start
    break_data['trans_end'] = trans_end
    break_data['break_duration'] = break_obj.duration
    if break_obj.calc_type == 0:
        break_data['break_time'] = break_obj.duration
    else:
        break_time = max(int((calc_end - calc_start).total_seconds()) // 60, break_obj.minimum_duration)
        break_data['break_time'] = break_time
        sub_time = break_time - break_obj.duration
        if break_obj.loss_rule and sub_time >= break_obj.min_late_in:
            break_data['late_in'] = sub_time
        else:
            if break_obj.profit_rule and -sub_time >= break_obj.min_early_in:
                    break_data['early_in'] = -sub_time
    return break_data
def calc_break(cur_date, transaction, interval, break_dict, leaves):
    """Calc breaks\n\n    Args:\n        cur_date: datetime.date\n        transaction: [dict, ...], calc date relevant transaction\n        interval: Interval obj\n        break_dict: cache dict\n        leaves: list, calc date relevant leaves\n    \n    Returns:\n        break_list: [dict, ...], calc breaks result\n    """
    break_list = []
    for break_id in interval.break_time_ids:
        break_obj = cache_data(break_dict, break_id, BreakTime)
        if break_obj:
            break_data = calc_each_break(cur_date, transaction, break_obj, leaves)
            if break_data:
                break_list.append(break_data)
    return break_list
def calc_overtime(overtimes, start_time, end_time):
    # irreducible cflow, using cdg fallback
    """Calc overtime\n\n    Args:\n        overtimes: [dict, ...]\n        start_time: datetime, valid start_time\n        end_time: datetime, valid end_time\n\n    Returns:\n        ot_data_list: [dict, ...]\n    """
    ot_data_list = []
    for overtime in overtimes:
        if start_time <= overtime['start_time'] <= end_time and start_time <= overtime['end_time'] <= end_time:
                        ot_time = int((overtime['end_time'] - overtime['start_time']).total_seconds()) // 60
                        ot_data = {'start_time': overtime['start_time'], 'end_time': overtime['end_time'], 'pay_code_time': ot_time, 'pay_code_id': overtime['pay_code_id']}
                        ot_data_list.append(ot_data)
    return ot_data_list
def calc_training(trainings, in_time, out_time):
    # irreducible cflow, using cdg fallback
    """Calc trainings\n\n    Args:\n        trainings: list, calc date relevant trainings\n        in_time: Interval.in_time\n        out_time: Interval.in_time\n\n    Returns:\n        data_list: calc training results\n\n    Example:\n        interval   |______________________________________|\n                in_time                                out_time\n        trainings |______________|                |________________________|\n           start_time      end_time         start_time               end_time\n    """
    data_list = []
    for training in trainings:
        if training['end_time'] <= in_time:
            continue
        if training['start_time'] <= in_time < training['end_time'] <= out_time:
                _traing = {'start_time': in_time, 'end_time': training['end_time'], 'pay_code_id': training['pay_code_id'], 'break_overlap': 0}
                data_list.append(_traing)
                if training['start_time'] <= in_time < out_time <= training['end_time']:
                        _traing = {'start_time': in_time, 'end_time': out_time, 'pay_code_id': training['pay_code_id'], 'break_overlap': 0}
                        data_list.append(_traing)
                        if in_time <= training['start_time'] < training['end_time'] <= out_time:
                                _leave = {'start_time': training['start_time'], 'end_time': training['end_time'], 'pay_code_id': training['pay_code_id'], 'break_overlap': 0}
                                data_list.append(_leave)
                                if in_time <= training['start_time'] < out_time <= training['end_time']:
                                        _leave = {'start_time': training['start_time'], 'end_time': out_time, 'pay_code_id': training['pay_code_id'], 'break_overlap': 0}
                                        data_list.append(_leave)
                                        if training['start_time'] >= out_time:
                                            break
    return data_list
def calc_leave(leaves, in_time, out_time):
    # irreducible cflow, using cdg fallback
    """Calc leaves\n\n    Args:\n        leaves: list, calc date relevant leaves\n        in_time: Interval.in_time\n        out_time: Interval.in_time\n\n    Returns:\n        data_list: calc leave results\n        cover_in_punch: start_time < in_time < end_time < out_time\n                        cover_in_punch = end_time\n        cover_out_punch: in_time < start_time < out_time < end_time\n                         cover_out_punch = start_time\n    Example:\n        interval   |______________________________________|\n                in_time                                out_time\n        leaves |______________|                |________________________|\n           start_time      end_time         start_time               end_time\n                        (cover_in_punch)   (cover_out_punch)\n    """
    data_list = []
    cover_in_punch, cover_out_punch = (None, None)
    for leave in leaves:
        if leave['end_time'] <= in_time:
            continue
        if leave['start_time'] <= in_time < leave['end_time'] <= out_time:
                cover_in_punch = in_time
                cover_out_punch = leave['end_time']
                _leave = {'start_time': in_time, 'end_time': leave['end_time'], 'pay_code_id': leave['pay_code_id'], 'break_overlap': 0}
                data_list.append(_leave)
                if leave['start_time'] <= in_time < out_time <= leave['end_time']:
                        _leave = {'start_time': in_time, 'end_time': out_time, 'pay_code_id': leave['pay_code_id'], 'break_overlap': 0}
                        cover_in_punch = in_time
                        cover_out_punch = out_time
                        data_list.append(_leave)
                        if in_time <= leave['start_time'] < leave['end_time'] <= out_time:
                                cover_out_punch = leave['end_time']
                                _leave = {'start_time': leave['start_time'], 'end_time': leave['end_time'], 'pay_code_id': leave['pay_code_id'], 'break_overlap': 0}
                                data_list.append(_leave)
                                if in_time <= leave['start_time'] < out_time <= leave['end_time']:
                                        cover_out_punch = out_time
                                        _leave = {'start_time': leave['start_time'], 'end_time': out_time, 'pay_code_id': leave['pay_code_id'], 'break_overlap': 0}
                                        data_list.append(_leave)
                                        if leave['start_time'] >= out_time:
                                            break
    return (data_list, cover_in_punch, cover_out_punch)
def calc_regular_ot(paycode, regular_id, ot_rule, otp_dict):
    """according to regular overtime rule clac update regular to paycode\n    """
    for ot_lv in [OT_LV3, OT_LV2, OT_LV1]:
        otp_key = '%s_%s' % (ot_rule, ot_lv)
        otp_obj = otp_dict.get(otp_key)
        if not otp_obj:
            otp_dict[otp_key] = OvertimePolicy.cache_data(ot_rule, ot_lv)
            otp_obj = otp_dict[otp_key]
        if not otp_obj:
            continue
        else:
            if otp_obj.hrs_from * 60 <= paycode[regular_id]:
                ot_time = min(paycode[regular_id], otp_obj.hrs_to * 60) - otp_obj.hrs_from * 60
                if otp_obj.pay_code_id and ot_time > 0:
                        paycode[regular_id] -= ot_time
                        paycode[otp_obj.pay_code_id] += ot_time
def calc_pay_code(ot_paycodes, leave_paycodes, break_list, training_list):
    """calc overtime, leave, break paycode\n\n    Returns:\n        paycode: defaultdict(int)\n            key: pay_code_id\n            value: pay_code_time\n    """
    paycode = collections.defaultdict(int)
    for i in [ot_paycodes, leave_paycodes, training_list]:
        for _data in i:
            paycode[_data['pay_code_id']] += _data['pay_code_time']
    for _data in break_list:
        if _data['early_in'] and _data['early_in_pay_code']:
                paycode[_data['early_in_pay_code']] += _data['early_in']
        if _data['late_in'] and _data['late_in_pay_code']:
                paycode[_data['late_in_pay_code']] += _data['late_in']
    return paycode
def calc_att_time(attcode, paycode, in_time, in_punch, out_time, out_punch, interval, policy, otp_dict, pc, need_calc_ot=False):
    """Calc Att Time\n\n    Args:\n        paycode: dict, will be update\n        in_time: datetime, should in_time\n        in_punch: datetime, real in_punch\n        out_time: datetime, should out_time\n        out_punch: datetime, real out_punch\n\n    Returns:\n        is_absent: bool\n    """
    is_absent = False
    is_incomplete = False
    if in_punch:
        in_ot = int((in_time - in_punch).total_seconds()) // 60
        if in_punch < in_time:
            attcode['unschedule'] += in_ot
        if in_punch > in_time:
            _late_in = int((in_punch - in_time).total_seconds()) // 60
            if _late_in <= interval.allow_late:
                _late_in = 0
            if _late_in > policy.late_in2absence:
                paycode[pc['absent']] += _late_in
            else:
                paycode[pc['late_in']] += _late_in
        else:
            if need_calc_ot and interval.enable_early_in and (in_ot >= interval.min_early_in):
                        otp_key = '%s_%s' % (interval.ot_rule, EARLY_IN)
                        otp_obj = otp_dict.get(otp_key)
                        if not otp_obj:
                            otp_dict[otp_key] = OvertimePolicy.cache_data(interval.ot_rule, EARLY_IN)
                            otp_obj = otp_dict[otp_key]
                        if otp_obj and otp_obj.pay_code_id:
                                if not interval.count_early_in_interval:
                                    in_ot -= interval.min_early_in
                                paycode[otp_obj.pay_code_id] += in_ot
    else:
        if not out_punch:
            is_absent = True
        else:
            if policy.miss_in == 1:
                paycode[pc['late_in']] += policy.late_in_hrs
            else:
                if policy.miss_in == 2:
                    is_absent = True
                else:
                    if policy.miss_in == 0:
                        is_incomplete = True
    if out_punch:
        out_ot = int((out_punch - out_time).total_seconds()) // 60
        if out_punch > out_time:
            attcode['unschedule'] += out_ot
        if out_punch < out_time:
            _early_out = int((out_time - out_punch).total_seconds()) // 60
            if _early_out <= interval.allow_leave_early:
                _early_out = 0
            if _early_out > policy.early_out2absence:
                paycode[pc['absent']] += _early_out
            else:
                paycode[pc['early_out']] += _early_out
        else:
            if need_calc_ot and interval.enable_late_out and (out_ot >= interval.min_late_out):
                        otp_key = '%s_%s' % (interval.ot_rule, LATE_OUT)
                        otp_obj = otp_dict.get(otp_key)
                        if not otp_obj:
                            otp_dict[otp_key] = OvertimePolicy.cache_data(interval.ot_rule, LATE_OUT)
                            otp_obj = otp_dict[otp_key]
                        if otp_obj and otp_obj.pay_code_id:
                                if not interval.count_late_out_interval:
                                    out_ot -= interval.min_late_out
                                paycode[otp_obj.pay_code_id] += out_ot
    else:
        if not in_punch:
            is_absent = True
        else:
            if policy.miss_out == 1:
                paycode[pc['early_out']] += policy.early_out_hrs
            else:
                if policy.miss_out == 2:
                    is_absent = True
                else:
                    if policy.miss_out == 0:
                        is_incomplete = True
    if out_punch and in_punch:
            attcode['total_hrs'] = int((out_punch - in_punch).total_seconds()) // 60
    return (is_absent, is_incomplete)
def calc_flex_att_time(attcode, paycode, check_punchs, interval, policy, otp_dict, pc, need_calc_ot=False, leave_list=None):
    if not check_punchs:
        return True
    else:
        total_leave_time = sum([i['pay_code_time'] for i in leave_list])
        regular_time = 0
        for _in, _out in check_punchs:
            if _in and _out:
                    regular_time += int((_out - _in).total_seconds()) // 60
        attcode['total_hrs'] = regular_time
        sub_time = regular_time - interval.work_time_duration
        if sub_time > 0:
            attcode['unschedule'] += sub_time
            if need_calc_ot and interval.enable_late_out and (sub_time >= interval.min_late_out):
                        otp_key = '%s_%s' % (interval.ot_rule, LATE_OUT)
                        otp_obj = otp_dict.get(otp_key)
                        if not otp_obj:
                            otp_dict[otp_key] = OvertimePolicy.cache_data(interval.ot_rule, LATE_OUT)
                            otp_obj = otp_dict[otp_key]
                        if otp_obj and otp_obj.pay_code_id:
                                if not interval.count_late_out_interval:
                                    sub_time -= interval.min_late_out
                                paycode[otp_obj.pay_code_id] = sub_time
        else:
            sub_time = sub_time + total_leave_time
            if sub_time < 0:
                _early_out = -sub_time
                if _early_out > policy.early_out2absence:
                    paycode[pc['absent']] += _early_out
                else:
                    paycode[pc['early_out']] += _early_out
        return False
def calc_full_attendance_present(paycode, in_punch, out_punch, pc_dict, pc):
    """\n    非满勤条件:\n        1.人员迟到早退 2.人员排班当天未打卡 3.人员请假的Pay Code是un-paid类型\n    出勤:\n        -1: 当天有缺勤（absent）或 paid_leave\n        0: 默认, 当天不用上班\n        1: 排班, 无缺勤\n        3: 节假日\n    """
    full_attendance = False
    present = 1
    has_paid_leave = False
    for pc_id in paycode:
        if not pc_dict[pc_id].is_paid and pc_dict[pc_id].code_type == const.LEAVE:
                has_paid_leave = True
                break
    if not has_paid_leave:
        if pc['absent'] in paycode and paycode[pc['absent']]:
                present = (-1)
        if in_punch and out_punch and (not paycode[pc['late_in']]) and (not paycode[pc['early_out']]):
                        full_attendance = True
    else:
        present = (-1)
    return (full_attendance, present)
def calc_auto_shift_interval_time(cur_date, transactions, interval_obj, leaves):
    """calc auto_shift interval_time, for get best interval for auto_shift\n    """
    in_time = datetime.datetime.combine(cur_date, get_dt4mssql(interval_obj.in_time, 2))
    out_time = in_time + datetime.timedelta(minutes=interval_obj.duration)
    in_punch = in_time
    out_punch = out_time
    if interval_obj.in_required:
        in_start = in_time - datetime.timedelta(minutes=interval_obj.in_ahead_margin)
        in_end = in_time + datetime.timedelta(minutes=interval_obj.in_above_margin)
        in_punch_state = 'check_in' if interval_obj.func_key else None
        in_trans = filter_transaction_start(transactions, in_start, in_end, in_punch_state)
        if in_trans:
            in_trans['used'] = True
        in_punch = in_trans['punch_time'] if in_trans else None
    if interval_obj.out_required:
        out_start = out_time - datetime.timedelta(minutes=interval_obj.out_ahead_margin)
        out_end = out_time + datetime.timedelta(minutes=interval_obj.out_above_margin)
        out_punch_state = 'check_out' if interval_obj.func_key else None
        out_trans = filter_transaction_end(transactions, out_start, out_end, out_punch_state)
        if out_trans:
            out_trans['used'] = True
        out_punch = out_trans['punch_time'] if out_trans else None
    _, leave_in_punch, leave_out_punch = calc_leave(leaves, in_time, out_time)
    if leave_in_punch:
        in_time, in_punch = (leave_in_punch, leave_in_punch)
    if leave_out_punch:
        out_time, out_punch = (leave_out_punch, leave_out_punch)
    return (in_time, in_punch, out_time, out_punch)
def calc_auto_shift_flex_interval_time(cur_date, transactions, interval_obj, leaves):
    """calc auto_shift flex interval_time, for get best interval for auto_shift\n    """
    max_work_time = 0
    in_time = datetime.datetime.combine(cur_date, get_dt4mssql(interval_obj.in_time, 2))
    out_time = in_time + datetime.timedelta(minutes=interval_obj.duration)
    _, leave_in_punch, leave_out_punch = calc_leave(leaves, in_time, out_time)
    if leave_in_punch:
        in_time = leave_in_punch
    if leave_out_punch:
        out_time = leave_out_punch
    if interval_obj.multiple_punch == 0:
        in_punch_state = 'check_in' if interval_obj.func_key else None
        first = filter_transaction_start(transactions, in_time, out_time, in_punch_state)
        if first:
            first['used'] = True
        out_punch_state = 'check_out' if interval_obj.func_key else None
        last = filter_transaction_end(transactions, in_time, out_time, out_punch_state)
        if last:
            last['used'] = True
        if first and last and (first['punch_time']!= last['punch_time']):
                    work_time = int((last['punch_time'] - first['punch_time']).total_seconds()) // 60
                    max_work_time = max(max_work_time, work_time)
    else:
        punch_state = 'check' if interval_obj.func_key else None
        punch_parings = filter_pairs_transaction(transactions, in_time, out_time, punch_state, True, False)
        work_time = 0
        for _in, _out in punch_parings:
            if _in and _out:
                    work_time += int((_out - _in).total_seconds()) // 60
        max_work_time = max(max_work_time, work_time)
    return max_work_time
def auto_shift_interval(cur_date, day_transaction, intervals, interval_objs, leaves):
    """for get best interval for auto_shift\n    """
    import copy
    two_punch, one_punch, zero_punch = ({}, {}, {})
    for _id in intervals:
        transactions = copy.deepcopy(day_transaction)
        interval = cache_data(interval_objs, _id, TimeInterval)
        if interval.use_mode == mc.NORMAL_TIME_INTERVAL:
            in_time, in_punch, out_time, out_punch = calc_auto_shift_interval_time(cur_date, transactions, interval, leaves)
            if in_punch and out_punch:
                two_punch[_id] = (out_punch - in_punch).total_seconds()
            else:
                if in_punch or out_punch:
                    one_punch[_id] = (out_time - in_time).total_seconds()
                else:
                    zero_punch[_id] = (out_time - in_time).total_seconds()
        else:
            work_time = calc_auto_shift_flex_interval_time(cur_date, transactions, interval, leaves)
            two_punch[_id] = work_time
    if two_punch:
        match_punch = two_punch
    else:
        if one_punch:
            match_punch = one_punch
        else:
            match_punch = zero_punch
    max_time = max(match_punch.values())
    for i in match_punch:
        if match_punch[i] == max_time:
            return [i]