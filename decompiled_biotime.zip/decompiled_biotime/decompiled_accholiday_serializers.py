# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\acc\\api\\serializers\\accholiday_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from rest_framework import serializers
from mysite.acc.models.model_acc_holiday import AccHoliday
from mysite.att.api.serializers import util_serializers
class AccHolidaySerializer(serializers.ModelSerializer):
    class Meta:
        model = AccHoliday
        fields = ['id', 'alias', 'start_date', 'duration_day', 'timezone']
class AccHolidayCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccHoliday
        fields = '__all__'
class AccHolidayEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccHoliday
        fields = '__all__'
class AccHolidayActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AccHoliday
        action_type_choices = (('delete', 'delete'),)