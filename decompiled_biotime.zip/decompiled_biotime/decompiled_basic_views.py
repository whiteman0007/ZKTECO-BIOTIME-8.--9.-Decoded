# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\asgi_views\\basic_views.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import asyncio
import json
import random
import nest_asyncio
from asgiref.sync import sync_to_async
from channels.generic.http import AsyncHttpConsumer
from django.conf import settings
from django.utils.translation import gettext_lazy as _, activate
from mysite.asgi_sse_redis import asgi_login_check, send_event
from mysite.tools.export_utils.export_interface import ExportInterface
class MessageSender(object):
    """for sending message via redis to client"""
    def __init__(self, *args, **kwargs):
        import queue
        self.channel = args[0]
        self.redis_channel = args[1]
        self.m_queue = queue.Queue()
    def __call__(self, event_name: str='message', data: str='', progress_total: int=100, progress_value: int=0, progress_message: str='', *args, **kwargs):
        """\n        send event data via redis\n        :param event_name: message-default normal event,progressMessage-event for progress,result-event for task result,close-event for close sse\n        :param data:define new event\n        :param progress_total:for progressMessage event\n        :param progress_value:for progressMessage event\n        :param progress_message:for progressMessage event\n        """
        channel, redis_channel = (self.channel, self.redis_channel)
        if not data:
            data = json.dumps({'channel': channel, 'progress': {'progress_total': progress_total, 'progress_value': progress_value, 'progress_message': str(progress_message or '')}})
        if hasattr(self, 'm_queue') and self.m_queue and (not settings.IMPORT_EXPORT_USE_REDIS):
            self.m_queue.put({'event_name': event_name, 'data': data, 'channel': redis_channel})
        else:
            send_event(event_name=event_name, data=data, channel=redis_channel)
    _canBeCancelled = False
    def set_cancel_enabled(self, enable: bool=True):
        self._canBeCancelled = enable
    _finished = False
    def set_finished(self, finish: bool=True):
        self._finished = finish
    _cancelled = False
    def cancel(self):
        """\n        :return : 1 cancelling ;0 to be finished ;-1 can not be cancelled\n        """
        if not self._canBeCancelled:
            return ((-1), _('CanNotBeCancelled'))
        else:
            if self._finished:
                return (0, _('FinishedNoNeedToCancel'))
            else:
                self._cancelled = True
                return (1, _('Cancelling'))
    def is_aborted(self):
        return self._cancelled
class BasicAsyncHttpConsumer(AsyncHttpConsumer):
    """handle basic http data"""
    query_string = {}
    user = None
    request = None
    async def http_request(self, message):
        from urllib import parse
        qs = self.scope.get('query_string', b'').decode()
        self.query_string = parse.parse_qs(qs)
        self.user = self.scope['user']
        await super().http_request(message)
    def create_request(self, scope, body_file=None, body=None):
        """\n        Create the Request object and returns either (request, None) or\n        (None, (status,message))) if there is an error response.\n        """
        if not body_file:
            import tempfile
            from django.conf import settings
            body_file = tempfile.SpooledTemporaryFile(max_size=settings.FILE_UPLOAD_MAX_MEMORY_SIZE, mode='w+b')
        try:
            if body:
                body_file.write(body)
        except Exception as e10:
            print(str(e10))
        body_file.seek(0)
        from django.core.exceptions import RequestDataTooBig
        try:
            from django.core.handlers.asgi import ASGIRequest
            return (ASGIRequest(scope, body_file), None)
        except UnicodeDecodeError:
            return (None, (400, '400 Bad Request (UnicodeDecodeError)'))
        except RequestDataTooBig:
            return (None, (413, '413 Payload too large'))
    @asgi_login_check
    async def init_request(self, body):
        # irreducible cflow, using cdg fallback
        """\n        basic check,like login check\n        :return:result of basic check\n        """
        body_file = None
        request, res = self.create_request(self.scope, body_file, body)
        if request is None:
            await self.send_response(res[0], res[1].encode(encoding='UTF8'))
                return False
            request.user = self.user
            lan = request.COOKIES.get('django_language', 'en')
            request.LANGUAGE_CODE = lan if lan else 'en'
            query_params = {}
            for k in self.query_string:
                v = self.query_string[k]
                if v and len(v) == 1:
                    query_params[k] = v[0]
                else:
                    query_params[k] = v
            request.query_params = query_params
            self.request = request
                return True
    async def handle(self, body):
        """\n        basic check,like login check\n        :return:result of basic check\n        """
        return await self.init_request(body)
    message_sender: MessageSender = None
    @property
    def send_event(self):
        return self.message_sender
class BasicExportConsumer(BasicAsyncHttpConsumer):
    """handle export request"""
    channel = ''
    redis_channel = ''
    params = {}
    model_admin = None
    model_viewSet = None
    model = str
    async def handle(self, body):
        # irreducible cflow, using cdg fallback
        """handle request"""
        _continue = await super().handle(body)
        if not _continue:
            return
        if not self.model_admin and (not self.model_viewSet):
            from django.urls import resolve
            from mysite.admin import ZKModelAdmin
            from mysite.api.utils_class import BaseExportModelMixin
            url = str(self.query_string.get('url', [''])[0])
            if url:
                if not url.startswith('/'):
                    url = '/' + url
                def get_view():
                    from django.urls import Resolver404
                    try:
                        return (resolve(url), None)
                    except Resolver404 as e0:
                        return (404, 'function not found')
                    except Exception as e1:
                        return (200, str(e1))
                view, msg = get_view()
                if isinstance(view, int):
                    await self.send_response(status=view, body=json.dumps({'code': (-1), 'payload': {}, 'message': msg}).encode(encoding='UTF8'))
                        return
                    if hasattr(view.func, 'model_admin') and isinstance(view.func.model_admin, ZKModelAdmin):
                        self.model_admin = view.func.model_admin
                        self.model = self.model_admin.model
                        self.allow_format = self.model_admin.allow_format
                        self.tool_map = self.model_admin.tool_map
                    else:
                        if hasattr(view.func, 'cls'):
                            from mysite.ep.api.utils_class import ReportUserGenericViewSet as epReportUtilGenericViewSet
                            from mysite.att.api.utils_class import ReportUserGenericViewSet as attReportUtilGenericViewSet
                            if issubclass(view.func.cls, (attReportUtilGenericViewSet, epReportUtilGenericViewSet, BaseExportModelMixin)):
                                self.model_viewSet = view.func.cls(**view.func.initkwargs)
                                self.model_viewSet.request = self.request
                                self.model_viewSet.action = 'export'
                                self.model_viewSet.initial(self.request)
                                self.model_viewSet.progress_recorder = self.send_event
                                self.model_viewSet.request_user = self.user
                                self.model = self.model_viewSet.model
                                self.allow_format = self.model_viewSet.allow_format
                        valid, msg = await self.check_params()
                        if not valid:
                            await self.send_response(status=200, body=json.dumps({'code': (-1), 'payload': {}, 'message': msg}).encode(encoding='UTF8'))
                            return
                        else:
                            channel, redis_channel = self.set_channel()
                            self.send_event.set_cancel_enabled(True)
                            nest_asyncio.apply()
                            loop = asyncio.get_event_loop()
                except Exception as e:
                        await self.send_response(status=200, body=json.dumps({'code': (-1), 'payload': {}, 'message': str(e)}).encode(encoding='UTF8'))
                            return None
                task = loop.create_task(coro=self.export_executor(), name=redis_channel, context=None)
                    except Exception as e1:
                            await self.send_response(status=200, body=json.dumps({'code': (-1), 'payload': {}, 'message': str(e1)}).encode(encoding='UTF8'))
                                return
                        pass
                        await self.send_response(status=200, body=json.dumps({'code': 0, 'use_asgi': True, 'payload': {'task_id': channel}}).encode(encoding='UTF8'))
    async def check_params(self) -> tuple:
        """\n        :return:  (bool,str) valid and not valid reason\n        """
        return (True, '')
    def set_channel(self):
        self.channel = 'export_{0}_{1}'.format(self.model.__name__, random.randint(a=100000, b=999999))
        if hasattr(self.user, 'is_employee') and self.user.is_employee:
            self.redis_channel = 'sse_%s_%s' % (self.user.emp_code, self.channel)
        else:
            self.redis_channel = 'sse_%s_%s' % (self.scope['user'].username, self.channel)
        self.message_sender = MessageSender(*(self.channel, self.redis_channel))
        return (self.channel, self.redis_channel)
    def get_channel(self):
        return (self.channel, self.redis_channel)
    async def get_export_data(self, *args, **kwargs):
        """\n        :return: (list,int)  data and data length\n        """
        return ([], 0)
    async def export2file(self, *args, **kwargs):
        """\n        :return: str  file path\n        """
        return ''
    async def export_executor(self, *args, **kwargs):
        channel, redis_channel = self.get_channel()
        await asyncio.sleep(1)
        self.send_event(event_name='progressMessage', progress_total=0, progress_value=0, progress_message=_('exportProgress.status.preparingData'))
        try:
            datas, data_len = await self.get_export_data(**{'request': self.request})
        except Exception as e3:
            pass
        self.send_event(event_name='progressMessage', progress_total=0, progress_value=0, progress_message=_('exportProgress.status.generateDoc'))
        try:
            file_path = await self.export2file(**self.params)
            if file_path:
                file_url = '/files{path}'.format(path=file_path.split('files')[1])
                self.send_event(event_name='result', data=json.dumps({'code': 0, 'file': file_path.split('\\')[(-1)], 'url': file_url, 'channel': channel}), channel=redis_channel)
        except Exception as e3:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(e3), 'channel': channel}), channel=redis_channel)
        self.send_event(event_name='close', data=json.dumps({'channel': channel}), channel=redis_channel)
class BasicExportActionConsumer(BasicExportConsumer):
    """handle model action"""
    action_class = None
    action = None
    form_class = None
    form = None
    async def check_params(self) -> tuple:
        request = self.request
        if request.method!= 'POST':
            return (False, 'invalid request 404')
        else:
            action_name = request.POST.get('action_name', request.GET.get('action_name', None))
            if not action_name:
                return (False, 'invalid request 404')
            else:
                actions = self.get_actions(self.request)
                if not actions:
                    return (False, 'invalid request 404')
                else:
                    from mysite.admin.mixins import ENCRYPT_ACTION_NAME
                    if ENCRYPT_ACTION_NAME:
                        try:
                            action_name = bytes.fromhex(action_name).decode()
                        except TypeError:
                            return (False, 'invalid request 404')
                    if action_name not in actions:
                        return (False, 'invalid request 404')
                    else:
                        from mysite.admin.utils import hungary_notation
                        from mysite.admin.utils import BUILD_IN_PERMISSION
                        if not request.user.has_perm('{app}.{action}_{model}'.format(app=self.model._meta.app_label, action=hungary_notation(BUILD_IN_PERMISSION.get(action_name, action_name)), model=self.model._meta.model_name)):
                            return (False, 'invalid request 401')
                        else:
                            self.action_class = actions[action_name]
                            cls, name, desc = self.action_class
                            self.action = self.action_class.klass(request, self, [])
                            self.form_class = self.get_action_form(request, cls)
                            if self.form_class:
                                from mysite.admin.forms import ZKActionForm
                                if issubclass(self.form_class, ZKActionForm):
                                    self.form = await sync_to_async(self.form_class, thread_sensitive=False)(request=request, objects=self.action.objects, data=request.POST, files=request.FILES)
                                else:
                                    self.form = self.form_class(request.POST, request.FILES)
                                form_valid = await sync_to_async(self.form.is_valid, thread_sensitive=False)()
                                if not form_valid:
                                    from mysite.admin.utils import export_error_dict
                                    return (False, export_error_dict(self.form.errors))
                                else:
                                    from mysite.admin.exceptions import AdminRuntimeWarning
                                    try:
                                        self.check_xss_risk_action(self.form)
                                    except AdminRuntimeWarning as e:
                                        return (False, str(e))
                                    return (True, '')
                            else:
                                return (False, 'invalid request 404')
    async def export2file(self, *args, **kwargs):
        from mysite.admin.utils import log_operation
        channel, redis_channel = self.get_channel()
        items = list(self.form.cleaned_data.items())
        cls, name, desc = self.action_class
        try:
            params = self.form.cleaned_data
            params['progress_recorder'] = self.send_event
            process = await self.save_data(**params)
            self.send_event(event_name='close', data=json.dumps({'channel': channel}))
        except Exception as e:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(e), 'channel': channel}))
            self.send_event(event_name='close', data=json.dumps({'channel': channel}))
            if settings.DEBUG:
                import logging
                logging.exception('response_action_post error')
            from mysite.admin.utils import log_operation
            action_verbose_name = '%s' % getattr(self.action, 'verbose_name', name)
            await sync_to_async(log_operation, thread_sensitive=False)(self.request, self.action.obj_ids, action_verbose_name, str(e), status=(-1), model=self.model)
        else:
            action_verbose_name = '%s' % getattr(self.action, 'verbose_name', name)
            messages = ''
            for k, v in items:
                pass
            if v == [] and k == 'emp':
                    v = self.form.data.getlist('employee', None)
            if self.form.fields.get(k):
                messages += ','.join(['{key}={val}'.format(key=self.form.fields.get(k).label, val=v)])
        await sync_to_async(log_operation, thread_sensitive=False)(self.request, self.action.obj_ids, action_verbose_name, messages, model=self.model)
    async def save_data(self, *args, **kwargs):
        return
class BasicExportModelMixinConsumer(BasicExportConsumer):
    """"""
    file_format = ''
    export_headers = ''
    async def check_params(self) -> tuple:
        self.file_format = self.query_string.get('export_type', [''])[0]
        self.export_headers = self.query_string.get('export_headers', [''])[0].strip()
        if self.file_format not in self.allow_format:
            return (False, 'export_type required and must in csv txt xls pdf')
        else:
            if not self.export_headers:
                return (False, 'Parameter Error: fields nod found.')
            else:
                self.params['file_format'] = self.file_format
                self.params['export_headers'] = self.export_headers
                if self.request.LANGUAGE_CODE:
                    activate(self.request.LANGUAGE_CODE)
                fields = list(filter(None, self.export_headers.split(',')))
                headers = []
                from django.contrib.admin.utils import label_for_field
                for index, field in enumerate(fields):
                    try:
                        headers.append(str(label_for_field(field, self.model, self)))
                    except Exception as e0:
                        headers.append(field)
                    fields[index] = field
                self.params['fields'] = fields
                self.params['headers'] = headers
                if self.model_viewSet:
                    self.model_viewSet.group_by = self.request.query_params.get('export_style', None)
                    self.model_viewSet.page_wise = self.request.query_params.get('page_wise', False)
                    self.model_viewSet.start_date = self.request.query_params.get('start_date', False)
                    self.model_viewSet.end_date = self.request.query_params.get('end_date', False)
                    self.model_viewSet.pdf_page_size = self.request.query_params.get('pdf-page-size', '')
                    self.model_viewSet.orientation = self.request.query_params.get('orientation', '')
                    self.model_viewSet.page = self.request.query_params.get('page', None)
                return (True, '')
    def yield_export_results(self, cl):
        counter = 0
        total = cl.result_list.count()
        interval = total // 30
        try:
            min_interval = settings.PROGRESS_INTERVAL_MIN
        except:
            min_interval = 10
        interval = interval if interval > min_interval else min_interval
        for res in cl.result_list:
            if hasattr(cl.model_admin, 'update_result'):
                res = cl.model_admin.update_result(res)
            counter += 1
            if counter < total and counter % interval == 0 or counter == total:
                self.send_event(event_name='progressMessage', progress_total=total, progress_value=counter, progress_message=_('exportProgress.status.preparingData'))
            from mysite.admin.admin_list import items_for_result
            yield items_for_result(cl, res, None, True)
    async def get_export_data(self, *args, **kwargs):
        request = kwargs.get('request', self.request)
        from channels.db import database_sync_to_async
        if self.model_admin:
            cl = await database_sync_to_async(self.model_admin._setup_changelist, thread_sensitive=False)(request)
            data_len = await database_sync_to_async(cl.result_list.count, thread_sensitive=False)()
            self.send_event(event_name='progressMessage', progress_total=data_len, progress_value=0, progress_message=_('exportProgress.status.preparingData'))
            if data_len:
                self.empty_value_display = ''
                result_list = self.yield_export_results(cl)
                self.params['data'] = result_list
                self.params['data_len'] = data_len
                return (result_list, data_len)
            else:
                self.params['data'] = []
                self.params['data_len'] = data_len
        else:
            if self.model_viewSet:
                if self.model_viewSet.page is not None:
                    queryset = await database_sync_to_async(self.model_viewSet.get_export_queryset, thread_sensitive=False)()
                    queryset = await database_sync_to_async(self.model_viewSet.paginate_queryset, thread_sensitive=False)(queryset)
                    self.params['data_len'] = len(queryset)
                    if getattr(self.model_viewSet, 'serializer_dict'):
                        serializer = self.model_viewSet.serializer_dict.get('export', None)
                        if serializer:
                            wrap_serializer = self.model_viewSet.serializer_class_wrapper(serializer, self.params['data_len'])
                            self.model_viewSet.serializer_dict['export'] = wrap_serializer
                    def get_data():
                        ser = self.model_viewSet.get_serializer(queryset, many=True)
                        return ser.data
                    self.params['data'] = await database_sync_to_async(get_data, thread_sensitive=False)()
                    return (self.params['data'], self.params['data_len'])
                else:
                    queryset = await database_sync_to_async(self.model_viewSet.get_export_data, thread_sensitive=False)(request)
                    try:
                        self.params['data_len'] = queryset.count()
                    except:
                        self.params['data_len'] = len(queryset)
                    self.params['data'] = queryset
                    return (queryset, self.params['data_len'])
        return ([], 0)
    async def export2file(self, *args, **kwargs):
        file_format = kwargs.get('file_format', self.file_format)
        _kwargs = {'request_user': self.user or '', 'progress_recorder': self.send_event, 'pdf_config': {'pdf-page-size': self.query_string.get('pdf-page-size', [''])[0], 'orientation': self.query_string.get('orientation', [''][0])}, 'datas': kwargs.get('data', []), 'total': kwargs.get('data_len', 0), 'filename': self.get_filename(None, file_format)}
        cls = self.tool_map[file_format]
        if file_format in self.allow_format:
            encryption_type = int(self.query_string.get('export_encryption_type', ['0'])[0])
            _kwargs['password'] = None
            from mysite.base import const
            if encryption_type == const.ENCRYPTION_SYS_PASSWORD:
                from mysite.base.models import SecurityPolicy
                security_policy = SecurityPolicy.default()
                if security_policy.export_encryption:
                    _kwargs['password'] = security_policy.get_export_encryption_password()
            else:
                if encryption_type == const.ENCRYPTION_SELF_PASSWORD:
                    _kwargs['password'] = self.query_string.get('export_encryption_password', [''])[0]
        if self.model_admin:
            fields = kwargs.get('fields', [])
            headers = kwargs.get('headers', [])
            _kwargs['title'] = self.get_file_title()
            _kwargs['fields'] = fields
            _kwargs['headers'] = headers
            _kwargs['filename_model'] = self.get_filename_model(file_format)
        else:
            if self.model_viewSet:
                export_data = self.params['data']
                data_len = self.params['data_len']
                _fields = kwargs.get('fields', [])
                data_fields = list(export_data[0].keys()) if len(export_data) else []
                headers_list = []
                for header in _fields:
                    if header in data_fields:
                        headers_list.append(header)
                self.export_headers = headers_list
                from django.utils import translation
                if translation.get_language_bidi():
                    self.export_headers = list(reversed(self.export_headers))
                from mysite.att.api.report_views import LeaveBalanceSummaryViewSet
                if isinstance(self.model_viewSet, LeaveBalanceSummaryViewSet):
                    from mysite.att.report.admin import LeaveBalanceSummaryAdmin
                    self.model_viewSet.rowspan = 2
                    leavebalancesummary = LeaveBalanceSummaryAdmin()
                    self.model_viewSet.headers_translation = leavebalancesummary.get_layui_cols(self.export_headers)
                    if self.file_format == 'xls':
                        self.model_viewSet.rowspan_headers = leavebalancesummary.get_layui_cols_for_export_xls(self.export_headers)
                show_header = True
                if hasattr(self.model_viewSet, 'show_header'):
                    show_header = self.model_viewSet.show_header
                if self.request.LANGUAGE_CODE:
                    activate(self.request.LANGUAGE_CODE)
                translated_headers = await sync_to_async(self.model_viewSet.get_headers_translation, thread_sensitive=False)(self.export_headers) if show_header else []
                _kwargs['fields'] = self.export_headers
                _kwargs['headers'] = translated_headers
                _kwargs['group_by_field'] = self.model_viewSet.get_group_by_field()
                _kwargs['statistics_fields'] = self.model_viewSet.summary_fields
                _kwargs['page_wise'] = self.model_viewSet.page_wise
                _kwargs['group_info_tpl'] = self.model_viewSet.group_title
                _kwargs['rowspan_headers'] = self.model_viewSet.rowspan_headers if hasattr(self.model_viewSet, 'rowspan_headers') else ''
                _kwargs['show_header'] = show_header
                _kwargs['export_format'] = self.query_string.get('export_format', ['default'])[0]
                _kwargs['rowspan'] = self.model_viewSet.rowspan if hasattr(self.model_viewSet, 'rowspan') else 1
                _kwargs['pdf_config'] = {'start_date': self.model_viewSet.start_date, 'end_date': self.model_viewSet.end_date, 'pdf-page-size': self.model_viewSet.pdf_page_size, 'orientation': self.model_viewSet.orientation, 'is_report': True}
        handler = await sync_to_async(cls, thread_sensitive=False)(**_kwargs)
        result = await sync_to_async(handler.save_file, thread_sensitive=False)()
        return result
class BasicExportEssentialConsumer(BasicExportModelMixinConsumer):
    """use old codes directly [get data|write to file]"""
    async def export_executor(self, *args, **kwargs):
        channel, redis_channel = self.get_channel()
        await asyncio.sleep(1)
        try:
            if self.request.LANGUAGE_CODE:
                activate(self.request.LANGUAGE_CODE)
            from channels.db import database_sync_to_async
            file_path = ''
            if self.model_viewSet:
                file_path = await database_sync_to_async(self.model_viewSet.export_executor, thread_sensitive=False)(self.request, self.send_event)
            else:
                if self.model_admin:
                    file_path = await database_sync_to_async(self.model_admin.export_executor, thread_sensitive=False)(self.request, self.send_event)
            if file_path:
                file_url = '/files{path}'.format(path=file_path.split('files')[1])
                self.send_event(event_name='result', data=json.dumps({'code': 0, 'file': file_path.split('\\')[(-1)], 'url': file_url, 'channel': channel}), channel=redis_channel)
        except Exception as e3:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(e3), 'channel': channel}), channel=redis_channel)
        finally:
            import gc
            gc.collect()
        self.send_event(event_name='close', data=json.dumps({'channel': channel}), channel=redis_channel)
class BasicImportConsumer(BasicAsyncHttpConsumer):
    """handle import request"""
    channel = ''
    redis_channel = ''
    params = {}
    model = str
    async def handle(self, body):
        # irreducible cflow, using cdg fallback
        """handle request"""
        _continue = await super().handle(body)
        if not _continue:
            return
        else:
            try:
                valid, msg = await self.check_params()
            except Exception as e20230927:
                valid, msg = (False, str(e20230927))
            if not valid:
                await self.send_response(status=200, body=json.dumps({'code': (-1), 'payload': {}, 'message': msg}).encode(encoding='UTF8'))
                return
            else:
                channel, redis_channel = self.set_channel()
                self.send_event.set_cancel_enabled(True)
                nest_asyncio.apply()
                loop = asyncio.get_event_loop()
        task = loop.create_task(coro=self.import_executor(), name=redis_channel, context=None)
            except Exception as e1:
                    await self.send_response(status=200, body=json.dumps({'code': (-1), 'payload': {}, 'message': str(e1)}).encode(encoding='UTF8'))
                        return
                await self.send_response(status=200, body=json.dumps({'code': 0, 'use_asgi': True, 'payload': {'task_id': channel}}).encode(encoding='UTF8'))
    async def check_params(self) -> tuple:
        """\n        :return:  (bool,str) valid and not valid reason\n        """
        return (True, '')
    def set_channel(self):
        self.channel = 'import_{0}_{1}'.format(self.model.__name__, random.randint(a=100000, b=999999))
        if hasattr(self.user, 'is_employee') and self.user.is_employee:
            self.redis_channel = 'sse_%s_%s' % (self.user.emp_code, self.channel)
        else:
            self.redis_channel = 'sse_%s_%s' % (self.scope['user'].username, self.channel)
        self.message_sender = MessageSender(*(self.channel, self.redis_channel))
        return (self.channel, self.redis_channel)
    def get_channel(self):
        return (self.channel, self.redis_channel)
    async def import_data(self, *args, **kwargs):
        return ''
    async def import_executor(self, *args, **kwargs):
        channel, redis_channel = self.get_channel()
        await asyncio.sleep(1)
        await self.import_data()
        self.send_event(event_name='close', data=json.dumps({'channel': channel}), channel=redis_channel)
class BasicImportActionConsumer(BasicImportConsumer):
    """handle model action"""
    action_class = None
    action = None
    form_class = None
    form = None
    async def check_params(self) -> tuple:
        from mysite.admin.mixins import ENCRYPT_ACTION_NAME
        from mysite.admin.utils import hungary_notation
        from mysite.admin.utils import BUILD_IN_PERMISSION
        request = self.request
        if request.method!= 'POST':
            return (False, 'invalid request 404')
        else:
            action_name = request.POST.get('action_name', request.GET.get('action_name', None))
            if not action_name:
                return (False, 'invalid request 404')
            else:
                actions = self.get_actions(self.request)
                if not actions:
                    return (False, 'invalid request 404')
                else:
                    if ENCRYPT_ACTION_NAME:
                        try:
                            action_name = bytes.fromhex(action_name).decode()
                        except TypeError:
                            return (False, 'invalid request 404')
                    if action_name not in actions:
                        return (False, 'invalid request 404')
                    else:
                        if not await sync_to_async(request.user.has_perm, thread_sensitive=False)('{app}.{action}_{model}'.format(app=self.model._meta.app_label, action=hungary_notation(BUILD_IN_PERMISSION.get(action_name, action_name)), model=self.model._meta.model_name)):
                            return (False, 'invalid request 401')
                        else:
                            self.action_class = actions[action_name]
                            cls, name, desc = self.action_class
                            self.action = self.action_class.klass(request, self, [])
                            self.form_class = self.get_action_form(request, cls)
                            if self.form_class:
                                from mysite.admin.forms import ZKActionForm
                                if issubclass(self.form_class, ZKActionForm):
                                    self.form = await sync_to_async(self.form_class, thread_sensitive=False)(request=request, objects=self.action.objects, data=request.POST, files=request.FILES)
                                else:
                                    self.form = self.form_class(request.POST, request.FILES)
                                form_valid = await sync_to_async(self.form.is_valid, thread_sensitive=False)()
                                if not form_valid:
                                    from mysite.admin.utils import export_error_dict
                                    return (False, export_error_dict(self.form.errors))
                                else:
                                    from mysite.admin.exceptions import AdminRuntimeWarning
                                    try:
                                        self.check_xss_risk_action(self.form)
                                    except AdminRuntimeWarning as e:
                                        return (False, str(e))
                                    return (True, '')
                            else:
                                return (False, 'invalid request 404')
    async def save_data(self, *args, **kwargs):
        return
    async def import_data(self, *args, **kwargs):
        from mysite.admin.utils import log_operation
        channel, redis_channel = self.get_channel()
        items = list(self.form.cleaned_data.items())
        cls, name, desc = self.action_class
        try:
            params = self.form.cleaned_data
            params['progress_recorder'] = self.send_event
            self.send_event(event_name='progressMessage', progress_total=0, progress_value=0, progress_message=_('importProgress.status.dataVerification'))
            process = await self.save_data(**params)
            self.send_event(event_name='close', data=json.dumps({'channel': channel}))
        except Exception as e:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(e), 'channel': channel}))
            self.send_event(event_name='close', data=json.dumps({'channel': channel}))
            if settings.DEBUG:
                import logging
                logging.exception('response_action_post error')
            action_verbose_name = '%s' % getattr(self.action, 'verbose_name', name)
            await sync_to_async(log_operation, thread_sensitive=False)(self.request, self.action.obj_ids, action_verbose_name, str(e), status=(-1), model=self.model)
        else:
            action_verbose_name = '%s' % getattr(self.action, 'verbose_name', name)
            messages = ''
            for k, v in items:
                pass
            if v == [] and k == 'emp':
                    v = self.form.data.getlist('employee', None)
            if self.form.fields.get(k):
                messages += ','.join(['{key}={val}'.format(key=self.form.fields.get(k).label, val=v)])
        await sync_to_async(log_operation, thread_sensitive=False)(self.request, self.action.obj_ids, action_verbose_name, messages, model=self.model)
class CancelCoroutineTask(BasicAsyncHttpConsumer):
    """"""
    async def handle(self, body):
        _continue = await super().handle(body)
        if not _continue:
            return
        else:
            if self.request.LANGUAGE_CODE:
                activate(self.request.LANGUAGE_CODE)
            redis_channel = self.get_redis_channel()
            loop = asyncio.get_event_loop()
            tasks = asyncio.all_tasks(loop)
            from asyncio import Task
            task = None
            consumer = None
            try:
                for t in tasks:
                    if t.get_name() == redis_channel:
                        task = t
                        consumer = t.get_coro().cr_frame.f_locals['self']
            except Exception as e1:
                pass
            if not consumer:
                await self.send_response(status=200, body=json.dumps({'code': 0, 'payload': {}, 'message': str(_('TaskCannotBeFound'))}).encode(encoding='UTF8'))
                return
            else:
                result, msg = consumer.send_event.cancel()
                message = str(msg) if isinstance(consumer, BasicExportConsumer) or result!= (-1) else '{0}  {1}'.format(msg, _('WillRunningBackground'))
                await self.send_response(status=200, body=json.dumps({'code': result, 'payload': {}, 'message': message}).encode(encoding='UTF8'))
    def get_redis_channel(self):
        user = self.scope['user']
        channel = self.scope['url_route']['kwargs'].get('channel', '')
        if hasattr(user, 'is_employee') and user.is_employee:
            return 'sse_%s_%s' % (user.emp_code, channel)
        else:
            return 'sse_%s_%s' % (user.username, channel)