# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\staff_meeting\\api\\serializers\\meetingEntity_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:34 UTC (1750673074)

import json
from rest_framework import serializers
from mysite.staff.api.serializers import util_serializers
from mysite.meeting.models import MeetingEntity
from mysite.meeting import const, choices
from mysite.workflow.models_choices import PENDING
from django.utils.translation import gettext_lazy as _
from mysite.personnel.models import Employee
class MeetingEntitySerializer(serializers.ModelSerializer):
    class Meta:
        model = MeetingEntity
        fields = '__all__'
class MeetingEntityRequestSerializer(serializers.ModelSerializer):
    meeting_period = serializers.SerializerMethodField()
    start_host_link = serializers.SerializerMethodField()
    invitation_link = serializers.SerializerMethodField()
    attender_quantity = serializers.SerializerMethodField()
    applier = serializers.SerializerMethodField()
    applier_photo = serializers.SerializerMethodField()
    approval_status_display = serializers.CharField(source='get_approval_status_display', allow_null=True)
    room_alias = serializers.CharField(source='room.alias', allow_null=True)
    edit_permission = serializers.SerializerMethodField()
    def get_meeting_period(self, obj):
        return '{start}~{end}'.format(start=obj.start_time, end=obj.end_time)
    def get_start_host_link(self, obj):
        if obj.link_data:
            link_data = json.loads(obj.link_data)
            return link_data.get('start_url', '')
        else:
            return ''
    def get_invitation_link(self, obj):
        return obj.get_invitation_link()
    def get_attender_quantity(self, obj):
        return obj.attender.count()
    def get_applier(self, obj):
        if not obj.employee:
            return ''
        else:
            return obj.employee.first_name or obj.employee.emp_code
    def get_applier_photo(self, obj):
        return obj.emp_photo
    def get_edit_permission(self, obj):
        if obj.approval_status!= PENDING:
            return False
        else:
            not_pendding = obj.nodeinstance_set.exclude(approval_status=PENDING).exists()
            return False if not_pendding else True
    class Meta:
        model = MeetingEntity
        fields = '__all__'
class MeetingEntityCreateSerializer(serializers.ModelSerializer):
    host_video = serializers.BooleanField(default=False)
    participant_video = serializers.BooleanField(default=False)
    enable_waiting_room = serializers.BooleanField(default=False)
    jbh_anytime = serializers.BooleanField(default=False)
    mute_upon_entry = serializers.BooleanField(default=False)
    auto_recording = serializers.ChoiceField(choices=choices.ZOOM_AUTORECORDING_CHOICES)
    def validate(self, attrs):
        user = self.context['request'].user
        if not isinstance(user, Employee):
            raise serializers.ValidationError({'detail': 'User not a Employee'})
        else:
            attrs['employee'] = user
            if not attrs['attender']:
                raise serializers.ValidationError(_('meetingEntity.save.error.missAttender'))
            else:
                if attrs['room'] and attrs['room'].capacity < len(attrs['attender']):
                    raise serializers.ValidationError(_('meetingEntity.save.error.roomCapacity'))
                else:
                    if not attrs['enable_virtual'] and (not attrs['room']):
                        raise serializers.ValidationError(_('meetingEntity.save.error.missRoom'))
                    else:
                        preferences = {key: attrs.get(key, '') for key in attrs.keys() if key in const.ZOOM_PREFERENCES}
                        attrs['preferences'] = json.dumps(preferences)
                        return attrs
    class Meta:
        model = MeetingEntity
        fields = ('alias', 'content', 'start_time', 'end_time', 'apply_reason', 'room', 'attender', 'in_required', 'in_start', 'in_end', 'out_required', 'out_start', 'out_end', 'time_zone', 'enable_virtual', 'host_video', 'participant_video', 'enable_waiting_room', 'jbh_anytime', 'mute_upon_entry', 'auto_recording', 'view_date')
class MeetingEntityRetrieveSerializer(serializers.ModelSerializer):
    approval_status_display = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = MeetingEntity
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'department', 'position', 'workflow_engine', 'workflow_name', 'start_time', 'end_time', 'apply_reason', 'apply_time', 'approval_status', 'approval_status_display', 'approval_remark', 'approval_time', 'last_approver')
class MeetingEntityApproveSerializer(MeetingEntityRequestSerializer):
    approval_permission = serializers.SerializerMethodField()
    room = serializers.CharField(source='room.alias', allow_null=True)
    def get_approval_permission(self, obj):
        if obj.approval_status!= 1:
            return False
        else:
            pending_node = obj.get_first_pending_node()
            if pending_node is None:
                return False
            else:
                perm = pending_node.has_approval_permission(self.context['request'].user)
                return True if perm else False
    class Meta:
        model = MeetingEntity
        fields = ('id', 'alias', 'content', 'meeting_period', 'attender_quantity', 'room', 'apply_reason', 'applier', 'approval_status_display', 'approver', 'approval_permission', 'emp_photo', 'approval_status', 'apply_time')