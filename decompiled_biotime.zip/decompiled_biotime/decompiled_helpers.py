# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\admin\\helpers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:53 UTC (1750672973)

import functools
import json
import time
import logging
from django import forms
from django.contrib.admin import helpers
from django.contrib.admin.utils import flatten_fieldsets, help_text_for_field, label_for_field
from django.forms.utils import flatatt
from django.template.defaultfilters import capfirst
import six
from django.utils.encoding import force_str
from django.utils.html import conditional_escape, format_html
from django.utils.safestring import mark_safe
from django.utils.translation import gettext, gettext_lazy as _
from django.conf import settings
from mysite._utils import colored
ACTION_CHECKBOX_NAME = '_selected_action'
class ZKActionForm(forms.Form):
    action = forms.ChoiceField(label=_('helpers_actionForm_actionLabel'))
    select_across = forms.BooleanField(label='', required=False, initial=0, widget=forms.HiddenInput({'class': 'select-across'}))
checkbox = forms.CheckboxInput({'class': 'action-select'}, lambda value: False)
class ZKActionAdminForm(object):
    def __init__(self, form, fieldsets, admin=None):
        self.form, self.fieldsets = (form, fieldsets)
        self.admin = admin
    def __iter__(self):
        for name, options in self.fieldsets:
            yield ZKActionFieldset(self.form, name, admin=self.admin, **options)
    @property
    def errors(self):
        return self.form.errors
    @property
    def non_field_errors(self):
        return self.form.non_field_errors
    @property
    def media(self):
        media = self.form.media
        for fs in self:
            media = media + fs.media
        return media
class ZKActionFieldset(object):
    pass
    def __init__(self, form, name=None, readonly_fields=(), fields=(), classes=(), description=None, admin=None):
        self.form = form
        self.name, self.fields = (name, fields)
        self.classes = ' '.join(classes)
        self.description = description
        self.admin = admin
        self.readonly_fields = readonly_fields
    def __iter__(self):
        for field in self.fields:
            yield ZKActionFieldline(self.form, field, self.readonly_fields, admin=self.admin)
class ZKActionFieldline(object):
    def __init__(self, form, field, readonly_fields=None, admin=None):
        self.form = form
        if hasattr(field, '__iter__') and isinstance(field, six.text_type):
            self.fields = [field]
        else:
            self.fields = field
        self.has_visible_field = not all((field in self.form.fields and self.form.fields[field].widget.is_hidden for field in self.fields))
        self.admin = admin
        if readonly_fields is None:
            readonly_fields = ()
        self.readonly_fields = readonly_fields
    def __iter__(self):
        for i, field in enumerate(self.fields):
            if field in self.readonly_fields:
                continue
            else:
                yield ZKActionAdminField(self.form, field, is_first=i == 0)
    def errors(self):
        return mark_safe('\n'.join((self.form[f].errors.as_ul() for f in self.fields if f not in self.readonly_fields)).strip('\n'))
class ZKActionAdminField(object):
    def __init__(self, form, field, is_first):
        self.field = form[field]
        self.is_first = is_first
        self.is_checkbox = isinstance(self.field.field.widget, forms.CheckboxInput)
        self.is_readonly = False
    def label_tag(self):
        classes = ['layui-form-label']
        contents = conditional_escape(force_str(self.field.label))
        if self.is_checkbox:
            classes.append('vCheckboxLabel')
        if self.field.field.required:
            contents = '%s<span class=\"required\">*</span>' % contents
        if not self.is_first:
            classes.append('inline')
        attrs = {'class': ' '.join(classes)} if classes else {}
        return self.field.label_tag(contents=mark_safe(contents), attrs=attrs, label_suffix='' if self.is_checkbox else None)
    def errors(self):
        return mark_safe(self.field.errors.as_ul())
class ZKAdminForm(helpers.AdminForm):
    def __iter__(self):
        for name, options in self.fieldsets:
            yield ZKFieldset(self.form, name, readonly_fields=self.readonly_fields, model_admin=self.model_admin, **options)
class ZKFieldset(helpers.Fieldset):
    def __iter__(self):
        for field in self.fields:
            yield ZKFieldline(self.form, field, self.readonly_fields, model_admin=self.model_admin)
class ZKFieldline(helpers.Fieldline):
    def __iter__(self):
        for i, field in enumerate(self.fields):
            if field in self.readonly_fields:
                yield ZKAdminReadonlyField(self.form, field, is_first=i == 0, model_admin=self.model_admin)
            else:
                yield ZKAdminField(self.form, field, is_first=i == 0)
class ZKAdminField(helpers.AdminField):
    def label_tag(self):
        classes = ['layui-form-label']
        contents = conditional_escape(force_str(self.field.label))
        if self.is_checkbox:
            classes.append('vCheckboxLabel')
        if self.field.field.required:
            contents = '%s<span class=\"required\">*</span>' % contents
        if not self.is_first:
            classes.append('inline')
        attrs = {'class': ' '.join(classes)} if classes else {}
        return self.field.label_tag(contents=mark_safe(contents), attrs=attrs, label_suffix='' if self.is_checkbox else None)
class ZKAdminReadonlyField(helpers.AdminReadonlyField):
    def label_tag(self):
        attrs = {}
        if not self.is_first:
            attrs['class'] = 'inline'
        label = self.field['label']
        return format_html('<label{}>{}:</label>', flatatt(attrs), capfirst(force_str(label)))
class InlineAdminFormSet(object):
    """\n    A wrapper around an inline formset for use in the admin system.\n    """
    def __init__(self, inline, formset, fieldsets, prepopulated_fields=None, readonly_fields=None, model_admin=None):
        self.opts = inline
        self.formset = formset
        self.fieldsets = fieldsets
        self.model_admin = model_admin
        if readonly_fields is None:
            readonly_fields = ()
        self.readonly_fields = readonly_fields
        if prepopulated_fields is None:
            prepopulated_fields = {}
        self.prepopulated_fields = prepopulated_fields
        self.classes = ' '.join(inline.classes) if inline.classes else ''
    def __iter__(self):
        for form, original in zip(self.formset.initial_forms, self.formset.get_queryset()):
            view_on_site_url = self.opts.get_view_on_site_url(original)
            yield ZKInlineAdminForm(self.formset, form, self.fieldsets, self.prepopulated_fields, original, self.readonly_fields, model_admin=self.opts, view_on_site_url=view_on_site_url)
        for form in self.formset.extra_forms:
            yield ZKInlineAdminForm(self.formset, form, self.fieldsets, self.prepopulated_fields, None, self.readonly_fields, model_admin=self.opts)
        yield ZKInlineAdminForm(self.formset, self.formset.empty_form, self.fieldsets, self.prepopulated_fields, None, self.readonly_fields, model_admin=self.opts)
    def fields(self):
        fk = getattr(self.formset, 'fk', None)
        for i, field_name in enumerate(flatten_fieldsets(self.fieldsets)):
            if fk and fk.name == field_name:
                    continue
            if field_name in self.readonly_fields:
                yield {'label': label_for_field(field_name, self.opts.model, self.opts), 'widget': {'is_hidden': False}, 'required': False, 'help_text': help_text_for_field(field_name, self.opts.model)}
            else:
                form_field = self.formset.empty_form.fields[field_name]
                label = form_field.label
                if label is None:
                    label = label_for_field(field_name, self.opts.model, self.opts)
                yield {'label': label, 'widget': form_field.widget, 'required': form_field.required, 'help_text': form_field.help_text}
    def inline_formset_data(self):
        verbose_name = self.opts.verbose_name
        return json.dumps({'name': '#%s' % self.formset.prefix, 'options': {'prefix': self.formset.prefix, 'addText': '%s' % {_('helpers_addText_addAnother%(verbose_name)s') % {'verbose_name': capfirst(verbose_name)}}, 'deleteText': '%s' % _('helpers_deleteText_remove')}})
    @property
    def forms(self):
        return self.formset.forms
    @property
    def non_form_errors(self):
        return self.formset.non_form_errors
    @property
    def media(self):
        media = self.opts.media + self.formset.media
        for fs in self:
            media = media + fs.media
        return media
class ZKInlineAdminForm(ZKAdminForm):
    """\n    A wrapper around an inline form for use in the admin system.\n    """
    def __init__(self, formset, form, fieldsets, prepopulated_fields, original, readonly_fields=None, model_admin=None, view_on_site_url=None):
        self.formset = formset
        self.model_admin = model_admin
        self.original = original
        self.show_url = original and view_on_site_url is not None
        self.absolute_url = view_on_site_url
        super(ZKInlineAdminForm, self).__init__(form, fieldsets, prepopulated_fields, readonly_fields, model_admin)
    def __iter__(self):
        for name, options in self.fieldsets:
            yield ZKInlineFieldset(self.formset, self.form, name, self.readonly_fields, model_admin=self.model_admin, **options)
    def needs_explicit_pk_field(self):
        if not self.form._meta.model._meta.auto_field and (not self.form._meta.model._meta.pk.editable):
            return True
        else:
            for parent in self.form._meta.model._meta.get_parent_list():
                if parent._meta.auto_field or not parent._meta.model._meta.pk.editable:
                    return True
            return False
    def pk_field(self):
        return ZKAdminField(self.form, self.formset._pk_field.name, False)
    def fk_field(self):
        fk = getattr(self.formset, 'fk', None)
        if fk:
            return ZKAdminField(self.form, fk.name, False)
        else:
            return ''
    def deletion_field(self):
        from django.forms.formsets import DELETION_FIELD_NAME
        return ZKAdminField(self.form, DELETION_FIELD_NAME, False)
    def ordering_field(self):
        from django.forms.formsets import ORDERING_FIELD_NAME
        return ZKAdminField(self.form, ORDERING_FIELD_NAME, False)
class ZKInlineFieldset(ZKFieldset):
    def __init__(self, formset, *args, **kwargs):
        self.formset = formset
        super(ZKInlineFieldset, self).__init__(*args, **kwargs)
    def __iter__(self):
        fk = getattr(self.formset, 'fk', None)
        for field in self.fields:
            if fk and fk.name == field:
                    continue
            yield ZKFieldline(self.form, field, self.readonly_fields, model_admin=self.model_admin)
class AdminErrorList(forms.utils.ErrorList):
    """\n    Stores all errors for the form/formsets in an add/change stage view.\n    """
    def __init__(self, form, inline_formsets):
        super(AdminErrorList, self).__init__()
        if form.is_bound:
            self.extend(list(form.errors.values()))
            for inline_formset in inline_formsets:
                self.extend(inline_formset.non_form_errors())
                for errors_in_inline_form in inline_formset.errors:
                    self.extend(list(errors_in_inline_form.values()))
def time_it(method):
    """\n    t_start - t_end = used_time\n\n    you can offer a dict to store the timing result\n\n    example:\n    log_time_container ={}\n    result = SomeClass.get_all_result(log_time=log_time_container)\n\n    :param method: callable\n    :return:\n    """
    @functools.wraps(method)
    def timed(*args, **kw):
        t_start = time.time()
        result = method(*args, **kw)
        t_end = time.time()
        if 'log_time' in kw:
            name = kw.get('log_name', method.__name__.upper())
            kw['log_time'][name] = int((t_end - t_start) * 1000)
        else:
            if settings.DEBUG:
                logging.getLogger(__file__).info('# ' + colored('{!r} --- {: >10.5f} ms ---'.format(method.__name__, (t_end - t_start) * 1000), 'blue'))
        return result
    return timed
def template_sentry(*tmp_list, **kwargs):
    """模板哨兵(当 model 自定义的模板文件不存在时，选用对应类型的默认的模板文件)\n    :param tmp_list: template list\n    :param kwargs: specfiy the template type\n    :return: return valid template file (if any)\n    """
    import os
    from django.template.loader import get_template
    from django.template import TemplateDoesNotExist
    tmp_type = kwargs.get('tmp_type', None)
    reserved_sentry = dict(grid='data_grid.html', edit='data_edit.html')
    valid = None
    for tmp in tmp_list:
        if tmp is None:
            continue
        else:
            try:
                get_template(tmp)
            except TemplateDoesNotExist:
                continue
            else:
                valid = tmp
                break
    if valid is None:
        if tmp_type:
            valid = reserved_sentry.get(tmp_type, None)
        else:
            try:
                suffix = os.path.basename(os.path.splitext(tmp_list[(-1)])[0])
            except TypeError:
                pass
            else:
                if suffix:
                    valid = reserved_sentry.get(suffix, None)
    return valid