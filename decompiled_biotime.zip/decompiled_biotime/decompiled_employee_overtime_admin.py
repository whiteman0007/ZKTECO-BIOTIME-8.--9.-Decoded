# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\employee_overtime_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att import const
from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import EmployeeOvertimeViewSet
from mysite.att.api.report_views.employee_overtime import EmployeeOvertimeSerializer
@report_register()
class EmployeeOvertimeAdmin(ReportAdminBase):
    model_name = 'employeeOvertimeReport'
    view_name = 'employee_overtime'
    template = 'att/report_new/employee_overtime.html'
    api_view = EmployeeOvertimeViewSet
    serializer = EmployeeOvertimeSerializer
    data_source = '/att/api/employeeOvertimeReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name')
    hidden_fields = ('company_code', 'last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = 'emp_code'
    add_paycode_column = True
    paycode_type = const.OVERTIME