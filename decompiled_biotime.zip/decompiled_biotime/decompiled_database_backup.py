# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\database_backup.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

import copy
import datetime
import logging
import os
import zipfile
from shutil import copyfileobj
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from mysite.tools.system_cmd import run_command
from mysite.utils import get_or_create_photo_folder
from mysite.base.const import USER_DEFINE_PASSWORD
backup_photo_file_name = 'photo_backup.zip'
logger = logging.getLogger(__name__)
def mssql_backup(path, backup_time):
    db_file = '%s.bak' % backup_time.strftime('%Y%m%d%H%M%S')
    backup_file = os.path.join(path, db_file)
    cmd = 'sqlcmd -U %(user)s -P %(password)s -S %(host)s -Q \"backup database %(name)s to disk=\'%(location)s\'\"' % {'user': settings.DATABASE_USER, 'password': settings.DATABASE_PASSWORD, 'host': settings.DATABASE_HOST, 'name': settings.DATABASE_NAME, 'location': backup_file}
    logger.info('[*]Database Backup Command: %s' % cmd)
    run_command(cmd)
    return db_file
def mysql_backup(path, backup_time):
    db_file = '%s.sql' % backup_time.strftime('%Y%m%d%H%M%S')
    backup_file = os.path.join(path, db_file)
    if settings.DATABASE_PASSWORD:
        password = '-p%s ' % settings.DATABASE_PASSWORD
    else:
        password = ''
    cmd = 'mysqldump --hex-blob -l --opt -q -R --default-character-set=utf8 -h %(host)s -u%(user)s %(password)s-P %(port)s --databases %(name)s' % {'user': settings.DATABASE_USER, 'password': password, 'host': settings.DATABASE_HOST, 'name': settings.DATABASE_NAME, 'port': settings.DATABASE_PORT}
    logger.info('[*]Database Backup Command: %s' % cmd)
    stdout, stderr = run_command(cmd)
    stdout.seek(0)
    with open(backup_file, 'wb') as fd:
        copyfileobj(stdout, fd)
    return db_file
def oracle_backup(path, backup_time):
    db_file = '%s.dmp' % backup_time.strftime('%Y%m%d%H%M%S')
    backup_file = os.path.join(path, db_file)
    cmd = 'exp \"%(user)s/%(password)s\" file=%(location)s' % {'user': settings.DATABASE_USER, 'password': settings.DATABASE_PASSWORD, 'location': backup_file}
    logger.info('[*]Database Backup Command: %s' % cmd)
    run_command(cmd)
    return db_file
def postgresql_backup(path, backup_time):
    db_file = '%s.sql' % backup_time.strftime('%Y%m%d%H%M%S')
    backup_file = os.path.join(path, db_file)
    cmd = 'pg_dump -h %(host)s -c -p %(port)s -U %(user)s %(name)s' % {'user': settings.DATABASE_USER, 'password': settings.DATABASE_PASSWORD, 'host': settings.DATABASE_HOST, 'port': settings.DATABASE_PORT, 'name': settings.DATABASE_NAME}
    logger.info('[*]Database Backup Command: %s' % cmd)
    stdout, stderr = run_command(cmd)
    stdout.seek(0)
    with open(backup_file, 'wb') as fd:
        copyfileobj(stdout, fd)
    return db_file
def backup(path, backup_info, need_backup_photo=False):
    now = datetime.datetime.now()
    backup_func = {'sql_server': mssql_backup, 'mysql': mysql_backup, 'oracle': oracle_backup, 'postgresql': postgresql_backup}
    func = backup_func.get(settings.DATABASE_ENGINE, None)
    if not func or not callable(func):
        raise Exception(_('%(engine)_backup_is_unavailable') % {'engine': settings.DATABASE_ENGINE})
    else:
        db_file = func(path, now)
        if not os.path.exists(os.path.join(path, db_file)):
            raise Exception(_('%(engine)_backup_is_unavailable') % {'engine': settings.DATABASE_ENGINE})
        else:
            if backup_info.get('global_backup_set'):
                db_file = db_encryption(backup_info, os.path.join(path, db_file))
            if need_backup_photo:
                try:
                    backup_photo_v2(os.path.join(path, db_file), backup_info)
                except Exception as e:
                    logger.exception('backup_photo error')
                    raise e
            return (now, db_file)
def backup_photo_v2(db_file, backup_info):
    """ Using os.walk method, can directly obtain all photos in the specified folder, including sub folders.\n    also applicable when enable WDMS\n    """
    path = os.path.dirname(db_file)
    os.makedirs(path, exist_ok=True)
    if backup_info.get('global_backup_set'):
        path, file_name = os.path.split(db_file)
        zip_photo_name = '{0}{1}'.format('photo_', file_name)
        photo_backup_file = os.path.join(path, zip_photo_name)
    else:
        tmp = db_file.split('.')
        tmp[(-1)] = 'zip'
        photo_backup_file = '.'.join(tmp)
    zip_file = zipfile.ZipFile(photo_backup_file, 'w', zipfile.ZIP_DEFLATED)
    for photo_dir_name in ['photo', 'biophoto', 'upload', 'register', 'visitor']:
        crt_photo_store_dir = get_or_create_photo_folder(photo_dir_name)
        for root, dirs, files in os.walk(crt_photo_store_dir):
            if files:
                for file_name in files:
                    zip_photo_dir = photo_dir_name + root.replace(crt_photo_store_dir, '')
                    zip_file.write(os.path.join(root, file_name), os.path.join(zip_photo_dir, file_name))
    zip_file.close()
def backup_photo(db_file):
    path = os.path.dirname(db_file)
    os.makedirs(path, exist_ok=True)
    photo_store_dir = get_or_create_photo_folder('photo')
    biophoto_store_dir = get_or_create_photo_folder('biophoto')
    upload_store_dir = get_or_create_photo_folder('upload')
    register_photo_store_dir = get_or_create_photo_folder('register')
    visitor_store_dir = get_or_create_photo_folder('visitor')
    tmp = db_file.split('.')
    tmp[(-1)] = 'zip'
    photo_backup_file = '.'.join(tmp)
    zip_file = zipfile.ZipFile(photo_backup_file, 'w', zipfile.ZIP_DEFLATED)
    backup_photo_store_dir = 'photo'
    backup_biophoto_store_dir = 'biophoto'
    backup_upload_store_dir = 'upload'
    backup_register_photo_store_dir = 'register'
    backup_visitor_store_dir = 'visitor'
    photos = os.listdir(photo_store_dir)
    for photo in photos:
        zip_file.write(os.path.join(photo_store_dir, photo), os.path.join(backup_photo_store_dir, photo))
    biophotos = os.listdir(biophoto_store_dir)
    for photo in biophotos:
        zip_file.write(os.path.join(biophoto_store_dir, photo), os.path.join(backup_biophoto_store_dir, photo))
    register_photos = os.listdir(register_photo_store_dir)
    for photo in register_photos:
        zip_file.write(os.path.join(register_photo_store_dir, photo), os.path.join(backup_register_photo_store_dir, photo))
    visitor_photos = os.listdir(visitor_store_dir)
    for photo in visitor_photos:
        zip_file.write(os.path.join(visitor_store_dir, photo), os.path.join(backup_visitor_store_dir, photo))
    dates = os.listdir(upload_store_dir)
    for d in dates:
        upload_store_date_dir = os.path.join(upload_store_dir, d)
        if os.path.isdir(upload_store_date_dir):
            backup_d = os.path.join(backup_upload_store_dir, d)
            sns = os.listdir(upload_store_date_dir)
            for sn in sns:
                upload_store_pics_dir = os.path.join(upload_store_date_dir, sn)
                if os.path.isdir(upload_store_pics_dir):
                    backup_sn = os.path.join(backup_d, sn)
                    pics = os.listdir(upload_store_pics_dir)
                    for pic in pics:
                        pic_path = os.path.join(upload_store_pics_dir, pic)
                        if os.path.isfile(pic_path):
                            zip_file.write(pic_path, os.path.join(backup_sn, pic))
    zip_file.close()
def postgresql_create_db(db_name):
    cmd = 'createdb -h %(host)s -p %(port)s -U %(user)s \"%(name)s\"' % {'user': settings.DATABASE_USER, 'password': settings.DATABASE_PASSWORD, 'host': settings.DATABASE_HOST, 'port': settings.DATABASE_PORT, 'name': db_name}
    logger.info('[*]PostgreSQL Create DB Command:%s' % cmd)
    run_command(cmd)
def postgresql_restore(db_name, bak_path):
    cmd = 'psql -h %(host)s -p %(port)s -U %(user)s -d %(name)s -f \"%(bak_path)s\"' % {'user': settings.DATABASE_USER, 'password': settings.DATABASE_PASSWORD, 'host': settings.DATABASE_HOST, 'port': settings.DATABASE_PORT, 'name': db_name, 'bak_path': bak_path}
    logger.info('[*]Database Restore Command: %s' % cmd)
    run_command(cmd)
def restore_photo(zip_file):
    import zipfile
    if settings.ENABLE_ENCRYPT_PHOTO:
        file_path = settings.AUTH_FILE_ROOT
    else:
        file_path = settings.ADDITION_FILE_ROOT
    if os.path.exists(zip_file):
        f = zipfile.ZipFile(zip_file, 'r')
        for file in f.namelist():
            f.extract(file, file_path)
def update_database_setting(new_db_name):
    import configparser
    from mysite.settings.components.paths import CONFIG_FILE_NAME
    config = configparser.RawConfigParser(strict=False, allow_no_value=True)
    config.read(CONFIG_FILE_NAME, encoding='utf-8-sig')
    config.set('DATABASE', 'name', new_db_name)
    wf = open(CONFIG_FILE_NAME, 'w')
    config.write(wf, space_around_delimiters=True)
    wf.close()
def restore(db_name, bak_path, flag, photo_path, need_restore_photo=False, sync_to_service_console=False):
    if need_restore_photo:
        if flag:
            restore_photo(photo_path)
        else:
            restore_photo(bak_path.replace('sql', 'zip'))
    if settings.DATABASE_ENGINE not in ['postgresql']:
        raise Exception(_('dbBackup_action_dbRestoreErrorNoSupport'))
    else:
        if not os.path.isfile(bak_path):
            raise Exception(_('dbBackup_action_dbRestoreErrorFileNoFound'))
        else:
            if db_name in [settings.DATABASE_NAME]:
                raise Exception(_('dbBackup_action_dbRestoreErrorIllegalDatabaseName'))
            else:
                postgresql_create_db(db_name)
                postgresql_restore(db_name, bak_path)
                if sync_to_service_console:
                    update_database_setting(db_name)
                if flag:
                    os.remove(bak_path)
def db_encryption(backup_info, backup_file):
    import os
    import logging
    import pyminizip
    if backup_info.get('auto_backup_encryption') == USER_DEFINE_PASSWORD:
        password = backup_info.get('auto_backup_password')
    else:
        password = backup_info.get('global_password')
        if not password:
            return os.path.split(backup_file)[1]
    try:
        compression_level = 5
        path, encrypt_file = os.path.split(backup_file)
        zip_file_name = encrypt_file.replace(encrypt_file.split('.')[(-1)], 'zip')
        zip_file_path = os.path.join(path, zip_file_name)
        pyminizip.compress(backup_file, None, zip_file_path, password, compression_level)
        os.remove(backup_file)
        return zip_file_name
    except Exception as e:
        logging.getLogger('base.backup.encrypt').exception(str(e))
def db_file_decrypt(file_path, bak_path, pwd):
    import pyminizip
    try:
        compression_level = 5
        zip_path, zip_name = os.path.split(bak_path)
        file_name = zip_name.replace('zip', 'sql')
        photo_name = '{0}{1}'.format('photo_', zip_name)
        pyminizip.uncompress(bak_path, pwd, file_path, compression_level)
        sql_path, photo_path = (os.path.join(zip_path, file_name), os.path.join(zip_path, photo_name))
        return (sql_path, photo_path)
    except Exception as e:
        logging.getLogger('base.backup.encrypt').exception(str(e))