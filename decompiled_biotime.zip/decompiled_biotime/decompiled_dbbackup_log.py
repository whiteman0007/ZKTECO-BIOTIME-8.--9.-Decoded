# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\models\\dbbackup_log.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:25 UTC (1750673005)

from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.admin.models import BaseModel
from mysite.base.db_const import APP_LABEL, DATABASE, BACKUP_STATUS
class DBBackupLog(BaseModel):
    db_type = models.CharField(verbose_name=_('dbBackupLog_field_type'), max_length=50, choices=DATABASE)
    db_name = models.CharField(verbose_name=_('dbBackupLog_field_name'), max_length=50)
    operator = models.CharField(verbose_name=_('dbBackupLog_field_operator'), null=True, max_length=50)
    backup_file = models.FilePathField(verbose_name=_('dbBackupLog_field_filePath'))
    backup_time = models.DateTimeField(verbose_name=_('dbBackupLog_field_time'), auto_now_add=True)
    backup_status = models.SmallIntegerField(verbose_name=_('dbBackupLog_field_status'), choices=BACKUP_STATUS, default=0)
    remark = models.TextField(verbose_name=_('dbBackupLog_field_remark'), null=True, blank=True)
    class Meta:
        app_label = APP_LABEL
        verbose_name = _('base_model_dbBackupLog')
        verbose_name_plural = verbose_name
        default_permissions = ()