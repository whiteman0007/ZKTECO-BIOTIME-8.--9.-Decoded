# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\templatetags\\common.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from django import forms
from django import template
from django.conf import settings
from django.template.defaultfilters import stringfilter
from mysite.authorized import auth_settings
from mysite._utils import getattr_ex
register = template.Library()
class SetVarNode(template.Node):
    def __init__(self, var_name, var_value):
        self.var_name = var_name
        self.var_value = var_value
    def render(self, context):
        try:
            value = template.Variable(self.var_value).resolve(context)
        except template.VariableDoesNotExist:
            value = ''
        context[self.var_name] = value
        return ''
@register.tag(name='set')
def set_var(parser, token):
    """\n    {% set some_var = \'123\' %}\n    """
    parts = token.split_contents()
    if len(parts) < 4:
        raise template.TemplateSyntaxError('\'set\' tag must be of the form: {% set <var_name> = <var_value> %}')
    else:
        return SetVarNode(parts[1], parts[3])
register = template.Library()
def label_tag(field, has_suffix=True):
    is_checkbox = isinstance(field.field.widget, forms.CheckboxInput)
    classes = ['layui-form-label']
    if field.field.required:
        classes.append('required')
    attrs = {'class': ' '.join(classes)}
    if has_suffix:
        label_tag = field.label_tag(attrs=attrs)
    else:
        label_tag = field.label_tag(attrs=attrs, label_suffix=' ')
    return label_tag
@register.filter
def get_auth_settings_param(value):
    result = ''
    if hasattr(auth_settings, value):
        result = getattr(auth_settings, value)
    return result
@register.filter
def get_settings_param(value):
    """\n    value==ENABLE_MULTIPLE_COMPANY: controlled by settings\n    value==ALLOW_MULTIPLE_COMPANY: controlled by settings and license\n     """
    result = ''
    if value == 'ENABLE_MULTIPLE_COMPANY':
        return (getattr_ex(settings, 'MULTI_COMPANY_EXT', False),)
    else:
        if value == 'ALLOW_MULTIPLE_COMPANY':
            from mysite.authorized import auth_settings
            if hasattr(auth_settings, 'AUTHORIZED_FIRM'):
                return auth_settings.AUTHORIZED_FIRM > 1 and getattr_ex(settings, 'MULTI_COMPANY_EXT', False)
            else:
                return False
        else:
            if hasattr(settings, value):
                result = getattr_ex(settings, value)
            return result
@register.filter
def get_list_value(data_list, index=0):
    try:
        return data_list[int(index)]
    except Exception:
        return None
@register.filter
def thailand(value):
    return getattr_ex(settings, 'THAILAND', False)
@register.filter
def logo_name(prefix):
    suffix = ''
    if getattr_ex(settings, 'MEXICO', False):
        suffix = '_mexico'
    return f'{prefix}{suffix}'
@register.filter
def login_class(value):
    if getattr_ex(settings, 'MEXICO', False):
        return 'mexico'
    else:
        if getattr_ex(settings, 'ENABLE_WDMS', False):
            return 'wdms'
        else:
            return ''
@register.filter
def layui_label_tag(field):
    return label_tag(field, has_suffix=False)
@register.filter
def layui_item_field(field):
    if field and len(field):
        field_html = '<div class=\"layui-form-item field-{field_name}\">{label_tag}<div class=\"layui-input-inline\">{widget}</div>{help_text}</div>'
        if field.help_text:
            help_text = '<a href=\"#\" onclick=\"tipsPrompt(this);\" class=\"fa fa-info-circle fa-lg fa-fw\" aria-hidden=\"true\" edbox data-box-target=\"#{field_name}_tips\" style=\"padding-top: 8px;\" title=\"{help_text}\"></a><div class=\"target-box\" style=\"display: none;\"><div id=\"{field_name}_tips\" style=\"display: block;\">{help_text}</div></div>'
            help_text = help_text.format(field_name=field.name, help_text=field.help_text)
        else:
            help_text = ''
        return field_html.format(label_tag=layui_label_tag(field), widget=field.as_widget(), help_text=help_text, field_name=field.name)
    else:
        return ''
@register.filter
def layui_item_field_ignore(field, ignore_tag=None):
    field_html = '<div class=\"layui-form-item\" style=\"display: none;\">{0}<div class=\"layui-input-inline\">{1}</div></div>'
    result = field_html.format(layui_label_tag(field), field.as_widget())
    if ignore_tag is None:
        return result
    else:
        return result.replace('<{}'.format(ignore_tag), '<{} lay-ignore'.format(ignore_tag))
@register.filter
def layui_inline_field(field):
    field_html = '<div class=\"layui-inline\">{0}<div class=\"layui-input-inline\">{1}</div></div>'
    return field_html.format(layui_label_tag(field), field.as_widget())
@register.filter
def layui_inline_no_label_field(field):
    field_html = '<div class=\"layui-inline\"><div class=\"layui-input-inline\">{0}</div></div>'
    return field_html.format(field.as_widget())
@register.filter
def field_as_label_tag_no_asterisk(field):
    result = label_tag(field, has_suffix=False)
    if result.__contains__('required'):
        result = result.replace('required', '')
    return '%s' % result
@register.filter
def available_style(export_style):
    return export_style in ['pdf', 'xls']
@register.filter(is_safe=True)
@stringfilter
def stripe_unicode_prefix(value):
    import re
    from django.utils.encoding import force_str
    value = force_str(value)
    pattern = re.compile('u(([\'\"]).*?\\2)', flags=re.I)
    for match in pattern.finditer(value):
        value = value.replace(match.group(), match.group(1))
    return value
@register.filter(is_safe=True)
@stringfilter
def py_dict_to_js(value):
    import re
    from django.utils.encoding import force_str
    value = force_str(value)
    digit_pattern = re.compile('(?<=:)\\s*(\\d+)\\s*L', flags=re.I)
    bool_pattern = re.compile('(?<=:)\\s*(False|True)\\s*(?=,)')
    single_bool_pattern = re.compile('^\\s*(False|True)\\s*$')
    for match in digit_pattern.finditer(value):
        value = value.replace(match.group(), match.group(1))
    for match in bool_pattern.finditer(value):
        value = value.replace(match.group(), match.group().lower())
    for match in single_bool_pattern.finditer(value):
        value = value.replace(match.group(), match.group().lower())
    value = value.replace('None', 'null')
    return stripe_unicode_prefix(value)
@register.inclusion_tag('layui/includes/layui_form_item.html')
def layui_form_item(field):
    return {'field': field}
@register.inclusion_tag('layui/includes/layui_inline.html')
def layui_inline(field, reversed_label=False, with_label=True, need_required_html=False):
    return {'field': field, 'reversed': reversed_label, 'with_label': with_label, 'need_required_html': need_required_html}
@register.inclusion_tag('layui/includes/layui_combine.html')
def layui_combine(label, field1, filed2, separator=None):
    from django.utils.translation import gettext
    return {'label': gettext(label), 'field1': field1, 'field2': filed2, 'separator': separator}
@register.inclusion_tag('layui/includes/layui_mid.html')
def layui_mid(field):
    return {'field': field}
@register.inclusion_tag('layui/includes/layui_checkbox.html')
def layui_checkbox(field, with_label=True):
    return {'field': field, 'with_label': with_label}
@register.inclusion_tag('layui/includes/layui_switch.html')
def layui_switch(field, with_label=True):
    return {'field': field, 'with_label': with_label}
@register.inclusion_tag('layui/includes/layui_enable.html')
def layui_enable(field, with_label=True):
    return {'field': field, 'with_label': with_label}
@register.inclusion_tag('att/timeinterval/widgets/layui_inline_duration.html')
def layui_inline_duration(field):
    return {'field': field}
@register.inclusion_tag('layui/includes/layui_inline_switch.html')
def layui_inline_switch(field):
    return {'field': field}
@register.inclusion_tag('layui/includes/layui_inline_hidden.html')
def layui_inline_hidden(field):
    return {'field': field}
@register.inclusion_tag('layui/includes/layui_inline_without_label.html')
def layui_inline_without_label(field):
    return {'field': field}
@register.inclusion_tag('layui/includes/layui_form_item_block.html')
def layui_form_item_block(field):
    return {'field': field}
@register.inclusion_tag('layui/includes/layui_inline_week_days.html')
def layui_inline_week_days(field, with_label=True):
    days = str(field.initial).split(';')
    dic = {'day0': days.__contains__('0'), 'day1': days.__contains__('1'), 'day2': days.__contains__('2'), 'day3': days.__contains__('3'), 'day4': days.__contains__('4'), 'day5': days.__contains__('5'), 'day6': days.__contains__('6')}
    return {'field': field, 'with_label': with_label, 'selects': dic}