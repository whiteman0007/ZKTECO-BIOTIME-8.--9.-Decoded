# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0004_auto_20201021_1551.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0003_auto_20200909_1810')]
    operations = [migrations.AddField(model_name='manuallog', name='is_mask', field=models.IntegerField(choices=[(1, 'epTransaction.opts.withMask'), (0, 'epTransaction.opts.withoutMask'), (255, 'epTransaction.opts.notEnable')], default=1, verbose_name='epTransaction.fields.isMask')), migrations.AddField(model_name='manuallog', name='temperature', field=models.DecimalField(decimal_places=1, max_digits=4, null=True, verbose_name='epTransaction.fields.temperature')), migrations.AddField(model_name='manuallog', name='temperature_F', field=models.DecimalField(decimal_places=1, max_digits=4, null=True, verbose_name='epTransaction.fields.temperature.Fahrenheit'))]