# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\asgi_views\\import_views.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import json
import logging
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from mysite.asgi_views.basic_views import BasicImportActionConsumer, MessageSender
from mysite.att.admin import TemporaryScheduleAdmin, AttScheduleAdmin, LeaveAdmin, ManualLogAdmin, OvertimeAdmin, TrainingAdmin
from mysite.iclock.admin import BioPhotoAdmin, TransactionAdmin
from mysite.personnel.admin import EmployeeAdmin, AreaAdmin, CertificationAdmin, DepartmentAdmin, PositionAdmin, ResignAdmin
class EmployeeImportConsumer(BasicImportActionConsumer, EmployeeAdmin):
    """export employee data"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Employee
        self.model = Employee
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.admin.employee_import import ImportEmployeeData
        process = await sync_to_async(ImportEmployeeData, thread_sensitive=False)(model_admin=self, app_label=self.model._meta.app_label, model_name=self.model._meta.model_name, **kwargs)
        await sync_to_async(process.save, thread_sensitive=False)()
        def save_user_profile():
            if not process or not process.columns:
                return None
            else:
                employee_fields = process.columns.keys()
                if not self.request.user or not self.request.user.is_employee:
                        self.request.user.userprofile.employee_fields = ','.join(employee_fields)
                        self.request.user.userprofile.save()
        await sync_to_async(save_user_profile, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.errors:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.errors[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class CertificationImportConsumer(BasicImportActionConsumer, CertificationAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Certification
        self.model = Certification
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.admin.certification_admin import ImportCertificationData
        process = await sync_to_async(ImportCertificationData, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class EmployeeCertImportConsumer(BasicImportActionConsumer, EmployeeAdmin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import EmployeeCertification
        from mysite.personnel.models import Employee
        self.model = Employee
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    def set_channel(self):
        import random
        from mysite.personnel.models import EmployeeCertification
        self.channel = 'import_{0}_{1}'.format(EmployeeCertification.__name__, random.randint(a=100000, b=999999))
        if hasattr(self.user, 'is_employee') and self.user.is_employee:
            self.redis_channel = 'sse_%s_%s' % (self.scope['user'].emp_code, self.channel)
        else:
            self.redis_channel = 'sse_%s_%s' % (self.scope['user'].username, self.channel)
        self.message_sender = MessageSender(*(self.channel, self.redis_channel))
        return (self.channel, self.redis_channel)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.admin.employeecertification_admin import ImportEmployeeCertificationData
        from mysite.personnel.models import EmployeeCertification
        process = await sync_to_async(ImportEmployeeCertificationData, thread_sensitive=False)(self.request, app_label=EmployeeCertification._meta.app_label, model_name=EmployeeCertification._meta.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class EmployeePhotoImportConsumer(BasicImportActionConsumer, EmployeeAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Employee
        self.model = Employee
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    def set_channel(self):
        import random
        self.channel = 'import_{0}_{1}'.format('EmployeePhoto', random.randint(a=100000, b=999999))
        if hasattr(self.user, 'is_employee') and self.user.is_employee:
            self.redis_channel = 'sse_%s_%s' % (self.scope['user'].emp_code, self.channel)
        else:
            self.redis_channel = 'sse_%s_%s' % (self.scope['user'].username, self.channel)
        self.message_sender = MessageSender(*(self.channel, self.redis_channel))
        return (self.channel, self.redis_channel)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        res = await sync_to_async(self.photo_import, thread_sensitive=False)(self.request, **kwargs)
        channel, redis_channel = self.get_channel()
        if res:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(res), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return None
class EmployeeUSBDataImportConsumer(BasicImportActionConsumer, EmployeeAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Employee
        self.model = Employee
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.import_usb_data import ImportUSBData
        process = await sync_to_async(ImportUSBData, thread_sensitive=False)(self.request, **kwargs)
        await sync_to_async(process.usb_data_import, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class DepartmentImportConsumer(BasicImportActionConsumer, DepartmentAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Department
        self.model = Department
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.admin.department_admin import ImportDeptData
        process = await sync_to_async(ImportDeptData, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class AreaImportConsumer(BasicImportActionConsumer, AreaAdmin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Area
        self.model = Area
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.admin.area_admin import ImportAreaData
        process = await sync_to_async(ImportAreaData, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class PositionImportConsumer(BasicImportActionConsumer, PositionAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Position
        self.model = Position
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.admin.position_admin import ImportPositionData
        process = await sync_to_async(ImportPositionData, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class ResignImportConsumer(BasicImportActionConsumer, ResignAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.personnel.models import Resign
        self.model = Resign
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.personnel.admin.resign_admin import ImportResignData
        process = await sync_to_async(ImportResignData, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class AttTemporaryScheduleImportConsumer(BasicImportActionConsumer, TemporaryScheduleAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.att.models.model_temporaryschedule import TemporarySchedule
        self.model = TemporarySchedule
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.att.admin.temporaryschedule_admin import ImportTemporaryScheduleData
        process = await sync_to_async(ImportTemporaryScheduleData, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class AttScheduleImportConsumer(BasicImportActionConsumer, AttScheduleAdmin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.att.models.model_attschedule import AttSchedule
        self.model = AttSchedule
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.att.admin.attschedule_admin import ImportAttScheduleData
        process = await sync_to_async(ImportAttScheduleData, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.exe_import_data, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.error_info:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.error_info[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class AttLeaveImportConsumer(BasicImportActionConsumer, LeaveAdmin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.att.models.model_leave import Leave
        self.model = Leave
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.att.data_import import LeaveImport
        process = await sync_to_async(LeaveImport, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.process)()
        channel, redis_channel = self.get_channel()
        if process.errors:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.errors[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class AttManualLogImportConsumer(BasicImportActionConsumer, ManualLogAdmin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.att.models.model_manuallog import ManualLog
        self.model = ManualLog
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.att.data_import import ManualLogImport
        process = await sync_to_async(ManualLogImport, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.process, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.errors:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.errors[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class AttOverTimeImportConsumer(BasicImportActionConsumer, OvertimeAdmin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.att.models.model_overtime import Overtime
        self.model = Overtime
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.att.data_import import OvertimeImport
        process = await sync_to_async(OvertimeImport, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.process)()
        channel, redis_channel = self.get_channel()
        if process.errors:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.errors[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class AttTrainingImportConsumer(BasicImportActionConsumer, TrainingAdmin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from mysite.att.models.model_training import Training
        self.model = Training
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        from mysite.att.data_import import TrainingImport
        process = await sync_to_async(TrainingImport, thread_sensitive=False)(self.request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        await sync_to_async(process.process, thread_sensitive=False)()
        channel, redis_channel = self.get_channel()
        if process.errors:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(process.errors[0]), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return process
class IClockBioPhotoImportConsumer(BasicImportActionConsumer, BioPhotoAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        """"""
        super().__init__(*args, **kwargs)
        from mysite.iclock.models.model_biophoto import BioPhoto
        self.model = BioPhoto
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        res = await sync_to_async(self.data_import, thread_sensitive=False)(self.request, **kwargs)
        channel, redis_channel = self.get_channel()
        if res:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(res), 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        return None
class IClockTransactionImportConsumer(BasicImportActionConsumer, TransactionAdmin):
    """"""
    def __init__(self, *args, **kwargs):
        """"""
        super().__init__(*args, **kwargs)
        from mysite.iclock.models.model_transaction import Transaction
        self.model = Transaction
        self.opts = self.model._meta
        self.info = (self.opts.app_label, self.opts.model_name)
    def import_usb_data(self, **kwargs) -> tuple:
        data = kwargs
        company = data.get('company', None)
        f = data.get('upload_file')
        fmt = f.name.split('.')[(-1)]
        if fmt not in ['dat', 'json']:
            return (False, str(_('file_format_incorrect')))
        else:
            import datetime
            import os
            encrypted = data.get('encrypted', False)
            f_data = []
            dt_now = datetime.datetime.now()
            store_folder = os.path.join(settings.ADDITION_FILE_ROOT, 'usb_data', 'manul', dt_now.strftime('%Y%m%d-%H%M%S'))
            os.makedirs(store_folder, exist_ok=True)
            store_file = os.path.join(store_folder, f.name)
            is_json_file = fmt in ['json']
            if is_json_file:
                data = json.load(f)
                if 'ATT_LOG' in data:
                    logs = data['ATT_LOG']
                    log_format = '{pin}\t{punch_time}\t{punch_state}\t{verify}\t{work_code}\t0\r\n'
                    for index, log in enumerate(logs):
                        f_data.append(log_format.format(pin=log['User_PIN'], punch_time=log['Verify_Time'], punch_state=log['Status'], verify=log['Verify_Type'], work_code=log['Work_Code_ID']))
            else:
                if encrypted:
                    from mysite.core.zkcmdproc import zk_transaction_decrypt
                    content = zk_transaction_decrypt(data=f.read())
                    if content == (-1):
                        return (False, _('file_format_incorrect'))
                    else:
                        if content == (-2):
                            return (False, _('terminal.errors.dataNotFound'))
                        else:
                            if content == (-3):
                                return (False, _('terminal.errors.dataError'))
                            else:
                                ts = content.strip().split('\r\n')
                else:
                    try:
                        ts = f.read()
                        ts = ts.decode('utf8')
                        ts = ts.strip().split('\r\n')
                    except Exception:
                        return (False, _('read_file_failed'))
                sn = f.name.split('_')[0]
                sn = str(sn).split('.')[0]
                from mysite.iclock.models import Terminal
                dev = Terminal.objects.filter(sn=sn)
                if not dev.exists():
                    return (False, _('device_not_found'))
                else:
                    for i, row in enumerate(ts):
                        cols = row.split('\t')
                        if len(cols) < 5:
                            return (False, _('row_%(row_num)s_data_incorrect') % {'row_num': i})
                        else:
                            _cols = list(map(lambda x: x.strip(), cols))
                            row_vals = dict(zip(('pin', 'punch_time', 'terminal_id', 'punch_state', 'verify'), _cols))
                            try:
                                if 'T' in row_vals['punch_time']:
                                    datetime.datetime.strptime(row_vals['punch_time'], '%Y-%m-%dT%H:%M:%S')
                                    row_vals['punch_time'] = row_vals['punch_time'].replace('T', ' ')
                                else:
                                    datetime.datetime.strptime(row_vals['punch_time'], '%Y-%m-%d %H:%M:%S')
                            except Exception:
                                return (False, _('row_%(row_num)s_data_incorrect') % {'row_num': i})
                            row_vals['work_code'] = 0
                            if len(_cols) >= 6:
                                row_vals = dict(zip(('pin', 'punch_time', 'terminal_id', 'punch_state', 'verify', 'work_code'), _cols))
                            f_data.append('{pin}\t{punch_time}\t{punch_state}\t{verify}\t{work_code}\t0\r\n'.format(**row_vals))
            with open(store_file, 'w', encoding='utf8', newline='') as tf:
                tf.write(''.join(f_data))
            from mysite.iclock.admin.transaction_admin import usb_transaction_data_import
            func = usb_transaction_data_import
            func(store_file, dt_now, company, self.send_event)
            return (True, '')
    async def save_data(self, *args, **kwargs):
        from asgiref.sync import sync_to_async
        res, msg = await sync_to_async(self.import_usb_data, thread_sensitive=False)(**kwargs)
        channel, redis_channel = self.get_channel()
        if res:
            self.send_event(event_name='result', data=json.dumps({'code': 0, 'message': '', 'channel': channel}))
        else:
            self.send_event(event_name='result', data=json.dumps({'code': (-1), 'message': str(msg), 'channel': channel}))
        return None