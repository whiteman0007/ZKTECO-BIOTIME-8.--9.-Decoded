# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\attshift_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models.model_attshift import AttShift
from mysite.att.api.serializers import util_serializers
class AttShiftSerializer(serializers.ModelSerializer):
    shift_timetable = serializers.SerializerMethodField()
    cycle_unit = serializers.CharField(source='get_cycle_unit_display', allow_null=True)
    def get_shift_timetable(self, obj):
        tbs = obj.shiftdetail_set.values_list('time_interval__alias', flat=True)
        return ','.join(set(tbs))
    class Meta:
        model = AttShift
        fields = ['id', 'alias', 'shift_timetable', 'cycle_unit', 'shift_cycle', 'auto_shift']
class AttShiftExportSerializer(serializers.ModelSerializer):
    shift_timetable = serializers.SerializerMethodField()
    cycle_unit = serializers.CharField(source='get_cycle_unit_display', allow_null=True)
    def get_shift_timetable(self, obj):
        tbs = obj.shiftdetail_set.values_list('time_interval__alias', flat=True)
        return ','.join(set(tbs))
    class Meta:
        model = AttShift
        fields = ['id', 'alias', 'shift_timetable', 'cycle_unit', 'shift_cycle', 'auto_shift']
class AttShiftCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttShift
        fields = '__all__'
class AttShiftEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttShift
        fields = '__all__'
class AttShiftActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AttShift
        action_type_choices = (('delete', 'delete'),)