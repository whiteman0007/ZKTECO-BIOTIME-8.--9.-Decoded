# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\mobile\\api\\serializers\\leave_serialier.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from rest_framework import serializers
from mysite.att.models import Leave
from mysite.mobile.api import fields
from mysite.mobile.api.serializers import EmployeeSerializer
class LeaveSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer()
    pay_code_desc = serializers.CharField(source='pay_code.name')
    start_stamp = fields.DateTimeField(source='start_time')
    end_stamp = fields.DateTimeField(source='end_time')
    apply_stamp = fields.DateTimeField(source='apply_time')
    approval_stamp = fields.DateTimeField(source='approval_time')
    approval_desc = serializers.CharField(source='get_approval_status_display')
    class Meta:
        model = Leave
        fields = ('id', 'employee', 'pay_code', 'pay_code_desc', 'start_stamp', 'end_stamp', 'apply_reason', 'apply_stamp', 'approval_status', 'approval_desc', 'approver', 'approval_stamp', 'approval_remark')