# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0015_auto_20250102_20141.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('personnel', '0014_auto_20241212_20114')]
    operations = [migrations.AlterField(model_name='employee', name='is_active', field=models.BooleanField(default=False, verbose_name='emp_field_isActive'))]