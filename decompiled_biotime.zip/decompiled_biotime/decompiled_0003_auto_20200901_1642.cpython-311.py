# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\payroll\\migrations\\0003_auto_20200901_1642.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:06 UTC (1750702746)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    initial = True
    dependencies = [('personnel', '0001_initial'), ('att', '0002_auto_20200901_1642'), ('payroll', '0002_auto_20200901_1642')]
    operations = [migrations.AddField(model_name='payrollpayloadpaycode', name='pay_code', field=models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='att.PayCode')), migrations.AddField(model_name='payrollpayloadpaycode', name='payload', field=models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='att.PayCode', verbose_name='leave.fields.payCode')), migrations.AddField(model_name='extraincrease', name='pay_code', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='personnel.Employee', verbose_name='extraDeduction_field_employee')), migrations.AddField(model_name='emppayrollprofile', name='employee', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='personnel.Employee', verbose_name='empLoan_field_employee'))]