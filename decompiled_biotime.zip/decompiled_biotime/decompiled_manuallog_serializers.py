# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\manuallog_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.personnel.api.serializers import EmployeeWithPhotoSerializer
from mysite.att.models.model_manuallog import ManualLog
from mysite.att.api.serializers import util_serializers
class ManualLogSerializer(serializers.ModelSerializer):
    approval_status_display = serializers.CharField(source='get_approval_status_display', allow_null=True)
    punch_state_display = serializers.CharField(source='get_punch_state_display', allow_null=True)
    attachment = serializers.SerializerMethodField()
    def get_attachment(self, obj):
        if obj.attachment:
            return '/files/' + str(obj.attachment)
        else:
            return ''
    class Meta:
        model = ManualLog
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'department', 'position', 'workflow_engine', 'workflow_name', 'punch_time', 'punch_state', 'punch_state_display', 'apply_reason', 'apply_time', 'work_code', 'attachment', 'approval_status', 'approval_status_display', 'approval_remark', 'approval_time', 'last_approver', 'approver']
class ManualLogCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ManualLog
        fields = ['employee', 'punch_time', 'punch_state', 'apply_reason', 'work_code', 'attachment']
class ManualLogEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = ManualLog
        fields = ['punch_time', 'punch_state', 'apply_reason', 'work_code', 'attachment']
class ManualLogActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = ManualLog
        action_type_choices = (('delete', 'delete'),)
class ManualLogForEmailSerializer(serializers.ModelSerializer):
    punch_state = serializers.CharField(source='get_punch_state_display', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = ManualLog
        exclude = ('employee', 'approver_instance')
class ManualLogForNotificationSerializer(serializers.ModelSerializer):
    employee = EmployeeWithPhotoSerializer()
    punch_state = serializers.CharField(source='get_punch_state_display')
    approval_status = serializers.CharField(source='get_approval_status_display')
    class Meta:
        model = ManualLog
        fields = ('id', 'employee', 'punch_time', 'punch_state', 'work_code', 'apply_reason', 'apply_time', 'approval_status', 'approver', 'approval_time', 'approval_remark')