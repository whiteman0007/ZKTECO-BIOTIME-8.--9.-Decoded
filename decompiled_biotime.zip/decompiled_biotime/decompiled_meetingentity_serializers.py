# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\meeting\\api\\serializers\\meetingentity_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:05 UTC (1750673045)

from rest_framework import serializers
from mysite.personnel.api.serializers import EmployeeWithPhotoSerializer
from mysite.meeting.models import MeetingEntity
class MeetingEntitySerializer(serializers.ModelSerializer):
    class Meta:
        model = MeetingEntity
        fields = '__all__'
class MeetingEntityAttenderSerializer(serializers.ModelSerializer):
    class Meta:
        model = MeetingEntity
        fields = ('attender',)
class MeetingEntityForEmailSerializer(serializers.ModelSerializer):
    meeting_room_alias = serializers.CharField(source='room.alias', allow_null=True)
    meeting_room_location = serializers.CharField(source='room.location', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    zoom_link = serializers.SerializerMethodField()
    def get_zoom_link(self, obj):
        return obj.get_invitation_link(suffix1='<br /><br />', suffix2='<br />')
    class Meta:
        model = MeetingEntity
        exclude = ('employee', 'approver_instance', 'code', 'attender', 'meeting_date', 'duration', 'in_required', 'out_required', 'calculation_time', 'sync_time')
class MeetingEntityForNotificationSerializer(serializers.ModelSerializer):
    employee = EmployeeWithPhotoSerializer()
    meeting_room_alias = serializers.CharField(source='room.alias', allow_null=True)
    meeting_room_location = serializers.CharField(source='room.location', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    zoom_link = serializers.SerializerMethodField()
    def get_zoom_link(self, obj):
        return obj.get_invitation_link(suffix1='<br /><br />', suffix2='<br />')
    class Meta:
        model = MeetingEntity
        fields = ('id', 'employee', 'alias', 'content', 'meeting_date', 'start_time', 'end_time', 'meeting_room_alias', 'meeting_room_location', 'zoom_link', 'apply_reason', 'apply_time', 'approval_status')