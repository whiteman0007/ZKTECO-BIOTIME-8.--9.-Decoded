# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\actions\\clone_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.personnel import widgets, models
from django import forms as django_forms
class CloneToAreaForm(forms.ZKActionForm):
    area = django_forms.ModelMultipleChoiceField(label=_('accPrivilege_field_area'), queryset=models.Area.objects.all(), widget=widgets.AreaSelectMultiple)
    remarks = forms.CharField(label=_('accTimezone_field_remark'), empty_value='', required=False)
class CloneToArea(admin.ZKModelAction):
    batch_select = True
    verbose_name = _('clone_to_area')
    help_txt = _('clone_to_area')
    short_description = _('clone_to_area')
    action_form = CloneToAreaForm
    def action(self, *args, **kwargs):
        if self.request.method == 'POST':
            self.admin.clone_to_area(self.request, self.objects)