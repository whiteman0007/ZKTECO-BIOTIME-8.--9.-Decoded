# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\mobile\\api\\serializers\\auth_token_serializer.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from django.utils.translation import gettext_lazy as _
from rest_framework.exceptions import AuthenticationFailed, ValidationError
from rest_framework_simplejwt.serializers import TokenObtainSerializer
from rest_framework_simplejwt.tokens import AccessToken
from mysite.personnel.db_const import app_v0, app_v1
from mysite.personnel.models import Employee
class AppAuthTokenSerializer(TokenObtainSerializer):
    token_class = AccessToken
    @property
    def object(self):
        return self.validated_data
    def get_token(self, emp):
        token = self.token_class.for_user(emp)
        return token
    def validate(self, attrs):
        from mysite._utils import getattr_ex
        from django.conf import settings
        credentials = {self.username_field: attrs.get(self.username_field), 'password': attrs.get('password')}
        use_encrypt = False
        if getattr(settings, 'ENABLE_APP_ENCRYPT', 0):
            try:
                from mysite.tools.encryption_utils import decrypt_parameter
                credentials[self.username_field] = decrypt_parameter(credentials[self.username_field])
                credentials['password'] = decrypt_parameter(credentials['password'])
                use_encrypt = True
            except:
                pass
        username = credentials.get(self.username_field)
        if getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
            emp = Employee.objects.filter(email=username).first()
        else:
            emp = Employee.objects.filter(emp_code=username).first()
        from django.core.cache import cache
        cache_user = cache.get('user_auth-{0}'.format(username), {}) or {'times': 0}
        times = cache_user.get('times', 0)
        if times >= 3:
            raise ValidationError({'detail': ['%s' % _('triedMoreTimesLocked')]})
        else:
            if emp and emp.check_password(credentials.get('password')):
                setattr(emp, 'app_client', app_v1 if use_encrypt else app_v0)
                return {'token': self.get_token(emp), 'user': emp}
            else:
                cache.set('user_auth-{0}'.format(username), {'times': times + 1}, 3600)
                raise AuthenticationFailed()