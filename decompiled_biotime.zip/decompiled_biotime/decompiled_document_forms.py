# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\forms\\document_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

import datetime
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.personnel.models import EmployeeCertification, Certification
class CertificateField(forms.FileField):
    def to_python(self, data):
        data = super(self.__class__, self).to_python(data)
        return data
class EmployeeDocumentForm(ModelForm):
    employee_id = forms.IntegerField()
    expire_on = forms.DateField(label=_('employeeCert_field_expireOn'), required=True, initial=datetime.datetime.now)
    before = forms.IntegerField(label=_('employeeCert_field_before'), required=True, initial=0, min_value=0)
    certification_code = forms.CharField(label=_('employeeCert_field_code'), required=False)
    certificate = CertificateField(label=_('employeeCert_field_cert'), required=False)
    def __init__(self, *args, **kwargs):
        emp_id = kwargs.pop('emp_id', '0')
        super().__init__(*args, **kwargs)
        data = getattr(self, 'data', {})
        if data and emp_id in (None, '0'):
                emp_id = data.get('employee_id', '0')
        from mysite.personnel.models import Employee
        emp = Employee.objects.filter(pk=emp_id).first()
        if emp:
            self.fields['certification'].queryset = Certification.objects.filter(company=emp.company)
        else:
            self.fields['certification'].queryset = Certification.objects.none()
    class Meta:
        model = EmployeeCertification
        fields = ('employee_id', 'certification_code', 'expire_on', 'before', 'email_alert', 'certificate', 'certification')