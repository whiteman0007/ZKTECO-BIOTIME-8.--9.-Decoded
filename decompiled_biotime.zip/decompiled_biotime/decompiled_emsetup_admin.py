# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\ep\\admin\\emsetup_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

import uuid
from mysite import admin
from mysite.ep.models import EPSetup
def _id():
    return uuid.uuid4().hex
@admin.register(EPSetup)
class EPSetupAdmin(admin.ZKModelAdmin):
    list_display = ('temp_warning', 'temp_alarm', 'mask_alarm', 'temp_unit')
    def has_delete_permission(self, request, obj=None):
        return False
    @staticmethod
    def initial_data():
        if EPSetup.objects.all().count() == 0:
            EPSetup(temp_alarm=1, mask_alarm=1, temp_warning=37.3, temp_unit=1).save()