# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\admin\\acc_terminal_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.utils.translation import gettext_lazy as _
from django.conf import settings
from django.utils.html import format_html
from mysite import admin
from mysite.acc import models_choices
from mysite.acc import actions, forms
from mysite.acc.models import AccTerminal
@admin.register(AccTerminal)
class AccTerminalAdmin(admin.ZKModelAdmin):
    form = forms.AccTerminalCreationForm
    def terminal_sn(self, obj):
        return obj.terminal.sn
    terminal_sn.short_description = _('terminal_field_sn')
    def terminal_name(self, obj):
        return obj.terminal.alias
    terminal_name.short_description = _('terminal_field_alias')
    def terminal_state(self, obj):
        state = obj.terminal.getDynState()
        icon_url = settings.MEDIA_URL + 'img/icons/state%(state)s.gif' % {'state': state}
        return format_html('<img src=\"{}\" alt=\"{}\" />', icon_url, state)
    terminal_state.short_description = _('terminal_field_state')
    def terminal_state_exp_display(self, obj, val):
        state = obj.terminal.getDynState()
        return state
    def sensor_type(self, obj):
        if obj.terminal.is_android:
            sensor_type_alias = models_choices.DOOR_SENSOR_TYPE_PHOTO_DEVICE[obj.door_sensor_type][1]
        else:
            sensor_type_alias = models_choices.DOOR_SENSOR_TYPE[obj.door_sensor_type][1]
        return sensor_type_alias
    sensor_type.short_description = _('accTerminal_field_doorSensorType')
    actions = [actions.OpenDoor, actions.CancelAlarm, actions.SetParameter]
    list_filter = ('terminal__sn', 'terminal__alias', 'terminal__area__area_name')
    list_display = ('id', 'terminal_sn', 'terminal_name', 'terminal_state', 'door_lock_delay', 'door_sensor_delay', 'sensor_type', 'door_alarm_delay', 'retry_times', 'valid_holiday')
    ordering = ('terminal__sn',)
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        qs = super(AccTerminalAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_area.all():
                qs = qs.filter(terminal__area__in=request.user.auth_area.all()).distinct()
        return qs
    def save_model(self, request, obj, form, changed):
        obj.save(update_fields=form.changed_data)