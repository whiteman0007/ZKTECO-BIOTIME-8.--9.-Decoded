# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0016_v904.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:26 UTC (1750702706)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('base', '0015_pro_903_2024090600')]
    operations = [migrations.AddField(model_name='securitypolicy', name='fp_login', field=models.BooleanField(default=False, verbose_name='securityPolicy_fields_enableFpLogin'))]