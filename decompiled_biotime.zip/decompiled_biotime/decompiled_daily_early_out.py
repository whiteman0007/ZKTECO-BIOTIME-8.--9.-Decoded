# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\daily_early_out.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.api import fields
from mysite.att.api.base_serializers import EmployeeTimeCardPayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.models import PayloadPayCode
from mysite.att.models.model_attcode import AttCode
from mysite.att.models.model_paycode import PayCode, EARLY_OUT, WORKDAY, HOUR, MINUTE, HOUR_MINUTE
class DailyEarlyOutSerializer(EmployeeTimeCardPayCodeRelatedReportModelSerializer):
    att_date = fields.DateField(label=_('report_column_attendanceDate'))
    check_in = fields.TimeField(label=_('report.columns.checkIn'), source='time_card.check_in')
    check_out = fields.TimeField(label=_('report.columns.checkOut'), source='time_card.check_out')
    clock_in = fields.TimeField(label=_('report.columns.clockIn'), source='time_card.clock_in')
    clock_out = fields.TimeField(label=_('report.columns.clockOut'), source='time_card.clock_out')
    weekday = fields.WeekdayField(label=_('report_column_attendanceWeekday'))
    time_table_alias = serializers.SerializerMethodField(label=_('report.columns.timetable'))
    def get_time_table_alias(self, obj):
        color = obj.time_card.time_table.color_setting if obj.time_card.time_table else None
        alias = obj.time_card.time_table_alias or ''
        if not color:
            return alias
        else:
            return format_html('<div style=\"color:#ffffff;background:{0}\">{1}</div>', color, alias)
    class Meta:
        model = PayloadPayCode
        fields = ('id', 'emp_id', 'emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday', 'time_table_alias', 'company_code', 'company_name', 'check_in', 'check_out', 'clock_in', 'clock_out')
class DailyEarlyOutFilter(ReportGenericFilter):
    class Meta:
        model = PayloadPayCode
        fields = ['employees', 'departments', 'start_date', 'end_date']
class DailyEarlyOutViewSet(ReportUserGenericViewSet):
    model = PayloadPayCode
    queryset = PayloadPayCode.objects.get_queryset().filter(time_card__isnull=False).order_by('emp', 'att_date', 'time_card__clock_in')
    filterset_class = DailyEarlyOutFilter
    serializer_dict = {'list': DailyEarlyOutSerializer, 'export': DailyEarlyOutSerializer}
    @property
    def att_codes(self):
        if not hasattr(self, '_att_codes'):
            att_code = AttCode.cache_data('total_hrs')
            self._att_codes = [{'id': att_code.id, 'code': att_code.code, 'alias': att_code.alias, 'display_format': att_code.display_format, 'min_val': att_code.min_val, 'round_off': att_code.round_off}]
        return self._att_codes
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.filter(fixed_code__in=(EARLY_OUT,)).order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def get_queryset(self):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            ordering = ['emp__emp_code_digit', 'emp__emp_code', 'att_date', 'time_card__clock_in']
        else:
            ordering = ['emp__emp_code', 'att_date', 'time_card__clock_in']
        queryset = self.queryset.filter(pay_code=PayCode.early_out()).order_by(*ordering)
        data_format = PayCode.early_out().display_format
        if data_format in (MINUTE, HOUR_MINUTE):
            queryset = queryset.filter(minutes__gt=0)
        else:
            if data_format == HOUR:
                queryset = queryset.filter(hours__gt=0)
            else:
                if data_format == WORKDAY:
                    queryset = queryset.filter(workday__gt=0)
                else:
                    queryset = queryset.get(duration__gt=0)
        return queryset
    def get_file_title(self):
        return _('att.menus.reports.dailyEarlyOut')