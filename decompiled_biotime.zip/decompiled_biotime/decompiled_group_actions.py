# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\group_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.admin.action import ActionHandleError
from mysite.att.models import AttEmployee
from mysite.personnel.actions.personnel_actions import SetPsnlModelForm
class SetGroupForm(SetPsnlModelForm):
    # return None
    pass
class SetGroup(admin.ZKModelAction):
    verbose_name = _('atGroup.actions.addEmployee')
    help_txt = _('atGroup.actions.addEmployee.helpTxt')
    short_description = _('atGroup.actions.addEmployee.description')
    action_form = SetGroupForm
    batch_select = True
    unique_object_required = True
    def action(self, *args, **kwargs):
        from mysite.personnel.models import Employee
        from mysite.personnel.models.model_employee import flush_cache_data
        emps = self.request.POST.getlist('employee')
        if not emps:
            raise ActionHandleError(_('select_none_employee'))
        else:
            AttEmployee.objects.filter(emp__id__in=emps).update(group=self.objects[0])
            employees = Employee.objects.filter(id__in=emps)
            for emp in employees:
                flush_cache_data(emp)