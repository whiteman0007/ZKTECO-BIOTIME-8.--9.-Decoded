# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\email_template_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

from rest_framework import serializers
from mysite.att.models import ManualLog, Leave, Overtime, Training, ChangeSchedule
from mysite.visitor.models import Reservation
from mysite.meeting.models import MeetingEntity, MeetingManualLog
class ManualLogSerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    punch_state = serializers.CharField(source='get_punch_state_display', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = ManualLog
        fields = '__all__'
class LeaveSerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    pay_code = serializers.CharField(source='pay_code.name', allow_null=True)
    class Meta:
        model = Leave
        fields = '__all__'
class OvertimeSerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    pay_code = serializers.CharField(source='pay_code.name', allow_null=True)
    class Meta:
        model = Overtime
        fields = '__all__'
class TrainingSerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    class Meta:
        model = Training
        fields = '__all__'
class ChangeScheduleSerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    class Meta:
        model = ChangeSchedule
        fields = '__all__'
class MeetingEntitySerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    room = serializers.CharField(source='room.alias', allow_null=True)
    content = serializers.CharField(source='format_content')
    class Meta:
        model = MeetingEntity
        fields = '__all__'
class MeetingManualLogSerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    punch_state = serializers.CharField(source='get_punch_state_display', allow_null=True)
    approval_status = serializers.CharField(source='get_approval_status_display', allow_null=True)
    class Meta:
        model = MeetingManualLog
        fields = '__all__'
class ReservationSerializer(serializers.ModelSerializer):
    emp = serializers.CharField(source='employee.format_name', allow_null=True)
    class Meta:
        model = Reservation
        fields = '__all__'
MODEL_SERIALIZER = {'manuallog': ManualLogSerializer, 'leave': LeaveSerializer, 'overtime': OvertimeSerializer, 'training': TrainingSerializer, 'changeschedule': ChangeScheduleSerializer, 'reservation': ReservationSerializer, 'meetingentity': MeetingEntitySerializer, 'meetingmanuallog': MeetingManualLogSerializer}
NOT_WORKFLO = {'ae_employee': ['emp', 'start_date', 'end_date', 'late', 'early_leave', 'absent']}
def get_email_content(instance, queryset=None, **kwargs):
    import re
    content = instance.content
    model = instance.content_type
    param = re.compile('{(\\w+)}')
    m = re.findall(param, content)
    if model in MODEL_SERIALIZER:
        context = MODEL_SERIALIZER[model](instance=queryset).data
        context.update(**kwargs)
        for i in m:
            if i not in context:
                content = content.replace('{' + i + '}', '{{' + i + '}}')
        content = content.format(**context)
    else:
        for i in m:
            if i not in NOT_WORKFLO[instance.content_type]:
                content = content.replace('{' + i + '}', '{{' + i + '}}')
    return content