# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\tools\\image_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import os
import re
import base64
import logging
from io import BytesIO
import shutil
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from PIL import Image
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.files import File
ORIENTATION_EXIF_TAG = 274
def flip_horizontal(im):
    return im.transpose(Image.FLIP_LEFT_RIGHT)
def flip_vertical(im):
    return im.transpose(Image.FLIP_TOP_BOTTOM)
def rotate_180(im):
    return im.transpose(Image.ROTATE_180)
def rotate_90(im):
    return im.transpose(Image.ROTATE_90)
def rotate_270(im):
    return im.transpose(Image.ROTATE_270)
def transpose(im):
    return rotate_90(flip_horizontal(im))
def transverse(im):
    return rotate_90(flip_vertical(im))
ORIENTATION_FUNCS = [lambda x: x, lambda x: x, flip_horizontal, rotate_180, flip_vertical, transpose, rotate_270, transverse, rotate_90]
def apply_orientation(im):
    # irreducible cflow, using cdg fallback
    """\n    Extract the oritentation EXIF tag from the image, which should be a PIL Image instance,\n    and if there is an orientation tag that would rotate the image, apply that rotation to\n    the Image instance given to do an in-place rotation.\n\n    :param Image im: Image instance to inspect\n    :return: A possibly transposed image instance\n    """
    if hasattr(im, '_getexif'):
        e = im._getexif()
        if e is not None:
            orientation = e[ORIENTATION_EXIF_TAG]
            if settings.DEBUG:
                print(('[DEBUG][image_utils.apply_orientation.orientation]', orientation, type(orientation)))
            f = ORIENTATION_FUNCS[orientation]
            return f(im)
            except TypeError:
                    pass
                except Exception:
                    import traceback
                    traceback.print_exc()
                    return im
def adjust_orientation(src, dst):
    """ Adjust the orientation of the JPEG image """
    im = Image.open(src)
    im = apply_orientation(im)
    im.save(dst)
def resize_by_pixel(src, dst, size):
    """Scale down to the specified pixel value and the scale are keeping (Size is a unit of pixel)\n    @:param size: type is int ,eg:320 * 240\n    """
    im = Image.open(src)
    x, y = im.size
    if x * y <= size:
        return
    else:
        while x * y > size:
            x = int(x / 1.05)
            y = int(y / 1.05)
        out = im.resize((x, y), Image.ANTIALIAS)
        out.save(dst)
def resize_by_size(src, dst, size):
    """Process images according to the specified file size(Size is a unit of KB)\n    @:param size: type is int\n    """
    size *= 1024
    im = Image.open(src)
    size_tmp = os.path.getsize(src)
    q = 100
    while size_tmp > size and q > 0:
        if q == 100 and src!= dst:
                shutil.copy(src, dst)
    else:
        out = im.resize(im.size, Image.ANTIALIAS)
        out.save(dst, quality=q)
        size_tmp = os.path.getsize(dst)
        q -= 5
def base64_to_image(base64_str):
    base64_data = re.sub('^data:image/.+;base64,', '', base64_str)
    byte_data = base64.b64decode(base64_data)
    image_data = BytesIO(byte_data)
    im = Image.open(image_data)
    return im
def image_to_base64(im, img_format='png'):
    output_buffer = BytesIO()
    img_format = img_format.upper()
    im.save(output_buffer, format=img_format)
    byte_data = output_buffer.getvalue()
    base64_str = base64.b64encode(byte_data).decode()
    return base64_str
def crop_image(im, crop_info):
    kwargs = {'x': 0, 'y': 0, 'width': im.width, 'height': im.height}
    kwargs.update(crop_info)
    kwargs['width'] += kwargs['x']
    kwargs['height'] += kwargs['y']
    if kwargs.get('kwargs')!= 0:
        im = im.rotate(-crop_info['rotate'], expand=True)
    return im.crop((kwargs['x'], kwargs['y'], kwargs['width'], kwargs['height']))
def encrypt_image(image, is_path=False):
    if is_path:
        with open(image, 'rb') as f:
            image = f.read()
    cbc_cipher = AES.new(settings.IMAGE_AES_PASSWORD, AES.MODE_CBC, settings.IMAGE_AES_IV)
    enc_data = settings.IMAGE_AES_PREFIX + cbc_cipher.encrypt(pad(image, 16))
    return enc_data
def decrypt_image(image, is_path=False):
    if is_path:
        with open(image, 'rb') as f:
            image = f.read()
    cbc_cipher = AES.new(settings.IMAGE_AES_PASSWORD, AES.MODE_CBC, settings.IMAGE_AES_IV)
    if b'$' in image[:10]:
        prefix = image[:10].split(b'$')[0]
        image = image[len(prefix) + 1:]
    try:
        dec_data = cbc_cipher.decrypt(image)
        dec_data = unpad(dec_data, 16)
    except:
        dec_data = b''
        logging.getLogger('exception').exception('unpad %s error' % image)
    return dec_data
def resize_emp_photo(src, dst, size):
    """Process images according to the specified file size(Size is a unit of KB)\n    @:param size: type is int\n    """
    size *= 1024
    im = Image.open(src)
    if im.mode!= 'RGB':
        im = im.convert('RGB')
    size_tmp = os.path.getsize(src)
    quality = 100
    max_height = 320
    _width, _height = im.size
    if _height > max_height:
        rate = max_height / _height
        _height = max_height
        _width = int(_width * rate)
    while size_tmp > size and quality > 0:
        if quality == 100 and src!= dst:
                shutil.copy(src, dst)
    else:
        out = im.resize((_width, _height), Image.ANTIALIAS)
        out.save(dst, quality=quality)
        size_tmp = os.path.getsize(dst)
        quality -= 5
class ImageEncryptStorage(FileSystemStorage):
    def save(self, name, content, max_length=None):
        if name is None:
            name = content.name
        if not hasattr(content, 'chunks'):
            content = File(content, name)
        name = self.get_available_name(name, max_length=max_length)
        result = self._save(name, content)
        if result:
            result_file = self.path(result)
            resize_emp_photo(result_file, result_file, 20)
            with open(result_file, 'rb') as f:
                source = f.read()
            with open(result_file, 'wb') as f:
                en_data = encrypt_image(source)
                f.write(en_data)
        return result
class ImageStorage(FileSystemStorage):
    def save(self, name, content, max_length=None):
        if name is None:
            name = content.name
        if not hasattr(content, 'chunks'):
            content = File(content, name)
        name = self.get_available_name(name, max_length=max_length)
        result = self._save(name, content)
        if result:
            result_file = self.path(result)
            resize_emp_photo(result_file, result_file, 20)
        return result