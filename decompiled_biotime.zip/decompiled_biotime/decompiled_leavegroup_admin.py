# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\leavegroup_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import json
from django.conf import settings
from django.db.models import Q
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite import admin, config
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.att.actions.leavegroup_actions import AddLeaveGroup, AssignLeaveGroup
from mysite.att.models import LeaveGroup, LeaveGroupDetail
class LeaveGroupForm(ModelForm):
    company_name = forms.CharField(label=_('company.field.name'), disabled=True, required=False)
    code = forms.CharField(label=_('leaveGroup.fields.code'), max_length=50, disabled=True)
    name = forms.CharField(label=_('leaveGroup.fields.name'), max_length=100)
    def __init__(self, *args, **kwargs):
        super(LeaveGroupForm, self).__init__(*args, **kwargs)
        if self.instance and getattr_ex(settings, 'MULTI_COMPANY', False):
            self.fields['company_name'].initial = str(self.instance.company)
        else:
            self.fields['company_name'].widget = forms.ZKHiddenInput()
        try:
            objs = LeaveGroup.objects.values('code')
            codes = [int(i['code']) for i in objs if i['code'].isdigit()]
            self.fields['code'].initial = str(max(codes) + 1 if codes else 1)
        except Exception:
            return None
    class Meta:
        models = LeaveGroup
        fields = ('code', 'name')
@admin.register(LeaveGroup)
class LeaveGroupAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'code', 'name') + config.WDMS_LIST_DISPLAY
    list_filter = ('code', 'name') + config.WDMS_LIST_FILTER
    form = LeaveGroupForm
    actions = (AssignLeaveGroup, AddLeaveGroup)
    def get_queryset(self, request):
        qs = super(LeaveGroupAdmin, self).get_queryset(request)
        if request.user.is_employee:
            return qs.filter(company=request.user.company)
        else:
            if not request.user.is_superuser and request.user.assign_company:
                    qs = qs.filter(company_id=request.user.assign_company)
            return qs
    def has_add_permission(self, request):
        return False