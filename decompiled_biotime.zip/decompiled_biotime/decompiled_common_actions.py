# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\common_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
from mysite.admin.utils import get_permission_name
from mysite.att.models import Leave, ManualLog, Overtime, Training, ChangeSchedule
from mysite.meeting.models import MeetingEntity, MeetingManualLog
from mysite.visitor.models import Reservation
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.settings.components.secretes import THAILAND
class AuditForm(forms.ZKActionForm):
    approval_remark = forms.TextField(label=_('leave_field_approvalReason'), required=False)
class Approve(ZKModelAction):
    batch_select = True
    verbose_name = _('att_action_approved')
    help_txt = _('att_action_approved')
    short_description = _('att_action_approved')
    action_form = AuditForm
    def action(self, *args, **kwargs):
        for obj in self.objects:
            obj.do_approve(self.request.user, kwargs['approval_remark'])
class Reject(ZKModelAction):
    batch_select = True
    verbose_name = _('att_action_reject')
    help_txt = _('att_action_reject')
    short_description = _('att_action_reject')
    action_form = AuditForm
    def action(self, *args, **kwargs):
        for obj in self.objects:
            obj.do_reject(self.request.user, kwargs['approval_remark'])
class Revoke(ZKModelAction):
    batch_select = True
    verbose_name = _('att_action_revoke')
    help_txt = _('att_action_revoke')
    short_description = _('att_action_revoke')
    action_form = AuditForm
    def action(self, *args, **kwargs):
        if THAILAND.fget():
            for obj in self.objects:
                if obj.is_approved and self.request.user.is_employee:
                    raise AdminRuntimeWarning(_('Not allowed to revoke after being approved.'))
                else:
                    obj.do_revoke(self.request.user, kwargs['approval_remark'])
        else:
            for obj in self.objects:
                obj.do_revoke(self.request.user, kwargs['approval_remark'])
APPROVAL_MODELS = [ManualLog, Leave, Overtime, Training, ChangeSchedule, MeetingEntity, MeetingManualLog, Reservation]
APPROVAL_VIEW_PERMISSION = dict([(cls._meta.model_name, get_permission_name('view', (cls._meta.app_label, cls._meta.model_name))[0]) for cls in APPROVAL_MODELS])
APPROVAL_APPROVE_PERMISSION = dict([(cls._meta.model_name, get_permission_name(Approve.__name__, (cls._meta.app_label, cls._meta.model_name))[0]) for cls in APPROVAL_MODELS])
APPROVAL_APPROVE_PERMISSION['leave'] = 'att.approve_leave_leave'
APPROVAL_REJECT_PERMISSION = dict([(cls._meta.model_name, get_permission_name(Reject.__name__, (cls._meta.app_label, cls._meta.model_name))[0]) for cls in APPROVAL_MODELS])