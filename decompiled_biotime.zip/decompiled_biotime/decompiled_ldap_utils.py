# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\tools\\ldap_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import ldap
import json
from mysite.base.models import SystemSetting
from mysite.tools.encryption_utils import aes_decrypt
from mysite.personnel.models import Position, Department, Employee, Area
from mysite.personnel.utils import get_default_company, get_default_company_id
from mysite.accounts.models import MyUser
def get_position(name):
    if not name:
        return
    else:
        position = Position.objects.filter(position_name=name).first()
        if not position:
            position = Position()
            position.position_name = name
            position_code_set = Position.objects.values_list('position_code', flat=True)
            position_code_int = []
            for i in position_code_set:
                if i.isdigit():
                    position_code_int.append(int(i))
            position_code_int.sort()
            code = position_code_int[(-1)] + 1
            position.position_code = code
            position.company = get_default_company()
        position.save()
        return position.id
def get_department(name):
    if not name:
        return
    else:
        dept = Department.objects.filter(dept_name=name).first()
        if not dept:
            dept = Department()
            dept.dept_name = name
            dept_code_set_list = Department.objects.values_list('dept_code', flat=True)
            dept_code_int = []
            for i in dept_code_set_list:
                if i.isdigit():
                    dept_code_int.append(int(i))
            dept_code_int.sort()
            code = dept_code_int[(-1)] + 1
            dept.dept_code = code
            dept.company = get_default_company()
        dept.save()
        return dept.id
class LDAPClient:
    client = None
    def __init__(self):
        _obj = SystemSetting.cache_data(name='ldap_setup')
        if _obj:
            self.ldap_info = json.loads(_obj.value)
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.unbind()
    def bind(self):
        self.client = ldap.initialize(self.ldap_info['host'])
        self.client.bind_s(self.ldap_info['username'], aes_decrypt(self.ldap_info['password']))
    def unbind(self):
        if self.client:
            self.client.unbind_s()
    def sync_employee(self):
        data_dict = {}
        field_map = {i['fn']: i['mn'] for i in self.ldap_info['emp_fields'] if i['mn']}
        location = self.ldap_info['emp_location']
        if not location:
            return
        else:
            default_department = Department.objects.filter(is_default=True).first()
            default_area = Area.objects.filter(is_default=True).first()
            datas = self.client.search_s(location, ldap.SCOPE_SUBTREE)
            for data in datas:
                emp_set = {}
                for k, v in field_map.items():
                    value = data[1].get(v, [None])[0]
                    if value:
                        if k == 'position':
                            position_id = get_position(value)
                            emp_set['position_id'] = position_id
                        else:
                            if k == 'department':
                                department_id = get_department(value)
                                emp_set['department_id'] = department_id
                            else:
                                emp_set[k] = str(value, encoding='utf8')
                        emp_set['company_id'] = get_default_company_id()
                emp_set['self_password'] = ''
                if emp_set.get('emp_code', None):
                    pin = emp_set['emp_code']
                    data_dict[pin] = emp_set
            for i in data_dict:
                if not data_dict[i].get('department_id', None) and default_department:
                        data_dict[i]['department_id'] = default_department.id
                emp, result = Employee.objects.update_or_create(emp_code=i, defaults=data_dict[i])
                if result and emp:
                        emp.area.set([default_area])
                        emp.save()
    def get_user(self, info, password, field_map):
        ll = ldap.initialize(self.ldap_info['host'])
        ll.bind_s(info[0], password)
        ll.unbind_s()
        data = {}
        for k, v in field_map.items():
            value = info[1].get(v, [None])[0]
            if value:
                data[k] = str(value, encoding='utf8')
        username = data.get('username', None)
        if not username:
            return
        else:
            user = MyUser.objects.filter(username=username).first()
            if not user:
                data['is_staff'] = True
                data['is_superuser'] = True
                user = MyUser.objects.create(**data)
            return user
    def auth_user(self, username, password):
        field_map = {i['fn']: i['mn'] for i in self.ldap_info['user_fields'] if i['mn']}
        ad_username = field_map['username']
        location = self.ldap_info['user_location']
        re = self.client.search_s(location, ldap.SCOPE_SUBTREE, ad_username + '=%s' % username)
        user = self.get_user(re[0], password, field_map)
        if self.user_can_authenticate(user):
            user.login_type = 0
            if user.login_count is not None:
                user.login_count += 1
            else:
                user.login_count = 0
            user.save(update_fields=['login_count'])
            return user
    def get_employee(self, info, password, field_map):
        ll = ldap.initialize(self.ldap_info['host'])
        ll.bind_s(info[0], password)
        ll.unbind_s()
        data = {}
        for k, v in field_map.items():
            value = info[1].get(v, [None])[0]
            if value:
                if k in ['position', 'department']:
                    if k == 'position':
                        position_id = get_position(value)
                        data['position_id'] = position_id
                    else:
                        department_id = get_department(value)
                        data['department_id'] = department_id
                else:
                    data[k] = str(value, encoding='utf8')
                data['company_id'] = get_default_company_id()
        data['self_password'] = ''
        emp_code = data.get('emp_code', None)
        if not emp_code:
            return
        else:
            emp, created = Employee.objects.update_or_create(emp_code=emp_code, defaults=data)
            return emp
    def auth_employee(self, username, password):
        field_map = {i['fn']: i['mn'] for i in self.ldap_info['emp_fields'] if i['mn']}
        ad_empcode = field_map['emp_code']
        location = self.ldap_info['emp_location']
        re = self.client.search_s(location, ldap.SCOPE_SUBTREE, ad_empcode + '=%s' % username)
        user = self.get_employee(re[0], password, field_map)
        if self.user_can_authenticate(user):
            user.login_type = 1
            return user
        else:
            return None
    def user_can_authenticate(self, user):
        """\n        Reject users with is_active=False. Custom user models that don\'t have\n        that attribute are allowed.\n        """
        is_active = getattr(user, 'is_active', None)
        return is_active or is_active is None