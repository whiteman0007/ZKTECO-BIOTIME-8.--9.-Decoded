# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\meeting\\api\\report\\meeting_attendance.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:05 UTC (1750673045)

from rest_framework import mixins, serializers
from rest_framework.response import Response
import django_filters
from mysite.meeting.api.serializers import NoneSerializer
from mysite.meeting.api.utils_class import UserLayUIGenericViewSet
from mysite.meeting.models import MeetingPayloadBase
from django.utils.translation import gettext_lazy as _
class MeetingAttendanceSerializer(serializers.ModelSerializer):
    emp_code = serializers.CharField(source='emp.emp_code')
    first_name = serializers.CharField(source='emp.first_name', allow_null=True)
    meeting_name = serializers.CharField(source='meeting.alias')
    meeting_date = serializers.CharField(source='meeting.meeting_date')
    meeting_period = serializers.SerializerMethodField()
    meeting_duration = serializers.SerializerMethodField()
    attended_duration = serializers.SerializerMethodField()
    late_in = serializers.SerializerMethodField()
    early_out = serializers.SerializerMethodField()
    absent = serializers.SerializerMethodField()
    def get_meeting_period(self, obj):
        return '{start}~{end}'.format(start=obj.start_time.time(), end=obj.end_time.time())
    def get_meeting_duration(self, obj):
        duration = obj.duration
        hrs = duration // 3600
        mins = duration % 3600 // 60
        return '{hrs:0>2d}:{mins:0>2d}'.format(hrs=int(hrs), mins=int(mins))
    def get_attended_duration(self, obj):
        duration = obj.attended_duration
        hrs = duration // 3600
        mins = duration % 3600 // 60
        return '{hrs:0>2d}:{mins:0>2d}'.format(hrs=int(hrs), mins=int(mins))
    def get_late_in(self, obj):
        late_in = obj.late_in
        hrs = late_in // 3600
        mins = late_in % 3600 // 60
        return '{hrs:0>2d}:{mins:0>2d}'.format(hrs=int(hrs), mins=int(mins))
    def get_early_out(self, obj):
        early_out = obj.early_out
        hrs = early_out // 3600
        mins = early_out % 3600 // 60
        return '{hrs:0>2d}:{mins:0>2d}'.format(hrs=int(hrs), mins=int(mins))
    def get_absent(self, obj):
        absent = obj.absent
        hrs = absent // 3600
        mins = absent % 3600 // 60
        return '{hrs:0>2d}:{mins:0>2d}'.format(hrs=int(hrs), mins=int(mins))
    class Meta:
        model = MeetingPayloadBase
        fields = ('id', 'emp_code', 'first_name', 'meeting_name', 'meeting_date', 'meeting_period', 'meeting_duration', 'clock_in', 'clock_out', 'attended_duration', 'late_in', 'early_out', 'absent')
class MeetingAttendanceFilter(django_filters.rest_framework.FilterSet):
    meeting = django_filters.CharFilter(field_name='meeting__alias', lookup_expr='contains')
    start_date = django_filters.DateFilter(field_name='meeting_date', lookup_expr='gte')
    end_date = django_filters.DateFilter(field_name='meeting_date', lookup_expr='lte')
class MeetingAttendanceViewSet(mixins.ListModelMixin, UserLayUIGenericViewSet):
    model = MeetingPayloadBase
    queryset = MeetingPayloadBase.objects.get_queryset()
    serializer_dict = {'list': MeetingAttendanceSerializer, 'export': MeetingAttendanceSerializer}
    filterset_class = MeetingAttendanceFilter
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)
    def get_queryset(self):
        queryset = super(MeetingAttendanceViewSet, self).get_queryset()
        queryset = queryset.select_related('emp', 'meeting').order_by('-meeting_date')
        return queryset
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        else:
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
    def get_file_title(self):
        return _('meeting.menus.meetingAttendanceReport')