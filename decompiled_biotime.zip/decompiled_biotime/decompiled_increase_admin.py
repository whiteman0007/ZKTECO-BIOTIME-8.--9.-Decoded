# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\report\\admin\\increase_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:15 UTC (1750673055)

from mysite.payroll.report.base import PayRollReportAdminBase
from mysite.payroll.report.decorators import report_admin_register
from mysite.payroll.api.serializers import PayrollPayloadIncreaseSerializer
from mysite.att.models.model_paycode import PayCode, OVERTIME
@report_admin_register()
class IncreaseAdmin(PayRollReportAdminBase):
    api_url = '/payroll/api/report/payrollincrease/'
    model_name = 'PayrollIncrease'
    api_serializer = PayrollPayloadIncreaseSerializer
    view_name = 'payrollincrease_report'
    list_display = ['emp_code', 'first_name', 'last_name', 'department', 'calc_time', 'basic_salary', 'effective_date', 'payment_mode_display', 'increase', 'extra_increase', 'loan_increase', 'advance_increase', 'reimbursement', 'total_increase']
    hidden_fields = ()
    def get_pay_codes(self):
        return PayCode.objects.filter(code_type=OVERTIME).order_by('display_order').values('id', 'is_display')
    def insert_ext_cols(self, cols):
        self.add_emp_ext_cols(cols)
        self.add_paycode_cols(cols)