# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\emp_workcode_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att import const
from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import EmployeeWorkCodeViewSet
from mysite.att.api.report_views.employee_workcode import EmployeeWorkCodeSerializer
@report_register()
class EmpWorkCodeAdmin(ReportAdminBase):
    model_name = 'empWorkCodeReport'
    view_name = 'emp_workcode_report'
    template = 'att/report_new/employeeworkcodereport.html'
    api_view = EmployeeWorkCodeViewSet
    serializer = EmployeeWorkCodeSerializer
    data_source = '/att/api/empWorkCodeReport/'
    list_display = ('emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'company_code', 'company_name', 'dept_code', 'dept_name', 'position_code', 'position_name')
    hidden_fields = ('last_name', 'nick_name', 'gender', 'dept_code', 'position_code', 'position_name')
    sort_fields = ('emp_code',)
    add_paycode_column = True
    paycode_type = const.WORKCODE