# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\admin\\announcement_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from django.db.models import Q
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin.kernel import ZKModelAdmin
from mysite.mobile import actions
from mysite.mobile.models import Announcement
from mysite.personnel.models import Employee
from mysite.accounts.models import MyUser
@admin.register(Announcement)
class AnnouncementAdmin(ZKModelAdmin):
    list_display = ('get_subject_display', 'category', 'get_emp_display', 'get_content_display', 'get_sender_display', 'system_sender', 'create_time')
    query_fields = ('subject', 'category', 'content')
    list_filter = ('subject', 'category', 'receiver__emp_code', 'receiver__first_name')
    actions = [actions.push_public_notice, actions.push_private_notice]
    def save_model(self, request, obj, form, change):
        """\n        Given a model instance save it to the database.\n        """
        obj.save(request=request)
    def get_subject_display(self, obj):
        subject = obj.subject
        if subject and len(subject) > 50:
                subject = '{0}....'.format(obj.subject[:50])
        return subject
    get_subject_display.short_description = _('announcement_filed_subject')
    def get_content_display(self, obj):
        content = obj.content
        if obj.content and len(obj.content) > 50:
                content = '{0}....'.format(obj.content[:50])
        return content
    get_content_display.short_description = _('announcement_filed_content')
    def get_emp_display(self, obj):
        if not obj.receiver:
            return '{0}'.format(_('announce_all_emp'))
        else:
            return obj.receiver.emp_code
    get_emp_display.short_description = _('announcement_filed_emp')
    def get_sender_display(self, obj):
        if not obj.sender:
            return '{0}'.format(obj.system_sender)
        else:
            return '{0}'.format(obj.sender)
    def get_queryset(self, request):
        qs = super(AnnouncementAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                user_list = MyUser.objects.filter(Q(auth_dept__in=request.user.auth_dept.all()) | Q(is_superuser=True)).distinct()
                user_name = [u.username for u in user_list] if user_list else []
                emp = Employee.objects.filter(department__in=request.user.auth_dept.all())
                emp_code = [e.emp_code for e in emp] if emp else []
                qs = qs.filter(Q(receiver__department__in=request.user.auth_dept.all()) & Q(category=2) | Q(category=1) & Q(system_sender__in=user_name) & Q(sender=None) | Q(category=1) & Q(sender__in=emp_code) & Q(system_sender=None))
            if request.user.auth_area.exists():
                user_list = MyUser.objects.filter(Q(auth_area__in=request.user.auth_area.all()) | Q(is_superuser=True)).distinct()
                user_name = [u.username for u in user_list] if user_list else []
                emp = Employee.objects.filter(area__in=request.user.auth_area.all()).distinct()
                emp_code = [e.emp_code for e in emp] if emp else []
                emp_list_by_area = Employee.objects.filter(area__in=request.user.auth_area.all())
                qs = qs.filter(Q(receiver__in=emp_list_by_area) & Q(category=2) | Q(category=1) & Q(system_sender__in=user_name) & Q(sender=None) | Q(category=1) & Q(sender__in=emp_code) & Q(system_sender=None))
        return qs
    get_sender_display.short_description = _('announcement_filed_sender')