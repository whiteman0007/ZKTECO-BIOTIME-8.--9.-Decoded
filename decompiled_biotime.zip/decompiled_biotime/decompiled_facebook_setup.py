# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\facebook_setup.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from rest_framework import serializers
class FacebookConnectionSetupSerializer(serializers.Serializer):
    authorization = serializers.CharField()
    token = serializers.IntegerField()
    bot_id = serializers.CharField()
    bot_pid = serializers.CharField()
    pat = serializers.CharField()
    def validate_authorization(self, value):
        return value
    def validate_token(self, value):
        return value
    def validate_bot_id(self, value):
        return value
    def validate_bot_pid(self, value):
        return value
    def validate_pat(self, value):
        return value
class FacebookSetupSerializer(serializers.Serializer):
    authorization = serializers.CharField()
    token = serializers.IntegerField()
    bot_id = serializers.CharField()
    bot_pid = serializers.CharField()
    pat = serializers.CharField()
    def validate_authorization(self, value):
        return value
    def validate_token(self, value):
        return value
    def validate_bot_id(self, value):
        return value
    def validate_bot_pid(self, value):
        return value
    def validate_pat(self, value):
        return value