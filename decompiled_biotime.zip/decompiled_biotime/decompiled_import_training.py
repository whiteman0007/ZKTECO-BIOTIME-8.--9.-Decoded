# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\data_import\\import_training.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
from django.utils.translation import gettext_lazy as _
from mysite.personnel.models import Employee
from mysite.att.data_import.import_base import DataImportBase
from mysite.att.models import PayCode, Training
class TrainingImport(DataImportBase):
    def init_required_fields(self):
        self.required_fields = [_('emp_field_employeeCode'), _('training.fields.payCode'), _('training_field_startTime'), _('training_field_endTime'), _('training_field_applyReason')]
    def clean_row(self, index, row):
        row_index = index + 1
        emp_code = row.get(_('emp_field_employeeCode'), None)
        if not emp_code:
            self.errors.append(_('error_data_on_row(%(index)s)_the_employee_code_is_empty') % {'index': row_index})
            return
        else:
            employee = Employee.objects.filter(emp_code=emp_code).first()
            if not employee:
                self.errors.append(_('error_data_on_row(%(index)s)_the_employee_code_does_not_exists') % {'index': row_index})
                return
            else:
                start_time = row.get(_('training_field_startTime'), None)
                if not start_time:
                    self.errors.append(_('error_data_on_row(%(index)s)_the_start_time_is_empty') % {'index': row_index})
                    return
                else:
                    if not isinstance(start_time, datetime.datetime):
                        try:
                            start_time = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
                        except Exception as e:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_format_of_start_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': row_index})
                            return None
                    end_time = row.get(_('training_field_endTime'), None)
                    if not end_time:
                        self.errors.append(_('error_data_on_row(%(index)s)_the_end_time_is_empty') % {'index': row_index})
                        return
                    else:
                        if not isinstance(end_time, datetime.datetime):
                            try:
                                end_time = datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
                            except Exception as e:
                                self.errors.append(_('error_data_on_row(%(index)s)_the_format_of_end_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': row_index})
                                return None
                        if start_time >= end_time:
                            self.errors.append(str(_('error_data_on_row(%(index)s)') % {'index': row_index}) + ', ' + str(_('leave_time_invalid_range')))
                        pay_code = row.get(_('training.fields.payCode'), None)
                        if not pay_code:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_leave_category_is_empty') % {'index': row_index})
                        pay_code = PayCode.objects.filter(name=pay_code).first()
                        if not pay_code:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_leave_category_is_not_in_category_name') % {'index': row_index})
                        reason = row.get(_('training_field_applyReason'), None)
                        return {'employee': employee, 'start_time': start_time, 'end_time': end_time, 'pay_code': pay_code, 'apply_reason': reason}
    def save(self, index, row):
        from mysite.workflow.models_choices import PENDING
        user = self.request.user
        if self.overwrite:
            obj = Training.objects.filter(employee=row['employee'], start_time=row['start_time'], end_time=row['end_time'], approval_status=PENDING).first()
            if obj:
                obj.start_time = row['start_time']
                obj.end_time = row['end_time']
                obj.pay_code = row['pay_code']
                obj.apply_reason = row['apply_reason']
                obj.save(force_update=True)
                if self.auto_approve:
                    obj.do_approve(user, _('common.fields.autoApproved'))
                return obj
        try:
            obj = Training(**row)
            obj.save(force_insert=True)
            if self.auto_approve:
                obj.do_approve(user, _('common.fields.autoApproved'))
            return obj
        except Exception as e:
            self.errors.append(str(e))