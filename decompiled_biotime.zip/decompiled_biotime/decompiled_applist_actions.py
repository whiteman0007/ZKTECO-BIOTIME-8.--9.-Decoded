# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\actions\\applist_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.mobile.choices import IOS, ANDROID
class PushNotificationForm(forms.ZKActionForm):
    content = forms.TextField(label=_('appNotice_field_content'), required=True)
class PushNotification(admin.ZKModelAction):
    """\n    Push Notification\n    """
    batch_select = True
    verbose_name = _('mobile_action_pushNotification')
    help_text = _('mobile_action_pushNotificationHelpTxt')
    short_description = _('mobile_action_pushNotificationDescription')
    action_form = PushNotificationForm
    def action(self, *args, **kwargs):
        from mysite.admin.exceptions import AdminRuntimeWarning
        from mysite.mobile.utils import push_notification2ios, push_notification2android, check_fcm_conn
        objects = self.objects
        notification = kwargs['content']
        for obj in objects:
            if not obj.device_token:
                continue
            else:
                if not obj.active or not obj.enable:
                    continue
                else:
                    try:
                        if obj.client_category == IOS:
                            push_notification2ios(obj.device_token, notification)
                        else:
                            if obj.client_category == ANDROID:
                                if not check_fcm_conn():
                                    raise AdminRuntimeWarning('conn https://fcm.googleapis.com/fcm/send error.')
                                else:
                                    push_notification2android(obj.device_token, notification)
                    except Exception as e:
                        raise AdminRuntimeWarning(e)
class ForceOffline(admin.ZKModelAction):
    """\n    Force Offline\n    """
    batch_select = True
    verbose_name = _('applist_action_forceOffline')
    short_description = verbose_name
    help_text = _('applist_action_forceOffline')
    confirmation = _('force_offline_confirm {0} {1}')
    def action(self, *args, **kwargs):
        objects = self.objects
        for obj in objects:
            obj.active = 0
            obj.save()
class Disable(admin.ZKModelAction):
    """\n    Disable Client\n    """
    batch_select = True
    verbose_name = _('applist_action_disable')
    short_description = verbose_name
    help_text = _('applist_action_disable')
    confirmation = _('app_account_disable_confirm {0} {1}')
    def action(self, *args, **kwargs):
        objects = self.objects
        for obj in objects:
            obj.enable = 0
            obj.save()
class Enable(admin.ZKModelAction):
    """\n    Enable Client\n    """
    batch_select = True
    verbose_name = _('applist_action_enable')
    short_description = verbose_name
    help_text = _('applist_action_enable')
    confirmation = _('app_account_enable_confirm {0} {1}')
    def action(self, *args, **kwargs):
        objects = self.objects
        for obj in objects:
            obj.enable = 1
            obj.save()