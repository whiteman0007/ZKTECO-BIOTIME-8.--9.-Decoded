# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\company_setting.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import os
import json
import base64
import re
from django.conf import settings
from rest_framework import serializers
from mysite.tools.image_utils import base64_to_image, crop_image, image_to_base64
class CompanySettingUpdateSerializer(serializers.Serializer):
    company_name = serializers.CharField(required=False, allow_blank=True, default='')
    name_pos = serializers.CharField(required=False, allow_blank=True, default='0')
    logo_pos = serializers.CharField(required=False, allow_blank=True, default='0')
    logo_img = serializers.CharField(required=False, allow_blank=True, default='')
    logo_crop_info = serializers.CharField(required=False, allow_blank=True, default='')
    def validate(self, data):
        logo_img = data.get('logo_img')
        logo_crop_info = data.get('logo_crop_info')
        if logo_crop_info:
            crop_info = json.loads(logo_crop_info)
            prefix = ''
            img_format = 'png'
            prefix_search = re.search('^data:image/.+;base64,', logo_img)
            if prefix_search:
                prefix = prefix_search.group()
                img_format = prefix.split('/')[(-1)].split(';')[0]
            logo_img = base64_to_image(logo_img)
            logo_img = crop_image(logo_img, crop_info)
            logo_img = logo_img.resize((200, 75))
            logo_img = image_to_base64(logo_img, img_format)
            logo_img = prefix + logo_img
            data['logo_img'] = logo_img
            data['logo_crop_info'] = ''
        if logo_img:
            if not os.path.exists(settings.COMPANY_LOGO_STORE_PATH):
                os.mkdir(settings.COMPANY_LOGO_STORE_PATH)
            img_info, img_code = logo_img.split(',')
            with open(settings.COMPANY_LOGO, 'wb') as f:
                f.write(base64.b64decode(img_code))
        return data