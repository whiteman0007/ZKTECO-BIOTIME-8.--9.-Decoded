# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\admin\\emp_loan_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:11 UTC (1750673051)

from mysite import admin
from mysite.admin.kernel import ZKModelAdmin
from mysite.payroll.models import EmpLoan
from mysite.payroll.forms.emploan_forms import AddEmpLoanAction
@admin.register(EmpLoan)
class EmpLoanAdmin(ZKModelAdmin):
    list_display = ('id', 'emp_code', 'first_name', 'last_name', 'department', 'loan_amount', 'loan_time', 'refund_cycle', 'per_cycle_refund', 'loan_clean_time', 'remark')
    list_filter = ('employee__emp_code', 'employee__first_name', 'employee__last_name', 'loan_amount', 'loan_time')
    actions = [AddEmpLoanAction]
    def get_queryset(self, request):
        qs = super(EmpLoanAdmin, self).get_queryset(request)
        qs = qs.select_related('employee', 'employee__department')
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                qs = qs.filter(employee__department__in=request.user.auth_dept.all())
            if request.user.auth_area.exists():
                qs = qs.filter(employee__area__in=request.user.auth_area.all()).distinct()
        return qs
    def has_add_permission(self, request):
        return False