# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\leavegroupdetail_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models import LeaveGroupDetail
from mysite.att.models_choices import LEAVE_TYPE, BASED_ON_SERVICE, COMPENSATORY_LEAVE
from django.utils.translation import gettext_lazy as _
class LeaveGroupDetailSerializer(serializers.ModelSerializer):
    is_base_on_service = serializers.SerializerMethodField(source='get_is_base_on_service')
    pay_code_name = serializers.CharField(source='pay_code.name', allow_null=True)
    leave_type_display = serializers.CharField(source='get_leave_type_display')
    min_leave_time = serializers.SerializerMethodField(source='get_min_leave_time')
    def get_is_base_on_service(self, obj):
        return 1 if obj.leave_type == BASED_ON_SERVICE or obj.leave_type == COMPENSATORY_LEAVE else 0
    def get_min_leave_time(self, obj):
        if obj.pay_code.is_cpl():
            return '{value}({unit})'.format(value=obj.min_leave_day, unit=_('time.units.hour'))
        else:
            return '{value}({unit})'.format(value=obj.min_leave_day, unit=_('time.units.day'))
    class Meta:
        model = LeaveGroupDetail
        fields = ['id', 'leave_type_display', 'is_base_on_service', 'pay_code', 'pay_code_id', 'pay_code_name', 'allow_leave_day', 'min_leave_day', 'deduct_holiday_day', 'leave_entitlement', 'leave_interval', 'leave_distribution_time', 'min_leave_time', 'start_day', 'set_hire_day', 'allow_balance', 'max_balance', 'leave_group']