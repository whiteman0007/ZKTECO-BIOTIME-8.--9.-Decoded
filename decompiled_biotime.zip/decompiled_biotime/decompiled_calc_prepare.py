# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\calc_new\\calc_prepare.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import collections
import datetime
from django.conf import settings
from django.db.models import F, DateField, Q, Value, CharField, IntegerField
from django.db.models.functions import Cast, TruncDate
from mysite.att.calc_new.utils import get_punch_states, cache_data, get_shift_detail_index
from mysite.att.models import Holiday, Overtime, Leave, TemporarySchedule, AttSchedule, GroupSchedule, DepartmentSchedule, AttShift, Training
from mysite.iclock.models import Transaction
from mysite.workflow.models_choices import APPROVED
from mysite.utils import get_dt4mssql
def get_transaction_dict(emp, start_date, end_date, punch_state_cache=None):
    """Get transaction between start_date, end_date\n\n    1. Consider the calc end date across Date needs an extra day\n    2. Only the first attendance record is taken in the same minute\n    3. The six clocking statuses defined in attendance calculation are         converted into actual letters to represent non numbers\n\n    Args:\n        emp: Employee obj\n        start_date: datetime.date\n        end_date: datetime.date\n\n    Returns:\n        res_dict: defaultdict\n            key: datetime.date\n            value: [dict, ...]\n    """
    if punch_state_cache:
        punch_state = punch_state_cache
    else:
        punch_state = get_punch_states()
    punch_state_dict = {}
    for k, v in punch_state.items():
        punch_state_dict[v] = k
    _start_date = start_date - datetime.timedelta(days=3)
    _end_date = end_date + datetime.timedelta(days=3)
    queryset = Transaction.objects.get_att_queryset().filter(emp=emp, punch_time__gte=_start_date, punch_time__lte=datetime.datetime.combine(_end_date, datetime.time.max))
    queryset = queryset.annotate(att_date=TruncDate('punch_time'), used=Cast(Value(0), output_field=IntegerField()))
    queryset = queryset.values('id', 'punch_time', 'punch_state', 'used', 'work_code').order_by('punch_time')
    res_dict = collections.defaultdict(list)
    for record in queryset:
        if settings.NEED_REMOVE_SECONDS:
            record['punch_time'] = datetime.datetime(record['punch_time'].year, record['punch_time'].month, record['punch_time'].day, record['punch_time'].hour, record['punch_time'].minute)
        if res_dict[record['punch_time'].date()]:
            last_time = res_dict[record['punch_time'].date()][(-1)]['punch_time']
            if int((record['punch_time'] - last_time).total_seconds()) < 60 and record['punch_time'].minute == last_time.minute:
                    continue
        record['source_punch_state'] = record['punch_state']
        record['punch_state'] = punch_state_dict.get(record['punch_state'], record['punch_state'])
        res_dict[record['punch_time'].date()].append(record)
    return res_dict
def get_employee_policy(emp):
    """Get employee policy\n\n    GroupPolicy > DepartmentPolicy > AttPolicy\n\n    Returns:\n        Policy obj\n    """
    from mysite.att.models import GroupPolicy, DepartmentPolicy, AttPolicy
    globle_policy = AttPolicy.cache_data()
    if hasattr(emp, 'attemployee') and emp.attemployee.group:
        g_policy = GroupPolicy.cache_data(emp.attemployee.group.id)
        if g_policy:
            g_policy.start_of_week = globle_policy.start_of_week
            return g_policy
    d_policy = DepartmentPolicy.cache_data(emp.department.id)
    if d_policy:
        d_policy.start_of_week = globle_policy.start_of_week
        return d_policy
    else:
        return globle_policy
def get_employee_holiday(emp, start_date, end_date):
    """Get employee policy\n\n    GroupHoliday > DepartmentHoliday > AllHoliday\n\n    Returns:\n        result: dict\n            key: datetime.date\n            value: holiday obj\n    """
    if not emp.attemployee or not emp.attemployee.enable_holiday:
        return {}
    else:
        result = {}
        all_holiday_qs = []
        all_holidays = []
        if hasattr(emp, 'attemployee') and emp.attemployee.group:
                all_holidays.append({'att_group': emp.attemployee.group})
        all_holidays.append({'department': emp.department})
        all_holidays.append({'department__isnull': True, 'att_group__isnull': True})
        for _filter in all_holidays:
            qs = Holiday.objects.filter(**_filter).exclude(Q(end_date__lt=start_date) | Q(start_date__gt=end_date)).order_by('start_date')
            all_holiday_qs.append(qs)
        for qs in all_holiday_qs:
            for holiday in qs:
                for i in range(holiday.duration_day):
                    _date = get_dt4mssql(holiday.start_date, 1) + datetime.timedelta(days=i)
                    if not result.get(_date):
                        result[_date] = holiday
        return result
def get_employee_overtime(emp, start_date, end_date):
    """Get employee overtime\n\n    Args:\n        emp: Employee obj\n        start_date: datetime.date\n        end_date: datetime.date\n\n    Returns:\n        res_dict: defaultdict\n            key: datetime.date\n            value: [dict, ...]\n    """
    if not emp.attemployee or not emp.attemployee.enable_overtime:
        return collections.defaultdict(list)
    else:
        _start_date = start_date - datetime.timedelta(days=3)
        _end_date = end_date + datetime.timedelta(days=3)
        queryset = Overtime.objects.filter(employee=emp, approval_status=APPROVED).exclude(Q(end_time__lt=_start_date) | Q(start_time__gt=datetime.datetime.combine(_end_date, datetime.time.max)))
        queryset = queryset.values('id', 'start_time', 'end_time', 'pay_code_id').order_by('start_time')
        res_dict = collections.defaultdict(list)
        for record in queryset:
            _start = record['start_time'].date()
            _end = record['end_time'].date()
            _date = _start
            while _date <= _end:
                res_dict[_date].append(record)
                _date += datetime.timedelta(days=1)
        return res_dict
def get_employee_leave(emp, start_date, end_date):
    """Get employee leave\n\n    Args:\n        emp: Employee obj\n        start_date: datetime.date\n        end_date: datetime.date\n\n    Returns:\n        res_dict: defaultdict\n            key: datetime.date\n            value: [dict, ...]\n    """
    _start_date = start_date - datetime.timedelta(days=3)
    _end_date = end_date + datetime.timedelta(days=3)
    queryset = Leave.objects.filter(employee=emp, approval_status=APPROVED).exclude(Q(end_time__lt=_start_date) | Q(start_time__gt=datetime.datetime.combine(_end_date, datetime.time.max)))
    queryset = queryset.values('id', 'start_time', 'end_time', 'pay_code_id', 'pay_code__name').order_by('start_time')
    res_dict = collections.defaultdict(list)
    for record in queryset:
        _start = record['start_time'].date()
        _end = record['end_time'].date()
        _date = _start
        while _date <= _end:
            res_dict[_date].append(record)
            _date += datetime.timedelta(days=1)
    return res_dict
def get_employee_training(emp, start_date, end_date):
    """Get employee training\n\n    Args:\n        emp: Employee obj\n        start_date: datetime.date\n        end_date: datetime.date\n\n    Returns:\n        res_dict: defaultdict\n            key: datetime.date\n            value: [dict, ...]\n    """
    _start_date = start_date - datetime.timedelta(days=3)
    _end_date = end_date + datetime.timedelta(days=3)
    queryset = Training.objects.filter(employee=emp, approval_status=APPROVED).exclude(Q(end_time__lt=_start_date) | Q(start_time__gt=datetime.datetime.combine(_end_date, datetime.time.max)))
    queryset = queryset.values('id', 'start_time', 'end_time', 'pay_code_id', 'pay_code__name').order_by('start_time')
    res_dict = collections.defaultdict(list)
    for record in queryset:
        _start = record['start_time'].date()
        _end = record['end_time'].date()
        _date = _start
        while _date <= _end:
            res_dict[_date].append(record)
            _date += datetime.timedelta(days=1)
    return res_dict
def get_employee_schedule(emp, start_date, end_date):
    # irreducible cflow, using cdg fallback
    """Get employee schedule\n\n    TemporarySchedule > Holiday > AttSchedule > GroupSchedule > DepartmentSchedule\n\n    Args:\n        emp: Employee obj\n        start_date: datetime.date\n        end_date: datetime.date\n\n    Returns:\n        res_dict: defaultdict\n            key: datetime.date\n            value: [dict, ...]\n    """
    result = {}
    _date = start_date
    while _date <= end_date:
        result[_date] = {}
        _date += datetime.timedelta(days=1)
    if not emp.attemployee or not emp.attemployee.enable_schedule:
        return result
    else:
        if emp.hire_date:
            start_date = start_date if start_date > get_dt4mssql(emp.hire_date, 1) else get_dt4mssql(emp.hire_date, 1)
        if emp.resign_date:
            end_date = end_date if end_date < get_dt4mssql(emp.resign_date, 1) else get_dt4mssql(emp.resign_date, 1)
        temp_sche = TemporarySchedule.objects.filter(employee=emp, att_date__gte=start_date, att_date__lte=end_date)
        for sche in temp_sche:
            if not result.get(sche.att_date):
                result[sche.att_date] = {'sche_type': 'temp_sche', 'intervals': [sche.time_interval_id]}
            else:
                result[sche.att_date]['intervals'].append(sche.time_interval_id)
        all_sche_qs = []
        all_sches = [(AttSchedule, {'employee': emp}, 'emp_sche')]
        if hasattr(emp, 'attemployee') and emp.attemployee.group:
                all_sches.append((GroupSchedule, {'group': emp.attemployee.group}, 'group_sche'))
        all_sches.append((DepartmentSchedule, {'department': emp.department}, 'dept_sche'))
        for ScheClass, _filter, _type in all_sches:
            qs = ScheClass.objects.filter(**_filter).exclude(Q(end_date__lt=start_date) | Q(start_date__gt=end_date)).order_by('start_date').annotate(sche_type=Value(_type, output_field=CharField()), shift_unit=Cast('shift__cycle_unit', output_field=IntegerField()), shift_cycle=Cast('shift__shift_cycle', output_field=IntegerField()))
            all_sche_qs.append(qs)
        sche_dict = {}
        for qs in all_sche_qs:
            pass
        for sche in qs:
            temp_date = get_dt4mssql(sche.start_date, 1)
            while temp_date <= get_dt4mssql(sche.end_date, 1):
                if start_date <= temp_date <= end_date and (not result.get(temp_date)):
                            shift_obj = cache_data(sche_dict, sche.shift_id, AttShift)
                            unit, cycle = (sche.shift_unit, sche.shift_cycle)
                            detail_index = get_shift_detail_index(temp_date, sche.start_date, unit, cycle)
                            intervals = sche_dict[sche.shift_id].shift_detail_dict.get(detail_index, [])
                            result[temp_date] = {'sche_type': sche.sche_type, 'shift_obj': shift_obj, 'intervals': intervals}
                temp_date += datetime.timedelta(days=1)
        none_flag = False
        for i in result:
            if not result[i]:
                none_flag = True
                break
        if none_flag is False:
            break
    holidays = get_employee_holiday(emp, start_date, end_date)
    for _date in holidays:
        if _date in result:
            sche = result.get(_date)
            if sche and sche['sche_type']!= 'temp_sche':
                if sche['intervals']:
                    result[_date]['holiday'] = holidays[_date]
                if not sche:
                    result[_date]['holiday'] = holidays[_date]
    return result
def get_leave_group_detail(emp):
    from mysite.att.models import LeaveGroupDetail
    leave_group_detail = LeaveGroupDetail.objects.filter(leave_group_id=emp.leave_group) if emp.leave_group else []
    group_detail = {detail.pay_code_id: detail for detail in leave_group_detail}
    return group_detail