# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0001_initial.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.manager
import django.utils.timezone
import mysite._plugins.multi_email_field.fields
import mysite.admin.fields
import mysite.base.models.modelless
class Migration(migrations.Migration):
    initial = True
    dependencies = [('auth', '0008_alter_user_username_max_length')]
    def description(adminLog_field_description, ip_address, GenericIPAddressField, adminLog_field_ipAddress, can_routable, BooleanField, adminLog_field_routable, op_time, DateTimeField, adminLog_field_operationTime, base.models.adminLog, view, verbose_name_plural, default_permissions, name, fields, options, AttParam, ParaName, paraname, 30, Att parameter name, db_column, ParaType, paratype, 10, Att parameter type, ParaValue, paravalue, 250, Att parameter value, attendance rule, attparam, db_table, attParamDepts, ruleName, rulename, 40, unique, DeptID, IntegerField, deptid, Operator, operator, 20, OpTime, optime, AutoAttExportTask, create_time, baseModel_field_createTime, auto_now_add, create_user, 150, baseModel_field_createUser, ParaType, paratype, 10, Att parameter type, ParaValue, paravalue, 250, Att parameter value, attendance rule, attparam, db_table, attParamDepts, ruleName, rulename, 40, unique, DeptID, IntegerField, deptid, Operator, operator, 20, OpTime, optime, AutoAttExportTask, create_time, baseModel_field_createTime, auto_now_add, create_user, 150,