# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\visitor\\migrations\\0010_alter_bio_type_903.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:28 UTC (1750702768)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('visitor', '0009_alter_visitorbiophoto_first_name_and_more')]
    operations = [migrations.AlterField(model_name='visitorbiodata', name='bio_type', field=models.IntegerField(choices=[(1, 'bio_fingerprint'), (2, 'bio_face'), (3, 'bio.types.vocalPrint'), (4, 'bio.types.iris'), (5, 'bio.types.retina'), (6, 'bio.types.palmPrint'), (7, 'bio_finger_vein'), (8, 'bio.types.palmVein'), (9, 'bio.types.visibleFace'), (10, 'bio.types.visiblePalm')], verbose_name='bioData_field_bioType'))]