# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\leave_balance_summary.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

import django_filters
from celery_progress.backend import AbstractProgressRecorder
from django.db.models import Q
from django.utils import translation
from django.utils.translation import gettext_lazy as _, activate
from django_filters.rest_framework import FilterSet
from rest_framework import serializers
from mysite.admin.models import STATUS_VALID
from mysite.api.serializers.utils import EmployeeExtraInfoSerializer
from mysite.att.api.serializers import NoneSerializer
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.models import LeaveGroup, LeaveYearBalance
from mysite.att.models.model_paycode import PayCode, LEAVE
from mysite.att.models_choices import UNLIMITED_LEAVE
from mysite.base import const
from mysite.base.models import SecurityPolicy
from mysite.personnel.models import Employee
from mysite.utils import progress_record
class LeaveBalanceSummarySerializer(serializers.ModelSerializer, EmployeeExtraInfoSerializer):
    company_code = serializers.CharField(label=_('company.field.code'), source='emp__company__company_code', allow_null=True)
    company_name = serializers.CharField(label=_('company.field.name'), source='emp__company__company_name', allow_null=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='department__dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='department__dept_name', allow_null=True)
    position_code = serializers.CharField(label=_('report_column_positionCode'), source='position__position_code', allow_null=True)
    position_name = serializers.CharField(label=_('report_column_positionName'), source='position__position_name', allow_null=True)
    leave_group_name = serializers.SerializerMethodField(label=_('report.columns.leave_group'))
    leave_group = serializers.IntegerField(label=_('report.columns.leave_group'), allow_null=True)
    emp_id_key = 'id'
    def __init__(self, *args, **kwargs):
        super(LeaveBalanceSummarySerializer, self).__init__(*args, **kwargs)
        self.pay_codes = PayCode.objects.filter(code_type=LEAVE).order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        for pay_code in self.pay_codes:
            self.fields['sum_leave_day_paycode_{index}'.format(index=pay_code['id'])] = serializers.CharField(allow_null=True, default='-', label=str(_('report.columns.usedleaveDay')))
            self.fields['sum_exceed_leave_day_paycode_{index}'.format(index=pay_code['id'])] = serializers.CharField(allow_null=True, default='-', label=str(_('report.columns.exceedLeaveDay')))
            self.fields['sum_total_leave_day_paycode_{index}'.format(index=pay_code['id'])] = serializers.CharField(allow_null=True, default='-', label=str(_('report.columns.totalLeaveDay')))
            self.fields['sum_remain_leave_day_paycode_{index}'.format(index=pay_code['id'])] = serializers.CharField(allow_null=True, default='-', label=str(_('report.columns.remainLeaveDay')))
    class Meta:
        model = Employee
        fields = ('id', 'emp_code', 'first_name', 'last_name', 'dept_code', 'dept_name', 'position_code', 'position_name', 'gender', 'nickname', 'leave_group', 'leave_group_name', 'company_code', 'company_name')
    def get_leave_group_name(self, obj):
        if obj.get('leave_group', None):
            return LeaveGroup.objects.get(id=obj.get('leave_group')).name
        else:
            return None
    def get_fields(self):
        fields = super(LeaveBalanceSummarySerializer, self).get_fields()
        self.add_emp_extra_info_fields(fields)
        return fields
class LeaveBalanceSummaryFilter(FilterSet):
    employees = django_filters.CharFilter(method='employee_filter')
    departments = django_filters.CharFilter(method='department_filter')
    leave_groups = django_filters.CharFilter(method='leave_group_filter')
    def leave_group_filter(self, queryset, name, value):
        if not value or str(value) == '0':
            return queryset
        else:
            queryset = queryset.filter(leave_group=value)
            return queryset
    def employee_filter(self, queryset, name, value):
        if not value or str(value) == '-1':
            return queryset
        else:
            objs = value.split(',')
            try:
                objs = [int(i) for i in objs if i]
            except ValueError:
                objs = []
            queryset = queryset.filter(id__in=objs)
            return queryset
    def department_filter(self, queryset, name, value):
        if not value or str(value) == '-1':
            return queryset
        else:
            objs = value.split(',')
            try:
                objs = [int(i) for i in objs if i]
            except ValueError:
                objs = []
            queryset = queryset.filter(department_id__in=objs)
            from mysite.att.global_cache import C_ATT_RULE
            C_ATT_RULE.action_init()
            resign_emp = str(C_ATT_RULE.value.get('resign_emp'))
            if resign_emp == '0':
                queryset = queryset.filter(Q(status=STATUS_VALID) | Q(status=None))
            return queryset
    class Meta:
        model = Employee
        fields = ['employees', 'departments']
    @property
    def qs(self):
        queryset = super(LeaveBalanceSummaryFilter, self).qs
        employees = self.data.get('employees') or '-1'
        departments = self.data.get('departments') or '-1'
        if employees == '-1' and departments == '-1':
            return queryset.none()
        else:
            return queryset
class LeaveBalanceSummaryViewSet(ReportUserGenericViewSet):
    model = Employee
    queryset = Employee.objects.filter(leave_group__isnull=False).select_related()
    filterset_class = LeaveBalanceSummaryFilter
    export_head = {}
    serializer_dict = {'list': LeaveBalanceSummarySerializer, 'export': LeaveBalanceSummarySerializer}
    def __init__(self, *args, **kwargs):
        super(LeaveBalanceSummaryViewSet, self).__init__(*args, **kwargs)
    def annotate_queryset(self, queryset):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            ordering = ['emp_code_digit', 'emp_code']
        else:
            ordering = ['emp_code']
        queryset = queryset.values('id', 'emp_code', 'first_name', 'last_name', 'nickname', 'gender', 'department__dept_code', 'department__dept_name', 'position__position_code', 'position__position_name', 'leave_group', 'emp_code_digit').order_by(*ordering)
        return queryset
    def get_serializer(self, *args, **kwargs):
        serializer = super(LeaveBalanceSummaryViewSet, self).get_serializer(*args, **kwargs)
        if kwargs.get('many') is not True:
            return serializer
        else:
            serializer = self.get_leave_group_detail(serializer)
            return serializer
    def get_leave_group_detail(self, serializer):
        year = None
        if getattr(self, 'request', None):
            year = self.request.query_params.get('year', None)
        else:
            if getattr(self, 'year', None):
                year = self.year
        if not year:
            import datetime
            year = datetime.datetime.now().year
        for data in serializer.data:
            emp_code = data['emp_code']
            ly_list = LeaveYearBalance.objects.filter(employee__emp_code=emp_code, year=year).values('pay_code_id', 'leave_day', 'entitlement_days', 'leave_type', 'pre_balance')
            for ly_obj in ly_list:
                ly_obj_c = ly_obj['pay_code_id']
                data['sum_leave_day_paycode_{index}'.format(index=ly_obj_c)] = ly_obj['leave_day']
                if ly_obj['leave_type'] == UNLIMITED_LEAVE:
                    data['sum_exceed_leave_day_paycode_{index}'.format(index=ly_obj_c)] = '-'
                    data['sum_total_leave_day_paycode_{index}'.format(index=ly_obj_c)] = '-'
                    data['sum_remain_leave_day_paycode_{index}'.format(index=ly_obj_c)] = '-'
                else:
                    pre_ly = LeaveYearBalance.objects.filter(employee__emp_code=emp_code, year=int(year) - 1, pay_code_id=ly_obj_c).first()
                    data['sum_exceed_leave_day_paycode_{index}'.format(index=ly_obj_c)] = max(ly_obj['leave_day'] - ly_obj['entitlement_days'] - ly_obj['pre_balance'], 0)
                    data['sum_total_leave_day_paycode_{index}'.format(index=ly_obj_c)] = ly_obj['entitlement_days'] + ly_obj['pre_balance']
                    data['sum_remain_leave_day_paycode_{index}'.format(index=ly_obj_c)] = max(ly_obj['entitlement_days'] - ly_obj['leave_day'] - (pre_ly.exceed_leave_day if pre_ly else 0) + ly_obj['pre_balance'], 0)
        return serializer
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)
    def get_file_title(self):
        return _('att.menus.reports.leaveBalanceSummary')
    def export_executor(self, request, progress_recorder):
        if request.LANGUAGE_CODE:
            activate(request.LANGUAGE_CODE)
        self.request_user = request.user
        self.file_format = request.query_params.get('export_type', '')
        self.progress_recorder = progress_recorder
        self.export_headers = request.query_params.get('export_headers', '').split(',')
        self.group_by = request.query_params.get('export_style', None)
        self.page_wise = request.query_params.get('page_wise', False)
        self.start_date = request.query_params.get('year', False)
        self.end_date = request.query_params.get('year', False)
        self.pdf_page_size = request.query_params.get('pdf-page-size', '')
        self.orientation = request.query_params.get('orientation', '')
        self.password = None
        self.rowspan = 2
        if self.file_format in ['pdf', 'xls', 'txt', 'csv']:
            encryption_type = int(request.query_params.get('export_encryption_type', 0))
            if encryption_type == const.ENCRYPTION_SYS_PASSWORD:
                security_policy = SecurityPolicy.default()
                if security_policy.export_encryption:
                    self.password = security_policy.get_export_encryption_password()
            else:
                if encryption_type == const.ENCRYPTION_SELF_PASSWORD:
                    self.password = request.query_params.get('export_encryption_password', '')
        export_data = self.get_export_data(request)
        self.data_len = len(export_data)
        if not self.data_len:
            if isinstance(self.progress_recorder, AbstractProgressRecorder):
                self.progress_recorder.stop_task(0, 1, _('progress.status.empty'))
            else:
                if self.progress_recorder:
                    import json
                    self.progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('progress.status.empty')), 'channel': ''})})
            return ''
        else:
            progress_record(self.progress_recorder, 0, self.data_len, _('exportProgress.status.generateDoc'))
            data_fields = list(export_data[0].keys()) if len(export_data) else []
            headers_list = []
            for header in self.export_headers:
                if header in data_fields:
                    headers_list.append(header)
            self.export_headers = headers_list
            if translation.get_language_bidi():
                self.export_headers = list(reversed(self.export_headers))
            file_path = None
            from mysite.att.report.admin import LeaveBalanceSummaryAdmin
            leavebalancesummary = LeaveBalanceSummaryAdmin()
            self.headers_translation = leavebalancesummary.get_layui_cols(self.export_headers)
            if self.file_format == 'csv':
                file_path = self.export_to_csv(self.export_headers, export_data, as_file=True)
            else:
                if self.file_format == 'xls':
                    self.rowspan_headers = leavebalancesummary.get_layui_cols_for_export_xls(self.export_headers)
                    file_path = self.export_to_xls(self.export_headers, export_data, as_file=True)
                else:
                    if self.file_format == 'txt':
                        file_path = self.export_to_txt(self.export_headers, export_data, as_file=True)
                    else:
                        if self.file_format == 'pdf':
                            file_path = self.export_to_pdf(self.export_headers, export_data, as_file=True)
            if file_path:
                progress_record(self.progress_recorder, self.data_len, self.data_len, _('exportProgress.status.finished'))
                file_url = '/files{path}'.format(path=file_path.split('files')[1])
                return file_url
    def auto_export(self, options, headers, cols, export_data, file_name, **kwargs):
        from mysite.att.report.admin import LeaveBalanceSummaryAdmin
        leavebalancesummary = LeaveBalanceSummaryAdmin()
        self.file_format = options.get('export_format', 'csv')
        self.export_headers = []
        self.password = None
        self.rowspan = 2
        self.show_header = options.get('contains_heads', True)
        self.page_wise = False
        self.group_by = None
        self.pdf_page_size = ''
        self.orientation = ''
        if self.file_format in ['pdf', 'xls', 'txt', 'csv']:
            encryption_type = int(options.get('export_encryption_type', 0))
            if encryption_type == const.ENCRYPTION_SYS_PASSWORD:
                security_policy = SecurityPolicy.default()
                if security_policy.export_encryption:
                    self.password = security_policy.get_export_encryption_password()
            else:
                if encryption_type == const.ENCRYPTION_SELF_PASSWORD:
                    self.password = options.get('export_encryption_password', '')
        for row in cols:
            for item in row:
                if 'field' in item and (not item.get('hide', 0)):
                        self.export_headers.append(item['field'])
        self.data_len = len(export_data)
        data_fields = list(export_data[0].keys()) if len(export_data) else []
        headers_list = []
        for header in self.export_headers:
            if header in data_fields:
                headers_list.append(header)
        self.export_headers = headers_list
        if translation.get_language_bidi():
            self.export_headers = list(reversed(self.export_headers))
        self.headers_translation = leavebalancesummary.get_layui_cols(self.export_headers)
        file_path = None
        if self.file_format == 'csv':
            file_path = self.export_to_csv(self.export_headers, export_data, file_name=file_name, as_file=True)
        else:
            if self.file_format == 'xls':
                self.rowspan_headers = leavebalancesummary.get_layui_cols_for_export_xls(self.export_headers)
                file_path = self.export_to_xls(self.export_headers, export_data, file_name=file_name, as_file=True)
            else:
                if self.file_format == 'txt':
                    file_path = self.export_to_txt(self.export_headers, export_data, file_name=file_name, as_file=True)
                else:
                    if self.file_format == 'pdf':
                        file_path = self.export_to_pdf(self.export_headers, export_data, file_name=file_name, as_file=True)
        return file_path
    def get_headers_translation(self, export_headers):
        if self.file_format in ['xls', 'csv', 'txt']:
            return super(LeaveBalanceSummaryViewSet, self).get_headers_translation(export_headers)
        else:
            headers = []
            parentkey = []
            headers1 = ''
            headers2 = ''
            for i, th_i in enumerate(self.headers_translation[0]):
                if th_i.get('rowspan', None) == 2:
                    th_class = 'layui-unselect'
                    div_class = 'laytable-cell-2-0-%(key)s' % {'key': i}
                else:
                    if th_i.get('rowspan', None) == 4:
                        th_class = 'layui-table-col-special'
                        div_class = 'laytable-cell-group'
                headers_i = '<th data-field=\"%(field)s\" data-key=\"2-0-%(key)s\" colspan=\"%(colspan)s\" rowspan=\"%(rowspan)s\" class=\"%(th_class)s\"> <div class=\"layui-table-cell %(div_class)s\"><span>%(title)s</span ></div></th>' % {'field': th_i.get('field', ''), 'key': i, 'colspan': th_i.get('colspan', '1'), 'rowspan': th_i.get('rowspan', '1'), 'th_class': th_class, 'div_class': div_class, 'title': str(th_i['title'])}
                parentkey.append(i)
                headers1 += headers_i
            for i, th_i in enumerate(self.headers_translation[1]):
                headers_ii = '<th data-field=\"%(field)s\" data-key=\"2-1-%(key)s\" data-parentkey=\"0-%(parentkey)s\" colspan=\"%(colspan)s\" rowspan=\"%(rowspan)s\" class=\"\"><div class=\"layui-table-cell laytable-cell-2-0-%(key)s\"><span>%(title)s</span ></div> </th>' % {'field': th_i.get('field', ''), 'key': i, 'parentkey': parentkey[1], 'colspan': th_i.get('colspan', '1'), 'rowspan': th_i.get('rowspan', '1'), 'title': str(th_i['title'])}
                headers2 += headers_ii
            headers.append(str(headers1))
            headers.append(str(headers2))
            return headers