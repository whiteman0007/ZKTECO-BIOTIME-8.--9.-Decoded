# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\dbbackup_log_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from mysite import admin
from mysite.admin import ZKModelAdmin
from mysite.base.models import DBBackupLog
from mysite.base import actions
@admin.register(DBBackupLog)
class DBBackupLogAdmin(ZKModelAdmin):
    list_display = ['db_type', 'db_name', 'operator', 'backup_time', 'backup_file', 'backup_status', 'remark']
    list_filter = ('operator', 'backup_time', 'backup_status', 'remark')
    sort_fields = ['backup_time']
    actions = (actions.DBBackupAuto, actions.DBBackupManually, actions.DBRestoreManually)
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False