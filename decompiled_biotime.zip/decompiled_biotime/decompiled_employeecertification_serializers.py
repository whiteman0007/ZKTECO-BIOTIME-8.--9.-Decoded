# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\api\\serializers\\employeecertification_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

from rest_framework import serializers
from mysite.personnel.models.model_employee_certification import EmployeeCertification
from mysite.personnel.models.model_employee import Employee
from mysite.personnel.models.model_certification import Certification
from mysite.utils import get_dt4mssql
class CertificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Certification
        fields = '__all__'
class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = ['id', 'emp_code', 'first_name', 'last_name']
class EmployeeCertificationSerializer(serializers.ModelSerializer):
    certification = CertificationSerializer()
    emp_code = serializers.CharField(source='employee.emp_code', allow_null=True)
    first_name = serializers.CharField(source='employee.first_name', allow_null=True)
    last_name = serializers.CharField(source='employee.last_name', allow_null=True)
    cert_name = serializers.CharField(source='certification.cert_name', allow_null=True)
    email_alert = serializers.CharField(source='get_email_alert_display', allow_null=True)
    expire_on = serializers.SerializerMethodField()
    def get_expire_on(self, obj):
        return get_dt4mssql(obj.expire_on, 1)
    class Meta:
        model = EmployeeCertification
        fields = ['id', 'emp_code', 'first_name', 'last_name', 'certification', 'cert_name', 'expire_on', 'email_alert', 'before', 'certification_code', 'file_name']
class EmployeeCertificationExportSerializer(serializers.ModelSerializer):
    employee = serializers.CharField(source='employee.emp_code', allow_null=True)
    certification = serializers.CharField(source='certification.cert_name', allow_null=True)
    expire_on = serializers.SerializerMethodField()
    def get_expire_on(self, obj):
        return get_dt4mssql(obj.expire_on, 1)
    class Meta:
        model = EmployeeCertification
        fields = ['id', 'employee', 'certification', 'expire_on', 'email_alert', 'before']
class EmployeeCertificationCreateSerializer(serializers.ModelSerializer):
    expire_on = serializers.SerializerMethodField()
    def get_expire_on(self, obj):
        return get_dt4mssql(obj.expire_on, 1)
    class Meta:
        model = EmployeeCertification
        fields = ['id', 'employee', 'certification', 'expire_on', 'email_alert', 'before']
class EmployeeCertificationEditSerializer(serializers.ModelSerializer):
    expire_on = serializers.SerializerMethodField()
    def get_expire_on(self, obj):
        return get_dt4mssql(obj.expire_on, 1)
    class Meta:
        model = EmployeeCertification
        fields = ['id', 'employee', 'certification', 'expire_on', 'email_alert', 'before']
        extra_kwargs = {'employee': {'required': False, 'allow_null': False}, 'certification': {'required': False, 'allow_null': False}}