# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\management\\commands\\do_update_extra_operation.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:23 UTC (1750673063)

import json
from django.core.management.base import BaseCommand
from mysite.att.models.model_attrule import AttRule, DEFAULT_PARAMS
class Command(BaseCommand):
    help = 'do extra operation when update from 8.0.1 to 8.0.2'
    def handle(self, *args, **options):
        main()
        print('do extra operation when update from 8.0.1 to 8.0.2 Done')
def main():
    old_rule = AttRule.objects.filter(param_name='global_att_rule')[0]
    old_params = json.loads(old_rule.param_value)
    new_params = DEFAULT_PARAMS.copy()
    new_params.update(old_params)
    if new_params.get('miss_in') not in [0, 1, 2, '0', '1', '2']:
        new_params['miss_in'] = 0
    if new_params.get('miss_out') not in [0, 1, 2, '0', '1', '2']:
        new_params['miss_out'] = 0
    old_rule.param_value = json.dumps(new_params)
    old_rule.save()