# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0011_auto_20220118_1536.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0010_auto_20220106_1103')]
    operations = [migrations.AlterField(model_name='attpolicy', name='weekly_ot', field=models.BooleanField(default=False, verbose_name='attShift.fields.enableOvertimeRule')), migrations.AlterField(model_name='departmentpolicy', name='weekly_ot', field=models.BooleanField(default=False, verbose_name='attShift.fields.enableOvertimeRule')), migrations.AlterField(model_name='grouppolicy', name='weekly_ot', field=models.BooleanField(default=False, verbose_name='attShift.fields.enableOvertimeRule'))]