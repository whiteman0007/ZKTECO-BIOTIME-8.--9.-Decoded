# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\accounts\\backends.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:51 UTC (1750672971)

import logging
import json
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from mysite._utils import getattr_ex
from mysite.personnel.models import Employee
from mysite.base.models import SystemSetting
from mysite.tools.ldap_utils import LDAPClient
from mysite.authorized import auth_settings
class ModelBackend(object):
    """\n    Authenticates against settings.AUTH_USER_MODEL.\n    """
    def authenticate(self, request, username=None, password=None, **kwargs):
        # irreducible cflow, using cdg fallback
        UserType = kwargs.get('UserType', 'user')
        if UserType == 'user':
            UserModel = get_user_model()
            if username is None:
                username = kwargs.get(UserModel.USERNAME_FIELD)
            user = UserModel._default_manager.get_by_natural_key(username)
            if user.check_password(password) and self.user_can_authenticate(user):
                user.login_type = 0
                if user.login_count is not None:
                    user.login_count += 1
                else:
                    user.login_count = 0
                user.save(update_fields=['login_count'])
                return user
                if self.enable_ldap_auth('user_auth'):
                    user = self._authenticate_ldap(username, password, UserType)
                    if user:
                        return user
                            except UserModel.DoesNotExist:
                                if self.enable_ldap_auth('user_auth'):
                                    user = self._authenticate_ldap(username, password, UserType)
                                    if user:
                                        return user
                                        UserModel().set_password(password)
            if UserType == 'employee':
                pass
            if getattr_ex(settings, 'MULTI_COMPANY_EXT', False) and auth_settings.AUTHORIZED_FIRM > 1:
                emp = Employee.objects.filter(email=username).first()
            else:
                emp = Employee.objects.filter(emp_code=username).first()
            if emp and emp.check_password(password) and self.user_can_authenticate(emp):
                emp.login_type = 1
                return emp
                if self.enable_ldap_auth('emp_auth'):
                    emp = self._authenticate_ldap(username, password, UserType)
                    if emp:
                        return emp
                    except Exception:
                            return
    def _get_user_permissions(self, user_obj):
        return user_obj.user_permissions.all()
    def _get_group_permissions(self, user_obj):
        user_groups_field = get_user_model()._meta.get_field('groups')
        user_groups_query = 'group__%s' % user_groups_field.related_query_name()
        return Permission.objects.filter(**{user_groups_query: user_obj})
    def _get_permissions(self, user_obj, obj, from_name):
        """\n        Returns the permissions of `user_obj` from `from_name`. `from_name` can\n        be either \"group\" or \"user\" to return permissions from\n        `_get_group_permissions` or `_get_user_permissions` respectively.\n        """
        if not user_obj.is_active or user_obj.is_anonymous or obj is not None:
            return set()
        else:
            perm_cache_name = '_%s_perm_cache' % from_name
            if not hasattr(user_obj, perm_cache_name):
                if user_obj.is_superuser:
                    perms = Permission.objects.all()
                else:
                    perms = getattr(self, '_get_%s_permissions' % from_name)(user_obj)
                perms = perms.values_list('content_type__app_label', 'codename').order_by()
                setattr(user_obj, perm_cache_name, set(('%s.%s' % (ct, name) for ct, name in perms)))
            return getattr(user_obj, perm_cache_name)
    def get_user_permissions(self, user_obj, obj=None):
        """\n        Returns a set of permission strings the user `user_obj` has from their\n        `user_permissions`.\n        """
        return self._get_permissions(user_obj, obj, 'user')
    def get_group_permissions(self, user_obj, obj=None):
        """\n        Returns a set of permission strings the user `user_obj` has from the\n        groups they belong.\n        """
        return self._get_permissions(user_obj, obj, 'group')
    def get_all_permissions(self, user_obj, obj=None):
        if not user_obj.is_active or user_obj.is_anonymous or obj is not None:
            return set()
        else:
            if not hasattr(user_obj, '_perm_cache'):
                user_obj._perm_cache = self.get_user_permissions(user_obj)
                user_obj._perm_cache.update(self.get_group_permissions(user_obj))
            return user_obj._perm_cache
    def has_perm(self, user_obj, perm, obj=None):
        if not user_obj.is_active:
            return False
        else:
            return perm in self.get_all_permissions(user_obj, obj)
    def has_model_op_perms(self, user_obj, app_label, model_name):
        """\n        Returns True if user_obj has any operation permissions in the given app_label.\n        """
        if not user_obj.is_active:
            return False
        else:
            for perm in self.get_all_permissions(user_obj):
                assert '.' in perm, 'The format of permissions is wrong'
                _app_label, op_and_model = perm.split('.')
                if _app_label == app_label and op_and_model.endswith(model_name) or (model_name == 'transaction' and op_and_model.endswith('transaction') and (_app_label == 'iclock')):
                    return True
            return False
    def get_user(self, user_id):
        UserModel = get_user_model()
        try:
            return UserModel._default_manager.get(pk=user_id)
        except UserModel.DoesNotExist:
            return None
    def user_can_authenticate(self, user):
        """\n        Reject users with is_active=False. Custom user models that don\'t have\n        that attribute are allowed.\n        """
        is_active = getattr(user, 'is_active', None)
        if isinstance(user, Employee):
            return is_active and is_active is not None
        else:
            return is_active or is_active is None
    def _authenticate_user(self, username, password, user_type, **kwargs):
        # irreducible cflow, using cdg fallback
        if user_type == 'user':
            UserModel = get_user_model()
            if username is None:
                username = kwargs.get(UserModel.USERNAME_FIELD)
            user = UserModel._default_manager.get_by_natural_key(username)
            if not user.check_password(password) or self.user_can_authenticate(user):
                    user.login_type = 0
                    if user.login_count is not None:
                        user.login_count += 1
                    else:
                        user.login_count = 0
                    user.save(update_fields=['login_count'])
                    return user
                    except UserModel.DoesNotExist:
                        UserModel().set_password(password)
            if user_type == 'employee':
                from mysite.personnel.models import Employee
            emp = Employee.objects.filter(emp_code=username).first()
            if emp and emp.check_password(password) and self.user_can_authenticate(emp):
                        emp.login_type = 1
                        return emp
                            except Exception:
                                    return
    def enable_ldap_auth(self, enable_key):
        ad_obj = SystemSetting.objects.filter(name='ldap_setup').first()
        if ad_obj:
            ad_info = json.loads(ad_obj.value)
            return ad_info.get(enable_key, False)
        else:
            return False
    def _authenticate_ldap(self, username, password, user_type):
        # irreducible cflow, using cdg fallback
        with LDAPClient() as _ldap:
            _ldap.bind()
                except Exception:
                    logging.getLogger(__name__).exception('_ldap.bind error')
                        return
                    if user_type == 'user':
                        return _ldap.auth_user(username, password)
                        return _ldap.auth_employee(username, password)
                            except Exception:
                                    return
class EmployeeBackend(ModelBackend):
    def get_user(self, user_id):
        from mysite.personnel.models import Employee
        try:
            return Employee.objects.get(pk=user_id)
        except Employee.DoesNotExist:
            return None
class RemoteUserBackend(ModelBackend):
    """\n    This backend is to be used in conjunction with the ``RemoteUserMiddleware``\n    found in the middleware module of this package, and is used when the server\n    is handling authentication outside of Django.\n\n    By default, the ``authenticate`` method creates ``User`` objects for\n    usernames that don\'t already exist in the database.  Subclasses can disable\n    this behavior by setting the ``create_unknown_user`` attribute to\n    ``False``.\n    """
    create_unknown_user = True
    def authenticate(self, remote_user):
        """\n        The username passed as ``remote_user`` is considered trusted.  This\n        method simply returns the ``User`` object with the given username,\n        creating a new ``User`` object if ``create_unknown_user`` is ``True``.\n\n        Returns None if ``create_unknown_user`` is ``False`` and a ``User``\n        object with the given username is not found in the database.\n        """
        if not remote_user:
            return
        else:
            user = None
            username = self.clean_username(remote_user)
            UserModel = get_user_model()
            if self.create_unknown_user:
                user, created = UserModel.objects.get_or_create(**{UserModel.USERNAME_FIELD: username})
                if created:
                    user = self.configure_user(user)
            else:
                try:
                    user = UserModel.objects.get_by_natural_key(username)
                except UserModel.DoesNotExist:
                    pass
            return user
    def clean_username(self, username):
        """\n        Performs any cleaning on the \"username\" prior to using it to get or\n        create the user object.  Returns the cleaned username.\n\n        By default, returns the username unchanged.\n        """
        return username
    def configure_user(self, user):
        """\n        Configures a user after creation and returns the updated user.\n\n        By default, returns the user unmodified.\n        """
        return user