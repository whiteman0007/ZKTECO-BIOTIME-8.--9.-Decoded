# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\admin\\acc_groups_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.core.cache import cache
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.acc import actions
from mysite.acc.forms import AccGroupForm, AccGroupEditForm
from mysite.acc.models import AccGroups
from mysite.admin.action import ActionTuple
from mysite.personnel import fields, widgets
from mysite.personnel.models import Area
@admin.register(AccGroups)
class AccGroupsAdmin(admin.ZKModelAdmin):
    formfield_overrides = {fields.AreaForeignKey: {'widget': widgets.AreaRadioSelect}}
    list_display = ('id', 'group_no', 'group_name', 'verify_mode', 'timezone1', 'timezone2', 'timezone3', 'is_include_holiday')
    list_filter = ('group_no', 'group_name')
    add_form = AccGroupForm
    form = AccGroupEditForm
    action_sets = (ActionTuple(_('op_menu_group_groupMenu'), (actions.CloneToArea, actions.SetEmployeeGroup)),)
    def clone_to_area(self, request, objects):
        areas = request.POST.getlist('area', [])
        if not areas:
            raise Exception('{error}'.format(error=_('employee_actionError_areaIsRequired')))
        else:
            for obj in objects:
                for area in areas:
                    if obj.area.pk == area:
                        continue
                    else:
                        obj.clone_group(area)
    def get_queryset(self, request):
        from mysite.acc.utils import get_current_area
        qs = super(AccGroupsAdmin, self).get_queryset(request)
        is_get_table = request.path.find('table') > 0 or request.path.find('export') > 0
        current_area = get_current_area(request)
        if is_get_table:
            qs = qs.filter(area__pk=current_area)
        if not request.user.is_superuser and request.user.auth_area.all():
                qs = qs.filter(area__in=request.user.auth_area.all()).distinct()
        return qs
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(AccGroupsAdmin, self).get_form(request, obj, **defaults)