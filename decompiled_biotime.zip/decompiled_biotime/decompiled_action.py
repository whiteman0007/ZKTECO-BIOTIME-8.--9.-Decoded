# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\admin\\action.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:52 UTC (1750672972)

from collections import namedtuple
from django.utils.translation import gettext_lazy as _
ActionTuple = namedtuple('ActionTuple', ['name', 'cls'])
ActionToolbar = namedtuple('ActionToolbar', ['name', 'multi', 'action'])
class ZKAction(object):
    verbose_name = None
    short_description = None
    help_txt = None
    action_form = None
    action_template = None
    action_icon = ''
    action_url = None
    confirmation = ''
    confirmation_times = 1
    action_confirm_password = False
    batch_select = False
    unique_object_required = False
    px_height = None
    px_width = None
    visible = True
    async_progress = False
    use_asgi = False
    @property
    def asgi_url(self):
        if self.admin and self.admin.model:
            return '/async/{0}/{1}/import/'.format(self.admin.model._meta.app_label, self.admin.model._meta.model_name)
        else:
            return ''
    def __init__(self, request, admin=None, obj_ids=None):
        self.request = request
        self.admin = admin
        self.obj_ids = obj_ids
        self.valid_form = None
    def action(self, *args, **kwargs):
        raise NotImplementedError('subclasses of ZKAction must override action() method')
class ActionHandleError(Exception):
    """Some errors happened during handle procedure of the requested action """
    pass
class ZKModelAction(ZKAction):
    def __init__(self, request, admin=None, obj_ids=None):
        super(ZKModelAction, self).__init__(request, admin, obj_ids)
        if self.obj_ids:
            cls = self.admin.model
            self.objects = cls.objects.filter(id__in=self.obj_ids)
        else:
            self.objects = None
class GeneralActionDelete(ZKModelAction):
    verbose_name = _('common_action_deleteSelectedRecord')
    short_description = _('common_action_deleteSelectedRecordDescription')
    help_txt = _('common_action_deleteSelectedRecordHelpTxt')
    action_icon = ''
    confirmation = _('are_you_sure_to_delete_the_selected')
    batch_select = True
    def action(self, **kwargs):
        # irreducible cflow, using cdg fallback
        from mysite.admin.utils import get_error_message
        from django.db import ProgrammingError
        from django.db import DatabaseError
        from django.core.cache import cache
        remove_non_permitted = kwargs.get('remove_denied', {})
        if len(remove_non_permitted) == len(self.objects):
            pass
        else:
            for k in getattr(self.admin, 'cache_keys', []):
                cache.delete(k)
                user = self.request.user
                if not user.is_superuser:
                    cache.delete('{key}_{user_id}'.format(key=k, user_id=user.id))
        msg_list = []
        objects = []
        for obj in self.objects:
            pass
        obj_id = getattr(obj, 'id', getattr(obj, 'pk'))
        error_msg = remove_non_permitted.get(obj_id, None)
        if error_msg is not None:
            pass
        msg_list.append(str(error_msg))
        continue
        objects.append('{obj}'.format(obj=obj))
        obj.delete()
        except (ProgrammingError, DatabaseError) as e:
            pass
        msg_list.append(get_error_message(e, field='<{}>'.format(obj.__class__.__name__)))
        if len(msg_list) > 0:
            raise ActionHandleError(';'.join(msg_list))
        else:
            return '|{obj}'.format(obj=','.join(objects))
class GeneralActionNew(ZKModelAction):
    verbose_name = _('common_action_new')
    short_description = _('common_action_newDescription')
    help_txt = _('common_action_newHelpTxt')
    action_icon = ''
    action_url = '%s_%s_add'
    batch_select = False
    def action(self, **kwargs):
        return