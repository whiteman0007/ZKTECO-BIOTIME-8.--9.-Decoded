# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\visitor\\admin\\certification_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

from django.conf import settings
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.admin.action import ActionHandleError
from mysite.admin.kernel import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.visitor.models import Certification as VisitorCertification
class CertificationForm(ModelForm):
    class Meta:
        model = VisitorCertification
        fields = '__all__'
class CertificationAdmin(ZKModelAdmin):
    list_display = ('id', 'cert_code', 'cert_name')
    sort_fields = ('cert_code', 'cert_name')
    list_filter = ('cert_code', 'cert_name')
    import_fields = ('cert_code', 'cert_name')
    form = CertificationForm
    actions = []
    def get_form(self, request, obj=None, change=False, **kwargs):
        self.form.user = request.user
        return super().get_form(request, obj, change, **kwargs)
    def response_action_post(self, request, cls, form, action_instance):
        from mysite.visitor.models import Visitor
        from mysite.visitor.models import Reservation
        if 'Delete' in str(action_instance.verbose_name):
            message = []
            for result in action_instance.objects:
                if len(Visitor.objects.filter(cert_type=result)) > 0 or len(Reservation.objects.filter(cert_type=result)) > 0:
                    message = _('some_certification_still_use_by_personnel_and_cannot_be_cancelled')
            if message:
                raise ActionHandleError(message)
        return super(CertificationAdmin, self).response_action_post(request, cls, form, action_instance)
    def get_changeform_initial_data(self, request):
        initial = super(CertificationAdmin, self).get_changeform_initial_data(request)
        try:
            from mysite.personnel.utils import get_num_from_list
            cert_code_obj = get_num_from_list(list(VisitorCertification.objects.values_list('cert_code', flat=True)))
            initial['cert_code'] = max(cert_code_obj) + 1
        except Exception:
            pass
        return initial
zk_site.register(VisitorCertification, CertificationAdmin)