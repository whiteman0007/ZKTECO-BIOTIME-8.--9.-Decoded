# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\auth_group_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:08 UTC (1750672988)

from django.contrib import admin
from django.contrib.auth.models import Group
from django.utils.translation import gettext_lazy as _
from mysite.admin import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.base.actions.group_actions import GroupDelete
from mysite.base.admin.forms.auth_group_form import GroupChangeForm
try:
    admin.site.unregister(Group)
except admin.sites.NotRegistered:
    pass
class GroupAdmin(ZKModelAdmin):
    list_display = ['id', 'get_group_name']
    list_filter = ['name']
    actions = [GroupDelete]
    cache_keys = ('group_tree_nodes',)
    form = GroupChangeForm
    def get_group_name(self, obj):
        return obj.name
    get_group_name.short_description = _('group_field_name')
    def formfield_for_manytomany(self, db_field, request=None, **kwargs):
        if db_field.name == 'permissions':
            qs = kwargs.get('queryset', db_field.remote_field.model.objects)
            kwargs['queryset'] = qs.select_related('content_type')
        return super(GroupAdmin, self).formfield_for_manytomany(db_field, request=request, **kwargs)
zk_site.register(Group, GroupAdmin)