# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\settings\\components\\config_file.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:10 UTC (1750702750)

import configparser
from mysite.settings.components.paths import CONFIG_FILE_NAME, SYS_FILE_NAME
CONFIG_FILE = configparser.RawConfigParser(strict=False, allow_no_value=True)
CONFIG_FILE.read(CONFIG_FILE_NAME, encoding='utf-8-sig')
SYS_FILE = configparser.RawConfigParser(strict=False, allow_no_value=True)
SYS_FILE.read(SYS_FILE_NAME, encoding='utf-8-sig')