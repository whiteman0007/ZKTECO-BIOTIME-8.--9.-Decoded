# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\config.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

__author__ = 'Jerry'
from django.utils.translation import gettext_lazy as _
ATT_MANUALLOG_TEMPLATE = [_('emp_field_employeeCode'), _('manualLog_field_punchTime'), _('manualLog_field_punchState'), _('manualLog_field_workCode'), _('manualLog_field_applyReason')]
ATT_LEAVE_TEMPLATE = [_('emp_field_employeeCode'), _('leaveCategory'), _('leave_field_startTime'), _('leave_field_endTime'), _('leave_field_applyReason')]
ATT_OVERTIME_TEMPLATE = [_('emp_field_employeeCode'), _('overtime_field_overtimeType'), _('overtime_field_startTime'), _('overtime_field_endTime'), _('overtime_field_applyReason')]
ATT_TRAINING_TEMPLATE = [_('emp_field_employeeCode'), _('training.fields.payCode'), _('training_field_startTime'), _('training_field_endTime'), _('training_field_applyReason')]
ATT_EMPSCHEDULE_TEMPLATE = [_('emp_field_employeeCode'), _('common_date'), _('timeInterval_field_alias'), _('tempSchedule_field_workType'), _('tempSchedule_field_rule')]
ATT_TEMPSCHEDULE_TEMPLATE = [_('temporarySchedule.fields.employee')]
ATT_TEMPORARYSCHEDULE_TEMPLATE = [_('temporarySchedule.fields.employee')]
ATT_ATTSCHEDULE_TEMPLATE = [_('emp_field_employeeCode'), _('attShift_field_alias'), _('schedule_field_startDate'), _('schedule_field_endDate')]