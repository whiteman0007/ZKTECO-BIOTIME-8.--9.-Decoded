# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\staff\\forms\\manual_log_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:31 UTC (1750673071)

import datetime
from django.forms import ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.iclock.models import TerminalWorkCode
from mysite.personnel.models import Employee
class ManualLogForm(forms.ZKActionForm):
    punch_time = forms.DateTimeField(label=_('manualLog_field_punchTime'))
    punch_state = forms.ChoiceField(label=_('manualLog_field_punchState'), choices=(('255', '255'),))
    work_code = ModelChoiceField(label=_('manualLog_field_workCode'), queryset=TerminalWorkCode.objects.get_queryset(), required=False)
    apply_reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    def __init__(self, *args, **kwargs):
        from mysite.base.utils import get_punch_states
        super(ManualLogForm, self).__init__(*args, **kwargs)
        self.fields['punch_state'].choices = get_punch_states()
class EmployeeManualLogGetForm(forms.ZKActionForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset(), disabled=True)
    punch_time = forms.DateTimeField(label=_('manualLog_field_punchTime'))
    punch_state = forms.ChoiceField(label=_('manualLog_field_punchState'), choices=(('255', '255'),))
    work_code = ModelChoiceField(queryset=TerminalWorkCode.objects.get_queryset(), required=False)
    apply_reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    def __init__(self, request, *args, **kwargs):
        from mysite.base.utils import get_punch_states
        from mysite.att.models import PayloadTimeCard
        from mysite.personnel.models import Employee
        super(EmployeeManualLogGetForm, self).__init__(*args, **kwargs)
        self.fields['punch_state'].choices = get_punch_states()
        emp_id = request.GET.get('emp_id', None)
        att_date = request.GET.get('att_date', None)
        timetable_id = request.GET.get('timetable_id', None)
        if not timetable_id:
            timetable_id = None
        if att_date:
            att_date = datetime.datetime.strptime(att_date, '%Y-%m-%d')
        if not emp_id:
            return
        else:
            obj = PayloadTimeCard.objects.filter(emp_id=emp_id, att_date=att_date, time_table_id=timetable_id).first()
            if not obj:
                return
            else:
                self.fields['employee'].queryset = Employee.objects.filter(id=emp_id)
                self.fields['employee'].initial = obj.emp
                self.fields['punch_time'].initial = obj.check_in
class EmployeeManualLogPostForm(EmployeeManualLogGetForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset())