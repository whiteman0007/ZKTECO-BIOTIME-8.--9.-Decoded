# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\api\\views\\base_view.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from rest_framework.decorators import api_view
from rest_framework.response import Response
from mysite.tools.progress_utils import get_progress_info
@api_view()
def get_task_progress(request):
    task_id = request.query_params.get('task_id', '')
    info = get_progress_info(task_id)
    if not info:
        info = {'status_code': (-2), 'percentage': 0, 'message': 'task progress info not found'}
    return Response(info)