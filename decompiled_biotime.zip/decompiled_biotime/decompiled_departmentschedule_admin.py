# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\departmentschedule_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from mysite import admin, config
from mysite.att.models import DepartmentSchedule
from mysite.att.actions import AddDepartmentSchedule
@admin.register(DepartmentSchedule)
class DepartmentScheduleAdmin(admin.ZKModelAdmin):
    def department_code(self, obj):
        return obj.department.dept_code or ''
    department_code.short_description = _('department_field_code')
    def department_name(self, obj):
        return obj.department.dept_name or ''
    department_name.short_description = _('department_filed_name')
    def employee_count(self, obj):
        return obj.department.employee_set.count()
    employee_count.short_description = _('department_filed_employeeCount')
    def shift_alias(self, obj):
        return obj.shift.alias
    shift_alias.short_description = _('attShift_field_alias')
    list_display = ('id', 'department_code', 'department_name', 'employee_count', 'shift_alias', 'start_date', 'end_date')
    list_filter = ('department__dept_code', 'department__dept_name', 'shift__alias')
    actions = (AddDepartmentSchedule,)
    def has_change_permission(self, request, obj=None):
        return False
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        queryset = super(DepartmentScheduleAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_dept.exists():
                queryset = queryset.filter(department__in=request.user.auth_dept.all())
        if not request.user.is_superuser and request.user.assign_company:
                queryset = queryset.filter(department__company=request.user.assign_company)
        queryset = queryset.select_related()
        return queryset