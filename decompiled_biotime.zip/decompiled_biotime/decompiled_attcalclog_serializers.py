# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\attcalclog_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models.model_attcalclog import AttCalcLog
from mysite.att.api.serializers import util_serializers
class AttCalcLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttCalcLog
        fields = '__all__'
class AttCalcLogCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttCalcLog
        fields = '__all__'
class AttCalcLogEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttCalcLog
        fields = '__all__'
class AttCalcLogActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AttCalcLog
        action_type_choices = (('delete', 'delete'),)