# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\data_import\\import_overtime.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
from django.utils.translation import gettext_lazy as _
from mysite.att.models.model_paycode import PayCode
from mysite.att.models.model_overtime import Overtime
from mysite.att.data_import.import_base import DataImportBase
from mysite.accounts.models import MyUser
from mysite.personnel.models import Employee
class ImportOvertimeData:
    def __init__(self, import_file, overwrite, request_user):
        self.import_file = import_file
        self.overwrite = overwrite
        self.row_recodes = []
        self.clean_recodes = []
        self.must_fields = [_('overtime_field_employee'), _('overtime_field_startTime'), _('overtime_field_endTime'), _('overtime_field_overtimeType'), _('overtime_field_applyReason')]
        self.error_info = []
        self.request_user = request_user
        if isinstance(request_user, MyUser):
            self.is_staff = False
        else:
            assert isinstance(request_user, Employee), 'request_user, not MyUser or Employee'
            self.is_staff = True
    def exe_import_data(self):
        from mysite.tools.file_utils import FileReader
        self.row_recodes = FileReader(import_file=self.import_file, must_fields=self.must_fields).dict_read()
        print('########### read data success... ########### ')
        print('########### row_data count: %s' % len(self.row_recodes))
        result = self.clean_data()
        if result is False or self.error_info:
            raise Exception(','.join(self.error_info))
        else:
            print('########### clean data success... ###########')
            print('########### clean data count: %s' % len(self.clean_recodes))
            result = self.data_insert()
            if result is False or self.error_info:
                raise Exception(','.join(self.error_info))
            else:
                print('########### data insert success... ###########')
    def clean_data(self):
        from mysite.personnel.models import Employee
        if self.error_info:
            return False
        else:
            for recode in self.row_recodes:
                data = {}
                data['employee'] = str(recode.get(_('overtime_field_employee')))
                data['start_time'] = recode.get(_('overtime_field_startTime'))
                data['end_time'] = recode.get(_('overtime_field_endTime'))
                data['pay_code'] = recode.get(_('overtime_field_overtimeType'))
                data['apply_reason'] = recode.get(_('overtime_field_applyReason'))
                data['index'] = recode.get('index')
                if data['employee'] is None or data['employee'] == '':
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_is_empty') % {'index': recode['index']})
                else:
                    if self.is_staff and data['employee']!= self.request_user.emp_code:
                            self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_is_not_itself') % {'index': recode['index']})
                    emp = Employee.objects.filter(emp_code=data['employee']).first()
                    if emp:
                        data['employee'] = emp
                    else:
                        self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_does_not_exists') % {'index': recode['index']})
                if data['start_time'] is None or data['start_time'] == '':
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_start_time_is_empty') % {'index': recode['index']})
                else:
                    if not isinstance(data['start_time'], datetime.datetime):
                        try:
                            data['start_time'] = datetime.datetime.strptime(data['start_time'], '%Y-%m-%d %H:%M:%S')
                        except Exception:
                            self.error_info.append(_('error_data_on_row(%(index)s)_the_format_of_start_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': recode['index']})
                if data['end_time'] is None or data['end_time'] == '':
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_end_time_is_empty') % {'index': recode['index']})
                else:
                    if not isinstance(data['end_time'], datetime.datetime):
                        try:
                            data['end_time'] = datetime.datetime.strptime(data['end_time'], '%Y-%m-%d %H:%M:%S')
                        except Exception:
                            self.error_info.append(_('error_data_on_row(%(index)s)_the_format_of_end_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': recode['index']})
                if data['pay_code'] is None or data['pay_code'] == '':
                    self.error_info.append(_('error_data_on_row(%(index)s)_the_overtime_type_is_empty') % {'index': recode['index']})
                else:
                    pay_code = PayCode.objects.filter(name=data['pay_code']).first()
                    if pay_code:
                        data['pay_code'] = pay_code
                    else:
                        self.error_info.append(_('error_data_on_row(%(index)s)_the_overtime_type_is_not_in_category_name') % {'index': recode['index']})
                if not self.error_info and data['end_time'] <= data['start_time']:
                        self.error_info.append(str(_('error_data_on_row(%(index)s)') % {'index': recode['index']}) + ', ' + str(_('overtime_time_invalid_range')))
                if self.error_info:
                    return False
                else:
                    self.clean_recodes.append(data)
            return True
    def data_insert(self):
        if self.error_info:
            return False
        else:
            for data in self.clean_recodes:
                obj = Overtime.objects.filter(employee=data['employee'], start_time=data['start_time'], end_time=data['end_time']).first()
                if obj is None:
                    obj = Overtime(employee=data['employee'], start_time=data['start_time'], end_time=data['end_time'])
                else:
                    if self.overwrite is False:
                        continue
                    else:
                        if self.overwrite is True and self.is_staff is True and (not obj.is_all_pending):
                                    continue
                try:
                    obj.apply_reason = data['apply_reason']
                    obj.pay_code = data['pay_code']
                    obj.save()
                    if self.is_staff is False and obj.is_pending:
                            obj.do_approve(self.request_user, '')
                except Exception as e:
                    self.error_info.append(str(_('error_data_on_row(%(index)s)') % {'index': data['index']}) + ', ' + str(e))
                    return False
            return True
class OvertimeImport(DataImportBase):
    def init_required_fields(self):
        self.required_fields = [_('emp_field_employeeCode'), _('overtime_field_startTime'), _('overtime_field_endTime'), _('overtime_field_overtimeType'), _('overtime_field_applyReason')]
    def clean_row(self, index, row):
        row_index = index + 1
        emp_code = row.get(_('emp_field_employeeCode'), None)
        if not emp_code:
            self.errors.append(_('error_data_on_row(%(index)s)_the_employee_code_is_empty') % {'index': row_index})
            return
        else:
            employee = Employee.objects.filter(emp_code=emp_code).first()
            if not employee:
                self.errors.append(_('error_data_on_row(%(index)s)_the_employee_code_does_not_exists') % {'index': row_index})
                return
            else:
                start_time = row.get(_('overtime_field_startTime'), None)
                if not start_time:
                    self.errors.append(_('error_data_on_row(%(index)s)_the_start_time_is_empty') % {'index': row_index})
                    return
                else:
                    if not isinstance(start_time, datetime.datetime):
                        try:
                            start_time = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
                        except Exception as e:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_format_of_start_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': row_index})
                            return None
                    end_time = row.get(_('overtime_field_endTime'), None)
                    if not end_time:
                        self.errors.append(_('error_data_on_row(%(index)s)_the_end_time_is_empty') % {'index': row_index})
                        return
                    else:
                        if not isinstance(end_time, datetime.datetime):
                            try:
                                end_time = datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
                            except Exception as e:
                                self.errors.append(_('error_data_on_row(%(index)s)_the_format_of_end_time_should_be_yyyy-mm-dd hh:mm:ss') % {'index': row_index})
                                return None
                        if start_time >= end_time:
                            self.errors.append(str(_('error_data_on_row(%(index)s)') % {'index': row_index}) + ', ' + str(_('leave_time_invalid_range')))
                        pay_code = row.get(_('overtime_field_overtimeType'), None)
                        if not pay_code:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_leave_category_is_empty') % {'index': row_index})
                        pay_code = PayCode.objects.filter(name=pay_code).first()
                        if not pay_code:
                            self.errors.append(_('error_data_on_row(%(index)s)_the_leave_category_is_not_in_category_name') % {'index': row_index})
                        reason = row.get(_('overtime_field_applyReason'), None)
                        return {'employee': employee, 'start_time': start_time, 'end_time': end_time, 'pay_code': pay_code, 'apply_reason': reason}
    def save(self, index, row):
        from mysite.workflow.models_choices import PENDING
        user = self.request.user
        if self.overwrite:
            obj = Overtime.objects.filter(employee=row['employee'], start_time=row['start_time'], end_time=row['end_time'], approval_status=PENDING).first()
            if obj:
                obj.start_time = row['start_time']
                obj.end_time = row['end_time']
                obj.pay_code = row['pay_code']
                obj.apply_reason = row['apply_reason']
                obj.save(force_update=True)
                if self.auto_approve:
                    obj.do_approve(user, _('common.fields.autoApproved'))
                return obj
        try:
            obj = Overtime(**row)
            obj.save(force_insert=True)
            if self.auto_approve:
                obj.do_approve(user, _('common.fields.autoApproved'))
            return obj
        except Exception as e:
            self.errors.append(str(e))