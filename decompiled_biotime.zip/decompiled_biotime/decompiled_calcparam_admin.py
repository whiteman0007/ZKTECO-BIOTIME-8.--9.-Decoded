# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\report\\admin\\calcparam_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:15 UTC (1750673055)

from mysite.payroll.report.base import PayRollReportAdminBase
from mysite.payroll.report.decorators import report_admin_register
from mysite.payroll.api.serializers import PayrollPayloadCalcParamSerializer
from mysite.att.models.model_paycode import PayCode, LEAVE, OVERTIME, EXCEPTION
@report_admin_register()
class PayloadCalcParamAdmin(PayRollReportAdminBase):
    api_url = '/payroll/api/report/payrollcalcparam/'
    model_name = 'PayrollPayloadCalcParam'
    api_serializer = PayrollPayloadCalcParamSerializer
    view_name = 'payrollcalcparam_report'
    list_display = ['emp_code', 'first_name', 'last_name', 'department', 'calc_time', 'payment_mode_display', 'Basic Salary', 'Schedule Period', 'Schedule Days', 'Required Work', 'Actual Work', 'Full Attendance', 'Full Attendance Day', 'Full Attendance Percentage', 'total_increase_formula', 'total_increase_formula_name', 'total_increase_expression', 'total_deduction_formula', 'total_deduction_formula_name', 'total_deduction_expression']
    hidden_fields = ['total_increase_formula', 'total_increase_formula_name', 'total_increase_expression', 'total_deduction_formula', 'total_deduction_formula_name', 'total_deduction_expression']
    def get_pay_codes(self):
        return PayCode.objects.filter(code_type__in=[EXCEPTION, LEAVE, OVERTIME]).order_by('display_order').values('code', 'is_display')
    def add_paycode_cols(self, cols):
        for code in self.get_pay_codes():
            field = code['code']
            cols.append({'field': field, 'title': self.get_column_title(field), 'hide': self.bool_value(not code['is_display'])})
    def insert_ext_cols(self, cols):
        self.add_emp_ext_cols(cols)
        self.add_paycode_cols(cols)