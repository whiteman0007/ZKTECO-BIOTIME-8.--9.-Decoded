# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\changeschedule_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from mysite import admin, config
from mysite.att.models import ChangeSchedule
from mysite.att.actions import Approve, Reject, Revoke
from mysite.personnel.models.model_employee import Employee
@admin.register(ChangeSchedule)
class ChangeScheduleAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'emp_code', 'emp_photo', 'first_name', 'last_name', 'department', 'position', 'workflow_engine', 'att_date', 'previous_timeinterval', 'timeinterval', 'apply_reason', 'apply_time', 'attachment_url', 'approval_status', 'approval_remark', 'approval_time', 'last_approver')
    list_filter = config.EMPLOYEE_LIST_FILTER + ('att_date', 'approval_status')
    hidden_fields = ('last_name', 'position', 'attachment_url', 'approval_remark', 'workflow_engine', 'approval_time', 'last_approver')
    non_display_fields = ('color',)
    ordering = ('-apply_time',)
    actions = [Approve, Reject, Revoke]
    def attachment_url(self, obj):
        if obj.attachment:
            return '/files/' + str(obj.attachment)
        else:
            return ''
    attachment_url.short_description = _('common_field_attachment')
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        qs = super(ChangeScheduleAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                qs = qs.filter(employee__department__in=request.user.auth_dept.all())
            if request.user.auth_area.exists():
                emp_list_by_area = Employee.objects.filter(area__in=request.user.auth_area.all())
                qs = qs.filter(employee__in=emp_list_by_area)
            if request.user.assign_company:
                qs = qs.filter(employee__company=request.user.assign_company)
        return qs