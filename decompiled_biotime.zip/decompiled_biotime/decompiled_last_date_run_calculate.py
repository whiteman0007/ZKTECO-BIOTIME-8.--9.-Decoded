# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\models\\last_date_run_calculate.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:59 UTC (1750672979)

from django.db import models
from mysite.att.db_const import APP_LABEL
class CalculateLastDate(models.Model):
    last_date = models.DateTimeField(db_index=True)
    class Meta:
        app_label = APP_LABEL