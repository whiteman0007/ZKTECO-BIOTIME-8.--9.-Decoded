# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\forms\\acc_terminal_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:49 UTC (1750672969)

from django.utils.translation import gettext_lazy as _
from django.forms import ModelForm
from mysite.admin import forms
from mysite.acc import models_choices
from mysite.acc.models import AccTerminal
class AccTerminalCreationForm(ModelForm):
    valid_holiday = forms.BooleanField(label=_('accTerminal_field_validHoliday'), initial=False, required=False)
    speaker_alarm = forms.BooleanField(label=_('accTerminal_field_speakerAlarm'), initial=False, required=False)
    duress_fun_on = forms.BooleanField(label=_('accTerminal_field_duressFunOn'), initial=False, required=False)
    alarm_1_1 = forms.BooleanField(label=_('accTerminal_field_alarmOn11Match'), initial=False, required=False)
    alarm_1_n = forms.BooleanField(label=_('accTerminal_field_alarmOn1nMatch'), initial=False, required=False)
    alarm_password = forms.BooleanField(label=_('accTerminal_field_alarmOnPassword'), initial=False, required=False)
    def save(self, commit=True):
        instance = super(AccTerminalCreationForm, self).save(commit=commit)
        return instance
    def __init__(self, *args, **kwargs):
        super(AccTerminalCreationForm, self).__init__(*args, **kwargs)
        self.initial_data()
    def initial_data(self):
        from mysite.iclock import utils
        dev = utils.getDevice(self.instance.terminal.sn)
        if dev.is_android:
            self.fields['door_sensor_type'].choices = models_choices.DOOR_SENSOR_TYPE_PHOTO_DEVICE
    class Meta:
        model = AccTerminal
        fields = ('door_lock_delay', 'door_sensor_delay', 'door_sensor_type', 'door_alarm_delay', 'retry_times', 'valid_holiday', 'nc_time_period', 'no_time_period', 'speaker_alarm', 'duress_fun_on', 'alarm_1_1', 'alarm_1_n', 'alarm_password', 'duress_alarm_delay', 'anti_passback_mode', 'anti_door_direction', 'verify_mode_485')