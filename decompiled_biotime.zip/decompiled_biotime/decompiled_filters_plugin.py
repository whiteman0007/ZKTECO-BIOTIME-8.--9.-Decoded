# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\admin\\xadmin\\filters_plugin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:53 UTC (1750672973)

import operator
from functools import reduce
from django.contrib.admin.options import IncorrectLookupParameters, get_content_type_for_model
from django.contrib.admin.utils import get_fields_from_path, lookup_spawns_duplicates
from django.core.exceptions import SuspiciousOperation, ImproperlyConfigured, ValidationError
from django.db import models
from django.db.models import Q
from django.core.exceptions import FieldDoesNotExist
from django.template import loader
from django.template.context import RequestContext
import six
from django.utils.encoding import smart_str
from django.utils.translation import gettext as _
from six import iteritems
from mysite.admin.views.main import RELATE_PREFIX, COL_LIST_VAR, ORDER_VAR
from mysite.base.models.bookmark import Bookmark
from .filters import manager as filter_manager
from .const import FILTER_PREFIX, SEARCH_VAR
from django.contrib.auth import get_user_model
User = get_user_model()
def get_context_dict(context):
    """\n     Contexts in django version 1.9+ must be dictionaries. As xadmin has a legacy with older versions of django,\n    the function helps the transition by converting the [RequestContext] object to the dictionary when necessary.\n    :param context: RequestContext\n    :return: dict\n    """
    if isinstance(context, RequestContext):
        ctx = context.flatten()
    else:
        ctx = context
    return ctx
def block_nav_menu(context, nodes):
    nodes.append(loader.render_to_string('xadmin/blocks/model_list.nav_menu.filters.html', context=get_context_dict(context)))
def block_nav_bookmark(context, nodes):
    nodes.insert(0, loader.render_to_string('xadmin/blocks/model_list.nav_menu.bookmarks.html', context=get_context_dict(context)))
def get_bookmark_context(admin, request):
    if not admin.show_bookmarks:
        return {}
    else:
        bookmarks = []
        user = request.user
        model_info = (admin.opts.app_label, admin.opts.model_name)
        menu_title = _('base_model_bookmarks')
        content_type = get_content_type_for_model(admin.model)
        if isinstance(user, User):
            bookmarks_queryset = Bookmark.objects.filter(content_type=content_type).filter(Q(user=user) | Q(is_share=True)).order_by(*Bookmark._meta.ordering)
        else:
            bookmarks_queryset = Bookmark.objects.get_queryset().none()
        for bk in bookmarks_queryset:
            bookmarks.append({'title': bk.title, 'filters': bk.filters})
        post_url = admin.admin_site.get_url('%s_%s_bookmark' % model_info)
        new_context = {'bk_menu_title': menu_title, 'bk_bookmarks': bookmarks, 'bk_post_url': post_url, 'has_add_permission_bookmark': True, 'has_change_permission_bookmark': True}
        return new_context
def get_filters_plugin(admin, request, **kwargs):
    params = dict(list(request.GET.items()))
    lookup_params = dict([(smart_str(k)[len(FILTER_PREFIX):], v) for k, v in list(params.items()) if not smart_str(k).startswith(FILTER_PREFIX) or v!= ''])
    for p_key, p_val in iteritems(lookup_params):
        if p_val == 'False':
            lookup_params[p_key] = False
    use_distinct = False
    is_history = kwargs.get('is_history', False)
    has_query_param = bool(lookup_params)
    filter_specs = []
    if is_history:
        filter_field = 'history_list_filter'
    else:
        filter_field = 'list_filter'
    list_filters = getattr(admin, filter_field, ())
    hidden_list_filter = getattr(admin, 'hidden_list_filter', None)
    if hidden_list_filter:
        list_filters = (i for i in list_filters if i not in hidden_list_filter)
    spec_filter = getattr(admin, 'calculated_filter', None)
    if spec_filter:
        list_filters += spec_filter
    for list_filter in list_filters:
        if callable(list_filter):
            spec = list_filter(request, lookup_params, admin.model, admin)
        else:
            field_path = None
            field_parts = []
            if isinstance(list_filter, (tuple, list)):
                field, field_list_filter_class = list_filter
            else:
                field, field_list_filter_class = (list_filter, filter_manager.create)
            if not isinstance(field, models.Field):
                field_path = field
                field_parts = get_fields_from_path(admin.model, field_path)
                field = field_parts[(-1)]
            spec = field_list_filter_class(field, request, lookup_params, admin.model, admin, field_path=field_path)
            use_distinct = use_distinct or lookup_spawns_duplicates(admin.opts, field_path)
        if spec and spec.has_output():
                filter_specs.append(spec)
    kwargs['has_query_param'] = has_query_param
    kwargs['has_filters'] = bool(filter_specs)
    kwargs['filter_specs'] = filter_specs
    obj = [f for f in filter_specs if f.is_used]
    if six.PY3:
        obj = list(obj)
    kwargs['used_filter_num'] = len(obj)
    return kwargs
def handle_lookup_params(admin, request, queryset, lookup_params, filter_specs, **kwargs):
    try:
        for key, value in list(lookup_params.items()):
            use_distinct = use_distinct or lookup_spawns_duplicates(admin.opts, key)
    except FieldDoesNotExist as e:
        raise IncorrectLookupParameters(e)
    try:
        if isinstance(queryset, models.query.QuerySet) and lookup_params:
                new_lookup_parames = dict()
                for k, v in list(lookup_params.items()):
                    list_v = v.split(',')
                    if len(list_v) > 0:
                        new_lookup_parames.update({k: list_v})
                    else:
                        new_lookup_parames.update({k: v})
                queryset = queryset.filter(**new_lookup_parames)
    except (SuspiciousOperation, ImproperlyConfigured):
        raise
    except Exception as e:
        raise IncorrectLookupParameters(e)
    else:
        if not isinstance(queryset, models.query.QuerySet):
            pass
    query = request.GET.get(SEARCH_VAR, '')
    def construct_search(field_name):
        if field_name.startswith('^'):
            return '%s__istartswith' % field_name[1:]
        else:
            if field_name.startswith('='):
                return '%s__iexact' % field_name[1:]
            else:
                if field_name.startswith('@'):
                    return '%s__search' % field_name[1:]
                else:
                    return '%s__icontains' % field_name
    if admin.search_fields and query:
            orm_lookups = [construct_search(str(search_field)) for search_field in admin.search_fields]
            for bit in query.split():
                or_queries = [models.Q(**{orm_lookup: bit}) for orm_lookup in orm_lookups]
                queryset = queryset.filter(reduce(operator.or_, or_queries))
            if not use_distinct:
                for search_spec in orm_lookups:
                    if lookup_spawns_duplicates(admin.opts, search_spec):
                        use_distinct = True
                        break
            kwargs['search_query'] = query
    for spec in filter_specs:
        try:
            new_qs = spec.apply_filter(queryset)
        except ValidationError as e:
            new_qs = None
            print('Filtering error:%s' % str(e))
        if new_qs is not None:
            queryset = new_qs
    if use_distinct:
        return queryset.distinct()
    else:
        return queryset