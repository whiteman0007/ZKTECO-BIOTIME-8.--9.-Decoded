# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\forms\\attshift_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import itertools
import json
import operator
import uuid
from django.forms import ModelForm, ValidationError
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att.models import AttShift, ShiftDetail, PayCode
from mysite.att.models.model_overtime_policy import OvertimePolicy, OT_LV1, OT_LV2, OT_LV3
from mysite.att.models.model_paycode import OVERTIME
from mysite.att.company_form import CompanyField4ModelForm
UNIT_DAYS = {0: 1, 1: 7, 2: 31}
class AttShiftCreationForm(CompanyField4ModelForm):
    daily_shift = forms.CharField()
    daily_shift_display = forms.CharField()
    auto_shift = forms.BooleanField(label=_('attShift_field_autoShift'), required=False)
    enable_ot_rule = forms.BooleanField(label=_('attShift.fields.enableOvertimeRule'), initial=False, required=False)
    t1_pay_code = forms.ModelChoiceField(label=_('attShift.fields.payCode'), queryset=PayCode.objects.filter(code_type=OVERTIME), required=False)
    t1_hrs_from = forms.DecimalField(label=_('attShift.fields.hrsFrom'), max_digits=4, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t1_hrs_to = forms.DecimalField(label=_('attShift.fields.hrsTo'), max_digits=4, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t2_pay_code = forms.ModelChoiceField(label=_('attShift.fields.payCode'), queryset=PayCode.objects.filter(code_type=OVERTIME), required=False)
    t2_hrs_from = forms.DecimalField(label=_('attShift.fields.hrsFrom'), max_digits=4, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t2_hrs_to = forms.DecimalField(label=_('attShift.fields.hrsTo'), max_digits=4, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t3_pay_code = forms.ModelChoiceField(label=_('attShift.fields.payCode'), queryset=PayCode.objects.filter(code_type=OVERTIME), required=False)
    t3_hrs_from = forms.DecimalField(label=_('attShift.fields.hrsFrom'), max_digits=4, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t3_hrs_to = forms.DecimalField(label=_('attShift.fields.hrsTo'), max_digits=4, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    class Meta:
        model = AttShift
        fields = '__all__'
        exclude = ['work_weekend', 'weekend_type', 'work_day_off', 'day_off_type', 'frequency', 'uuid']
    def __init__(self, *args, **kwargs):
        super(AttShiftCreationForm, self).__init__(*args, **kwargs)
        if self.instance:
            daily_shift_display = []
            days = UNIT_DAYS[self.instance.cycle_unit]
            for x in range(self.instance.shift_cycle):
                item = {'cycle': x + 1}
                for y in range(days):
                    item[y] = ''
                daily_shift_display.append(item)
            daily_shift = {}
            _item = {}
            if self.instance.pk:
                queryset = ShiftDetail.objects.filter(shift=self.instance).values('day_index', 'time_interval_id', 'time_interval__alias').order_by('day_index', 'time_interval_id')
                for day_index, items in itertools.groupby(queryset, operator.itemgetter('day_index')):
                    _cycle = int(day_index / days)
                    _index = int(day_index % days)
                    _items = list(items)
                    daily_shift[day_index] = ','.join((str(item['time_interval_id']) for item in _items))
                    daily_shift_display[_cycle][_index] = ','.join((item['time_interval__alias'] for item in _items))
            self.fields['daily_shift'].initial = json.dumps(daily_shift)
            self.fields['daily_shift_display'].initial = json.dumps(daily_shift_display)
            if self.instance.ot_rule:
                rules = OvertimePolicy.objects.filter(master=self.instance.ot_rule).values('mode', 'hrs_from', 'hrs_to', 'pay_code')
                for rule in rules:
                    self.fields['t{lv}_pay_code'.format(lv=rule['mode'])].initial = rule['pay_code']
                    self.fields['t{lv}_hrs_from'.format(lv=rule['mode'])].initial = rule['hrs_from']
                    self.fields['t{lv}_hrs_to'.format(lv=rule['mode'])].initial = rule['hrs_to']
    def clean_daily_shift(self):
        return self.cleaned_data['daily_shift']
    def clean(self):
        cleaned_data = super(AttShiftCreationForm, self).clean()
        data_pre_check(cleaned_data)
        return cleaned_data
    def save(self, commit=True):
        key = uuid.uuid1().hex
        obj = super(AttShiftCreationForm, self).save(commit=False)
        obj.ot_rule = key
        obj.save()
        self.save_overtime_policy(key)
        self.save_shift_detail(obj)
        from mysite.att.models.model_payload import shift_change
        if self.changed_data and self.changed_data!= ['ot_rule']:
                shift_change([obj.id])
        return obj
    def save_overtime_policy(self, key):
        data = self.cleaned_data
        rules = list()
        rules.append(OvertimePolicy(master=key, mode=OT_LV1, hrs_from=data['t1_hrs_from'], hrs_to=data['t1_hrs_to'], pay_code=data['t1_pay_code']))
        rules.append(OvertimePolicy(master=key, mode=OT_LV2, hrs_from=data['t2_hrs_from'], hrs_to=data['t2_hrs_to'], pay_code=data['t2_pay_code']))
        rules.append(OvertimePolicy(master=key, mode=OT_LV3, hrs_from=data['t3_hrs_from'], hrs_to=data['t3_hrs_to'], pay_code=data['t3_pay_code']))
        from django.conf import settings
        if settings.DATABASE_ENGINE == 'oracle':
            for r in rules:
                r.save()
        else:
            OvertimePolicy.objects.bulk_create(rules)
    def save_shift_detail(self, obj):
        from mysite.att.models import TimeInterval, ShiftDetail
        daily_shifts_json = self.cleaned_data.get('daily_shift', None)
        if not daily_shifts_json:
            return
        else:
            daily_shifts = json.loads(daily_shifts_json)
            objs = []
            old_shiftdetail = list(ShiftDetail.objects.filter(shift=obj).values_list('time_interval__id', flat=True))
            new_shiftdetail = []
            for k, v in list(daily_shifts.items()):
                if not v:
                    continue
                else:
                    tbs = v.split(',')
                    queryset = TimeInterval.objects.filter(id__in=tbs)
                    for q in queryset:
                        _obj = ShiftDetail(shift=obj, in_time=q.in_time, out_time='00:00:00', day_index=k, time_interval=q)
                        new_shiftdetail.append(q.id)
                        objs.append(_obj)
            ShiftDetail.objects.filter(shift=obj).delete()
            if objs:
                ShiftDetail.objects.bulk_create(objs)
            if new_shiftdetail!= old_shiftdetail:
                send_email(obj, new_shiftdetail)
def email_payload(obj, att_emp, new_shiftdetail):
    from mysite.att.tasks import normal_send_email
    from mysite.att.models import TimeInterval
    from mysite.att.utils import get_time
    from mysite.personnel.models import Employee
    if att_emp:
        for emp in att_emp:
            attemp_obj = Employee.objects.filter(id=emp).first()
            break_time_list = []
            table_time_list = []
            schedule_name_list = []
            for tv in new_shiftdetail:
                tv_obj = TimeInterval.objects.filter(id=tv).first()
                break_time, start_time, end_time = get_time(tv_obj)
                break_time_list.append(break_time)
                schedule_name_list.append(tv_obj.alias)
                table_time_list.append({'{}'.format(tv_obj.alias): '-'.join((start_time, end_time))})
            payload = {'alias': obj.alias, 'schedule_name': schedule_name_list, 'schedule_time': table_time_list, 'break_time': break_time_list}
            normal_send_email(attemp_obj, payload)
def send_email(obj, new_shiftdetail):
    from mysite.att.models import AttSchedule, GroupSchedule, DepartmentSchedule, AttEmployee
    from mysite.att.tasks import shift_send_email
    group_emp = []
    att_emp = AttSchedule.objects.filter(shift=obj).values_list('employee', flat=True)
    group_obj = GroupSchedule.objects.filter(shift=obj).first()
    dept_obj = DepartmentSchedule.objects.filter(shift=obj).first()
    if att_emp:
        shift_send_email.delay(obj, att_emp, new_shiftdetail)
    if group_obj:
        get_group = AttEmployee.objects.filter(group__code=group_obj.group.code)
        group_emp = get_group.exclude(emp__in=att_emp).values_list('emp', flat=True)
        shift_send_email.delay(obj, group_emp, new_shiftdetail)
    if dept_obj:
        dept_emp = dept_obj.department.employee_set.exclude(id__in=att_emp).exclude(id__in=group_emp).values_list('id', flat=True)
        shift_send_email.delay(obj, dept_emp, new_shiftdetail)
def data_pre_check(cleaned_data):
    import datetime
    from mysite.att.models import TimeInterval
    auto_shift = cleaned_data.get('auto_shift', None)
    daily_shifts_json = cleaned_data.get('daily_shift', None)
    if not daily_shifts_json:
        raise ValidationError(_('select_date'), code='-1')
    else:
        all_tbs = {}
        daily_shifts = json.loads(daily_shifts_json)
        for k, v in list(daily_shifts.items()):
            if not v:
                continue
            else:
                tbs = v.split(',')
                if not auto_shift:
                    tmps = []
                    for tb in tbs:
                        if tb not in all_tbs:
                            timetable = TimeInterval.objects.filter(id=tb)[0]
                            all_tbs[tb] = timetable
                        else:
                            timetable = all_tbs[tb]
                        scs = datetime.datetime.strptime(timetable.in_time.strftime('%H:%M:%S'), '%H:%M:%S')
                        sce = scs + datetime.timedelta(minutes=timetable.work_time_duration)
                        for tmp in tmps:
                            tmp_s = datetime.datetime.strptime(tmp.in_time.strftime('%H:%M:%S'), '%H:%M:%S')
                            tmp_e = tmp_s + datetime.timedelta(minutes=tmp.work_time_duration)
                            if max(scs, tmp_s) < min(sce, tmp_e):
                                raise ValidationError(_('%(t)s and %(ss)s time_period_are_duplicated!_In_section %(d)s day'), code='-1', params={'t': timetable, 'ss': tmp, 'd': str(int(k) + 1)})
                        tmps.append(timetable)