# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0012_901_attr_type_change.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('personnel', '0011_auto_20230223_1026')]
    operations = [migrations.AlterField(model_name='employeecustomattribute', name='attr_type', field=models.SmallIntegerField(choices=[(1, 'employeeCustomAttribute.attr_type.text'), (2, 'employeeCustomAttribute.attr_type.combobox')], default=1, verbose_name='employeeCustomAttribute.fields.attr_type')), migrations.AlterField(model_name='employeecustomattribute', name='attr_value', field=models.CharField(blank=True, max_length=999, null=True, verbose_name='employeeCustomAttribute.fields.attr_value'))]