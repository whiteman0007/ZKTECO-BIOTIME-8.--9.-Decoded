# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0016_pro_903_2024090600.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from django.db import migrations, models
import django.db.models.deletion
import mysite.personnel.fields
class Migration(migrations.Migration):
    dependencies = [('personnel', '0015_auto_20250102_20141')]
    operations = [migrations.AddField(model_name='certification', name='company', field=mysite.personnel.fields.CompanyForeignKey(default=1, on_delete=django.db.models.deletion.CASCADE, to='personnel.company', verbose_name='certification_field_company')), migrations.AddField(model_name='employee', name='area_privilege', field=mysite.personnel.fields.AreaManyToManyField(blank=True, related_name='employee_area_privilege', to='personnel.area', verbose_name='emp_field_areaPrivilege')), migrations.AlterField(model_name='certification', name='cert_code', field=models.CharField(max_length=20, verbose_name='certification_field_code')), migrations.AlterUniqueTogether(name='certification', unique_together={('cert_code', 'company')})]