# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\tools\\encryption_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

from Crypto.Cipher import AES
from binascii import b2a_hex, a2b_hex
def get_key_iv():
    from django.conf import settings
    key = getattr(settings, 'CONFIG_AES_PASSWORD', '')
    iv = getattr(settings, 'CONFIG_AES_IV', '')
    key = key.encode('utf8') if key else b'china@2018encryption#aes'
    iv = iv.encode('utf8') if iv else b'zkteco@china2019'
    return (key, iv)
def filling_data(data, restore=False):
    """\n    :param data: str\n    :return: str\n    """
    if restore:
        return data[0:-ord(data[(-1)])]
    else:
        block_size = AES.block_size
        return data + (block_size - len(data) % block_size) * chr(block_size - len(data) % block_size)
def aes_encrypt(content, specific_key: str=None):
    """\n    Encryption\n    :param content: str, The length of content must be times of AES.block_size, using filling_data to fill out\n    :param specific_key: use specific secret key\n    :return: str\n    """
    if isinstance(content, bytes):
        content = str(content, encoding='utf-8')
    key, iv = get_key_iv()
    if specific_key:
        key = specific_key.encode('utf-8') if isinstance(specific_key, str) else specific_key
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(filling_data(content).encode('utf-8'))
    result = b2a_hex(encrypted).decode('utf-8')
    return result
def aes_decrypt(content, specific_key: str=None):
    """\n    Decryption\n    :param content: str or bytes, Encryption string\n    :param specific_key: use specific secret key\n    :return: str\n    """
    if isinstance(content, str):
        content = content.encode('utf-8')
    key, iv = get_key_iv()
    if specific_key:
        key = specific_key.encode('utf-8') if isinstance(specific_key, str) else specific_key
    cipher = AES.new(key, AES.MODE_CBC, iv)
    result = cipher.decrypt(a2b_hex(content)).decode('utf-8')
    return filling_data(result, restore=True)
def get_encryption_params():
    from django.conf import settings
    key = getattr(settings, 'APP_AES_PASSWORD', '')
    iv = getattr(settings, 'APP_AES_IV', '')
    key = key.encode('utf8') if key else b'mMH7L4DFHzo2y8YSgntzfm1x0Z_hFvMA'
    iv = iv.encode('utf8') if iv else b'hQHu9xoUeXc=8YSg'
    return (key, iv)
def encrypt_parameter(value: str):
    import base64
    from Crypto.Util.Padding import pad
    AES_KEY, CONSTANT_IV = get_encryption_params()
    iv = CONSTANT_IV
    cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
    value_bytes = value.encode('utf-8')
    encrypted_bytes = cipher.encrypt(pad(value_bytes, AES.block_size))
    return base64.b64encode(iv + encrypted_bytes).decode('utf-8')
def decrypt_parameter(encrypted_value):
    """Decrypt a single parameter using AES-256  based on isCloud flag."""
    import base64
    from Crypto.Util.Padding import unpad
    AES_KEY, CONSTANT_IV = get_encryption_params()
    encrypted_bytes = base64.b64decode(encrypted_value)
    iv = CONSTANT_IV
    encrypted_message = encrypted_bytes[16:]
    cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
    decrypted_bytes = unpad(cipher.decrypt(encrypted_message), AES.block_size)
    return decrypted_bytes.decode('utf-8')
if __name__ == '__main__':
    in_list = ['1234', b'1234', '5678', b'5678']
    out_list = []
    for i in in_list:
        a = aes_decrypt(aes_encrypt(i))
        print(a)