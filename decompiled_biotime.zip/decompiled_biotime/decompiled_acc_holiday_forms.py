# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\forms\\acc_holiday_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:49 UTC (1750672969)

from django.core.cache import cache
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.acc.models import AccHoliday
from mysite.admin import forms
from mysite.personnel.models import Area
from mysite.acc.models import AccTimezone
class AccHolidayForm(ModelForm):
    area = forms.ModelChoiceField(label=_('accPrivilege_field_area'), queryset=Area.objects.all(), disabled=True)
    timezone = forms.ModelChoiceField(label=_('accPrivilege_field_timezone1'), queryset=AccTimezone.objects.all())
    class Meta:
        model = AccHoliday
        fields = '__all__'
    def __init__(self, *args, **kwargs):
        super(AccHolidayForm, self).__init__(*args, **kwargs)
        try:
            request = kwargs.get('initial', None)
            current_area = 1
            if request:
                current_area = request['request'].GET.get('current_area', 1)
            if args and args[0]['area']:
                    current_area = args[0]['area']
            if self.instance.area_id:
                current_area = self.instance.area_id
            timezones = AccTimezone.objects.filter(area_id=current_area)
            self.fields['timezone'].queryset = timezones
            self.fields['area'].initial = current_area
        except Exception:
            return None