# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\accounts\\migrations\\0010_901_notification_category.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:14 UTC (1750702694)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('accounts', '0009_userprofile_employee_fields')]
    operations = [migrations.AlterField(model_name='usernotification', name='category', field=models.IntegerField(blank=True, choices=[(1, 'CATEGORY_DEVICE'), (2, 'CATEGORY_ATT'), (3, 'CATEGORY_MTG'), (4, 'CATEGORY_VI'), (5, 'CATEGORY_EMP'), (6, 'CATEGORY_SYS')], null=True, verbose_name='userNotification.fields.category')), migrations.AlterField(model_name='usernotification', name='event', field=models.IntegerField(blank=True, choices=[(101, 'userNotification.events.deviceOffline'), (102, 'userNotification.events.deviceOnline'), (6, 'userNotification.events.lateIn'), (7, 'userNotification.events.earlyOut'), (3, 'userNotification.events.attOvertime'), (4, 'userNotification.events.attTraining'), (5, 'userNotification.events.schedule'), (10, 'userNotification.events.meeting'), (11, 'userNotification.events.mtgManualLog'), (9, 'userNotification.events.visitorReservation'), (119, 'userNotification.events.bioPhotoInvalid')], null