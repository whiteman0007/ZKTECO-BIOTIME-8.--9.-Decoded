# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\export_usb_data.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

import base64
import datetime
import json
import os
import struct
import shutil
from celery_progress.backend import AbstractProgressRecorder
from django.conf import settings
from django.db.models import Q
from django.utils.translation import gettext_lazy as _
from mysite.iclock import const
from mysite.personnel.models import Employee
from mysite.personnel.utils import device_pin
from mysite.utils import get_or_create_photo_folder, progress_record
from mysite.personnel.db_const import DAT, JSON
from mysite.personnel.utils import get_default_company
class ExportUSBData(object):
    progress_recorder = None
    total = 0
    current = 0
    fp_version = '10'
    face_version = '7'
    def __init__(self, request, **kwargs):
        self.emps = []
        self.bio_fps = []
        self.bio_datas = []
        self.request = request
        self.progress_recorder = kwargs.pop('progress_recorder', None)
        self.error_info = []
        self.usb_data_path = settings.UDISK_PATH + '/export/' + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + '/'
        self.code_id_dict = {}
        if not os.path.exists(self.usb_data_path):
            os.makedirs(self.usb_data_path)
        if self.request:
            self.fp_version = self.request.POST['fp_version']
            self.face_version = self.request.POST['face_version']
            self.company = self.request.POST.get('company', None)
            if not self.company:
                self.company = get_default_company()
            self.areas = self.request.POST.getlist('area', [])
            self.file_format = int(self.request.POST.get('file_format', '1'))
            self.biophoto_path = self.usb_data_path + 'biophoto/face/'
            self.userData_path = self.usb_data_path + 'userData/'
            if self.file_format == JSON:
                if not os.path.exists(self.biophoto_path):
                    os.makedirs(self.biophoto_path)
                if not os.path.exists(self.userData_path):
                    os.makedirs(self.userData_path)
    def update_bio_fp_list(self, emp):
        if self.fp_version == '12':
            return
        else:
            fp_version = (self.fp_version, self.fp_version + '.0')
            fps = emp.biodata_set.filter(bio_type=1, major_ver__in=fp_version)
            for fp in fps:
                bio_data_dic = {}
                bio_data_dic['is_duress'] = fp.duress
                bio_data_dic['fingerid'] = fp.bio_no
                bio_data_dic['pin'] = device_pin(fp.employee.emp_code)
                bio_data_dic['template_data'] = fp.bio_tmp
                self.bio_fps.append(bio_data_dic)
    def update_bio_data_list(self, emp):
        bio_datas = emp.biodata_set.all().exclude(Q(bio_type=const.bioFinger, major_ver='10') | Q(bio_type=const.bioFace, major_ver='7'))
        for bio in bio_datas:
            if bio.bio_type in (const.bioFace, const.bioHand):
                fc = json.loads(bio.bio_tmp)
                for key, value in fc.items():
                    bio_data_dic = {}
                    bio_data_dic['bio_type'] = bio.bio_type
                    bio_data_dic['data_format'] = bio.bio_format
                    bio_data_dic['is_duress'] = bio.duress
                    bio_data_dic['major_ver'] = bio.major_ver
                    bio_data_dic['minor_ver'] = bio.minor_ver
                    bio_data_dic['template_id'] = bio.id
                    bio_data_dic['template_no'] = bio.bio_no
                    bio_data_dic['template_no_index'] = int(key)
                    bio_data_dic['user_pin'] = device_pin(bio.employee.emp_code)
                    bio_data_dic['valid_flag'] = bio.valid
                    bio_data_dic['template_data'] = value
                    self.bio_datas.append(bio_data_dic)
            else:
                if bio.bio_type in (const.bioFaceVL, const.bioFinger):
                    bio_data_dic = {}
                    bio_data_dic['bio_type'] = bio.bio_type
                    bio_data_dic['data_format'] = bio.bio_format
                    bio_data_dic['is_duress'] = bio.duress
                    bio_data_dic['major_ver'] = bio.major_ver
                    bio_data_dic['minor_ver'] = bio.minor_ver
                    bio_data_dic['template_id'] = bio.id
                    bio_data_dic['template_no'] = bio.bio_no
                    bio_data_dic['template_no_index'] = bio.bio_index
                    bio_data_dic['user_pin'] = device_pin(bio.employee.emp_code)
                    bio_data_dic['valid_flag'] = bio.valid
                    bio_data_dic['template_data'] = bio.bio_tmp
                    self.bio_datas.append(bio_data_dic)
    def update_emp_list(self, employees):
        total = len(employees)
        current = 1
        for emp in employees:
            progress_record(self.progress_recorder, current, total, _('exportProgress.status.preparingData'))
            emp_dict = {}
            emp_dict['PIN'] = emp.id
            emp_dict['Privilege'] = emp.dev_privilege
            emp_dict['Password'] = emp.device_password
            emp_dict['Name'] = emp.first_name
            emp_dict['Card'] = emp.card_no
            emp_dict['Group'] = int(emp.acc_group or 1)
            emp_dict['TimeZone0'] = 0
            emp_dict['TimeZone1'] = 1
            emp_dict['TimeZone2'] = 0
            emp_dict['TimeZone3'] = 0
            emp_dict['PIN2'] = device_pin(emp.emp_code)
            self.emps.append(emp_dict)
            self.export_biophoto(emp)
            self.update_bio_fp_list(emp)
            self.update_bio_data_list(emp)
            current += 1
    def export_bio_employees(self):
        if self.emps:
            progress_record(self.progress_recorder, 0, len(self.emps), _('exportProgress.status.generateDoc'))
            bio_emps = {'USER_INFO': self.emps}
            userInfoFile = os.path.join(self.userData_path, 'userInfo.json')
            with open(userInfoFile, 'w') as f:
                json.dump(bio_emps, f)
            if self.bio_fps:
                bio_fps = {'fptemplate10': self.bio_fps}
                fpFile = os.path.join(self.userData_path, 'fpTemplate10.json')
                with open(fpFile, 'w') as fp:
                    json.dump(bio_fps, fp)
            if self.bio_datas:
                biodata = {'Pers_Biotemplate': self.bio_datas}
                bioFile = os.path.join(self.userData_path, 'persBiotemplate.json')
                with open(bioFile, 'w') as bio:
                    json.dump(biodata, bio)
            progress_record(self.progress_recorder, len(self.emps), len(self.emps), _('exportProgress.status.generateDoc'))
    def export_biophoto(self, emp):
        from mysite.tools.image_utils import decrypt_image
        store_dir = get_or_create_photo_folder('biophoto')
        approval_photo = '{pin}.jpg'.format(pin=emp.pin())
        approval_photo_path = os.path.join(store_dir, approval_photo)
        export_photo_path = os.path.join(self.biophoto_path, approval_photo)
        if settings.ENABLE_ENCRYPT_PHOTO:
            if os.path.exists(approval_photo_path):
                with open(os.path.join(export_photo_path), 'wb') as f:
                    f.write(decrypt_image(approval_photo_path, is_path=True))
        else:
            shutil.copy(approval_photo_path, export_photo_path)
    def usb_data_export(self):
        """\n        Employee struct:\n        PIN         unsigned short  2bytes\n        Privilege   signed char     1byte\n        Password    char[8]         8bytes\n        Name        char[24]        24bytes\n        Card        unsigned long   4bytes\n        Group       signed char     1byte\n        Timezone    unsigned long   8bytes\n        PIN2        char[24]        24bytes\n        :return:\n        """
        employees = Employee.objects.filter(company=self.company)
        if self.areas:
            employees = employees.filter(area__in=self.areas).distinct()
        if self.request and self.request.user and (not self.request.user.is_superuser):
                    if self.request.user.auth_dept.all():
                        employees = employees.filter(department__in=self.request.user.auth_dept.all())
                    if self.request.user.auth_area.all():
                        employees = employees.filter(area__in=self.request.user.auth_area.all()).distinct()
        if self.file_format == JSON:
            self.update_emp_list(employees)
            self.export_bio_employees()
            return
        else:
            if employees.count() > 65535:
                self.error_info.append(_('export.usb_data.error.moreThan'))
                return
            else:
                user_file_name = os.path.join(self.usb_data_path, 'user.dat')
                user_file = open(user_file_name, 'wb')
                fp_file_name = os.path.join(self.usb_data_path, 'template.fp10')
                fp_file = open(fp_file_name, 'wb')
                face_file_name = os.path.join(self.usb_data_path, 'ssrface.dat')
                face_file = open(face_file_name, 'wb')
                bio_file_name = os.path.join(self.usb_data_path, 'biotemplate.dat')
                bio_file = open(bio_file_name, 'w')
                total = len(employees)
                current = 1
                for index, emp in enumerate(employees):
                    progress_record(self.progress_recorder, current, total, _('exportProgress.status.generateDoc'))
                    emp_id = index + 1
                    self.code_id_dict[emp.emp_code] = emp_id
                    u_data = struct.pack('H', emp_id)
                    u_data = u_data + struct.pack('b', emp.dev_privilege)
                    u_data = u_data + struct.pack('8s', (emp.device_password or '').encode('utf-8'))
                    u_data = u_data + struct.pack('24s', (emp.first_name or '').encode('utf-8'))
                    try:
                        u_data = u_data + struct.pack('L', int(emp.card_no or 0))
                    except:
                        u_data = u_data + struct.pack('L', 0)
                        self.error_info.append('Card No.({card}) of {emp} is invalid'.format(card=emp.card_no, emp=emp.emp_code))
                    u_data = u_data + struct.pack('b', int(emp.acc_group or 1))
                    u_data = u_data + struct.pack('Q', 0)
                    u_data = u_data + struct.pack('24s', device_pin(emp.emp_code).encode('utf-8'))
                    user_file.write(u_data)
                    self.export_fp_to_udisk(emp, fp_file)
                    self.export_face_to_udisk(emp, face_file)
                    self.export_biodata_to_udisk(emp, bio_file)
                    current += 1
                user_file.close()
                fp_file.close()
                face_file.close()
                bio_file.close()
                progress_record(self.progress_recorder, total, total, _('exportProgress.status.generateDoc'))
    def export_fp_to_udisk(self, emp, fp_file):
        """\n        FP Struct\n        Size        unsigned short  2bytes\n        PIN         unsigned short  2bytes\n        Finger ID   signed char     1byte\n        Valid       signed char     1byte\n        Template    char[]\n\n        :param emp:\n        :param fp_file:\n        :return:\n        """
        if self.fp_version == '12':
            return
        else:
            fp_version = (self.fp_version, self.fp_version + '.0')
            fps = emp.biodata_set.filter(bio_type=1, major_ver__in=fp_version)
            for fp in fps:
                udata = struct.pack('H', len(base64.b64decode(fp.bio_tmp)) + 6)
                udata = udata + struct.pack('H', self.code_id_dict[emp.emp_code])
                udata = udata + struct.pack('b', fp.bio_no)
                udata = udata + struct.pack('b', fp.valid)
                udata = udata + base64.b64decode(fp.bio_tmp)
                fp_file.write(udata)
    def export_face_to_udisk(self, emp, face_file):
        """\n        Face Struct\n        Size                unsigned short  2bytes\n        PIN                 unsigned short  2bytes\n        Finger ID           signed char     1byte\n        Valid               signed char     1byte\n        Reserve             unsigned short  2bytes\n        Last active time    unsigned long   4bytes\n        Verify Count        unsigned long   4bytes\n        template            char[2560]      2560bytes\n        :param emp:\n        :param face_file:\n        :return:\n        """
        if self.face_version in ['9', '12']:
            return
        else:
            faces = emp.biodata_set.filter(bio_type=const.bioFace, major_ver=self.face_version)
            for face in faces:
                fc = json.loads(face.bio_tmp)
                for key, value in fc.items():
                    udata = struct.pack('H', len(value))
                    udata = udata + struct.pack('H', self.code_id_dict[emp.emp_code])
                    udata = udata + struct.pack('b', int(key))
                    udata = udata + struct.pack('b', face.valid)
                    udata = udata + struct.pack('H', int(face.major_ver or 0))
                    udata = udata + struct.pack('L', 0)
                    udata = udata + struct.pack('L', 0)
                    udata = udata + struct.pack('2560s', base64.b64decode(value)[16:])
                    face_file.write(udata)
    def export_biodata_to_udisk(self, emp, biodata_file):
        """\n        Pin=%s\tNo=%d\tIndex=%d\tValid=%d\tDuress=%d\tType=%d\tMajorVer=%d\tMinorVer=%d\tFormat=%d\tTmp=%s\r\n\n        """
        bio_str_mod = 'Pin={0}\tNo={1}\tIndex={2}\tValid={3}\tDuress={4}\tType={5}\tMajorVer={6}\tMinorVer={7}\tFormat={8}\tTmp={9}\n'
        bio_datas = emp.biodata_set.all().exclude(Q(bio_type=const.bioFinger, major_ver__in=('10', '10.0')) | Q(bio_type=const.bioFace, major_ver='7'))
        for bio in bio_datas:
            try:
                if bio.bio_type in (const.bioFace, const.bioHand):
                    fc = json.loads(bio.bio_tmp)
                    for key, value in fc.items():
                        bio_str = bio_str_mod.format(device_pin(emp.emp_code), bio.bio_no, int(key), bio.valid, bio.duress, bio.bio_type, bio.major_ver, bio.minor_ver, bio.bio_format, value)
                        biodata_file.write(bio_str)
                else:
                    if bio.bio_type in (const.bioFaceVL, const.bioFinger):
                        bio_str = bio_str_mod.format(device_pin(emp.emp_code), bio.bio_no, bio.bio_index, bio.valid, bio.duress, bio.bio_type, bio.major_ver, bio.minor_ver, bio.bio_format, bio.bio_tmp)
                        biodata_file.write(bio_str)
            except Exception as e:
                import traceback
                traceback.print_exc()