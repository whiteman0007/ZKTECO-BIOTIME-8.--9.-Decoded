# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\staff_meeting\\forms\\meetingEntity_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:34 UTC (1750673074)

import datetime
from django.forms import ModelForm, ModelMultipleChoiceField, ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.meeting import choices, const
from mysite.meeting.models import MeetingEntity
from mysite.personnel.widgets import AttenderManyToManyMiddleWidget
from mysite.personnel.models import Employee
from mysite.meeting import db_const
class MeetingEntityCreationForm(ModelForm):
    alias = forms.CharField(label=_('meetingEntity.fields.alias'), max_length=db_const.CHAR_MEETING_ALIAS)
    content = forms.CharField(label=_('meetingEntity.fields.content'), max_length=db_const.CHAR_MEETING_CONTENT, required=False)
    apply_reason = forms.CharField(label=_('meetingEntity.fields.purpose'), max_length=db_const.CHAR_MEETING_PURPOSE)
    attender = ModelMultipleChoiceField(label=_('meetingEntity.fields.attender'), queryset=Employee.objects.get_queryset(), widget=AttenderManyToManyMiddleWidget())
    view_date = forms.DateField(label=_('View Date'), initial=datetime.datetime.now)
    start_time = forms.DateTimeField(label=_('meetingEntity.fields.startTime'))
    end_time = forms.DateTimeField(label=_('meetingEntity.fields.endTime'))
    in_start = forms.DateTimeField(label=_('meetingEntity.fields.inStart'))
    in_end = forms.DateTimeField(label=_('meetingEntity.fields.inEnd'))
    out_start = forms.DateTimeField(label=_('meetingEntity.fields.outStart'))
    out_end = forms.DateTimeField(label=_('meetingEntity.fields.outEnd'))
    host_video = forms.BooleanField(label=_('zoomMeeting.fields.isHostVideo'), initial=False, required=False)
    participant_video = forms.BooleanField(label=_('zoomMeeting.fields.isParticipantVideo'), initial=False, required=False)
    enable_waiting_room = forms.BooleanField(label=_('zoomMeeting.fields.enableWaitingRoom'), initial=False, required=False)
    jbh_anytime = forms.BooleanField(label=_('zoomMeeting.fields.isJoinBeforeHostAnytime'), initial=False, required=False)
    mute_upon_entry = forms.BooleanField(label=_('zoomMeeting.fields.isMuteUponEntry'), initial=False, required=False)
    auto_recording = forms.ChoiceField(label=_('zoomMeeting.fields.autoRecording'), initial=const.ZOOM_AUTORECORDING_DISABLED, choices=choices.ZOOM_AUTORECORDING_CHOICES)
    class Meta:
        model = MeetingEntity
        fields = ('alias', 'content', 'start_time', 'end_time', 'apply_reason', 'room', 'attender', 'in_required', 'in_start', 'in_end', 'out_required', 'out_start', 'out_end', 'view_date', 'time_zone', 'enable_virtual', 'host_video', 'participant_video', 'enable_waiting_room', 'jbh_anytime', 'mute_upon_entry', 'auto_recording')
class AddMeetingAttenderForm(forms.ZKActionForm):
    attender = ModelMultipleChoiceField(label=_('meetingEntity.fields.attender'), queryset=None, widget=AttenderManyToManyMiddleWidget())
    def __init__(self, *args, **kwargs):
        super(AddMeetingAttenderForm, self).__init__(*args, **kwargs)
        self.fields['attender'].queryset = Employee.objects.get_queryset()