# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\iclock\\migrations\\0006_auto_20220419_1516.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:38 UTC (1750702718)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('iclock', '0005_terminalworkcode_company')]
    operations = [migrations.AddField(model_name='transaction', name='company_code', field=models.CharField(max_length=50, null=True, verbose_name='company.field.code')), migrations.AlterUniqueTogether(name='transaction', unique_together=set([('company_code', 'emp_code', 'punch_time')]))]