# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\auto_import.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
import os
import datetime
from django.utils.translation import gettext_lazy as _
from mysite.base import const
from mysite.base.models import SftpSetting
from mysite.base.utils import save_system_log
from mysite.personnel.admin.employee_admin import EmployeeAdmin, Employee, zk_site
from mysite.personnel.admin.employee_import import ImportEmployeeData
from mysite.tools.ftpclient.common_client import CommonFTPClient
ADD_DEFAULT, ADD_USER_DEFINE = (1, 2)
def auto_import_executor(obj, manually=False, **kwargs):
    total_sum = 0
    task_code = obj.task_code
    obj.process_time = datetime.datetime.now()
    obj.save()
    try:
        params = json.loads(obj.params)
        company = obj.company
        files_name = []
        description = ''
        execute_status = const.SUCCESS
        import_path = params.get('import_path', '')
        archived_path = params.get('archived_path', '')
        if import_path:
            files_name = listdir(import_path, files_name)
        ftp_path = params.get('ftp_path', '')
        ftp_server = params.get('ftp_server', '')
        if ftp_server:
            ftp_obj = SftpSetting.objects.filter(id=ftp_server).first()
            local_dir = ftp_download_files(ftp_obj, ftp_path)
            files_name = listdir(local_dir, files_name)
        if files_name and len(files_name) > 0:
            for file_name in files_name:
                backup_file(archived_path, file_name)
                existing_data = params.get('existing_data', 0)
                field = params.get('fields', '')
                kwargs.update({'auto_import': 1, 'overwrite': existing_data, 'import_file': file_name, 'start_row': 2, 'columns': field[0], 'company': company})
                process_emp = ImportEmployeeData(app_label='personnel', model_name='employee', model_admin=EmployeeAdmin(Employee, zk_site), **kwargs)
                process_emp.save()
                if process_emp.errors:
                    execute_status = const.FAILED
                    error_info = str(file_name) + ':' + str(process_emp.errors[0])
                    description += error_info + ';'
                else:
                    total_sum += int(process_emp.total)
        else:
            description = _('autoExport_task_action_manualImport_no_file')
            execute_status = const.FAILED
    except Exception as e:
        print(e)
        execute_status = const.FAILED
        description = str(e)
    if manually:
        return (description, execute_status, total_sum)
    else:
        if execute_status:
            description = _('import_%s_task_code_%s_error_%s') % (str(total_sum), str(task_code), str(description))
        else:
            description = _('import_%s') % str(total_sum)
        try:
            save_system_log(const.AUTO_IMPORT, execute_status, str(description))
        except Exception as e:
            import traceback
            traceback.print_exc()
def listdir(path, list_name):
    for file in os.listdir(path):
        file_path = os.path.join(path, file)
        if os.path.isfile(file_path) and os.path.splitext(file_path)[1] in ['.xlsx', '.xls']:
                list_name.append(file_path)
    return list_name
def ftp_download_files(ftp_obj, ftp_path):
    from mysite.base.models import SystemSetting
    from mysite.settings.components.paths import ADDITION_FILE_ROOT
    time_stamp = SystemSetting.cache_data('ftp_download_time_stamp')
    if time_stamp:
        time_stamp = time_stamp.value
    else:
        time_stamp = datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d%H%M%S')
        SystemSetting(name='ftp_download_time_stamp', value=time_stamp).save()
    ftp_down_path = 'ftp_download_' + str(time_stamp)
    localdir = os.path.join(ADDITION_FILE_ROOT, ftp_down_path)
    if not os.path.exists(localdir):
        os.makedirs(localdir)
    ftp = CommonFTPClient(ftp_obj.host)
    ftp.connect()
    ftp_files = ftp.listdir(ftp_path)
    for ftp_file in ftp_files:
        if '.xls' in ftp_file or '.xlsx' in ftp_file:
            f = os.path.join(ftp_path, ftp_file)
            ftp.download_file(os.path.join(ftp_path, ftp_file), os.path.join(localdir, ftp_file))
            ftp.delete(f)
    ftp.disconnect()
    return localdir
def backup_file(backpath, file_name):
    import shutil
    if not backpath:
        return
    else:
        if not os.path.exists(backpath):
            os.makedirs(backpath)
        time_stamp = datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d%H%M%S')
        f_name, f_ext = os.path.splitext(os.path.split(file_name)[1])
        new_name = f_name + '_' + time_stamp + f_ext
        new_file = os.path.join(backpath, new_name)
        shutil.copyfile(file_name, new_file)