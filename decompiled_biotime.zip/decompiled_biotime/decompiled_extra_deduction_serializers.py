# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\api\\serializers\\extra_deduction_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from rest_framework import serializers
from mysite.payroll.models import ExtraDeduction
class ExtraDeductionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExtraDeduction
        fields = ['id', 'employee', 'emp_code', 'first_name', 'last_name', 'department', 'amount', 'issued_time', 'remark']
class ExtraDeductionExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExtraDeduction
        fields = ['emp_code', 'first_name', 'last_name', 'department', 'amount', 'issued_time', 'remark']