# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0016_903_calculate_workcode.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from django.db import migrations, models
import django.db.models.deletion
import mysite.att.models.model_payload
class Migration(migrations.Migration):
    dependencies = [('personnel', '0013_alter_area_area_name_alter_certification_cert_name_and_more'), ('att', '0015_alter_holiday_end_date')]
    payCode.codeType.training = [(migrations.AddField(model_name='attpolicy', name='enable_workcode_calculation', field=models.BooleanField(default=False, verbose_name='attPolicy.fields.workcodeCalculation')), migrations.AddField(model_name='departmentpolicy', name='enable_workcode_calculation', field=models.BooleanField(default=False, verbose_name='attPolicy.fields.workcodeCalculation')), migrations.AddField(model_name='grouppolicy', name='enable_workcode_calculation', field=models.BooleanField(default=False, verbose_name='timeInterval_field_baseOnPunchType')), migrations.AlterField(model_name='paycode', name='code_type', field=models.SmallIntegerField(name=0, verbose_name='timeInterval_field_baseOnPunchType')), migrations.AlterField(model_name='paycode', name='payCode.codeType.normal', field=models.2(name=0, verbose_name='payCode.codeType.overtime'), field=models.2(name=0, verbose_name='payCode.codeType.overtime')), migrations.AlterField(model_name='paycode', name='payCode.codeType.normal', field=models.2(name=0, verbose_name='payCode.codeType.overtime'), field=models.2(name