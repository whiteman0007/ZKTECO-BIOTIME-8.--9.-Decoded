# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\dashboard_todo_list.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

from itertools import chain
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _
from rest_framework import mixins
from rest_framework.response import Response
from mysite.base.api.utils_class import UserLayUIGenericViewSet
from mysite.workflow.models import WorkflowInstance
from mysite.workflow import models_choices as mc
from mysite.accounts.models import MyUser
from mysite.att.models import Leave, ManualLog, Overtime, Training, ChangeSchedule
from mysite.meeting.models import MeetingEntity, MeetingManualLog
from mysite.visitor.models import Reservation
from mysite.att.actions.common_actions import APPROVAL_VIEW_PERMISSION, APPROVAL_APPROVE_PERMISSION, APPROVAL_REJECT_PERMISSION
class TodoListViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, UserLayUIGenericViewSet):
    model = WorkflowInstance
    queryset = WorkflowInstance.objects.filter(approval_status=mc.PENDING).order_by('approval_time')
    def get_queryset(self):
        import operator
        qs = super(TodoListViewSet, self).get_queryset()
        user = self.request.user
        if not isinstance(user, MyUser):
            return qs.none()
        else:
            if not user.is_superuser:
                if user.auth_dept.exists():
                    qs = qs.filter(employee__department__in=user.auth_dept.all())
                if user.auth_area.exists():
                    qs = qs.filter(employee__area__in=user.auth_area.all())
                if user.assign_company:
                    qs = qs.filter(employee__company=user.assign_company)
            APPROVAL_MODELS = [ManualLog, Leave, Overtime, Training, ChangeSchedule, MeetingEntity, MeetingManualLog, Reservation]
            _models = [m for m in APPROVAL_MODELS if user.has_perm(APPROVAL_VIEW_PERMISSION.get(m._meta.model_name))]
            _qs = [cls.objects.filter(pk__in=qs) for cls in _models if cls.objects.filter(pk__in=qs).exists()]
            qs = list(chain(*_qs))
            qs = sorted(qs, key=lambda x: x.apply_time, reverse=True)
            return qs
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        _approve_pers = [k for k, v in APPROVAL_APPROVE_PERMISSION.items() if request.user.has_perm(v)]
        _reject_pers = [k for k, v in APPROVAL_REJECT_PERMISSION.items() if request.user.has_perm(v)]
        page = self.paginate_queryset(queryset)
        if page is not None:
            data = [{'id': instance.id, 'event': instance.event_id, 'event_display': instance._meta.verbose_name, 'content': instance.n_serialize, 'approve': instance._meta.model_name in _approve_pers, 'reject': instance._meta.model_name in _reject_pers} for instance in page]
            return self.get_paginated_response(data)
        else:
            data = [{'id': instance.id, 'event': instance.event_id, 'event_display': instance._meta.verbose_name, 'content': instance.n_serialize, 'approve': instance._meta.model_name in _approve_pers, 'reject': instance._meta.model_name in _reject_pers} for instance in queryset]
            return Response(data)