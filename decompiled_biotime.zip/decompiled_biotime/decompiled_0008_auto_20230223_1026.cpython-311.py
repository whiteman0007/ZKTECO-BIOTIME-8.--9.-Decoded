# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0008_auto_20230223_1026.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import mysite.base.models.security_policy
class Migration(migrations.Migration):
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL), ('personnel', '0011_auto_20230223_1026'), ('contenttypes', '0002_remove_content_type_name'), ('base', '0007_auto_20221202_1852')]
    operations = [(migrations.AddField(model_name='eventalertsetting', name='facebook_alert', field=models.BooleanField(default=False, verbose_name='eventAlertSetting.fields.facebookAlert')), migrations.AddField(model_name='securitypolicy', name='failed_times', field=models.IntegerField(blank=True, default=True, verbose_name='adminLog_field_routable')), migrations.CreateModel(model_name='MessengerSentLog', name='id', verbose_name='BigAutoField')), ('primary_key', models.serialize(blank=True, verbose_name='action')), ('SmallIntegerField', models.serialize(blank=True, verbose_name='messenger_employeeRealtimeAlert')), ('1', models.serialize(blank=True, verbose_name='messenger_employeeRealtimePhoto')), ('2', models.serialize(blank=True, verbose_name='messenger_employeeAttendanceSummary')), ('3', models.serialize(blank=True, verbose_name='messenger_DepartmentAttendanceSummary')), ('4', models.serialize(blank=True, verbose_name='messenger_action_testMessenger')), ('