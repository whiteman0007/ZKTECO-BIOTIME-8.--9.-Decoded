# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\forms\\leave_group_detail_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att import models_choices as mc
from mysite.att.models import LeaveGroupDetail
from mysite.att.models.model_paycode import PayCode, LEAVE
from mysite.att.models_choices import BASED_ON_SERVICE, MIN_LEAVE_DAY
class LeaveGroupDetailForm(ModelForm):
    pay_code = forms.ModelChoiceField(label=_('leaveGroupDetail.fields.payCode'), queryset=PayCode.objects.get_leave_queryset())
    leave_type = forms.ChoiceField(label=_('leaveGroupDetail.fields.leaveType'), choices=mc.LEAVE_TYPE, initial=0)
    allow_leave_day = forms.IntegerField(label=_('leaveGroupDetail.fields.allowLeaveDay'), unit=_('time.units.day'), initial=1)
    min_leave_day = forms.FloatField(label=_('leaveGroupDetail.fields.minLeaveDay'), unit=_('time.units.day'), initial=1, min_value=0)
    deduct_holiday_day = forms.ChoiceField(label=_('leaveGroupDetail.fields.deductHolidayDay'), choices=mc.BOOLEANS, initial=0)
    leave_entitlement = forms.IntegerField(label=_('leaveGroupDetail.fields.leaveEntitlement'), initial=1)
    leave_interval = forms.ChoiceField(label=_('leaveGroupDetail.fields.leaveInterval'), initial=mc.LEAVE_INTERVAL_YEAR, choices=mc.LEAVE_INTERVA, disabled=True)
    leave_distribution_time = forms.ChoiceField(label=_('leaveGroupDetail.fields.leaveDistributionTime'), choices=mc.LEAVE_DISTRIBUTION_TIME)
    start_day = forms.CharField(label=_('leaveGroupDetail.fields.startDay'), initial=mc.START_DAY)
    set_hire_day = forms.ChoiceField(label=_('leaveGroupDetail.fields.setHireDay'), initial=0, choices=mc.BOOLEANS)
    allow_exceed_limit = forms.ChoiceField(label=_('leaveGroupDetail.fields.allowExceedLimit'), initial=0, choices=mc.BOOLEANS)
    allow_balance = forms.ChoiceField(label=_('leaveGroupDetail.fields.allowBalance'), initial=0, choices=mc.BOOLEANS)
    max_balance = forms.IntegerField(label=_('leaveGroupDetail.fields.maxBalance'), initial=0, required=False)
    entitlement_detail = forms.JSONField(label=_('leaveGroupDetail.fields.entitlement_detail'), required=False)
    class Meta:
        model = LeaveGroupDetail
        fields = '__all__'
    def __init__(self, request, *args, **kwargs):
        super(LeaveGroupDetailForm, self).__init__(*args, **kwargs)
        obj = request.GET.get('id', None)
        if not obj:
            return
        else:
            obj = LeaveGroupDetail.objects.filter(id=obj).first()
            kwargs['instance'] = obj
            super(LeaveGroupDetailForm, self).__init__(*args, **kwargs)
            try:
                self.fields['pay_code'].queryset = PayCode.objects.filter(code_type=LEAVE)
                self.fields['pay_code'].disabled = True
                self.fields['entitlement_detail'].initial = obj.entitlement_detail.replace('\'', '\"')
            except:
                return None
class LeaveGroupDetailPostForm(LeaveGroupDetailForm):
    def save(self, commit=True, id=None):
        if not commit:
            self.check_leave_group_detail(id)
        leavegroupdetail = super(LeaveGroupDetailPostForm, self).save(commit=commit)
        return leavegroupdetail
    def check_leave_group_detail(self, id=None):
        nodes_ex = LeaveGroupDetail.objects.filter(leave_group=self.cleaned_data['leave_group'], pay_code=self.cleaned_data['pay_code']).exclude(id=id)
        if self.cleaned_data['min_leave_day'] and self.cleaned_data['min_leave_day'] % MIN_LEAVE_DAY > 0:
            raise forms.ValidationError(_('leaveGroup.alert.invalidLeaveDay'))
        else:
            if nodes_ex.exists():
                raise forms.ValidationError(_('pay_code_already_exist'))
            else:
                if int(self.cleaned_data['leave_type']) == BASED_ON_SERVICE:
                    nodes_ex = LeaveGroupDetail.objects.filter(leave_group=self.cleaned_data['leave_group'], leave_type=BASED_ON_SERVICE).exclude(id=id)
                    if nodes_ex.exists():
                        raise forms.ValidationError(_('leave_type_repeat'))
                return True