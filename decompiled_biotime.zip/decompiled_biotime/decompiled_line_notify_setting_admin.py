# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\line_notify_setting_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import json
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms, ZKModelAction
from mysite.admin.kernel import ZKModelAdmin
from mysite.base.models import LineNotifySetting, LineNotifyForEmployee
from mysite.personnel import fields, widgets
from mysite.base.models import SystemSetting
LINE_NOTIFY_SERVICE = 'line_notify_service'
class AddLineNotifyServiceForm(forms.ZKActionForm):
    service_name = forms.CharField(label=_('Service name'), required=True)
    company = forms.CharField(label=_('Company/Enterprise'), required=True)
    client_id = forms.CharField(label=_('Client id'), required=True)
    client_secret = forms.CharField(label=_('Client secret'), required=True)
    callback_url = forms.URLField(label=_('Callback URL'), required=True, widget=forms.widgets.ZKTextInput(attrs={'readonly': True, 'placeholder': _('Click here to add content')}))
    service_url = forms.CharField(label=_('Service URL'), required=True)
class AddLineNotifyService(ZKModelAction):
    verbose_name = _('Add Line Service')
    short_description = _('The service that collects Line Notify tokens and generates QR codes')
    action_form = AddLineNotifyServiceForm
    action_template = 'lineconfig/linenotifyforemployee/actions/AddLineNotifyService.html'
    def action(self, *args, **kwargs):
        params = json.dumps(kwargs)
        line_sys = SystemSetting.objects.filter(name=LINE_NOTIFY_SERVICE).first()
        if line_sys:
            line_sys.value = params
            line_sys.save(force_update=True)
        else:
            SystemSetting(name=LINE_NOTIFY_SERVICE, value=params).save(force_insert=True)
class LineNotifyForEmployeeChangeForm(ModelForm):
    employee = forms.CharField(label=_('Employee'), disabled=True)
    def __init__(self, *args, **kwargs):
        super(LineNotifyForEmployeeChangeForm, self).__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields['employee'].initial = str(self.instance.employee)
    def save(self, commit=True):
        instance = super(LineNotifyForEmployeeChangeForm, self).save(commit)
        return instance
    class Meta:
        model = LineNotifyForEmployee
        fields = ('line_notify_token', 'message_type', 'message_head', 'message_tail', 'is_valid', 'remark')
@admin.register(LineNotifyForEmployee)
class LineNotifyForEmployeeAdmin(ZKModelAdmin):
    list_display = ['id', 'employee', 'line_notify_token', 'message_type', 'message_head', 'message_tail', 'is_valid', 'remark']
    sort_fields = ['employee']
    list_filter = ['employee', 'line_notify_token', 'message_type', 'is_valid']
    form = LineNotifyForEmployeeChangeForm
    grid_template = 'lineconfig/linenotifyforemployee/grid.html'
    add_form_template = 'lineconfig/linenotifyforemployee/edit.html'
    change_form_template = 'lineconfig/linenotifyforemployee/edit.html'
    actions = (AddLineNotifyService,)
    def has_add_permission(self, request):
        return False
@admin.register(LineNotifySetting)
class LineNotifySettingAdmin(ZKModelAdmin):
    list_display = ['id', 'line_notify_dept', 'include_sub_department', 'line_notify_token', 'message_type', 'message_head', 'message_tail', 'is_valid', 'remark']
    sort_fields = ['line_notify_dept']
    list_filter = ['line_notify_dept', 'line_notify_token', 'message_type', 'is_valid']
    formfield_overrides = {fields.DepartmentForeignKey: {'widget': widgets.DepartmentRadioSelect}}
    grid_template = 'lineconfig/linenotifysetting/grid.html'
    add_form_template = 'lineconfig/linenotifysetting/edit.html'
    change_form_template = 'lineconfig/linenotifysetting/edit.html'