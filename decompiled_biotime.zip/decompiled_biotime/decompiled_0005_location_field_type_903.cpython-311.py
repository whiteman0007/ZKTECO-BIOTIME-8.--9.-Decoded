# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\mobile\\migrations\\0005_location_field_type_903.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:58 UTC (1750702738)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('mobile', '0004_mobileapirequestlog')]
    operations = [migrations.AlterField(model_name='appnotification', name='category', field=models.SmallIntegerField(choices=[(1, 'notification_category_leave'), (2, 'notification_category_overtime'), (3, 'notification_category_manualLog'), (4, 'notification_category_training'), (5, 'notification_category_schedule'), (6, 'notification_category_announcement'), (7, 'notification_category_exception'), (8, 'menu_device_transaction')], verbose_name='appNotice_field_category')), migrations.AlterField(model_name='appnotification', name='sub_category', field=models.IntegerField(blank=True, choices=[(61, 'notification_subCategory_publicAnnouncement'), (62, 'notification_subCategory_privateAnnouncement'), (71, 'notification_subCategory_late'), (72, 'notification_subCategory_earlyLeave'), (73, 'notification_subCategory_absent'), (81, 'transaction_field_punchState')], null=True, verbose_name='appNotice_field_subCategory'))]