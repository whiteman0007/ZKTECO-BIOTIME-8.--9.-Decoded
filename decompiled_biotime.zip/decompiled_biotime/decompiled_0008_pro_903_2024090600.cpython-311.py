# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\payroll\\migrations\\0008_pro_903_2024090600.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:06 UTC (1750702746)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('payroll', '0007_extradeduction_special_type_and_more')]
    operations = [migrations.AddField(model_name='emppayrollprofile', name='internal_emp_num', field=models.CharField(blank=True, max_length=50, null=True, verbose_name='emp_field_InternalNum')), migrations.AddField(model_name='emppayrollprofile', name='national_num', field=models.CharField(blank=True, max_length=50, null=True, verbose_name='emp_field_nationalNumber')), migrations.AddField(model_name='emppayrollprofile', name='payroll_num', field=models.CharField(blank=True, max_length=50, null=True, verbose_name='emp_field_payrollNumber'))]