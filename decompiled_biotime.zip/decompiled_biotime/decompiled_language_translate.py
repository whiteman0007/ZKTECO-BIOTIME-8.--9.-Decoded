# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\language_translate.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:13 UTC (1750672993)

import os
from mysite.tools.system_cmd import run_command
const_messages = ['# SOME DESCRIPTIVE TITLE.\n', '# Copyright (C) YEAR THE PACKAGE\'S COPYRIGHT HOLDER\n', '# This file is distributed under the same license as the PACKAGE package.\n', '# FIRST AUTHOR <EMAIL@ADDRESS>, YEAR.\n', '#\n', '#, fuzzy\n', 'msgid \"\"\n', 'msgstr \"\"\n', '\"Project-Id-Version: biotime 8.0\\n\"\n', '\"Report-Msgid-Bugs-To: \\n\"\n', '\"POT-Creation-Date: 2019-03-15 23:43+0800\\n\"\n', '\"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\\n\"\n', '\"Last-Translator: FULL NAME <EMAIL@ADDRESS>\\n\"\n', '\"Language-Team: LANGUAGE <LL@li.org>\\n\"\n', '\"MIME-Version: 1.0\\n\"\n', '\"Content-Type: text/plain; charset=UTF-8\\n\"\n', '\"Content-Transfer-Encoding: 8bit\\n\"\n', '\"Language: {0}\\n\"\n', '\"Plural-Forms: nplurals=1; plural=0;\\n\"\n']
def new_row():
    return {'id': '', 'msgid': '', 'msgstr': '', 'newstr': ''}
def get_language_dictionary(lan, module):
    import collections
    from django.conf import settings
    language_dict = collections.OrderedDict()
    if lan:
        lan = lan.replace('-', '_')
        reference_lan_file = os.path.join(settings.PROJECT_PATH, '{module}locale/{lan}/LC_MESSAGES/django.po'.format(module=module + '/' if module!= 'att' else '', lan=lan))
        if os.path.isfile(reference_lan_file):
            with open(reference_lan_file, encoding='utf-8') as f:
                id_value = ''
                for line in f.readlines():
                    line = line.rstrip()
                    if line.startswith('msgid'):
                        id_value = line[6:].replace('\"', '')
                        if id_value and id_value not in language_dict:
                                language_dict[id_value] = ''
                    else:
                        if line.startswith('msgstr'):
                            str_value = line[7:].replace('\"', '')
                            if str_value and id_value and (id_value in language_dict):
                                        language_dict[id_value] = str_value
                                        id_value = ''
    return language_dict
def get_reference_language(request):
    data = []
    reference_lan = request.GET.get('ref_lan', '')
    module = request.GET.get('module', 'att')
    key_language_dict = get_language_dictionary('en', module)
    row = new_row()
    count = 1
    for key, value in list(key_language_dict.items()):
        row['id'] = count
        row['msgid'] = key
        if reference_lan == 'en':
            row['msgstr'] = value
        data.append(row)
        row = new_row()
        count = count + 1
    ref_language_dict = {}
    if reference_lan and reference_lan!= 'null' and (reference_lan!= 'en'):
                ref_language_dict = get_language_dictionary(reference_lan, module)
    tra_lan = request.GET.get('tra_lan', '')
    tra_language_dict = {}
    if tra_lan and tra_lan!= 'null':
            tra_language_dict = get_language_dictionary(tra_lan, module)
    for row in data:
        if row['msgid'] in ref_language_dict:
            row['msgstr'] = ref_language_dict[row['msgid']]
        if row['msgid'] in tra_language_dict:
            row['newstr'] = tra_language_dict[row['msgid']]
    return data
def save_translate_language(lan, module, data):
    import json
    from django.conf import settings
    lan = lan.replace('-', '_')
    if data and lan and (lan!= 'null'):
        messages = json.loads(data)
        file_path = os.path.join(settings.PROJECT_PATH, '{module}locale/{lan}/LC_MESSAGES/'.format(module=module + '/' if module!= 'att' else '', lan=lan))
        if not os.path.exists(file_path):
            os.makedirs(file_path)
        new_lan_file = os.path.join(settings.PROJECT_PATH, '{module}locale/{lan}/LC_MESSAGES/django.po'.format(module=module + '/' if module!= 'att' else '', lan=lan))
        index = 0
        for line in const_messages:
            if line.startswith('\"Language:'):
                break
            else:
                index = index + 1
        if index:
            const_messages[index] = const_messages[index].format(lan)
        write_messages = []
        for message in messages:
            write_messages.append('\n')
            write_messages.append('msgid \"{0}\"\n'.format(message['msgid']))
            write_messages.append('msgstr \"{0}\"\n'.format(message['newstr']))
        with open(new_lan_file, 'w') as f:
            f.writelines(const_messages)
            f.writelines(write_messages)
        return compilemessage(lan)
    else:
        return '0'
def compilemessage(lan):
    from django.conf import settings
    try:
        os.chdir(settings.PROJECT_PATH)
        cmd = 'call compilemessages.bat {0}'.format(lan)
        run_command(cmd)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return 'Current directory:{0},error:{1}'.format(os.getcwd(), str(e))
def restart_apache_service():
    from django.conf import settings
    try:
        os.chdir(settings.PROJECT_PATH)
        cmd = 'call restart.bat'
        run_command(cmd)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return 'Current directory:{0},error:{1}'.format(os.getcwd(), str(e))