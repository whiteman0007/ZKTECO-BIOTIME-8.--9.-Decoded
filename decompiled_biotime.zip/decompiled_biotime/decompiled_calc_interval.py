# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\calc_new\\calc_interval.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import collections
import datetime
import decimal
import uuid
from django.conf import settings
from mysite._utils import getattr_ex
from mysite.att import const
from mysite.att import models_choices as mc
from mysite.att.calc_new.calc_interval_detail import calc_leave, calc_overtime, calc_pay_code, calc_regular_ot, calc_break, calc_att_time, calc_full_attendance_present, calc_flex_att_time, calc_training
from mysite.att.calc_new.calc_save import auto_add_overtime, get_payload_pay_code, get_payload_att_code, get_payload_paring
from mysite.att.calc_new.const import NORMAL, DAY_OFF, WEEKEND, HOLIDAY
from mysite.att.calc_new.punch_match import punch_time_for_no_scheduled_day, punch_time_for_interval, get_paring_punchs, punch_time_for_flex_interval, punch_time_for_work_code
from mysite.att.calc_new.utils import cache_data, reset_overtime
from mysite.att.models import BreakTime
from mysite.utils import get_dt4mssql
def calc_work_code(in_time, out_time, transactions, policy, work_day, base_data, interval=None):
    work_code_parings = punch_time_for_work_code(in_time, out_time, transactions, policy, interval)
    work_code_paring_datas = []
    for paring in work_code_parings:
        paring_in, paring_out = (paring[0], paring[1])
        work_code = None
        work_code_in, work_code_out = (None, None)
        work_code_duration = 0
        if paring_in:
            work_code_in = paring_in['punch_time']
            work_code = paring_in['work_code']
        if paring_out:
            work_code_out = paring_out['punch_time']
            work_code = paring_out['work_code']
        if work_code_in and work_code_out:
                work_code_duration = int((work_code_out - work_code_in).total_seconds()) // 60
        paring_data = {}
        paring_data.update(base_data)
        paring_data.update({'clock_in': work_code_in, 'clock_out': work_code_out, 'duration': work_code_duration, 'work_code': work_code, 'workday': work_day, 'stamp': 0, 'worked_duration': 0})
        work_code_paring_datas.append(paring_data)
    return work_code_paring_datas
def calc_no_interval(emp, cur_date, base_data, policy, transactions, overtimes, leaves, otp_dict, pc_dict, ac_dict, punch_state_dict, pc, trainings, wc_dict, leave_group_detail):
    """Calc no interval day attendance\n    计算所有未排班的考勤\n        1. 当天没有shift，没有temp sche\n        2. 当天有shift，shift当天未排班\n\n    Args:\n        emp: Employee obj\n        cur_date: datetime.date\n        base_data: dict, for payload save\n        policy: att policy obj\n        transactions: [dict, ...]\n        overtimes: [dict, ...]\n        leaves: [dict, ...]\n        otp_dict: cache dict\n        pc_dict: cache dict\n        ac_dict: cache dict\n        punch_state_dict: cache dict\n        pc: cache dict\n\n    Returns:\n        payload dict:\n            ret_data = {\n                \'time_card\': time_card_data,\n                \'pay_code\': pay_code_datas,\n                \'att_code\': att_code_datas,\n                \'paring\': paring_datas,\n                \'effect_punch\': effect_punch_datas,\n            }\n    """
    work_day = 1
    in_time = datetime.datetime.combine(cur_date, get_dt4mssql(policy.day_change, 2))
    out_time = in_time + datetime.timedelta(days=1)
    work_time = int(policy.max_hrs * 60)
    training_list = calc_training(trainings, in_time, out_time)
    for training in training_list:
        training['pay_code_time'] = int((training['end_time'] - training['start_time']).total_seconds()) // 60
    leave_list, _cover_in, _cover_out = calc_leave(leaves, in_time, out_time)
    for leave in leave_list:
        group_detail = leave_group_detail.get(leave['pay_code_id'], None)
        if group_detail and (not group_detail.deduct_holiday_day):
            leave['pay_code_time'] = int((leave['end_time'] - leave['start_time']).total_seconds()) // 60
            leave['pay_code_time'] = min(leave['pay_code_time'], work_time)
        else:
            leave['pay_code_time'] = 0
    in_time = _cover_in if _cover_in else in_time
    out_time = _cover_out if _cover_out else out_time
    work_hrs = decimal.Decimal(round(int((out_time - in_time).total_seconds()) / 3600, 2))
    if work_hrs and work_hrs < policy.max_hrs:
            work_day = decimal.Decimal(round(work_hrs / policy.max_hrs, 2))
    punch_parings, overtime_punchs = punch_time_for_no_scheduled_day(in_time, out_time, transactions, policy)
    in_punch, out_punch = (None, None)
    if punch_parings:
        in_punch = punch_parings[0][0]['punch_time'] if punch_parings[0][0] else None
        out_punch = punch_parings[(-1)][1]['punch_time'] if punch_parings[(-1)][1] else None
    if not in_punch and (not out_punch):
            work_day = 0
    auto_add_overtime(emp, overtime_punchs, overtimes, policy.ot_pay_code_id, policy.overtime_policy)
    ot_paycodes = []
    if policy.use_ot in [2, 3]:
        ot_paycodes = calc_overtime(overtimes, in_time, out_time)
    paycode = calc_pay_code(ot_paycodes, leave_list, [], training_list)
    total_leave_time = sum([i['pay_code_time'] for i in leave_list])
    total_hrs = sum([int((_out['punch_time'] - _in['punch_time']).total_seconds()) // 60 for _in, _out in punch_parings if _in and _out])
    attcode = collections.defaultdict(int)
    attcode['duration'] = policy.max_hrs * 60
    attcode['duty_duration'] = 0
    attcode['total_hrs'] = total_hrs
    paycode[pc['regular']] += min(attcode['duration'], total_hrs)
    is_weekend = cur_date.weekday() == policy.weekend1 or cur_date.weekday() == policy.weekend2
    if is_weekend and policy.weekend_ot:
        calc_regular_ot(paycode, pc['regular'], policy.weekend_ot_rule, otp_dict)
    else:
        if policy.daily_ot:
            calc_regular_ot(paycode, pc['regular'], policy.daily_ot_rule, otp_dict)
    paycode[pc['regular']] = min(paycode[pc['regular']], int(policy.max_hrs * 60))
    total_ot = sum([v for k, v in paycode.items() if pc_dict[k].code_type == const.OVERTIME])
    attcode['worked_hrs'] = paycode[pc['regular']] + total_ot
    attcode['total_leave'] = total_leave_time
    attcode['total_ot'] = total_ot
    attcode['rule_total_ot'] = total_ot
    time_card_id = uuid.uuid4().hex
    if is_weekend:
        date_type = WEEKEND
        paycode[pc['regular']] = 0
    else:
        date_type = DAY_OFF
    time_card_data = {'id': time_card_id, 'time_table_alias': '', 'date_type': date_type, 'present': 0, 'full_attendance': 1, 'check_in': in_time, 'check_out': out_time, 'work_day': work_day, 'clock_in': in_punch, 'clock_out': out_punch}
    time_card_data.update(base_data)
    base_data['time_card_id'] = time_card_id
    if policy.enable_workcode_calculation:
        work_code_paring_datas = calc_work_code(in_time, out_time, transactions, policy, work_day, base_data)
        for work_code_paring in work_code_paring_datas:
            work_code = wc_dict.get(work_code_paring['work_code'])
            if work_code and work_code.pay_code:
                work_code_paring.update({'pay_code': work_code.pay_code.name})
                if work_code.pay_code.id in paycode:
                    paycode[work_code.pay_code.id] = paycode[work_code.pay_code.id] + work_code_paring['duration']
                else:
                    paycode[work_code.pay_code.id] = work_code_paring['duration']
            else:
                work_code_paring.update({'pay_code': ''})
    else:
        work_code_paring_datas = []
    pay_code_datas = get_payload_pay_code(cur_date, paycode, base_data, work_time, pc_dict, work_day)
    att_code_datas = get_payload_att_code(attcode, base_data, work_time, ac_dict, work_day)
    paring_datas = []
    effect_punch_datas = []
    data_index = 1
    for paring in punch_parings:
        in_punch = paring[0]['punch_time'] if paring[0] else None
        out_punch = paring[1]['punch_time'] if paring[1] else None
        paring, punchs = get_paring_punchs(in_punch, paring[0], out_punch, paring[1], punch_state_dict.get('check_in'), punch_state_dict.get('check_out'))
        paring_data = get_payload_paring(1, data_index, pc['regular'], work_day, base_data, paring)
        data_index += 1
        paring_datas.append(paring_data)
        effect_punch_datas.extend(punchs)
        for i, v in enumerate(effect_punch_datas):
            effect_punch_datas[i].update(base_data)
    ret_data = {'time_card': time_card_data, 'pay_code': pay_code_datas, 'att_code': att_code_datas, 'paring': paring_datas, 'effect_punch': effect_punch_datas, 'work_code_paring': work_code_paring_datas}
    return ret_data
def calc_interval(emp, cur_date, base_data, policy, interval, holiday, is_temp_sche, transactions, overtimes, leaves, break_dict, otp_dict, pc_dict, ac_dict, punch_state_dict, pc, trainings, wc_dict):
    # irreducible cflow, using cdg fallback
    """Calc interval day attendance\n    计算所有未排班的考勤\n        1. 当天有shift，shift当天排班有interval\n        2. 当天没有shift，当天有temp sche\n\n    Args:\n        emp: Employee obj\n        cur_date: datetime.date\n        base_data: dict, for payload save\n        policy: att policy obj\n\n        interval: interval obj\n        holiday: holiday obj\n        is_temp_sche: bool\n\n        transactions: [dict, ...]\n        overtimes: [dict, ...]\n        leaves: [dict, ...]\n        break_dict: cache dict\n        otp_dict: cache dict\n        pc_dict: cache dict\n        ac_dict: cache dict\n        punch_state_dict: cache dict\n        pc: cache dict\n\n    Returns:\n        payload dict:\n            ret_data = {\n                \'time_card\': time_card_data,\n                \'pay_code\': pay_code_datas,\n                \'att_code\': att_code_datas,\n                \'paring\': paring_datas,\n                \'effect_punch\': effect_punch_datas,\n            }\n    """
    total_leave_time, total_break_duration, total_break_time = (0, 0, 0)
    interval_in_time = in_time = datetime.datetime.combine(cur_date, get_dt4mssql(interval.in_time, 2))
    interval_out_time = out_time = in_time + datetime.timedelta(minutes=interval.duration)
    in_punch, in_trans = (None, None)
    out_punch, out_trans = (None, None)
    break_list = []
    paycode = collections.defaultdict(int)
    attcode = collections.defaultdict(int)
    check_punchs, check_trans = ([], [])
    is_flex_interval = False
    if interval.use_mode == mc.FLEXIBLE_TIME_INTERVAL:
        is_flex_interval = True
        interval_duration = interval.work_time_duration
    else:
        interval_duration = interval.duration
    enable_regular_ot, is_absent, is_incomplete = (False, False, False)
    regular_ot_rule = None
    is_weekend = cur_date.weekday() == policy.weekend1 or cur_date.weekday() == policy.weekend2
    is_dayoff = False
    if interval.work_type == WEEKEND:
        is_weekend = True
    else:
        if interval.work_type == DAY_OFF:
            is_weekend = False
            is_dayoff = True
    if is_temp_sche:
        holiday = None
    interval.work_day = decimal.Decimal(round(interval.work_day, 2))
    if holiday:
        if holiday.enable_ot_rule:
            enable_regular_ot = True
            regular_ot_rule = holiday.ot_rule
        else:
            if policy.holiday_ot:
                enable_regular_ot = True
                regular_ot_rule = policy.holiday_ot_rule
    for break_id in interval.break_time_ids:
        break_obj = cache_data(break_dict, break_id, BreakTime)
        if break_obj:
            total_break_time += break_obj.duration
    interval_work_time = interval_duration - total_break_time
    total_break_duration = total_break_time
    training_list = calc_training(trainings, in_time, out_time)
    for training in training_list:
        training['pay_code_time'] = int((training['end_time'] - training['start_time']).total_seconds()) // 60
    if holiday and (not enable_regular_ot):
        total_break_time = 0
        leave_list, leave_cover_in, leave_cover_out = calc_leave(leaves, in_time, out_time)
        leave_over_day = leave_cover_in and leave_cover_in <= interval_in_time and leave_cover_out and (leave_cover_out >= interval_out_time)
        if leave_cover_in and interval_out_time > leave_cover_in > interval_in_time:
                    in_time, in_punch = (leave_cover_in, leave_cover_in)
        if leave_cover_out and leave_cover_out > interval_out_time:
                out_time, out_punch = (leave_cover_out, leave_cover_out)
        break_list = calc_break(cur_date, transactions, interval, break_dict, leave_list)
        for leave in leave_list:
            leave['pay_code_time'] = int((leave['end_time'] - leave['start_time']).total_seconds()) // 60
            leave['pay_code_time'] -= leave['break_overlap']
            if is_flex_interval:
                leave['pay_code_time'] = min(leave['pay_code_time'], interval_duration)
        allow_ot_intervals = []
        if is_flex_interval:
            check_punchs, check_trans, overtime_punchs = punch_time_for_flex_interval(transactions, interval, in_time, out_time)
            allow_ot_intervals.append([in_time, out_time])
            in_punch, out_punch, in_trans, out_trans, overtime_punchs = punch_time_for_interval(transactions, interval, in_time, out_time)
            if not leave_over_day:
                if leave_cover_in and interval_out_time > leave_cover_in >= interval_in_time:
                            in_time = leave_cover_in
                            in_punch = leave_cover_in
                            in_ot = [in_time - datetime.timedelta(minutes=interval.in_ahead_margin), in_time]
                            allow_ot_intervals.append(in_ot)
                if leave_cover_out and leave_cover_out >= interval_out_time:
                    out_time = leave_cover_out
                    out_punch = leave_cover_out
                else:
                    out_ot = [out_time, out_time + datetime.timedelta(minutes=interval.out_above_margin)]
                    allow_ot_intervals.append(out_ot)
            check_punchs = [[in_punch, out_punch]]
            check_trans = [[in_trans, out_trans]]
        auto_add_overtime(emp, overtime_punchs, overtimes, interval.ot_pay_code_id, interval.overtime_policy)
        ot_paycodes = []
        need_calc_ot = False
        if policy.use_ot == 0:
            pass
        else:
            if policy.use_ot == 1:
                need_calc_ot = True
            else:
                if policy.use_ot == 2:
                    for ot_start_time, ot_end_time in allow_ot_intervals:
                        ot_paycodes.extend(calc_overtime(overtimes, ot_start_time, ot_end_time))
                else:
                    if policy.use_ot == 3:
                        for ot_start_time, ot_end_time in allow_ot_intervals:
                            ot_paycodes.extend(calc_overtime(overtimes, ot_start_time, ot_end_time))
                        if not ot_paycodes:
                            need_calc_ot = True
        paycode = calc_pay_code(ot_paycodes, leave_list, break_list, training_list)
        if is_flex_interval:
            is_incomplete = False
            is_absent = calc_flex_att_time(attcode, paycode, check_punchs, interval, policy, otp_dict, pc, need_calc_ot, leave_list)
        else:
            is_absent, is_incomplete = calc_att_time(attcode, paycode, in_time, in_punch, out_time, out_punch, interval, policy, otp_dict, pc, need_calc_ot)
        total_leave_time = sum([i['pay_code_time'] for i in leave_list])
        total_break_time = sum([i['break_time'] for i in break_list])
        if not holiday:
            enable_regular_ot = interval.enable_overtime
            regular_ot_rule = interval.ot_rule
            if policy.weekend_ot:
                if is_weekend:
                    enable_regular_ot = policy.weekend_ot
                    regular_ot_rule = policy.weekend_ot_rule
            else:
                if policy.daily_ot and is_dayoff:
                        enable_regular_ot = policy.daily_ot
                        regular_ot_rule = policy.daily_ot_rule
    if False:
        pass
    attcode['duration'] = interval_duration
    attcode['duty_duration'] = interval_work_time if not holiday else 0
    if is_absent is True:
        paycode[pc['absent']] = interval_duration - total_break_duration - total_leave_time
        paycode[pc['late_in']] = 0
        paycode[pc['early_out']] = 0
    if is_incomplete:
        attcode['total_hrs'] = 0
        paycode[pc['regular']] = 0
    else:
        exception_time = paycode[pc['absent']] + paycode[pc['late_in']] + paycode[pc['early_out']]
        paycode[pc['regular']] += interval_work_time - exception_time - total_leave_time
    if enable_regular_ot:
        calc_regular_ot(paycode, pc['regular'], regular_ot_rule, otp_dict)
    total_ot = sum([v for k, v in paycode.items() if pc_dict[k].code_type == const.OVERTIME])
    attcode['total_leave'] = total_leave_time
    attcode['break_duration'] = total_break_duration
    attcode['break_total_hrs'] = total_break_duration
    attcode['break_hrs'] = total_break_time
    attcode['total_ot'] = total_ot
    attcode['rule_total_ot'] = total_ot
    if interval.enable_max_ot_limit and interval.max_ot_limit < total_ot:
            attcode['rule_total_ot'] = interval.max_ot_limit
    full_attendance, present = calc_full_attendance_present(paycode, in_punch, out_punch, pc_dict, pc)
    time_card_id = uuid.uuid4().hex
    if holiday:
        date_type = HOLIDAY
        paycode[pc['regular']] = 0
        paycode[pc['absent']] = 0
        paycode[pc['late_in']] = 0
        paycode[pc['early_out']] = 0
        full_attendance = 0
        present = 3
    else:
        if is_weekend:
            date_type = WEEKEND
            paycode[pc['regular']] = 0
            paycode[pc['absent']] = 0
            paycode[pc['late_in']] = 0
            paycode[pc['early_out']] = 0
            full_attendance = 0
            present = 0
        else:
            if is_dayoff:
                date_type = DAY_OFF
                paycode[pc['regular']] = 0
                paycode[pc['absent']] = 0
                paycode[pc['late_in']] = 0
                paycode[pc['early_out']] = 0
                full_attendance = 0
            else:
                date_type = NORMAL
    attcode['remaining'] = attcode['duty_duration'] - total_leave_time - paycode[pc['regular']]
    attcode['worked_hrs'] = paycode[pc['regular']] + total_ot
    time_card_data = {'id': time_card_id, 'time_table_alias': interval.alias, 'time_table': interval, 'date_type': date_type, 'present': present, 'full_attendance': full_attendance, 'work_day': interval.work_day, 'check_in': in_time, 'check_out': out_time, 'clock_in': check_punchs[0][0] if check_punchs else None, 'clock_out': check_punchs[(-1)][(-1)] if check_punchs else None}
    if getattr_ex(settings, 'THAILAND', False) and (not emp.attemployee.enable_overtime):
            reset_overtime(paycode, attcode)
    time_card_data.update(base_data)
    base_data['time_card_id'] = time_card_id
    if policy.enable_workcode_calculation:
        work_code_paring_datas = calc_work_code(interval_in_time, interval_out_time, transactions, policy, interval.work_day, base_data, interval)
        for work_code_paring in work_code_paring_datas:
            work_code = wc_dict.get(work_code_paring['work_code'])
            if work_code and work_code.pay_code:
                work_code_paring.update({'pay_code': work_code.pay_code.name})
                if work_code.pay_code.id in paycode:
                    paycode[work_code.pay_code.id] = paycode[work_code.pay_code.id] + work_code_paring['duration']
                else:
                    paycode[work_code.pay_code.id] = work_code_paring['duration']
            else:
                work_code_paring.update({'pay_code': ''})
    else:
        work_code_paring_datas = []
    pay_code_datas = get_payload_pay_code(cur_date, paycode, base_data, interval_work_time, pc_dict, interval.work_day)
    att_code_datas = get_payload_att_code(attcode, base_data, interval_work_time, ac_dict, interval.work_day)
    paring_datas = []
    effect_punch_datas = []
    data_index = 1
    for _punchs, _transs in zip(check_punchs, check_trans):
        in_punch, out_punch = (_punchs[0], _punchs[1])
        in_trans, out_trans = (_transs[0], _transs[1])
        paring, punchs = get_paring_punchs(in_punch, in_trans, out_punch, out_trans, punch_state_dict.get('check_in'), punch_state_dict.get('check_out'))
        paring_data = get_payload_paring(1, data_index, pc['regular'], interval.work_day, base_data, paring)
        paring_datas.append(paring_data)
        effect_punch_datas.extend(punchs)
        data_index += 1
    data_index = 1
    for _break_data in break_list:
        start_punch, start_trans = (_break_data['break_out'], _break_data['trans_start'])
        end_punch, end_trans = (_break_data['break_in'], _break_data['trans_end'])
        paring, punchs = get_paring_punchs(start_punch, start_trans, end_punch, end_trans, punch_state_dict.get('break_out'), punch_state_dict.get('break_in'))
        paring_data = get_payload_paring(2, data_index, None, interval.work_day, base_data, paring)
        paring_datas.append(paring_data)
        effect_punch_datas.extend(punchs)
        if data_index == 1:
            time_card_data['break_out'] = start_trans['punch_time'] if start_trans else None
            time_card_data['break_in'] = end_trans['punch_time'] if end_trans else None
        data_index += 1
    for i, v in enumerate(effect_punch_datas):
        effect_punch_datas[i].update(base_data)
    ret_data = {'time_card': time_card_data, 'pay_code': pay_code_datas, 'att_code': att_code_datas, 'paring': paring_datas, 'effect_punch': effect_punch_datas, 'work_code_paring': work_code_paring_datas}
    return ret_data