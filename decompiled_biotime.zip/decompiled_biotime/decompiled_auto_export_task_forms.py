# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\forms\\auto_export_task_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

import json
import os
import re
import six
from django.forms import ModelForm, ModelMultipleChoiceField, ValidationError
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.base import const
from mysite.base.models import AutoExportTask, SftpSetting
from mysite.personnel import widgets
from mysite.personnel.models import Department, Area, Company
from mysite.personnel.utils import get_default_company
from mysite.authorized import auth_settings
WEEKDAY = (('0', _('weekday_option_monday')), ('1', _('weekday_option_tuesday')), ('2', _('weekday_option_wednesday')), ('3', _('weekday_option_thursday')), ('4', _('weekday_option_friday')), ('5', _('weekday_option_saturday')), ('6', _('weekday_option_sunday')))
FULL_VOLUME, INCREMENTAL = (1, 2)
EXPORT_TYPE = ((FULL_VOLUME, _('autoExport.choices.fullVolume')), (INCREMENTAL, _('autoExport.choices.incremental')))
MONTHLY = [(x, x) for x in range(1, 32, 1)]
regex = '^[^\\\\/:\\*\\?\"<>\\|]+$'
class AutoExportTaskCreationForm(ModelForm):
    task_code = forms.CharField(label=_('autoExportTask_field_code'), initial='1', disabled=True)
    task_name = forms.CharField(label=_('autoExportTask_field_name'), initial='T1')
    file_prefix = forms.CharField(label=_('autoExport_task_filePrefix'), initial='{cur_date}')
    file_date = forms.ChoiceField(label=_('autoExport.macros.curDate'), required=False, choices=const.HUMAN_FILE_SHORT_DATE, initial=12)
    file_time = forms.ChoiceField(label=_('autoExport.macros.curTime'), required=False, choices=const.HUMAN_FILE_SHORT_TIME, initial=11)
    data_template = forms.TextField(label=_('autoExport_task_dataTemplate'), initial='{emp_code}\\t{first_name}\\t{last_name}\\t{dept_code}\\t{dept_name}\\t{date}\\t{time}\\t{verify_type}\\t{punch_state}\\t{work_code}\\t{card_number}\\t{area_name}\\t{terminal_alias}\\t{terminal_sn}\\n')
    export_type = forms.ChoiceField(label=_('Export Type'), choices=EXPORT_TYPE, initial=FULL_VOLUME)
    short_date = forms.ChoiceField(label=_('autoExport_task_shortDate'), choices=const.HUMAN_SHORT_DATE, initial=1)
    short_time = forms.ChoiceField(label=_('autoExport_task_shortTime'), choices=const.HUMAN_SHORT_TIME, initial=5)
    export_format = forms.ChoiceField(label=_('autoExport_task_exportFormat'), initial='txt', choices=const.FILE_FORMAT)
    export_encryption_type = forms.ChoiceField(label=_('securityPolicy.fields.exportEncryption'), choices=const.EXPORT_ENCRYPTION_TYPE, required=False)
    export_encryption_password = forms.PasswordField(label=_('Password'), required=False)
    pin_digit = forms.IntegerField(label=_('autoExport_task_empCodeLength'), initial=0, max_value=20, min_value=0, help_text=_('autoExport_task_empCodeLengthSuffix'), unit=_('autoExport_task_id_digit'))
    departments = ModelMultipleChoiceField(label=_('autoExport_task_departments'), required=False, help_text=_('autoExport_departments_helpTxt'), queryset=Department.objects.get_queryset(), widget=widgets.CompanyDepartmentSelectMultiple)
    areas = ModelMultipleChoiceField(label=_('autoExport_task_areas'), required=False, help_text=_('autoExport_areas_helpTxt'), queryset=Area.objects.get_queryset(), widget=widgets.CompanyAreaSelectMultiple)
    query_field = forms.ChoiceField(label=_('autoExport_task_queryField'), choices=const.FILTER_FILED, initial=3)
    end_day = forms.ChoiceField(label=_('autoExport_task_deadline'), choices=const.EXPORT_PERIOD, initial=const.PREVIOUS_PERIOD)
    frequency = forms.ChoiceField(label=_('autoExport_task_frequency'), choices=const.EXPORT_FREQUENCY, initial=const.DAILY)
    month_day = forms.ChoiceField(label=_('autoExport_task_exportDay'), initial=1, choices=MONTHLY)
    week_day = forms.ChoiceField(label=_('autoExport_task_exportDay'), initial=1, choices=WEEKDAY)
    day = forms.ChoiceField(label=_('autoExport_task_exportDay'), initial=1, choices=((1, 1),))
    export_policy = forms.ChoiceField(label=_('autoExport.fields.policy'), choices=const.EXPORT_POLICES, initial=const.BY_TIMING, required=True)
    export_interval = forms.IntegerField(label=_('autoExport_task_interval'), initial=0, unit=_('timeInterval_field_workTimeDurationHelpTxt'), min_value=0)
    export_time = forms.CharField(label=_('autoExport_task_exportTime'), initial='00:01', unit=_('HH:mm'))
    export_path = forms.CharField(label=_('autoExport_task_exportPath'), initial='AutoExport', required=False)
    export_email = forms.CharField(label=_('autoExport_task_exportEmail'), required=False)
    ftp_server = forms.ModelChoiceField(label=_('autoExport_task_ftpServer'), queryset=SftpSetting.objects.get_queryset(), required=False)
    ftp_path = forms.CharField(label=_('autoExport_task_ftpPath'), required=False)
    company = forms.ModelChoiceField(queryset=Company.objects.all(), label=_('area.field.company'), required=auth_settings.AUTHORIZED_FIRM > 1 and getattr_ex(settings, 'MULTI_COMPANY_EXT', False), initial=get_default_company(), widget=widgets.CompanyRadioSelect(attrs={'onchange': True, 'first_click': 1, 'change_params': {'onchange_field': 'departments,areas', 'onchange_field_model': 'department,area', 'onchange_api_name': 'dept_name,area_name', 'onchange_parent_name': 'parent_dept,parent_area', 'input_type': 'checkbox', 'filter_field': 'company', 'contact_name': 'company'}}))
    def __init__(self, *args, **kwargs):
        super(AutoExportTaskCreationForm, self).__init__(*args, **kwargs)
        if kwargs.get('instance', None):
            self.initial.update(self.instance.get_options())
        else:
            codes = AutoExportTask.objects.all().values_list('task_code', flat=True)
            codes = list(map(int, filter(lambda x: x.isnumeric(), codes)))
            if codes:
                code = max(codes) + 1
                self.initial.update({'task_code': code, 'task_name': 'T{0}'.format(code)})
        company = get_default_company()
        if self.instance.pk:
            self.fields['company'].widget.attrs['first_click'] = 0
            if not self.instance.options.get('company', None):
                if len(self.instance.options['departments']) > 0:
                    company = self.instance.options['departments'][0].company
                else:
                    if len(self.instance.options['areas']) > 0:
                        company = self.instance.options['areas'][0].company
                company_id = company.id
            else:
                company_id = self.instance.options.get('company')
            self.fields['company'].initial = company_id
            self.fields['areas'].company_belong = company_id
            self.fields['departments'].company_belong = company_id
        else:
            self.fields['company'].widget.attrs['first_click'] = 0
            self.fields['company'].initial = company.id
            self.fields['areas'].company_belong = company.id
            self.fields['departments'].company_belong = company.id
    def clean_file_prefix(self):
        file_prefix = self.cleaned_data.get('file_prefix', '')
        if file_prefix and (not re.match(regex, file_prefix)):
            raise forms.ValidationError(_('autoExport.task.errorInvalidFileName'))
        else:
            return file_prefix
    def clean_export_encryption_password(self):
        encryption_password = self.cleaned_data.get('export_encryption_password', '')
        encryption_type = int(self.cleaned_data.get('export_encryption_type', 0))
        if encryption_type and encryption_type!= const.ENCRYPTION_SELF_PASSWORD:
                encryption_password = ''
        return encryption_password
    def clean_ftp_path(self):
        temp_ftp_path = self.cleaned_data.get('ftp_path', '')
        if temp_ftp_path:
            temp = ['..', '~/', '/、', '\\、', '..、', './']
            for stemp in temp:
                if stemp in temp_ftp_path:
                    raise ValidationError(_('database.backup.error.invalidPath'), code='-1')
        return temp_ftp_path
    def clean(self):
        # irreducible cflow, using cdg fallback
        from mysite.base.api.serializers import AutoExportTaskOptionSerializer
        cleaned_data = super(AutoExportTaskCreationForm, self).clean()
        serializer = AutoExportTaskOptionSerializer(data=cleaned_data)
        serializer.is_valid()
        if serializer.errors:
            for k, v in serializer.errors.items():
                raise ValidationError(','.join(map(six.text_type, v)))
                cleaned_data['params'] = json.dumps(serializer.validated_data)
                return cleaned_data
    class Meta:
        model = AutoExportTask
        fields = ('task_code', 'task_name', 'file_date', 'file_time', 'data_template', 'enable', 'export_type', 'short_date', 'short_time', 'export_format', 'export_encryption_type', 'export_encryption_password', 'pin_digit', 'departments', 'areas', 'query_field', 'end_day', 'frequency', 'month_day', 'week_day', 'day', 'export_policy', 'export_interval', 'export_time', 'export_path', 'export_email', 'ftp_server', 'ftp_path', 'file_prefix', 'params', 'company')