# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\attschedule_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from celery_progress.backend import AbstractProgressRecorder
from django.utils.translation import gettext_lazy as _, activate
from mysite import admin, config
from mysite.att.models import AttSchedule, AttShift
from mysite.att.actions import AddAttSchedule, Import
from mysite.att.import_data import ImportData
from mysite.admin.action import ActionHandleError
from mysite.personnel.models import Employee
import datetime
from mysite.utils import progress_record
@admin.register(AttSchedule)
class AttScheduleAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'emp_code', 'first_name', 'last_name', 'position', 'department', 'shift_alias', 'start_date', 'end_date')
    list_filter = config.EMPLOYEE_LIST_FILTER + ('shift__alias',)
    def has_change_permission(self, request, obj=None):
        return False
    def has_add_permission(self, request):
        return False
    def shift_no(self, obj):
        return obj.shift.pk
    shift_no.short_description = _('attShift_field_code')
    def shift_alias(self, obj):
        return obj.shift.alias
    shift_alias.short_description = _('attShift_field_alias')
    def emp_code(self, obj):
        return obj.employee.emp_code
    emp_code.short_description = _('emp_field_employeeCode')
    def first_name(self, obj):
        return obj.employee.first_name
    first_name.short_description = _('emp_field_firstName')
    def last_name(self, obj):
        return obj.employee.last_name
    last_name.short_description = _('emp_field_lastName')
    def position(self, obj):
        if not obj.employee.position:
            return ''
        else:
            return obj.employee.position.position_name
    position.short_description = _('employee_field_position')
    def department(self, obj):
        if not obj.employee.department:
            return ''
        else:
            return obj.employee.department.dept_name
    department.short_description = _('employee_field_department')
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(AttScheduleAdmin, self).get_form(request, obj, **defaults)
    def get_queryset(self, request):
        qs = super(AttScheduleAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_dept.exists():
                qs = qs.filter(employee__department__in=request.user.auth_dept.all())
        return qs
    actions = [AddAttSchedule, Import]
    def dataimport(self, request):
        obj_import = ImportAttScheduleData(req=request, input_name='import_data', app_label=self.opts.app_label, model_name=self.opts.model_name)
        obj_import.exe_import_data()
        ret_error = obj_import.error_info
        if ret_error:
            raise ActionHandleError(';'.join(ret_error))
    def data_import(self, request, **kwargs):
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ImportAttScheduleData(request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        process.exe_import_data()
        if process.error_info:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.error_info[0]
class ImportAttScheduleData(ImportData):
    progress_recorder = None
    total = 0
    current = 0
    def __init__(self, req, input_name='import_data', app_label=None, model_name=None, **kwargs):
        lng = kwargs.pop('template_lng', None)
        if lng:
            activate(lng)
        super(ImportAttScheduleData, self).__init__(req, input_name, app_label, model_name)
        self.progress_recorder = kwargs.pop('progress_recorder', None)
        self.stamp = None
        self.exist_pins = []
        self.ePin = None
    def before_insert(self):
        # irreducible cflow, using cdg fallback
        emp_objs = Employee.objects.all().values_list('emp_code', flat=True)
        shift_objs = AttShift.objects.all().values_list('alias', flat=True)
        self.total = len(self.records)
        for index, elem in enumerate(self.records):
            pass
        self.current = index
        progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.dataVerification'))
        index += 1
        if elem[0] not in emp_objs:
            self.error_info.append(_('error_data_on_row(%(index)s)_the_employee_code_is_not_exist') % {'index': index})
            break
        else:
            if elem[1] not in shift_objs:
                self.error_info.append(_('error_data_on_row(%(index)s)_period_name_error') % {'index': index})
                break
        datetime.datetime.strptime(elem[2], '%Y-%m-%d')
        self.error_info.append(_('error_data_on_row(%(index)s)_data_error') % {'index': index})
        datetime.datetime.strptime(elem[3], '%Y-%m-%d')
        self.error_info.append(_('error_data_on_row(%(index)s)_data_error') % {'index': index})
        return True
    def data_insert(self):
        overwrite = self.need_update_old_record
        shift_objs = {i[1]: i[0] for i in AttShift.objects.all().values_list('id', 'alias')}
        for index, single_data in enumerate(self.records):
            self.current = index
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
            _start = datetime.datetime.strptime(single_data[2] + ' 00:00:00', '%Y-%m-%d %H:%M:%S')
            _end = datetime.datetime.strptime(single_data[3] + ' 23:59:59', '%Y-%m-%d %H:%M:%S')
            emp = Employee.objects.get(emp_code=single_data[0])
            overlaps = AttSchedule.objects.filter(employee_id=emp, start_date__lte=_end, end_date__gte=_start)
            try:
                if overlaps.exists():
                    if overwrite:
                        overlaps.delete()
                        obj = AttSchedule(employee_id=emp.id, start_date=_start.date(), end_date=_end.date(), shift_id=shift_objs[single_data[1]])
                        obj.save()
                else:
                    obj = AttSchedule(employee_id=emp.id, start_date=_start.date(), end_date=_end.date(), shift_id=shift_objs[single_data[1]])
                    obj.save()
            except Exception as e:
                self.error_info.append(str(e))
    def sqlserver_insert(self):
        """sqlserver 数据插入"""
        self.data_insert()
    def mysql_insert(self):
        """mysql 数据插入"""
        self.data_insert()
    def oracle_insert(self):
        """oracle 数据插入"""
        self.data_insert()
    def postgresql_insert(self):
        """postgresql 数据插入"""
        self.data_insert()
    def after_insert(self):
        progress_record(self.progress_recorder, self.total, self.total, _('importProgress.status.finished'))