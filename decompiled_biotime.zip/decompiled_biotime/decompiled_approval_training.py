# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff\\models\\approval_training.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:33 UTC (1750673073)

from mysite.att.models import Training
class ApprovalTraining(Training):
    def get_template_base_root(self):
        return 'att/training'
    class Meta:
        default_permissions = ()
        app_label = 'staff'
        proxy = True