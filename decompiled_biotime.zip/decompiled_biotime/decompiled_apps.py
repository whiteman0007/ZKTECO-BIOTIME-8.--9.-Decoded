# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\notifications\\apps.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:11 UTC (1750673051)

from django.apps import AppConfig
class NotificationsConfig(AppConfig):
    name = 'mysite.notifications'
    def ready(self):
        from .notification_center import receivers