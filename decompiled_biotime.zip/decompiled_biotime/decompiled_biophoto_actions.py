# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\actions\\biophoto_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

from django.utils.translation import gettext_lazy as _
from django.conf import settings
from mysite._utils import getattr_ex
from mysite.admin import forms, ZKModelAction
from mysite.admin.action import ActionHandleError
from mysite.iclock import const
from mysite.personnel.actions.personnel_actions import CompanyField4ActionForm
from mysite.tools.progress_utils import progress_protected, TaskProgress
BOOLEANS = ((0, _('boolean_option_no')), (1, _('boolean_option_yes')))
class BioPhotoApproveForm(forms.ZKActionForm):
    state = forms.ChoiceField(label=_('bioPhoto_field_approvalState'), choices=((const.APPROVAL_PASSED, _('bioPhoto_approvalState_approvalPassed')), (const.APPROVAL_REJECTED, _('bioPhoto_approvalState_reject'))), initial=const.APPROVAL_PASSED)
    overwrite = forms.ChoiceField(label=_('dataImport_field_overwrite'), initial=0, choices=BOOLEANS)
    remark = forms.CharField(label=_('bioPhoto_field_remark'), required=False)
class BioPhotoApprove(ZKModelAction):
    batch_select = True
    verbose_name = _('biophoto_approve')
    help_txt = _('biophoto_approve')
    short_description = _('biophoto_approve')
    action_form = BioPhotoApproveForm
    def action(self, state, overwrite, remark):
        import os
        import shutil
        import datetime
        from mysite.utils import get_or_create_photo_folder
        from mysite.iclock.models import BioPhoto
        tmp = self.objects.filter(approval_state__gt=const.APPROVAL_PENDING)
        if tmp:
            raise ActionHandleError(_('approval_can_not_approve_again'))
        else:
            biophoto_path = get_or_create_photo_folder('biophoto')
            photo_path = get_or_create_photo_folder('photo')
            overwrite = int(overwrite)
            store_path = get_or_create_photo_folder('register')
            tmp = []
            for obj in self.objects:
                emp_code = obj.employee.emp_code
                if obj.approval_state in (const.APPROVAL_PASSED, const.APPROVAL_AUTO_APPROVED):
                    raise ActionHandleError(_('photo_of_%(emp_code)s_already_approval_passed') % {'emp_code': emp_code})
                else:
                    old_photos = BioPhoto.objects.filter(employee=obj.employee, approval_state__in=(const.APPROVAL_PASSED, const.APPROVAL_AUTO_APPROVED))
                    if old_photos and int(state) == const.APPROVAL_PASSED:
                            if not overwrite:
                                raise ActionHandleError(_('photo_of_%(emp_code)s_already_exist') % {'emp_code': emp_code})
                            else:
                                try:
                                    old_photos.delete()
                                except Exception:
                                    pass
                    p = os.path.join(store_path, obj.register_photo)
                    if not os.path.isfile(p):
                        raise ActionHandleError(_('photo_of_%(emp_code)s_is_not_found') % {'emp_code': emp_code})
                    else:
                        if int(state) == const.APPROVAL_PASSED:
                            photo_name = '{0}.jpg'.format(obj.employee.pin())
                            if getattr_ex(settings, 'MULTI_COMPANY', False):
                                photo_name = '{0}/{1}.jpg'.format(obj.employee.company_id, obj.employee.pin())
                                get_or_create_photo_folder('photo', obj.employee.company_id)
                                get_or_create_photo_folder('biophoto', obj.employee.company_id)
                            obj.approval_photo = photo_name
                            obj.save()
                            bio_path = os.path.join(biophoto_path, photo_name)
                            emp_photo_path = os.path.join(photo_path, photo_name)
                            shutil.copy(p, bio_path)
                            if not obj.employee.photo:
                                shutil.copy(p, emp_photo_path)
                                obj.employee.photo = 'photo/' + photo_name
                                obj.employee.save()
                            try:
                                os.remove(p)
                            except Exception:
                                pass
            self.objects.update(approval_state=state, approval_time=datetime.datetime.now(), remark=remark)
class BioPhotoQRCode(ZKModelAction):
    verbose_name = _('bioPhoto_action_qrCode')
    help_txt = _('bioPhoto_action_qrCode')
    short_description = _('bioPhoto_action_qrCode')
    def action(self, *args, **kwargs):
        return
class ImportBioPhotoForm(CompanyField4ActionForm):
    bio_photo = forms.FileField(label=_('dataImport_field_file'), help_text=_('data_import_fileHelpTxt'), required=False)
    overwrite = forms.ChoiceField(label=_('dataImport_field_overwrite'), initial=0, choices=BOOLEANS)
    ignore_error = forms.ChoiceField(label=_('dataImport_field_ignoreError'), initial=0, choices=BOOLEANS)
class ImportBioPhoto(ZKModelAction):
    verbose_name = _('dataImport_action_importBioPhoto')
    help_txt = _('dataImport_action_importBioPhotoHelpTxt')
    short_description = _('dataImport_action_importBioPhotoDescription')
    action_form = ImportBioPhotoForm
    async_progress = True
    use_asgi = True
    def action(self, *args, **kwargs):
        from mysite.tools.request_utils import PickleRequest
        from mysite.base.tasks import async_progress_task_wapper
        if self.request.method == 'POST':
            request = PickleRequest(self.request)
            data = self.valid_form.cleaned_data
            call_info = {'type': 'admin', 'model': self.admin.model, 'func': 'data_import', 'lng': self.request.LANGUAGE_CODE, 'delay': True if settings.ASYN_IMPORT_DATA else False}
            task = async_progress_task_wapper(call_info, request, **data)
            return task