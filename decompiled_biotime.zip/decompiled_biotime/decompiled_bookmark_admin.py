# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\bookmark_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from mysite import admin
from mysite.admin import ZKModelAdmin, zk_site
from mysite.base.models.bookmark import Bookmark
@admin.register(Bookmark)
class BookmarkAdmin(ZKModelAdmin):
    list_display = ['title', 'user', 'content_type', 'filters', 'is_share', 'time_saved']
    list_filter = ['title', 'filters', 'time_saved', 'content_type']
    sort_fields = ['user', 'content_type']
    list_select_related = ('user', 'content_type')
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return ['filters', 'user', 'content_type', 'time_saved']
        else:
            return []