# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\visitor\\migrations\\0008_auto_20230411_1415.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:28 UTC (1750702768)

from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('visitor', '0007_auto_20221202_1852')]
    operations = [migrations.AlterUniqueTogether(name='visitorbiodata', unique_together={('visitor', 'bio_no', 'bio_index', 'bio_type', 'bio_format', 'major_ver', 'minor_ver')})]