# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\line\\line_notify.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:13 UTC (1750672993)

import os.path
import datetime
import logging
import requests
from requests_toolbelt import MultipartEncoder
from django.conf import settings
from django.core.cache import cache
LN_EMP_IMAGE_CACHE_KEY = 'emp_im_{emp_code}_{token}'
LN_TOKEN_IMAGE_REMAIN_CACHE_KEY = 'im_remain_{token}'
LN_TOKEN_API_REMAIN_CACHE_KEY = 'api_remain_{token}'
LN_TOKEN_IMAGE_START_CALL_CACHE_KEY = 'im_st_{token}'
LN_TOKEN_API_START_CALL_CACHE_KEY = 'api_st_{token}'
logger = logging.getLogger('lineapp')
class LineNotify(object):
    """\n    Messenger of LINE Notify\n    """
    sticker_good_luck = (45, 2)
    sticker_good_bye = (43, 2)
    sticker_sorry = (38, 2)
    def __init__(self, token, company=None):
        self.token = token
        self.company = company
        self.url = 'https://notify-api.line.me/api/notify'
        self.headers = {'Authorization': 'Bearer ' + token}
        self.response = None
        self.api_limit = cache.get(LN_TOKEN_API_REMAIN_CACHE_KEY.format(token=token), 1000)
        self.image_limit = cache.get(LN_TOKEN_IMAGE_REMAIN_CACHE_KEY.format(token=token), 50)
        self.token_api_remaining = 0
        self.token_image_remaining = 0
        if not token:
            raise ValueError('The token cannot be empty')
        else:
            assert self.api_limit > 0, 'The number of remaining API be called is zero'
    def message_format(self, message):
        if self.company:
            message = '{0}\n[{1}]'.format(message, self.company)
        return message
    def refresh_rate_limit(self):
        if self.response is None or '\"status\":200' in self.response.text:
                token_api_remaining = int(self.response.headers['X-RateLimit-Remaining'])
                token_image_remaining = int(self.response.headers['X-RateLimit-ImageRemaining'])
                token_api_remain_cache_key = LN_TOKEN_API_REMAIN_CACHE_KEY.format(token=self.token)
                token_im_remain_cache_key = LN_TOKEN_IMAGE_REMAIN_CACHE_KEY.format(token=self.token)
                self.token_api_remaining = token_api_remaining
                self.token_image_remaining = token_image_remaining
                current_time = datetime.datetime.now()
                token_api_st_cache_key = LN_TOKEN_API_START_CALL_CACHE_KEY.format(token=self.token)
                token_im_st_cache_key = LN_TOKEN_IMAGE_START_CALL_CACHE_KEY.format(token=self.token)
                cache_api_st = cache.get_or_set(token_api_st_cache_key, current_time, 3600)
                cache_im_st = cache.get_or_set(token_im_st_cache_key, current_time, 3600)
                cache_api_duration_seconds = (current_time - cache_api_st).seconds
                cache_im_duration_seconds = (current_time - cache_im_st).seconds
                if cache.get_or_set(token_api_remain_cache_key, token_api_remaining, 3600)!= token_api_remaining and cache_api_duration_seconds < 3600:
                        cache.set(token_api_remain_cache_key, token_api_remaining, 3600 - cache_api_duration_seconds)
                if cache.get_or_set(token_im_remain_cache_key, token_image_remaining, 3600)!= token_image_remaining and cache_im_duration_seconds < 3600:
                        cache.set(token_im_remain_cache_key, token_image_remaining, 3600 - cache_im_duration_seconds)
    def send(self, message, image_path=None, sticker_id=None, package_id=None, push_sticker=False):
        fields = {'message': self.message_format(message)}
        if push_sticker and (not sticker_id or not package_id):
                sticker_id, package_id = self.sticker_good_luck
                fields.update({'stickerId': str(sticker_id), 'stickerPackageId': str(package_id)})
        if self.image_limit > 0 and image_path and os.path.isfile(image_path):
                    path_head, path_tail = os.path.split(image_path)
                    fields.update({'imageFile': (path_tail, open(image_path, 'rb'), 'image/png')})
        data = MultipartEncoder(fields=fields)
        self.headers.update({'Content-Type': data.content_type})
        try:
            self.response = requests.post(self.url, headers=self.headers, data=data, timeout=5)
        except Exception as e:
            logger.exception('Connection Error')
            logger.exception('Sent Fail %s ' % message)
        if settings.DEBUG:
            print('[DEBUG][line_notify.LineNotify.send.self.response.headers]', self.response.headers)
            print('[DEBUG][line_notify.LineNotify.send.self.response.text]', self.response.text)
        self.refresh_rate_limit()
        return self.response
    def get_token_remaining(self):
        return 'Token: {}, API remaining: {} and IMAGE remaining {}'.format(self.token, self.token_api_remaining, self.token_image_remaining)