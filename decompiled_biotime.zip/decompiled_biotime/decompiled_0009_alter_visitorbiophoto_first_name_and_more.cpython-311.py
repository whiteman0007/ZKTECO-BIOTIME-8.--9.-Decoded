# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\visitor\\migrations\\0009_alter_visitorbiophoto_first_name_and_more.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:28 UTC (1750702768)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('visitor', '0008_auto_20230411_1415')]
    operations = [migrations.AlterField(model_name='visitorbiophoto', name='first_name', field=models.CharField(blank=True, default='', max_length=100, null=True, verbose_name='visitor.bioPhoto.field.firstName')), migrations.AlterField(model_name='visitorbiophoto', name='last_name', field=models.CharField(blank=True, max_length=100, null=True, verbose_name='visitor.bioPhoto.field.lastName'))]