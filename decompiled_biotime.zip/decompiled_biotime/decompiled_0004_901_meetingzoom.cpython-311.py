# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\meeting\\migrations\\0004_901_meetingzoom.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:58 UTC (1750702738)

from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('base', '0010_901_zoomsetting'), ('meeting', '0003_auto_20210908_1006')]
    operations = [migrations.AddField(model_name='meetingentity', name='zoom', field=models.ForeignKey(null=True, on_delete=django.db.models.deletion.CASCADE, to='base.zoomsetting', verbose_name='meetingEntity.fields.zoomAccount'))]