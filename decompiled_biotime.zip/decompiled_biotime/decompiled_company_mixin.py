# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\models\\company_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:25 UTC (1750673065)

from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.personnel import db_const
def upload_path_handler(self, filename):
    import os
    try:
        os.unlink('' + db_const.LOGO_STORAGE.location + '/company_logo/{file}.jpg'.format(file=self.company_code))
    except Exception as e:
        pass
    return 'company_logo/{file}.jpg'.format(file=self.company_code)
class CompanyInfoMixin(models.Model):
    logo = models.ImageField(_('company_field_logo'), upload_to=upload_path_handler, storage=db_const.LOGO_STORAGE, blank=True, null=True, max_length=200)
    country = models.CharField(_('company.field.country'), null=True, blank=True, max_length=10)
    city = models.CharField(_('company.field.city'), null=True, blank=True, max_length=10)
    fax = models.CharField(_('company.field.fax'), null=True, blank=True, max_length=20)
    email = models.EmailField(_('company.field.email'), max_length=db_const.MAX_EMP_EMAIL, null=True, blank=True, editable=True)
    state = models.CharField(_('company.field.state'), null=True, blank=True, max_length=20)
    phone = models.CharField(_('company.field.phone'), null=True, blank=True, max_length=20)
    website = models.CharField(_('company.field.website'), null=True, blank=True, max_length=50)
    postal_code = models.CharField(_('company.field.postal'), null=True, blank=True, max_length=20)
    address = models.CharField(_('company.field.address'), null=True, blank=True, max_length=200)
    address2 = models.CharField(_('company.field.address2'), null=True, blank=True, max_length=200)
    logo_pos = models.SmallIntegerField(_('companySettingPage_label_logoDisplay'), default=0, blank=True, choices=db_const.DISPLAY_POSITION)
    name_pos = models.SmallIntegerField(_('companySettingPage_label_companyNameDisplay'), default=0, blank=True, choices=db_const.DISPLAY_POSITION)
    class Meta:
        abstract = True