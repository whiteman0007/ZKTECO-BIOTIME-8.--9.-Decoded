# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\mobile\\api\\serializers\\annc_serializer.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from rest_framework import serializers
from mysite.mobile.models import Announcement
class ANNCSerializer(serializers.ModelSerializer):
    category_display = serializers.CharField(source='get_category_display')
    class Meta:
        model = Announcement
        fields = ('id', 'subject', 'content', 'category', 'category_display', 'sender', 'admin_id')