# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\event_alert.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

from rest_framework import mixins, serializers
from mysite.base.api.utils_class import UserLayUIGenericViewSet
from mysite.base.models import EventAlertSetting
class EventAlertSettingSerializer(serializers.ModelSerializer):
    class Meta:
        model = EventAlertSetting
        fields = ('email_alert', 'app_alert', 'whatapp_alert', 'sms_alert', 'facebook_alert')
class EventAlertSettingViewSet(mixins.UpdateModelMixin, UserLayUIGenericViewSet):
    model = EventAlertSetting
    queryset = EventAlertSetting.objects.all()
    serializer_class = EventAlertSettingSerializer