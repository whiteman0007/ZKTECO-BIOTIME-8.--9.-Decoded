# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\admin\\departmentgps_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

import datetime
from django.utils.translation import gettext_lazy as _
from django import forms as django_forms
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite import admin
from mysite.admin import forms
from mysite.personnel.models import Department
from mysite.personnel import fields, widgets
from mysite.mobile.models import GPSForDepartment, GPSLocation
from django.forms import ModelForm, ModelMultipleChoiceField, ValidationError
from mysite.mobile.widgets import GPSLocationSelectMultiple
from mysite.mobile import tasks, const
class GPSForDepartmentChangeForm(ModelForm):
    dept = forms.CharField(label=_('gpsForDepartment_field_department'), disabled=True)
    location = ModelMultipleChoiceField(label=_('gpsForDepartment_field_location'), queryset=GPSLocation.objects.get_queryset(), widget=GPSLocationSelectMultiple())
    distance = forms.IntegerField(label=_('gpsForDepartment_field_distance'), suffix=_('distance.units.meter'))
    start_date = forms.DateField(label=_('gpsForDepartment_field_startDate'))
    end_date = forms.DateField(label=_('gpsForDepartment_field_endDate'))
    def __init__(self, *args, **kwargs):
        super(GPSForDepartmentChangeForm, self).__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields['dept'].initial = str(self.instance.department)
    def clean_distance(self):
        distance = self.cleaned_data.get('distance', 0)
        if distance is None or distance < 0:
            raise ValidationError(_('gps_distance_invalid'))
        else:
            return distance
    def clean_end_date(self):
        start_date = self.cleaned_data['start_date']
        end_date = self.cleaned_data['end_date']
        if end_date < start_date:
            raise ValidationError(_('gps_date_invalid_range'))
        else:
            return end_date
    def save(self, commit=True):
        instance = super(GPSForDepartmentChangeForm, self).save(commit)
        self.post_save(instance)
        return instance
    def post_save(self, instance):
        if not self.changed_data:
            return
        else:
            instance.location.set(self.cleaned_data['location'])
            tasks.update_department_gps(instance)
    class Meta:
        model = GPSForDepartment
        fields = ('location', 'distance', 'start_date', 'end_date')
class AddGPSForDepartmentForm(forms.ZKActionForm):
    department = django_forms.ModelMultipleChoiceField(label=_('gpsForDepartment_field_department'), queryset=Department.objects.all(), widget=widgets.DepartmentSelectMultiple, required=False)
    location = ModelMultipleChoiceField(label=_('gpsForDepartment_field_location'), queryset=GPSLocation.objects.get_queryset(), widget=GPSLocationSelectMultiple())
    distance = forms.IntegerField(label=_('gpsForDepartment_field_distance'), initial=50, suffix=_('distance.units.meter'))
    start_date = forms.DateField(label=_('gpsForDepartment_field_startDate'))
    end_date = forms.DateField(label=_('gpsForDepartment_field_endDate'))
    def clean_distance(self):
        distance = self.cleaned_data.get('distance', 0)
        if distance is None or distance < 0:
            raise ValidationError(_('gps_distance_invalid'))
        else:
            return distance
    def clean_end_date(self):
        start_date = self.cleaned_data['start_date']
        end_date = self.cleaned_data['end_date']
        if end_date < start_date:
            raise ValidationError(_('gps_date_invalid_range'))
        else:
            return end_date
class AddGPSForDepartment(admin.ZKModelAction):
    verbose_name = _('gpsForDepartment_action_addGPSForDepartment')
    help_txt = _('gpsForDepartment_action_addGPSForDepartmentHelpTxt')
    short_description = _('gpsForDepartment_action_addGPSForDepartmentDescription')
    action_form = AddGPSForDepartmentForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        departments = data.pop('department', None)
        if not departments:
            raise AdminRuntimeWarning(_('departmentGps_select_dept'))
        else:
            locations = data.pop('location', None)
            if not locations:
                raise AdminRuntimeWarning(_('departmentGps_select_location'))
            else:
                for department in departments:
                    obj = GPSForDepartment(department=department, **data)
                    obj.save()
                    obj.location.set(locations)
                    tasks.update_department_gps.delay(obj)
@admin.register(GPSForDepartment)
class GPSForDepartmentAdmin(admin.ZKModelAdmin):
    list_display = ('department', 'dept_location', 'distance', 'start_date', 'end_date')
    list_filter = ('department__dept_code', 'department__dept_name')
    form = GPSForDepartmentChangeForm
    actions = (AddGPSForDepartment,)
    def distance_viewing(self, obj, val):
        return '{0} {1}'.format(val, _('distance.units.meter'))
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        qs = super(GPSForDepartmentAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_dept.exists():
                qs = qs.filter(department__in=request.user.auth_dept.all())
        return qs
    def dept_location(self, obj):
        locations = obj.location.all()
        if not locations:
            return ''
        else:
            return ','.join([i.alias for i in locations])
    dept_location.short_description = _('gpsLocation.fields.location')