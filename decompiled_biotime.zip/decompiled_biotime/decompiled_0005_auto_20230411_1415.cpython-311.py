# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\workflow\\migrations\\0005_auto_20230411_1415.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:30 UTC (1750702770)

from django.db import migrations, models
import django.db.models.deletion
import mysite.personnel.fields
class Migration(migrations.Migration):
    dependencies = [('personnel', '0011_auto_20230223_1026'), ('workflow', '0004_auto_20230223_1026')]
    operations = [migrations.AddField(model_name='workflowengine', name='company', field=mysite.personnel.fields.CompanyForeignKey(default=1, on_delete=django.db.models.deletion.CASCADE, to='personnel.Company', verbose_name='area.field.company')), migrations.AddField(model_name='workflowrole', name='company', field=mysite.personnel.fields.CompanyForeignKey(default=1, on_delete=django.db.models.deletion.CASCADE, to='personnel.Company', verbose_name='area.field.company')), migrations.AlterField(model_name='workflowrole', name='role_code', field=models.CharField(max_length=30, verbose_name='workflowRole_field_code')), migrations.AlterUniqueTogether(name='workflowrole', unique_together={('company', 'role_code'), ('company', 'role_name')})]