# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0007_auto_20221202_1852.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from __future__ import unicode_literals
from django.db import migrations
class Migration(migrations.Migration):
    dependencies = [('base', '0006_autoimporttask_company')]
    operations = [migrations.AlterModelOptions(name='eventalertsetting', options={'default_permissions': ('view', 'change'), 'ordering': ['event_id'], 'verbose_name': 'base.models.eventAlertSetting'})]