# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\tools\\file_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:05:21 UTC (1750673121)

import xlrd
import csv
from django.utils.translation import gettext_lazy as _
from datetime import datetime
class FileReader(object):
    valid_formats = ['xls', 'xlsx']
    must_fields = []
    def __init__(self, import_file, must_fields=None, valid_formats=None):
        self.import_file = import_file
        if valid_formats:
            self.valid_formats = valid_formats
        if must_fields:
            self.must_fields = must_fields
        assert self.validate_format(valid_formats=['xls', 'xlsx']), _('file_format_incorrect')
    def validate_format(self, valid_formats=None):
        """\n        验证文件格式\n        """
        file_name = self.import_file.name
        f_format = file_name.split('.')[(-1)]
        valid_list = valid_formats if valid_formats is not None else self.valid_formats
        return f_format in valid_list
    def xls_read(self):
        """\n        读xls数据\n        """
        try:
            fd = self.import_file.read()
            wk = xlrd.open_workbook(file_contents=fd)
        except Exception as e:
            import traceback
            traceback.print_exc()
            raise e
        finally:
            self.import_file.close()
        assert wk.nsheets == 1, _('file_sheet_shoulb_be_one')
        sh = wk.sheet_by_index(0)
        assert sh.nrows >= 2, _('file_data_must_be_more_than_two')
        headers = sh.row_values(0)
        for i in self.must_fields:
            assert i in headers, _('the_%(index)s_field_is_requird') % {'index': i}
        records = []
        for i in range(1, sh.nrows):
            row_dict = {}
            for j in range(sh.ncols):
                ctype = sh.cell(i, j).ctype
                v = sh.cell_value(rowx=i, colx=j)
                if ctype == 2 and v % 1 == 0:
                    v = int(v)
                else:
                    if ctype == 3:
                        date_touple = xlrd.xldate_as_tuple(v, wk.datemode)
                        v = datetime(*date_touple)
                    else:
                        if ctype == 4:
                            v = True if v else False
                        else:
                            if ctype == 0 and (not v):
                                    v = None
                row_dict[headers[j]] = v
            row_dict['index'] = i
            records.append(row_dict)
        return records
    def dict_read(self):
        """\n        读文件数据\n        rtype: [{}, ...]\n        """
        records = []
        file_name = self.import_file.name
        f_format = file_name.split('.')[(-1)]
        if f_format in ['xls', 'xlsx']:
            records = self.xls_read()
        return records