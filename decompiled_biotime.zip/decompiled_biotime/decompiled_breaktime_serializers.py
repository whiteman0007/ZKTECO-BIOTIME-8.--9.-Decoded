# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\breaktime_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

import datetime
from rest_framework import serializers
from mysite.att.models.model_breaktime import BreakTime
from mysite.att.api.serializers import util_serializers
from mysite.utils import get_dt4mssql
class BreakTimeSerializer(serializers.ModelSerializer):
    cross_day = serializers.SerializerMethodField()
    period_end = serializers.SerializerMethodField()
    calc_type = serializers.CharField(source='get_calc_type_display', read_only=True)
    period_start = serializers.SerializerMethodField()
    def get_cross_day(self, obj):
        break_out = datetime.datetime.strptime('2000-01-01 {time}'.format(time=get_dt4mssql(obj.period_start, 2)), '%Y-%m-%d %H:%M:%S')
        break_in = break_out + datetime.timedelta(minutes=obj.end_margin) - datetime.timedelta(milliseconds=0.001)
        days = (break_in.date() - break_out.date()).days
        return days
    def get_period_end(self, obj):
        break_out = datetime.datetime.strptime('2000-01-01 {time}'.format(time=get_dt4mssql(obj.period_start, 2)), '%Y-%m-%d %H:%M:%S')
        break_in = break_out + datetime.timedelta(minutes=obj.end_margin)
        return break_in.strftime('%H:%M:%S')
    def get_period_start(self, obj):
        return get_dt4mssql(obj.period_start, 2)
    class Meta:
        model = BreakTime
        fields = ('id', 'alias', 'period_start', 'period_end', 'duration', 'cross_day', 'func_key', 'available_interval_type', 'available_interval', 'multiple_punch', 'calc_type', 'minimum_duration')
class BreakTimeExportSerializer(serializers.ModelSerializer):
    calc_type = serializers.CharField(source='get_calc_type_display', read_only=True)
    class Meta:
        model = BreakTime
        fields = '__all__'
class BreakTimeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = BreakTime
        fields = '__all__'
class BreakTimeEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = BreakTime
        fields = '__all__'
class BreakTimeActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = BreakTime
        action_type_choices = (('delete', 'delete'),)