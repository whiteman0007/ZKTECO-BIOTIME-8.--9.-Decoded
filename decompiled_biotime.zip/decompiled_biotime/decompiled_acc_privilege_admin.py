# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\acc\\admin\\acc_privilege_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from django.core.cache import cache
from mysite import admin
from mysite.acc import actions
from mysite.acc.forms import AccPrivilegeForm
from mysite.acc.models import AccPrivilege
from mysite.personnel.models import Area
@admin.register(AccPrivilege)
class AccPrivilegeAdmin(admin.ZKModelAdmin):
    actions = [actions.AdjustEmployeePrivilege]
    list_filter = ('employee__emp_code', 'employee__first_name', 'employee__last_name')
    list_display = ('id', 'emp_code', 'emp_first_name', 'emp_last_name', 'group_no', 'is_group_timezone', 'timezone1', 'timezone2', 'timezone3', 'verify_mode')
    form = AccPrivilegeForm
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
    def get_ordering(self, request):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            return ('employee__emp_code_digit', 'employee__emp_code')
        else:
            return ('employee__emp_code',)
    def get_queryset(self, request):
        from mysite.acc.utils import get_current_area
        qs = super(AccPrivilegeAdmin, self).get_queryset(request)
        is_get_table = request.path.find('table') > 0 or request.path.find('export') > 0
        current_area = get_current_area(request)
        if is_get_table:
            qs = qs.filter(area__pk=current_area)
        if not request.user.is_superuser and request.user.auth_area.all():
                qs = qs.filter(area__in=request.user.auth_area.all()).distinct()
        return qs