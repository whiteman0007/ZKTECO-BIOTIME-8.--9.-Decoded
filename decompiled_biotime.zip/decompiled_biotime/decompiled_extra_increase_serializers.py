# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\api\\serializers\\extra_increase_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from rest_framework import serializers
from mysite.payroll.models import ExtraIncrease
class ExtraIncreaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExtraIncrease
        fields = ['id', 'employee', 'emp_code', 'first_name', 'last_name', 'department', 'amount', 'issued_time', 'remark']
class ExtraIncreaseExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExtraIncrease
        fields = ['emp_code', 'first_name', 'last_name', 'department', 'amount', 'issued_time', 'remark']