# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\models\\employee_mixins.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:25 UTC (1750673065)

import logging
from django.contrib.auth.hashers import check_password, make_password
from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.personnel import db_const
from mysite.personnel.fields import WorkflowRoleManyToManyField, CompanyForeignKey, AreaManyToManyField
from mysite.personnel.models import Company, Area
class DeviceMixin(models.Model):
    device_password = models.CharField(_('emp_field_devicePassword'), max_length=db_const.MAX_EMP_DEV_PWD, blank=True, null=True)
    dev_privilege = models.IntegerField(_('emp_field_devicePrivilege'), default=0, null=True, blank=True, choices=db_const.PRIV_CHOICES)
    area_privilege = AreaManyToManyField(Area, verbose_name=_('emp_field_areaPrivilege'), related_name='employee_area_privilege', blank=True)
    card_no = models.CharField(_('emp_field_cardNumber'), max_length=db_const.MAX_EMP_CARD_NO, null=True, blank=True)
    acc_group = models.CharField(_('emp_field_accessGroup'), max_length=db_const.MAX_EMP_ACC_GROUP, null=True, blank=True)
    acc_timezone = models.CharField(_('emp_field_accessTimezone'), max_length=db_const.MAX_EMP_ACC_TIMEZONE, null=True, blank=True)
    enroll_sn = models.CharField(_('emp_field_enrollSN'), max_length=db_const.MAX_EMP_ENROLL_SN, null=True, blank=True)
    verify_mode = models.IntegerField(_('emp_field_verifyMode'), null=True, blank=True, editable=True, default=0, choices=db_const.VERIFICATION)
    def device_privilege_verify(self, privilege=None):
        if not privilege:
            privilege = self.dev_privilege
        return privilege in db_const.PRIVILEGES
    def set_devicepassword(self, raw_password):
        self.device_password = raw_password
    def delete_db_template(self):
        biodata = self.biodata_set.filter(bio_type=1)
        biodata.delete()
    def delete_db_face(self):
        biodata = self.biodata_set.filter(bio_type=2)
        biodata.delete()
    def delete_db_biodata(self, bio_types=None):
        if bio_types:
            biodata = self.biodata_set.filter(bio_type__in=bio_types)
        else:
            biodata = self.biodata_set.all()
        biodata.delete()
    def delete_emp_dev(self, bio_types=None):
        from mysite.iclock.models import Terminal
        from mysite.iclock.utils import getDevice
        from mysite.core.zkcmdproc import zk_delete_data
        devs = Terminal.objects.filter(area__in=self.area.all())
        if bio_types is None:
            bio_types = []
        if not isinstance(bio_types, (list, set)):
            bio_types = (bio_types,)
        for dev in devs:
            device = getDevice(dev.sn)
            try:
                area = device.area
                if not area or area.is_default:
                    continue
                else:
                    for bio_type in bio_types:
                        zk_delete_data(device, self.pin(), bio_type)
            except:
                logging.exception('Delete employee from device({}) failed'.format(dev.sn))
    def delete_db_file_biophoto(self, bio_types=None):
        from mysite.iclock.const import bioFaceVL
        if bio_types and str(bioFaceVL) not in bio_types:
                return
        biophoto = self.biophoto_set.all()
        for i in biophoto:
            i.remove_biophoto_file()
            i.delete()
    class Meta:
        abstract = True
class AppMixin(models.Model):
    app_status = models.SmallIntegerField(_('emp_field_appStatus'), null=True, blank=True, default=0, choices=db_const.APP_STATUS)
    app_role = models.SmallIntegerField(_('emp_field_appRole'), null=True, blank=True, default=db_const.APP_STAFF, choices=db_const.APP_ROLE)
    def app_enable(self):
        return self.app_status == db_const.APP_ENABLE
    def is_app_admin(self):
        return self.app_role == db_const.APP_ADMIN
    class Meta:
        abstract = True
class WorkflowMixin(models.Model):
    flow_role = WorkflowRoleManyToManyField('workflow.WorkflowRole', related_name='employees', verbose_name=_('emp_field_workflowRole'), blank=True)
    def delete_flow_role(self):
        workflowinstance = self.workflowinstance_set.all()
        workflowinstance.delete()
        nodeinstance = self.nodeinstance_set.all()
        nodeinstance.delete()
        engines = self.workflowengine_set.all()
        for engine in engines:
            if engine.employee.count() == 1 and engine.employee.first().emp_code == self.emp_code:
                    engine.delete()
    class Meta:
        abstract = True
dic_addPermissions = {'staff': ('pendingchangeschedule', 'pendingtraining', 'pendingmanuallog', 'pendingovertime', 'pendingleave', 'approvalchangeschedule', 'approvaltraining', 'approvalmanuallog', 'approvalovertime', 'approvalleave', 'staff_timecard_report', 'staff_breaktime_report', 'staff_multipletransaction_report', 'staff_summary_report', 'staff_attdetail_report', 'staff_scheduledlog_report', 'staff_transaction_report'), 'staff_meeting': ('pendingmeetingmanuallog', 'pendingmeetingentity', 'approvalmeetingmanuallog', 'approvalmeetingentity', 'meeting_attender_pendingmeetingentity'), 'staff_visitor': ('pendingreservation', 'approvalreservation'), 'contenttypes': ('contenttype',)}
dic_changePermissions = {'staff': ('pendingchangeschedule', 'pendingtraining', 'pendingmanuallog', 'pendingovertime', 'pendingleave', 'approvalchangeschedule', 'approvaltraining', 'approvalmanuallog', 'approvalovertime', 'approvalleave', 'staff_timecard_report', 'staff_breaktime_report', 'staff_multipletransaction_report', 'staff_summary_report', 'staff_attdetail_report', 'staff_scheduledlog_report', 'staff_transaction_report'), 'staff_meeting': ('pendingmeetingmanuallog', 'pendingmeetingentity', 'approvalmeetingmanuallog', 'approvalmeetingentity'), 'staff_visitor': ('pendingreservation', 'approvalreservation')}
dic_deletePermissions = {'staff': ('pendingchangeschedule', 'pendingtraining', 'pendingmanuallog', 'pendingovertime', 'pendingleave', 'approvalchangeschedule', 'approvaltraining', 'approvalmanuallog', 'approvalovertime', 'approvalleave', 'staff_timecard_report', 'staff_breaktime_report', 'staff_multipletransaction_report', 'staff_summary_report', 'staff_attdetail_report', 'staff_scheduledlog_report', 'staff_transaction_report'), 'staff_meeting': ('pendingmeetingmanuallog', 'pendingmeetingentity', 'approvalmeetingmanuallog', 'approvalmeetingentity'), 'staff_visitor': ('pendingreservation', 'approvalreservation'), 'contenttypes': ('contenttype',)}
APP_ADMIN = {'personnel': ('area', 'position', 'department', 'company', 'resign', 'employee', 'psnl_config_setting', 'employeecustomattribute', 'certification'), 'staff': ('pendingchangeschedule', 'pendingtraining', 'pendingmanuallog', 'pendingovertime', 'pendingleave', 'approvalchangeschedule', 'approvaltraining', 'approvalmanuallog', 'approvalovertime', 'approvalleave', 'staff_timecard_report', 'staff_breaktime_report', 'staff_multipletransaction_report', 'staff_summary_report', 'staff_attdetail_report', 'staff_scheduledlog_report', 'staff_transaction_report'), 'workflow': ('workflowengine', 'workflowrole'), 'att': ('att_workbench', 'attgroup', 'attcode', 'paycode', 'grouppolicy', 'departmentpolicy', 'attpolicy', 'attshift', 'timeinterval', 'breaktime', 'temporaryschedule', 'attschedule', 'groupschedule', 'departmentschedule', 'view_by_personnel',
dic_enterPermissions = {'accounts': ('personnel', 'attendance', 'terminal', 'access', 'visitor', 'meeting', 'system', 'ep', 'payroll')}
class AccountMixin(models.Model):
    """\n    The login attributes for employee\n    """
    USERNAME_FIELD = 'emp_code'
    last_login = models.DateTimeField(_('emp_field_lastLogin'), null=True, blank=True)
    is_active = models.BooleanField(_('emp_field_isActive'), default=True, editable=False)
    is_staff = True
    is_employee = True
    session_key = models.CharField(max_length=32, null=True, blank=True)
    login_ip = models.CharField(max_length=32, null=True, blank=True)
    @property
    def is_anonymous(self):
        """\n        Return a boolean of whether the user was anonymous.\n        """
        return False
    @property
    def is_authenticated(self):
        return True
    def get_params(self, perm, *args, **kwargs):
        app_label = kwargs.get('app')
        model_name = kwargs.get('model_name')
        if app_label is None and model_name is None and perm:
                    ps = perm.split('.', 1)
                    app_label = ps[0]
                    if len(ps) == 2 and ps[1]:
                            am = ps[1].split('_', 1)
                            action = am[0]
                            model_name = am[1] if len(am) == 2 else ''
        return (app_label, model_name)
    def has_add_perm(self, perm, *args, **kwargs):
        app_label, model_name = self.get_params(perm, *args, **kwargs)
        if app_label in dic_addPermissions and model_name in dic_addPermissions[app_label]:
                return True
        return False
    def has_delete_perm(self, perm, *args, **kwargs):
        app_label, model_name = self.get_params(perm, *args, **kwargs)
        if app_label in dic_deletePermissions and model_name in dic_deletePermissions[app_label]:
                return True
        return False
    def has_change_perm(self, perm, *args, **kwargs):
        app_label, model_name = self.get_params(perm, *args, **kwargs)
        if app_label in dic_changePermissions and model_name in dic_changePermissions[app_label]:
                return True
        return False
    def has_view_perm(self, perm: str, *args, **kwargs):
        return self.has_model_op_perms(*self.get_params(perm, *args, **kwargs))
    def has_enter_perm(self, perm, *args, **kwargs):
        app_label = kwargs.get('app')
        module = kwargs.get('module')
        if app_label in dic_enterPermissions and module in dic_enterPermissions[app_label]:
                return True
        return False
    def has_perm(self, perm: str, obj=None, *args, **kwargs):
        action = kwargs.get('action', 'unknown')
        app = kwargs.get('app', '')
        if action == 'unknown' and perm:
                ps = perm.split('.', 1)
                app = ps[0]
                if len(ps) == 2 and ps[1]:
                        am = ps[1].split('_', 2)
                        action = am[0]
                        if action == 'enter':
                            kwargs.update({'action': action, 'app': app, 'module': am[1] if len(am) >= 2 else ''})
        func = getattr(self, f'has_{action}_perm', None)
        if func and callable(func):
            return func(perm, obj, *args, **kwargs)
        else:
            if action!= 'unknown':
                if app in ['staff', 'staff_meeting', 'staff_visitor']:
                    return True
                else:
                    print(perm)
                    return False
            else:
                return True
    def has_model_op_perms(self, app_label, model_name):
        """permission of view"""
        if app_label in dic_viewPermissions and model_name in dic_viewPermissions[app_label]:
                return True
        return False
    def has_module_perms(self, module: str):
        if module.lower() in ['staff', 'staff_visitor', 'staff_meeting']:
            return True
        else:
            return False
    def check_password(self, raw_password):
        """\n        Return a boolean of whether the raw_password was correct. Handles\n        hashing formats behind the scenes.\n        """
        def setter(raw_password):
            self.set_password(raw_password)
            self._password = None
            self.save(update_fields=['self_password'])
        return check_password(raw_password, self.self_password, setter)
    def set_password(self, raw_password):
        self.self_password = make_password(raw_password)
        self._password = raw_password
    def get_username(self):
        return getattr(self, self.USERNAME_FIELD)
    class Meta:
        abstract = True
class CompanyMixin(models.Model):
    company = CompanyForeignKey(Company, verbose_name=_('employee.field.company'), blank=False, default=1, on_delete=models.CASCADE)
    class Meta:
        abstract = True