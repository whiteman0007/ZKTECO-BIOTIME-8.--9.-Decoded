# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\asgi_sse_redis.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from __future__ import unicode_literals
import asyncio
import datetime
import json
import functools
import re
import sys
import nest_asyncio
from channels.generic.http import AsyncHttpConsumer
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from redis import Redis, ConnectionPool as RedisConnectionPool
from redis.connection import UnixDomainSocketConnection, Connection, DefaultParser
DEFAULT_CHANNEL = getattr(settings, 'REDIS_SSEQUEUE_CHANEL_NAME', 'sse')
CONNECTION_KWARGS = getattr(settings, 'REDIS_SSEQUEUE_CONNECTION_SETTINGS', {})
MAX_NUM = 86400
class AsyncRedisQueueConsumer(AsyncHttpConsumer):
    @classmethod
    def as_asgi(cls, **initkwargs):
        async def app(scope, receive, send):
            consumer = cls(**initkwargs)
            return await consumer(scope, receive, send)
        app.consumer_class = cls
        app.consumer_initkwargs = initkwargs
        import functools
        functools.update_wrapper(app, cls, updated=())
        return app
    async def send_sse_event_empty(self):
        await self.send_body(body=b':\n\n', more_body=True)
    async def send_sse_event(self, event: str, data: str, id: str=None, retry: int=0, more_event=True):
        if id:
            await self.send_body(body='id:{0}\n'.format(id).encode(encoding='UTF8'), more_body=True)
        await self.send_body(body='event:{0}\n'.format(event or 'message').encode(encoding='UTF8'), more_body=True)
        await self.send_body(body='data:{0}\n'.format(data or ' ').encode(encoding='UTF8'), more_body=True)
        if retry > 0:
            await self.send_body(body='retry:{0}\n'.format(retry).encode(encoding='UTF8'), more_body=True)
        await self.send_body(body=b'\n', more_body=more_event)
    async def handle(self, body):
        if self.scope['user'].is_anonymous:
            await self.send_headers(status=200, headers=[[b'content-type', b'text/plain']])
            await self.send_body(body=json.dumps({'code': 401, 'message': 'Login Required'}).encode(encoding='utf8'), more_body=False)
            return
        else:
            await self.send_headers(status=200, headers=[[b'content-type', b'text/event-stream'], [b'Cache-Control', b'no-cache'], [b'Connection', b'keep-alive'], [b'Access-Control-Allow-Origin', b'*'], [b'Software', b'AGSI-SSE']])
            await self.send_sse_event(event='start', data=' ')
            if settings.IMPORT_EXPORT_USE_REDIS:
                await self.listen_send()
            else:
                await self.listen_send_ex()
            await self.send_sse_event(event='close', data=' ', more_event=False)
    async def listen_send(self):
        # irreducible cflow, using cdg fallback
        connection = _connect()
        pubsub = connection.pubsub()
        pubsub.subscribe(self.get_redis_channel())
        over_time = datetime.datetime.now() + datetime.timedelta(minutes=settings.IMPORT_EXPORT_PROGRESS_TIMEOUT)
        on_loop = True
        num = 0
        while on_loop and datetime.datetime.now() < over_time:
            message = pubsub.get_message(ignore_subscribe_messages=True, timeout=0.2)
            if message and message['type'] == 'message':
                num = 0
                event, data = json.loads(message['data'])
                if event == 'close':
                    on_loop = False
                await self.send_sse_event(event=event, data=data)
                num = num + 1
                if num >= MAX_NUM:
                    on_loop = False
                    await asyncio.sleep(1)
        pubsub.close()
    def get_task(self, task_name: str):
        """\n        :return: task,consumer\n        """
        if not task_name:
            return (None, None)
        else:
            from asyncio import Task
            tasks = []
            try:
                loop = asyncio.get_event_loop()
            except Exception as e0:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            else:
                tasks = asyncio.all_tasks(loop)
            task = None
            consumer = None
            try:
                for t in tasks:
                    if t.get_name() == task_name:
                        task = t
                        consumer = t.get_coro().cr_frame.f_locals['self']
            except Exception as e0:
                pass
            return (task, consumer)
    async def listen_send_ex(self):
        import queue
        task, consumer = (None, None)
        over_time = datetime.datetime.now() + datetime.timedelta(minutes=settings.IMPORT_EXPORT_PROGRESS_TIMEOUT)
        on_loop = True
        num = 0
        while not on_loop or datetime.datetime.now() < over_time:
            while True:
                if not task:
                    task, consumer = self.get_task(self.get_redis_channel())
                m = None
                if consumer and hasattr(consumer, 'send_event'):
                        try:
                            m_q = consumer.send_event.m_queue
                            m = m_q.get(timeout=0.2)
                        except Exception as e1:
                            pass
                if m:
                    num = 0
                    event = m.get('event_name')
                    data = m.get('data')
                    if event == 'close':
                        on_loop = False
                    await self.send_sse_event(event=event, data=data)
                else:
                    num = num + 1
                    if num >= MAX_NUM:
                        on_loop = False
                        return
                    else:
                        await asyncio.sleep(1)
    def make_bytes(self, value, charset='utf-8'):
        if isinstance(value, (bytes, memoryview)):
            return bytes(value)
        else:
            if isinstance(value, str):
                return bytes(value.encode(charset))
            else:
                return str(value).encode(charset)
    redis_channel = DEFAULT_CHANNEL
    def get_redis_channel(self):
        return self.redis_channel
    def get_last_id(self):
        if 'HTTP_LAST_EVENT_ID' in self.scope:
            return self.scope['HTTP_LAST_EVENT_ID']
        else:
            return None
class ConnectionPoolManager(object):
    pools = {}
    @classmethod
    def key_for_kwargs(cls, kwargs):
        return ':'.join([str(v) for v in kwargs.values()])
    @classmethod
    def connection_pool(cls, **kwargs):
        pool_key = cls.key_for_kwargs(kwargs)
        if pool_key in cls.pools:
            return cls.pools[pool_key]
        else:
            location = kwargs.get('location', None)
            if not location:
                raise ImproperlyConfigured('no `location` key on connection kwargs')
            else:
                params = {'connection_class': Connection, 'db': kwargs.get('db', 0), 'password': kwargs.get('password', None)}
                if location.startswith('unix:'):
                    params['connection_class'] = UnixDomainSocketConnection
                    params['path'] = location[5:]
                else:
                    try:
                        params['host'], params['port'] = location.split(':')
                        params['port'] = int(params['port'])
                    except ValueError:
                        raise ImproperlyConfigured('Invalid `location` key syntax on connection kwargs')
                cls.pools[pool_key] = RedisConnectionPool(**params)
                return cls.pools[pool_key]
def _connect():
    pool = ConnectionPoolManager.connection_pool(**CONNECTION_KWARGS)
    return Redis(connection_pool=pool)
def send_event(event_name, data, channel=DEFAULT_CHANNEL):
    """\n    :param event_name: message-normal event,progressMessage-event for progress,result-event for task result,close-event for close sse\n    :param channel:redis channel\n    """
    connection = _connect()
    connection.publish(channel, json.dumps([event_name, data]))
def asgi_login_check(func):
    async def app(*args, **kwargs):
        if len(args) == 0:
            return
        else:
            arg0 = args[0]
            user = None
            send = None
            from channels.generic.http import AsyncHttpConsumer
            if isinstance(arg0, AsyncHttpConsumer):
                obj = arg0
                scope = obj.scope
                if scope:
                    user = scope['user']
                if user and user.is_authenticated:
                    return await func(arg0, args[1])
                else:
                    send = obj.send
            else:
                if isinstance(arg0, dict):
                    scope = arg0
                    if scope:
                        user = scope['user']
                    if user and user.is_authenticated:
                        return await func(arg0, args[1], args[2])
                    else:
                        if len(args) == 3:
                            send = args[2]
            await send({'type': 'http.response.start', 'status': 401, 'headers': [[b'content-type', b'text/plain']]})
            await send({'type': 'http.response.body', 'body': b' ', 'more_body': False})
            return False
    return app
class Sse(object):
    _retry = None
    _buffer = None
    _rx_event = re.compile('^add_event_([\\w\\d\\_]+)$', flags=re.U)
    def __init__(self, default_retry=2000):
        self._buffer = []
        self.set_retry(default_retry)
    def set_retry(self, num):
        """\n        Set distinct retry timeout instead the default\n        value.\n        """
        self._retry = num
        self._buffer.append('retry: {0}\n\n'.format(self._retry))
    def set_event_id(self, event_id):
        if event_id:
            self._buffer.append('id: {0}\n\n'.format(event_id))
        else:
            self._buffer.append('id\n\n')
    def reset_event_id(self):
        """\n        Send a reset event id.\n        """
        self.set_event_id(None)
    def _parse_text(self, text, encoding):
        if isinstance(text, (list, tuple, set)):
            for item in text:
                if isinstance(item, bytes):
                    item = item.decode(encoding)
                for subitem in item.splitlines():
                    yield subitem
        else:
            if isinstance(text, bytes):
                text = text.decode(encoding)
            for item in text.splitlines():
                yield item
    def add_message(self, event, text, encoding='utf-8'):
        """\n        Add messaget with eventname to the buffer.\n\n        :param str event: event name\n        :param str/list text: event content. Must be a str or list of str\n        :param bool split: splits str content by lines. default(true)\n        """
        self._buffer.append('event: {0}\n'.format(event))
        for text_item in self._parse_text(text, encoding):
            self._buffer.append('data: {0}\n'.format(text_item))
        self._buffer.append('\n')
    def __getattr__(self, attr):
        """\n        Make a dynamic method for add messages to specific events\n        like add_event_<eventname>(text=\"Hello\")\n\n        Examples:\n            response.add_foo(text=\"bar\")\n\n        This sets event to \"foo\" and put \"bar\" as content.\n        """
        res = self._rx_event.search(attr)
        if not res:
            return super(Sse, self).__getattr__(attr)
        else:
            return functools.partial(self.add_message, event=res.group(1))
    def __str__(self):
        if sys.version_info[0] >= 3:
            return self.__unicode__()
        else:
            return self.__unicode__().encode('utf8')
    def __unicode__(self):
        return ''.join(self._buffer)
    def flush(self):
        """\n        Reset the internal buffer to initial state.\n        """
        self._buffer = []
    def __iter__(self):
        for item in self._buffer:
            yield item
        self.flush()
__all__ = ['send_event', 'AsyncRedisQueueConsumer', 'asgi_login_check']