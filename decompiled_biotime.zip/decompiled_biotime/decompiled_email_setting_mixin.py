# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\email_setting_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
from mysite.admin.services.email import send_one_mail
class EmailSettingViewMixin:
    @action(methods=['get', 'post'], url_path='email_setting', detail=False)
    def email_setting(self, request, *args, **kwargs):
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='email_setting').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        else:
            serializer = serializers.EmailSettingUpdateSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj = SystemSetting.objects.filter(name='email_setting').first()
            if not obj:
                obj = SystemSetting(name='email_setting')
            obj.value = json.dumps(data)
            obj.save()
            return Response(data)
    @action(methods=['get'], detail=False)
    def mail_test(self, request, *args, **kwargs):
        qs = self.get_queryset()
        own_mail = qs.filter(name='email_setting').first()
        if not own_mail:
            return Response({'detail': 'error'}, status=400)
        else:
            to = [json.loads(own_mail.value).get('email_account')]
            subject = 'Test Email'
            body = 'Test Email Body'
            try:
                send_one_mail(subject, body, to)
            except Exception as e:
                return Response({'detail': str(e)}, status=400)
            return Response({'detail': 'Success'})
    @action(methods=['get'], detail=False)
    def clear_email(self, request, *args, **kwargs):
        qs = self.get_queryset()
        qs.filter(name='email_setting').delete()
        return Response({'detail': 'Success'})