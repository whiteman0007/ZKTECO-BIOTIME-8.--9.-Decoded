# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\manuallog_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from django.forms.widgets import HiddenInput
from django.forms import ModelChoiceField
from mysite.admin import forms, ZKModelAction
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.att.models import ManualLog
from mysite.att.models_choices import PUNCH_STATES
from mysite.iclock.models import TerminalWorkCode
from mysite.personnel.forms.fields import EmployeeSearchChoiceField, EmployeeMultipleChoiceField
class AddManualLogForm(forms.ZKActionForm):
    employee = EmployeeSearchChoiceField()
    punch_time = forms.DateTimeField(label=_('manualLog_field_punchTime'))
    punch_state = forms.ChoiceField(label=_('manualLog_field_punchState'), choices=PUNCH_STATES)
    work_code = ModelChoiceField(label=_('manualLog_field_workCode'), queryset=TerminalWorkCode.objects.all(), required=False)
    auto_approve = forms.BooleanField(label=_('common.fields.autoApproved'), initial=True, required=False)
    reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    def __init__(self, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        from mysite.base.utils import get_punch_states
        self.permission = APPROVAL_APPROVE_PERMISSION.get('manuallog')
        super(AddManualLogForm, self).__init__(*args, **kwargs)
        self.fields['punch_state'].choices = get_punch_states()
        if not self.request or not self.request.user.has_perm(self.permission):
                self.fields['auto_approve'].widget = HiddenInput()
                self.fields['auto_approve'].initial = False
class AddManualLog(ZKModelAction):
    verbose_name = _('manualLog_Action_new')
    short_description = _('manualLog_Action_newDescription')
    help_txt = _('manualLog_Action_newHelpTxt')
    action_form = AddManualLogForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        if data.get('employee', None):
            obj = ManualLog(employee=data['employee'], punch_time=data['punch_time'], punch_state=data['punch_state'], work_code=data['work_code'], apply_reason=data['reason'], attachment=data['attachment'])
            obj.save(force_insert=True)
            user = self.request.user
            if data.get('auto_approve', None) and user.has_perm(self.valid_form.permission):
                    obj.do_approve(user, _('common.fields.autoApproved'))
        else:
            raise AdminRuntimeWarning(_('select_employee'))
class BulkAddManualLogForm(forms.ZKActionForm):
    employee = EmployeeMultipleChoiceField(required=False)
    punch_time = forms.DateTimeField(label=_('manualLog_field_punchTime'))
    punch_state = forms.ChoiceField(label=_('manualLog_field_punchState'), choices=PUNCH_STATES)
    work_code = ModelChoiceField(label=_('manualLog_field_workCode'), queryset=TerminalWorkCode.objects.all(), required=False)
    auto_approve = forms.BooleanField(label=_('common.fields.autoApproved'), initial=True, required=False)
    reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    def __init__(self, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        from mysite.base.utils import get_punch_states
        self.permission = APPROVAL_APPROVE_PERMISSION.get('manuallog')
        super(BulkAddManualLogForm, self).__init__(*args, **kwargs)
        self.fields['punch_state'].choices = get_punch_states()
        if not self.request or not self.request.user.has_perm(self.permission):
                self.fields['auto_approve'].widget = HiddenInput()
                self.fields['auto_approve'].initial = False
class BulkAddManualLog(ZKModelAction):
    verbose_name = _('manualLog.actions.bulkAdd')
    short_description = _('manualLog.actions.bulkAdd.description')
    help_txt = _('manualLog.actions.bulkAdd.helpTxt')
    action_form = BulkAddManualLogForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        if data.get('employee', None):
            for emp in data['employee']:
                obj = ManualLog(employee=emp, punch_time=data['punch_time'], punch_state=data['punch_state'], work_code=data['work_code'], apply_reason=data['reason'])
                obj.save(force_insert=True)
                user = self.request.user
                if data.get('auto_approve', None) and user.has_perm(self.valid_form.permission):
                        obj.do_approve(user, _('common.fields.autoApproved'))
        else:
            raise AdminRuntimeWarning(_('select_employee'))