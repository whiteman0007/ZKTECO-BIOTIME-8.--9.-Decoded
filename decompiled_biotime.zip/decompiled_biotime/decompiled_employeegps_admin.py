# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\admin\\employeegps_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from django.forms import ModelForm, ModelMultipleChoiceField, ValidationError
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.mobile import tasks
from mysite.mobile.models import GPSForEmployee, GPSLocation
from mysite.mobile.widgets import GPSLocationSelectMultiple
class GPSForEmployeeChangeForm(ModelForm):
    emp = forms.CharField(label=_('gpsForEmployee_field_employee'), disabled=True)
    location = ModelMultipleChoiceField(label=_('gpsForEmployee_field_location'), queryset=GPSLocation.objects.get_queryset(), widget=GPSLocationSelectMultiple())
    distance = forms.IntegerField(label=_('gpsForEmployee_field_distance'), suffix=_('distance.units.meter'))
    start_date = forms.DateField(label=_('gpsForEmployee_field_startDate'))
    end_date = forms.DateField(label=_('gpsForEmployee_field_endDate'))
    def __init__(self, *args, **kwargs):
        super(GPSForEmployeeChangeForm, self).__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields['emp'].initial = str(self.instance.employee)
    def clean_distance(self):
        distance = self.cleaned_data.get('distance', 0)
        if distance is None or distance < 0:
            raise ValidationError(_('gps_distance_invalid'))
        else:
            return distance
    def clean_end_date(self):
        start_date = self.cleaned_data['start_date']
        end_date = self.cleaned_data['end_date']
        if end_date < start_date:
            raise ValidationError(_('gps_date_invalid_range'))
        else:
            return end_date
    def save(self, commit=True):
        instance = super(GPSForEmployeeChangeForm, self).save(commit)
        self.post_save(instance)
        return instance
    def post_save(self, instance):
        if not self.changed_data:
            return
        else:
            instance.location.set(self.cleaned_data['location'])
            tasks.update_employee_gps(instance)
    class Meta:
        model = GPSForEmployee
        fields = ('location', 'distance', 'start_date', 'end_date')
class AddGPSForEmployeeForm(forms.ZKActionForm):
    emp = forms.EmployeeManyToManyField(label=_('gpsForEmployee_field_employee'), required=False)
    location = ModelMultipleChoiceField(label=_('gpsForEmployee_field_location'), queryset=GPSLocation.objects.get_queryset(), widget=GPSLocationSelectMultiple())
    distance = forms.IntegerField(label=_('gpsForEmployee_field_distance'), initial=50, suffix=_('distance.units.meter'))
    start_date = forms.DateField(label=_('gpsForEmployee_field_startDate'))
    end_date = forms.DateField(label=_('gpsForEmployee_field_endDate'))
    def clean_distance(self):
        distance = self.cleaned_data.get('distance', 0)
        if distance is None or distance < 0:
            raise ValidationError(_('gps_distance_invalid'))
        else:
            return distance
    def clean_end_date(self):
        start_date = self.cleaned_data['start_date']
        end_date = self.cleaned_data['end_date']
        if end_date < start_date:
            raise ValidationError(_('gps_date_invalid_range'))
        else:
            return end_date
class AddGPSForEmployee(admin.ZKModelAction):
    verbose_name = _('gpsForEmployee_action_addGPSForEmployee')
    help_txt = _('gpsForEmployee_action_addGPSForEmployeeHelpTxt')
    short_description = _('gpsForEmployee_action_addGPSForEmployeeDescription')
    action_form = AddGPSForEmployeeForm
    def action(self, *args, **kwargs):
        data = self.valid_form.cleaned_data
        emps = data.pop('emp', None)
        if not emps:
            raise AdminRuntimeWarning(_('select_employee'))
        else:
            locations = data.pop('location', None)
            if not locations:
                raise AdminRuntimeWarning(_('select_employee'))
            else:
                for emp in emps:
                    obj = GPSForEmployee(employee_id=emp, **data)
                    obj.save()
                    obj.location.set(locations)
                    tasks.update_employee_gps.delay(obj)
@admin.register(GPSForEmployee)
class GPSForEmployeeAdmin(admin.ZKModelAdmin):
    list_display = ('employee', 'emp_location', 'distance', 'start_date', 'end_date')
    list_filter = ('employee__emp_code', 'employee__first_name')
    form = GPSForEmployeeChangeForm
    actions = (AddGPSForEmployee,)
    def distance_viewing(self, obj, val):
        return '{0} {1}'.format(val, _('distance.units.meter'))
    def has_add_permission(self, request):
        return False
    def emp_location(self, obj):
        locations = obj.location.values_list('alias', flat=True)
        if not locations:
            return ''
        else:
            return ','.join(locations)
    emp_location.short_description = _('gpsLocation.fields.location')
    def get_queryset(self, request):
        qs = super(GPSForEmployeeAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            if request.user.auth_dept.all():
                qs = qs.filter(employee__department__in=request.user.auth_dept.all())
            if request.user.auth_area.all():
                qs = qs.filter(employee__area__in=request.user.auth_area.all())
        return qs