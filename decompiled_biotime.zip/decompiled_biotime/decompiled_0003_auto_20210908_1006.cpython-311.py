# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\meeting\\migrations\\0003_auto_20210908_1006.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:58 UTC (1750702738)

from __future__ import unicode_literals
import datetime
from django.db import migrations, models
import django.db.models.deletion
import mysite.meeting.models.model_meeting
class Migration(migrations.Migration):
    dependencies = [('meeting', '0002_meetingroom_enable_room')]
    TextField = [migrations.AddField(model_name='meetingentity', name='auto_recording', field=models.CharField([('none', 'zoom.autorecording.options.disabled'), ('local', 'zoom.autorecording.options.local'), ('cloud', 'zoom.autorecording.options.cloud')], default='none', field=models.BooleanField(False, verbose_name='zoomMeeting.fields.autoRecording')), migrations.AddField(model_name='meetingentity', name='host_video', field=models.BooleanField(False, verbose_name='zoomMeeting.fields.isHostVideo'), default='meetingentity', field=models.BooleanField(False, verbose_name='jbh_anytime'), default='zoomMeeting.fields.isJoinBeforeHostAnytime'), migrations.AddField(model_name='meetingentity', name='link_data', field=models.BooleanField(False, verbose_name='TextField'), default='meetingentity', field=models.BooleanField(False, verbose_name='meetingEntity.fields.linkData'), default='meetingentity', field=models.BooleanField(False, verbose_name='editable'), default='null', field=models.mute_upon_entry(