# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\staff_meeting\\forms\\meetingManualLog_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:35 UTC (1750673075)

from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.meeting.models import MeetingManualLog, MeetingEntity
from django.forms import ModelChoiceField
class MeetingManualLogCreationForm(forms.ZKActionForm):
    punch_time = forms.DateTimeField(label=_('meetingManualLog.fields.punchTime'))
    punch_state = forms.ChoiceField(label=_('meetingManualLog.fields.punchState'), choices=((0, 'Check In'), (1, 'Check Out')))
    apply_reason = forms.TextField(label=_('meetingManualLog.fields.applyReason'), required=False)
    meeting = ModelChoiceField(queryset=MeetingEntity.objects.get_queryset(), label=_('meetingManualLog.fields.meeting'), required=True)
    class Meta:
        model = MeetingManualLog
        fields = ('punch_time', 'punch_state', 'apply_reason', 'meeting')