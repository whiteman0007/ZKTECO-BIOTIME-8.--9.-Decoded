# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\basic_setting_mixin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import json
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.models import SystemSetting
from mysite.base.api import serializers
class BasicSettingViewMixin:
    @action(methods=['get', 'post'], url_path='basic_setting', detail=False)
    def basic_setting(self, request, *args, **kwargs):
        if request.method == 'GET':
            instance = SystemSetting.objects.filter(name='basic_setting').first()
            data = json.loads(instance.value) if instance else {}
            return Response(data)
        else:
            serializer = serializers.BasicSettingSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            obj = SystemSetting.objects.filter(name='basic_setting').first()
            if not obj:
                obj = SystemSetting(name='basic_setting')
            obj.value = json.dumps(data)
            obj.save()
            return Response(data)