# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\admin\\biophoto_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

from celery_progress.backend import AbstractProgressRecorder
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from mysite import config
from mysite.admin.kernel import ZKModelAdmin
from mysite.admin.sites import zk_site
from mysite.iclock import actions
from mysite.iclock.models import BioPhoto
from mysite.utils import progress_record
class BioPhotoAdmin(ZKModelAdmin):
    list_display = ('id', 'get_emp_code', 'emp_first_name', 'emp_last_name') + config.WDMS_LIST_DISPLAY + ('emp_email', 'enroll_sn', 'user_photo', 'bio_photo', 'register_time', 'remark', 'approval_state', 'approval_time')
    sort_fields = ('register_time', 'approval_time')
    list_filter = config.EMPLOYEE_LIST_FILTER + config.WDMS_LIST_FILTER_EMPLOYEE + ('register_time', 'approval_state')
    actions = (actions.BioPhotoApprove, actions.BioPhotoQRCode, actions.ImportBioPhoto)
    def company(self, obj):
        if obj.employee and obj.employee.company:
            return obj.employee.company.company_name
        else:
            return ''
    company.short_description = _('company.field.name')
    def company_code(self, obj):
        if obj.employee and obj.employee.company:
            return obj.employee.company.company_code
        else:
            return ''
    company_code.short_description = _('company.field.code')
    def user_photo(self, obj):
        import os
        from mysite.tools.access_utils import get_access_token
        file_path = str(obj.employee.photo)
        filename = os.path.basename(file_path)
        access_token = get_access_token({'n': filename, 'p': file_path})
        if settings.ENABLE_ENCRYPT_PHOTO:
            return '/auth_files/%s' % access_token
        else:
            return '/files/%s' % access_token
    user_photo.short_description = _('bioPhoto_field_userPhoto')
    def bio_photo(self, obj):
        import os
        from mysite.tools.access_utils import get_access_token
        file_path = str(obj.get_register_photo_display())
        filename = os.path.basename(file_path)
        access_token = get_access_token({'n': filename, 'p': file_path})
        if settings.ENABLE_ENCRYPT_PHOTO:
            return '/auth_files/%s' % access_token
        else:
            return '/files/%s' % access_token
    bio_photo.short_description = _('bioPhoto_field_bioPhoto')
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        qs = super(BioPhotoAdmin, self).get_queryset(request)
        if request.user.is_employee:
            qs = qs.filter(employee__company=request.user.company)
        else:
            if not request.user.is_superuser and request.user.auth_dept.exists():
                    qs = qs.filter(employee__department__in=request.user.auth_dept.all()).select_related('employee')
            if request.user.auth_area.exists():
                qs = qs.filter(employee__area__in=request.user.auth_area.all()).distinct()
            if request.user.assign_company:
                qs = qs.filter(employee__company=request.user.assign_company)
        return qs
    def data_import(self, request, **kwargs):
        from mysite.personnel.models import Employee
        from mysite.personnel.utils import devicePIN, formatPIN
        from mysite.utils import save_bio_photo
        from mysite.iclock.comm.utils import get_comm_setting
        from mysite.iclock.const import APPROVAL_AUTO_APPROVED, APPROVAL_PASSED
        photos = request.FILES.getlist('bio_photo')
        if not photos:
            return _('bioPhotoImport_error_noPhotoSelected')
        else:
            company = kwargs.pop('company', None)
            progress_recorder = kwargs.pop('progress_recorder', None)
            total = len(photos)
            current = 0
            progress_record(progress_recorder, current, total, _('importProgress.status.dataVerification'))
            pins = [devicePIN(photo.name.rsplit('.', 1)[0]) for photo in photos]
            exists_pins = Employee.objects.filter(emp_code__in=pins, company_id=company).values_list('emp_code', flat=True)
            extra_pins = set(pins) - set(list(exists_pins))
            ignore_error = int(kwargs.pop('ignore_error', '0'))
            if not ignore_error and extra_pins:
                return _('bioPhotoImport_error_userNoFound_{pin}').format(pin=','.join(extra_pins))
            else:
                overwrite = int(kwargs.pop('overwrite', '0'))
                approval_state = get_comm_setting('import_policy')
                for index, photo in enumerate(photos):
                    current = index
                    progress_record(progress_recorder, current, total, _('importProgress.status.uploading'))
                    pin = devicePIN(photo.name.rsplit('.', 1)[0])
                    if pin in extra_pins:
                        continue
                    else:
                        emp = Employee.objects.filter(emp_code=formatPIN(pin), company_id=company).first()
                        if not emp.biophoto_set.filter(approval_state__in=(APPROVAL_AUTO_APPROVED, APPROVAL_PASSED)):
                            overwrite = True
                        try:
                            save_bio_photo(emp, photo, approval_state, overwrite=overwrite, ignore_error=ignore_error)
                        except Exception as e:
                            return str(e)
zk_site.register(BioPhoto, BioPhotoAdmin)