# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\dashboard_present_list.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

import datetime
from django.utils.translation import gettext_lazy as _
from django.db.models.functions import TruncDate
from django.db.models import Count, Aggregate, TextField
from rest_framework import mixins, serializers
from mysite.att.api.serializers import NoneSerializer
from mysite.base.api.filters import EmployeeRelatedFilter
from mysite.base.api.utils_class import UserLayUIGenericViewSet
from mysite.iclock.models import Transaction
from mysite.base.utils import short_date_format
class GroupContact(Aggregate):
    def as_sql(self, compiler, connection, **extra_context):
        """\n        SQL Server 2017 Support STRING_AGG\n        STRING_AGG(column, separator)\n        """
        expression = self.get_source_expressions()[0]
        self.function = 'STUFF'
        self.template = '%(function)s((\n            SELECT \',\' + RIGHT(CONVERT(NVARCHAR(20), a.[{column}], 120), 8) \n            FROM [{table}] as a\n            WHERE a.[emp_id]  = [{table}].[emp_id] and CONVERT(char(10), a.[{column}], 101) = \n            CONVERT(datetime, CONVERT(char(10), [{table}].[{column}], 101), 101) \n            FOR xml path(\'\')\n        ), 1, 1, \'\')'.format(table=expression.alias, column=expression.field.attname)
        sql, params = super(GroupContact, self).as_sql(compiler, connection, **extra_context)
        return (sql, params)
    def as_oracle(self, compiler, connection, **extra_context):
        from mysite import sql_utils
        rows = sql_utils.p_query_one('select DISTINCT(VERSION) from product_component_version')
        version = rows and rows[0] or ''
        if version > '12.0':
            self.function = 'listagg'
            self.template = '%(function)s(substr(to_char(%(expressions)s,\'YYYY-MM-DD hh24:mi:ss\'), 12, 8), \',\')  within group(order by PUNCH_TIME)'
        else:
            self.function = 'WM_CONCAT'
            self.template = '%(function)s(substr(to_char(%(expressions)s,\'YYYY-MM-DD hh24:mi:ss\'), 12, 8))'
        sql, params = super(GroupContact, self).as_sql(compiler, connection, **extra_context)
        return (sql, params)
    def as_mysql(self, compiler, connection, **extra_context):
        self.function = 'GROUP_CONCAT'
        self.template = '%(function)s(SUBSTRING(%(expressions)s, 12, 8), \'\')'
        sql, params = super(GroupContact, self).as_sql(compiler, connection, **extra_context)
        return (sql, params)
    def as_postgresql(self, compiler, connection, **extra_context):
        self.function = 'ARRAY_TO_STRING'
        self.template = '%(function)s(ARRAY_AGG(to_char(%(expressions)s,\'hh24:mi:ss\')), \',\')'
        sql, params = super(GroupContact, self).as_sql(compiler, connection, **extra_context)
        return (sql, params)
class DailyPresentSerializer(serializers.ModelSerializer):
    emp_code = serializers.CharField(label=_('report_column_empCode'), source='emp__emp_code')
    first_name = serializers.CharField(label=_('report_column_firstName'), source='emp__first_name', allow_null=True)
    last_name = serializers.CharField(label=_('report_column_lastName'), source='emp__last_name', allow_null=True)
    nickname = serializers.CharField(label=_('report_column_nickName'), source='emp__nickname', allow_null=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='emp__department__dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='emp__department__dept_name', allow_null=True)
    position_code = serializers.CharField(label=_('report_column_positionCode'), source='emp__position__position_code', allow_null=True)
    position_name = serializers.CharField(label=_('report_column_positionName'), source='emp__position__position_name', allow_null=True)
    att_date = serializers.SerializerMethodField(label=_('report_column_attendanceDate'))
    punch_set = serializers.CharField(label=_('report_column_punchTime'), source='time_set', default=0)
    def get_att_date(self, obj):
        att_date = obj.get('punch_date', None)
        if not att_date:
            return ''
        else:
            return short_date_format(att_date)
    class Meta:
        model = Transaction
        fields = ('emp_code', 'first_name', 'last_name', 'nickname', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'punch_set')
class DailyPresentViewSet(mixins.ListModelMixin, UserLayUIGenericViewSet):
    model = Transaction
    queryset = Transaction.objects.select_related()
    filterset_class = EmployeeRelatedFilter
    serializer_dict = {'list': DailyPresentSerializer}
    def get_serializer_class(self):
        return self.serializer_dict.get(self.action, NoneSerializer)
    def get_queryset(self):
        from django.contrib.auth import get_user_model
        from mysite.att.api.views.report.view_report_timecard import TruncDateDefine
        queryset = super(DailyPresentViewSet, self).get_queryset()
        if not isinstance(self.request.user, get_user_model()) or not self.request.user.is_superuser:
                filters = {}
                distinct = False
                if self.request.user.auth_dept.exists():
                    filters['emp__department__in'] = self.request.user.auth_dept.all()
                if self.request.user.auth_area.exists():
                    distinct = True
                    filters['emp__area__in'] = self.request.user.auth_area.all()
                if self.request.user.assign_company:
                    filters['emp__company'] = self.request.user.assign_company
                if filters:
                    queryset = queryset.filter(**filters)
                if distinct:
                    queryset = queryset.distinct()
        else:
            queryset = queryset.filter(emp_code=self.request.user.emp_code)
        now = datetime.datetime.now()
        tmw = now + datetime.timedelta(days=1)
        queryset = queryset.filter(punch_time__range=(now.date(), tmw.date())).exclude(emp=None)
        queryset = queryset.annotate(punch_date=TruncDateDefine('punch_time'))
        queryset = queryset.values('emp_id', 'emp__emp_code', 'emp__first_name', 'emp__last_name', 'emp__nickname', 'emp__gender', 'emp__department__dept_code', 'emp__department__dept_name', 'emp__position__position_code', 'emp__position__position_name', 'punch_date').order_by('emp__emp_code', 'punch_date')
        queryset = queryset.annotate(time_set=GroupContact('punch_time', output_field=TextField()))
        return queryset