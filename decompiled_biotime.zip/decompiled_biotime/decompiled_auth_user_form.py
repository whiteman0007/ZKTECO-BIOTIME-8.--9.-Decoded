# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\forms\\auth_user_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import unicodedata
import datetime
import json
import re
from dateutil.relativedelta import relativedelta
from django import forms
from django.contrib.auth import authenticate, get_user_model, password_validation
from django.contrib.auth.hashers import UNUSABLE_PASSWORD_PREFIX, identify_hasher
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import EmailMultiAlternatives
from django.forms import ModelChoiceField
from django.template import loader
from django.conf import settings
from django.utils import timezone
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.utils.text import capfirst, format_lazy
from django.utils.translation import gettext, gettext_lazy as _
from mysite._utils import getattr_ex, db_passwords
from mysite.admin.forms.widgets import ZKPasswordInput, ZKTextInput, ZKEmailInput
from mysite.admin.forms import DateTimeField, IntegerField
from mysite.base.models import SystemSetting
from mysite.base.db_const import PASSWORD_EXPS, PASSWORD_EXPS_HIGH, PASSWORD_EXPS_LOWER
from mysite.base.const import PASSWORD_LEVEL_MEDIUM, PASSWORD_LEVEL_HIGHER, PASSWORD_LEVEL_LOWER
from mysite.personnel.models import Company, Department, Area
from mysite.personnel import widgets
from mysite.personnel.utils import get_default_company, get_default_company_id
UserModel = get_user_model()
class ReadOnlyPasswordHashWidget(forms.Widget):
    template_name = 'accounts/widgets/read_only_password_hash.html'
    def get_context(self, name, value, attrs):
        context = super(ReadOnlyPasswordHashWidget, self).get_context(name, value, attrs)
        summary = []
        if not value or value.startswith(UNUSABLE_PASSWORD_PREFIX):
            summary.append({'label': gettext('No password set.')})
        else:
            try:
                hasher = identify_hasher(value)
            except ValueError:
                summary.append({'label': gettext('Invalid password format or unknown hashing algorithm.')})
            else:
                for key, value_ in list(hasher.safe_summary(value).items()):
                    summary.append({'label': gettext(key), 'value': value_})
        context['summary'] = summary
        return context
class ReadOnlyPasswordHashField(forms.Field):
    widget = ReadOnlyPasswordHashWidget
    def __init__(self, *args, **kwargs):
        kwargs.setdefault('required', False)
        super(ReadOnlyPasswordHashField, self).__init__(*args, **kwargs)
    def bound_data(self, data, initial):
        return initial
    def has_changed(self, initial, data):
        return False
class UsernameField(forms.CharField):
    def to_python(self, value):
        return unicodedata.normalize('NFKC', super(UsernameField, self).to_python(value))
class UserCreationForm(forms.ModelForm):
    """\n    A form that creates a user, with no privileges, from the given username and\n    password.\n    """
    error_messages = {'password_mismatch': _('password_mismatch_errorMessage'), 'password_not_safe_lower': _('password.strength.lower.requirements'), 'password_not_safe': _('password_need_meet_strength_requirements'), 'password_not_safe_higher': _('password.strength.higher.requirements')}
    password1 = forms.CharField(label=_('user_createForm_password'), strip=False, widget=ZKPasswordInput, help_text=password_validation.password_validators_help_text_html())
    password2 = forms.CharField(label=_('user_createForm_passwordConfirmation'), widget=ZKPasswordInput, strip=False, help_text=_('user_createForm_passwordConfirmationHelpTxt'))
    date_joined = DateTimeField(label=_('user_field_dateJoined'), initial=timezone.now, disabled=True, required=False)
    password = ReadOnlyPasswordHashField(label=_('Password'), help_text=_('Raw passwords are not stored, so there is no way to see this user\'s password, but you can change the password using toolbar above.'))
    email = forms.EmailField(label=_('user.fields.email'), required=getattr_ex(settings, 'MEXICO', False), widget=ZKEmailInput)
    fp_count = IntegerField(label=_('user.fields.registeredFPQuantity'), required=False, initial=0, disabled=True, prefix='', suffix=format_lazy('<a id=\"fpRegister\" href=\"javascript:void(0);\" onclick=\"submitRegister()\">{btn}</a>', btn=_('user.buttons.enroll')))
    fp_type = forms.CharField(required=False, initial='')
    fps = forms.CharField(required=False, initial='')
    templates = forms.CharField(required=False, initial='')
    dur_fps = forms.CharField(required=False, initial='')
    del_fps = forms.CharField(required=False, initial='')
    class Meta:
        model = User
        fields = ('username',)
        field_classes = {'username': UsernameField}
    def __init__(self, *args, **kwargs):
        super(UserCreationForm, self).__init__(*args, **kwargs)
        self.fields['is_staff'].initial = True
        self.fields['is_superuser'].initial = True
        if self._meta.model.USERNAME_FIELD in self.fields:
            self.fields[self._meta.model.USERNAME_FIELD].widget.attrs.update({'autofocus': True})
        if self.instance.pk:
            fps = self.instance.adminbiodata_set.filter(bio_type=1).values_list('bio_no', 'bio_tmp', 'valid', 'duress', 'major_ver')
        else:
            fps = []
        self.fields['fp_count'].initial = len(fps)
        self.fields['fps'].initial = ','.join(map(str, [fp[0] for fp in fps]))
        self.fields['dur_fps'].initial = ','.join(map(str, [fp[0] for fp in fps if fp[3]]))
        if fps:
            templates = []
            for fp in fps:
                template = {'no': fp[0], 'version': fp[4], 'template': fp[1]}
                templates.append(template)
            self.fields['templates'].initial = json.dumps(templates)
        f = self.fields.get('user_permissions')
        if f is not None:
            f.queryset = f.queryset.select_related('content_type')
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            self.fields['company_widget'] = forms.ModelChoiceField(queryset=Company.objects.all(), label=_('label_authorized_company'), required=True, initial=get_default_company(), widget=widgets.CompanyRadioSelect(attrs={'onchange': True, 'first_click': 1, 'change_params': {'onchange_field': 'auth_dept,auth_area', 'onchange_field_model': 'department,area', 'onchange_api_name': 'dept_name,area_name', 'onchange_parent_name': 'parent_dept,parent_area', 'input_type': 'checkbox'}}))
    def clean_password2(self):
        from mysite.base.models.security_policy import SecurityPolicy
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')
        if password1 and password2 and (password1!= password2):
            raise forms.ValidationError(self.error_messages['password_mismatch'], code='password_mismatch')
        else:
            policy = SecurityPolicy.default()
            if policy.password_level:
                re_exp = PASSWORD_EXPS
                if policy.password_level == PASSWORD_LEVEL_HIGHER:
                    re_exp = PASSWORD_EXPS_HIGH
                else:
                    if policy.password_level == PASSWORD_LEVEL_LOWER:
                        re_exp = PASSWORD_EXPS_LOWER
                if not re.match(re_exp, password1):
                    if policy.password_level == PASSWORD_LEVEL_HIGHER:
                        raise forms.ValidationError(self.error_messages['password_not_safe_higher'], code='password_not_safe_higher')
                    else:
                        if policy.password_level == PASSWORD_LEVEL_MEDIUM:
                            raise forms.ValidationError(self.error_messages['password_not_safe'], code='password_not_safe')
                        else:
                            raise forms.ValidationError(self.error_messages['password_not_safe_lower'], code='password_not_safe_lower')
            if db_passwords and password1 in db_passwords:
                raise forms.ValidationError(_('password_need_strong_enough'), code='password_not_strong_enough')
            else:
                self.instance.username = self.cleaned_data.get('username')
                password_validation.validate_password(self.cleaned_data.get('password2'), self.instance)
                return password2
    def clean_email(self):
        from mysite.accounts.models import MyUser
        email = self.cleaned_data.get('email')
        if 'email' in self.changed_data and email:
            objs = list(filter(None, MyUser.objects.all().values_list('email', flat=True)))
            if email in objs:
                msg = _('userChange.error.emailNotUnique')
                raise forms.ValidationError(msg, code='email_not_unique')
        return email
    def remove_fingerprint(self):
        if 'del_fps' in self.changed_data:
            fps = self.data.get('del_fps', '')
            fps = fps.split(',')
            if fps:
                _fps = self.instance.adminbiodata_set.filter(bio_type=1, bio_no__in=fps)
                _fps.delete()
    def save_fingerprint(self):
        if 'templates' in self.changed_data:
            templates = self.data.get('templates', None)
            templates = json.loads(templates)
            if templates:
                cls = self.instance.adminbiodata_set.model
                for tem in templates:
                    if not tem or not tem['template']:
                        continue
                    else:
                        fid = tem['no']
                        ftmp = tem['template']
                        version = tem['version']
                        fp = self.instance.adminbiodata_set.filter(bio_no__exact=fid, major_ver__in=(version,), bio_type=1).first()
                        if not fp:
                            fp = cls(admin=self.instance, bio_no=fid, major_ver=version, bio_type=1, bio_tmp=ftmp).save()
                        else:
                            fp.bio_tmp = ftmp
                            fp.save()
    def save(self, commit=True):
        from django.contrib.auth.hashers import make_password
        from mysite.personnel.utils import get_default_company
        self.cleaned_data['password1'] = make_password(self.cleaned_data['password1'])
        self.cleaned_data['password2'] = make_password(self.cleaned_data['password2'])
        user = super(UserCreationForm, self).save(commit=False)
        user.password = self.cleaned_data['password1']
        self.remove_fingerprint()
        if 'photo' in self.files:
            user.photo = self.files['photo']
        if 'company_widget' in self.fields:
            user.assign_company = self.data.get('company_widget', None)
        else:
            default_company = get_default_company()
            if default_company:
                user.assign_company = default_company.id
        user.save()
        self.save_fingerprint()
        return user
    def _save_m2m(self):
        if getattr_ex(settings, 'MULTI_COMPANY', False) and 'is_superuser' in self.changed_data:
                widget_id = self.data.get('company_widget', None)
                if 'auth_dept' not in self.changed_data:
                    self.cleaned_data['auth_dept'] = Department.objects.filter(company_id=widget_id)
                if 'auth_area' not in self.changed_data:
                    self.cleaned_data['auth_area'] = Area.objects.filter(company_id=widget_id)
        super(UserCreationForm, self)._save_m2m()
class UserChangeForm(forms.ModelForm):
    email = forms.EmailField(label=_('user.fields.email'), required=getattr_ex(settings, 'MEXICO', False), widget=ZKEmailInput)
    password = ReadOnlyPasswordHashField(label=_('Password'), help_text=_('Raw passwords are not stored, so there is no way to see this user\'s password, but you can change the password using toolbar above.'))
    username = forms.CharField(required=False, disabled=True)
    date_joined = DateTimeField(label=_('user_field_dateJoined'), initial=timezone.now, disabled=True, required=False)
    last_login = DateTimeField(label=_('user_field_lastLogin'), initial=timezone.now, disabled=True, required=False)
    fp_count = IntegerField(label=_('user.fields.registeredFPQuantity'), required=False, initial=0, disabled=True, prefix='', suffix=format_lazy('<a id=\"fpRegister\" href=\"javascript:void(0);\" onclick=\"submitRegister()\">{btn}</a>', btn=_('user.buttons.enroll')))
    fp_type = forms.CharField(required=False, initial='')
    fps = forms.CharField(required=False, initial='')
    templates = forms.CharField(required=False, initial='')
    dur_fps = forms.CharField(required=False, initial='')
    del_fps = forms.CharField(required=False, initial='')
    class Meta:
        model = User
        fields = '__all__'
        field_classes = {'username': UsernameField}
    def __init__(self, *args, **kwargs):
        super(UserChangeForm, self).__init__(*args, **kwargs)
        f = self.fields.get('user_permissions')
        fps = self.instance.adminbiodata_set.filter(bio_type=1).values_list('bio_no', 'bio_tmp', 'valid', 'duress', 'major_ver')
        self.fields['fp_count'].initial = len(fps)
        self.fields['fps'].initial = ','.join(map(str, [fp[0] for fp in fps]))
        self.fields['dur_fps'].initial = ','.join(map(str, [fp[0] for fp in fps if fp[3]]))
        if fps:
            templates = []
            for fp in fps:
                template = {'no': fp[0], 'version': fp[4], 'template': fp[1]}
                templates.append(template)
            self.fields['templates'].initial = json.dumps(templates)
        if f is not None:
            f.queryset = f.queryset.select_related('content_type')
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            self.fields['company_widget'] = forms.ModelChoiceField(queryset=Company.objects.all(), required=not self.initial['is_superuser'], label=_('label_authorized_company'), widget=widgets.CompanyRadioSelect(attrs={'onchange': True, 'change_params': {'onchange_field': 'auth_dept,auth_area', 'onchange_field_model': 'department,area', 'onchange_api_name': 'dept_name,area_name', 'onchange_parent_name': 'parent_dept,parent_area', 'input_type': 'checkbox'}}))
            if self.instance:
                company_id = self.instance.assign_company
                self.fields['company_widget'].initial = company_id or get_default_company()
                self.fields['auth_dept'].company_belong = self.fields['auth_area'].company_belong = company_id
    def clean_password(self):
        return self.initial['password']
    def clean_email(self):
        from mysite.accounts.models import MyUser
        email = self.cleaned_data.get('email')
        if 'email' in self.changed_data and email:
            objs = list(filter(None, MyUser.objects.all().values_list('email', flat=True)))
            if email in objs:
                msg = _('userChange.error.emailNotUnique')
                raise forms.ValidationError(msg, code='email_not_unique')
        return email
    def clean_company_widget(self):
        company_widget = self.cleaned_data.get('company_widget')
        is_superuser = self.cleaned_data.get('is_superuser')
        if getattr_ex(settings, 'MULTI_COMPANY', False) and (not is_superuser) and (not company_widget):
            raise forms.ValidationError('Please choose one company at least', code='no_choose_company')
        else:
            return company_widget
    def remove_fingerprint(self):
        if 'del_fps' in self.changed_data:
            fps = self.data.get('del_fps', '')
            fps = fps.split(',')
            if fps:
                _fps = self.instance.adminbiodata_set.filter(bio_type=1, bio_no__in=fps)
                _fps.delete()
    def save_fingerprint(self):
        if 'templates' in self.changed_data:
            templates = self.data.get('templates', None)
            templates = json.loads(templates)
            if templates:
                cls = self.instance.adminbiodata_set.model
                for tem in templates:
                    if not tem or not tem['template']:
                        continue
                    else:
                        fid = tem['no']
                        ftmp = tem['template']
                        version = tem['version']
                        fp = self.instance.adminbiodata_set.filter(bio_no__exact=fid, major_ver__in=(version,), bio_type=1).first()
                        if not fp:
                            fp = cls(admin=self.instance, bio_no=fid, major_ver=version, bio_type=1, bio_tmp=ftmp).save()
                        else:
                            fp.bio_tmp = ftmp
                            fp.save()
    def save(self, commit=True):
        instance = super(UserChangeForm, self).save(commit)
        self.remove_fingerprint()
        self.save_fingerprint()
        if 'photo' in self.files:
            instance.photo = self.files['photo']
            instance.save()
        if 'company_widget' in self.fields:
            instance.assign_company = self.data.get('company_widget', None)
        return instance
class AuthenticationForm(forms.Form):
    """\n    Base class for authenticating users. Extend this to get a form that accepts\n    username/password logins.\n    """
    username = UsernameField(max_length=254, widget=forms.TextInput(attrs={'autofocus': True}))
    password = forms.CharField(label=_('Password'), strip=False, widget=forms.PasswordInput)
    error_messages = {'invalid_login': _('Please enter a correct %(username)s and password. Note that both fields may be case-sensitive.'), 'inactive': _('This account is inactive.')}
    def __init__(self, request=None, *args, **kwargs):
        """\n        The \'request\' parameter is set for custom auth use by subclasses.\n        The form data comes in via the standard \'data\' kwarg.\n        """
        self.request = request
        self.user_cache = None
        super(AuthenticationForm, self).__init__(*args, **kwargs)
        self.username_field = UserModel._meta.get_field(UserModel.USERNAME_FIELD)
        if self.fields['username'].label is None:
            self.fields['username'].label = capfirst(self.username_field.verbose_name)
    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        if username is not None and password:
                self.user_cache = authenticate(self.request, username=username, password=password)
                if self.user_cache is None:
                    raise forms.ValidationError(self.error_messages['invalid_login'], code='invalid_login', params={'username': self.username_field.verbose_name})
                else:
                    self.confirm_login_allowed(self.user_cache)
        return self.cleaned_data
    def confirm_login_allowed(self, user):
        """\n        Controls whether the given User may log in. This is a policy setting,\n        independent of end-user authentication. This default behavior is to\n        allow login by active users, and reject login by inactive users.\n\n        If the given user cannot log in, this method should raise a\n        ``forms.ValidationError``.\n\n        If the given user may log in, this method should return None.\n        """
        if not user.is_active:
            raise forms.ValidationError(self.error_messages['inactive'], code='inactive')
    def get_user_id(self):
        if self.user_cache:
            return self.user_cache.id
        else:
            return None
    def get_user(self):
        return self.user_cache
class SetPasswordForm(forms.Form):
    """\n    A form that lets a user change set their password without entering the old\n    password\n    """
    error_messages = {'password_mismatch': _('password_mismatch_errorMessage'), 'password_not_safe_lower': _('password.strength.lower.requirements'), 'password_not_safe': _('password_need_meet_strength_requirements'), 'password_not_safe_higher': _('password.strength.higher.requirements')}
    password1 = forms.CharField(label=_('New password'), widget=forms.PasswordInput, strip=False, help_text=password_validation.password_validators_help_text_html())
    password2 = forms.CharField(label=_('New password confirmation'), strip=False, widget=forms.PasswordInput)
    def __init__(self, user, *args, **kwargs):
        self.user = user
        super(SetPasswordForm, self).__init__(*args, **kwargs)
    def clean_password2(self):
        from mysite.base.models.security_policy import SecurityPolicy
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')
        if password1 and password2 and (password1!= password2):
            raise forms.ValidationError(self.error_messages['password_mismatch'], code='password_mismatch')
        else:
            policy = SecurityPolicy.default()
            if policy.password_level:
                re_exp = PASSWORD_EXPS
                if policy.password_level == PASSWORD_LEVEL_HIGHER:
                    re_exp = PASSWORD_EXPS_HIGH
                else:
                    if policy.password_level == PASSWORD_LEVEL_LOWER:
                        re_exp = PASSWORD_EXPS_LOWER
                if not re.match(re_exp, password1):
                    if policy.password_level == PASSWORD_LEVEL_HIGHER:
                        raise forms.ValidationError(self.error_messages['password_not_safe_higher'], code='password_not_safe_higher')
                    else:
                        if policy.password_level == PASSWORD_LEVEL_MEDIUM:
                            raise forms.ValidationError(self.error_messages['password_not_safe'], code='password_not_safe')
                        else:
                            raise forms.ValidationError(self.error_messages['password_not_safe_lower'], code='password_not_safe_lower')
            password_validation.validate_password(password2, self.user)
            return password2
    def save(self, commit=True):
        password = self.cleaned_data['password1']
        now = datetime.datetime.now()
        self.user.set_password(password)
        self.user.update_time = now
        if commit:
            self.user.save()
        return self.user
class PasswordChangeForm(SetPasswordForm):
    """\n    A form that lets a user change their password by entering their old\n    password.\n    """
    error_messages = dict(SetPasswordForm.error_messages, **{'password_incorrect': _('Your old password was entered incorrectly. Please enter it again.')})
    password_original = forms.CharField(label=_('original_password'), strip=False, widget=forms.PasswordInput(attrs={'autofocus': True}))
    field_order = ['password_original', 'password1', 'password2']
    def clean_password_original(self):
        """\n        Validates that the old_password field is correct.\n        """
        password_original = self.cleaned_data['password_original']
        if not self.user.check_password(password_original):
            raise forms.ValidationError(self.error_messages['password_incorrect'], code='password_incorrect')
        else:
            return password_original
    def save(self, commit=True):
        if self.user.check_password(self.cleaned_data['password_original']):
            password = self.clean_password2()
            self.user.set_password(password)
            if commit:
                self.user.save()
        else:
            err_msg = '%s %s' % (_('original_password'), _('base_inmedit_field_error'))
            raise ValueError(err_msg)
class AdminPasswordChangeForm(forms.Form):
    """\n    A form used to change the password of a user in the admin interface.\n    """
    error_messages = {'password_mismatch': _('The two password fields didn\'t match.'), 'password_not_safe_lower': _('password.strength.lower.requirements'), 'password_not_safe': _('password_need_meet_strength_requirements'), 'password_not_safe_higher': _('password.strength.higher.requirements'), 'password_repeat': _('new_password_same_as_origin_password')}
    required_css_class = 'required'
    password_original = forms.CharField(label=_('original_password'), widget=forms.PasswordInput(attrs={'class': 'layui-input'}), strip=False, help_text=_('Enter the original password for the user'))
    password1 = forms.CharField(label=_('Password'), widget=forms.PasswordInput(attrs={'autofocus': True, 'class': 'layui-input'}), strip=False, help_text=password_validation.password_validators_help_text_html())
    password2 = forms.CharField(label=_('Password (again)'), widget=forms.PasswordInput(attrs={'class': 'layui-input'}), strip=False, help_text=_('Enter the same password as before, for verification.'))
    def __init__(self, user, *args, **kwargs):
        from mysite.base.models.security_policy import SecurityPolicy
        policy = SecurityPolicy.default()
        if policy.password_level == PASSWORD_LEVEL_HIGHER:
            notice = self.error_messages['password_not_safe_higher']
        else:
            if policy.password_level == PASSWORD_LEVEL_LOWER:
                notice = self.error_messages['password_not_safe_lower']
            else:
                notice = self.error_messages['password_not_safe']
        self.user = user
        self.notice = notice
        super(AdminPasswordChangeForm, self).__init__(*args, **kwargs)
    def clean_password2(self):
        from mysite.base.models.security_policy import SecurityPolicy
        password1 = self.cleaned_data.get('password1', '')
        password2 = self.cleaned_data.get('password2', '')
        original_password = self.cleaned_data.get('password_original', '')
        if password1 and password2 and (password1!= password2):
            raise forms.ValidationError(self.error_messages['password_mismatch'], code='password_mismatch')
        else:
            policy = SecurityPolicy.default()
            if policy.password_level:
                re_exp = PASSWORD_EXPS
                if policy.password_level == PASSWORD_LEVEL_HIGHER:
                    re_exp = PASSWORD_EXPS_HIGH
                else:
                    if policy.password_level == PASSWORD_LEVEL_LOWER:
                        re_exp = PASSWORD_EXPS_LOWER
                if not re.match(re_exp, password1):
                    if policy.password_level == PASSWORD_LEVEL_HIGHER:
                        raise forms.ValidationError(self.error_messages['password_not_safe_higher'], code='password_not_safe_higher')
                    else:
                        if policy.password_level == PASSWORD_LEVEL_MEDIUM:
                            raise forms.ValidationError(self.error_messages['password_not_safe'], code='password_not_safe')
                        else:
                            raise forms.ValidationError(self.error_messages['password_not_safe_lower'], code='password_not_safe_lower')
            if original_password == password1:
                raise forms.ValidationError(self.error_messages['password_repeat'], code='password_repeat')
            else:
                if db_passwords and password1 in db_passwords:
                    raise forms.ValidationError(_('password_need_strong_enough'))
                else:
                    password_validation.validate_password(password2, self.user)
                    return password2
    def save(self, commit=True):
        """\n        Saves the new password.\n        """
        if self.user.check_password(self.cleaned_data['password_original']):
            password = self.clean_password2()
            now = datetime.datetime.now()
            self.user.set_password(password)
            self.user.update_time = now
            if commit:
                self.user.save()
        else:
            err_msg = '%s %s' % (_('original_password'), _('base_inmedit_field_error'))
            raise ValueError(err_msg)
    @property
    def changed_data(self):
        data = super(AdminPasswordChangeForm, self).changed_data
        for name in list(self.fields.keys()):
            if name not in data:
                return []
        return ['password']
class AdminSoftwareUpgradeForm(forms.Form):
    category = forms.CharField(label=_('category'))
    major_ver = forms.CharField(label=_('major_ver'))
    file_ver = forms.CharField(label=_('file_ver'))
    svn_ver = forms.CharField(label=_('svn_ver'))
    num_ver = forms.CharField(label=_('num_ver'))
    ver_value = forms.CharField(label=_('ver_value'))
    ver_category = forms.CharField(label=_('ver_category'))
    ver_level = forms.IntegerField(label=_('ver_level'))
    xml_name = forms.CharField(label=_('xml_name'))
    zip_name = forms.CharField(label=_('zip_name'))
    ver_language = forms.CharField(label=_('ver_language'))
    en_us = forms.CharField(label=_('en_us'))
    zh_hk = forms.CharField(label=_('zh_hk'))
    def __init__(self, *args, **kwargs):
        super(AdminSoftwareUpgradeForm, self).__init__(*args, **kwargs)