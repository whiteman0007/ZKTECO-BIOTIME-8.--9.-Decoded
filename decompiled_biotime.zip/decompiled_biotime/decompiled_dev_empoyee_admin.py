# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\admin\\dev_empoyee_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
import itertools
import operator
from django.db.models import Q, Count
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite import config
from mysite.admin.action import ActionTuple
from mysite.admin.models import STATUS_VALID
from mysite.iclock import actions as eacs
from mysite.iclock import const
from mysite.iclock.models import DeviceEmployee
from mysite.personnel.admin import filters
@admin.register(DeviceEmployee)
class DeviceEmployeeAdmin(admin.ZKModelAdmin):
    list_display = ('emp_code', 'first_name') + config.WDMS_LIST_DISPLAY + ('department', 'card_no', 'fingerprint_qty', 'face_qty', 'palm_qty', 'vl_palm_qty', 'vl_face_qty', 'vl_face_photo_qty', 'enroll_sn', 'dev_privilege', 'verify_mode', 'update_time', 'employee_area')
    list_filter = ('emp_code', 'first_name', 'department__dept_name') + config.WDMS_LIST_FILTER + ('card_no', 'dev_privilege', 'verify_mode', 'enroll_sn', 'area__area_name')
    calculated_filter = (filters.FPListFilter, filters.FaceListFilter, filters.PalmListFilter, filters.FaceVLListFilter, filters.VlFacePhotoListFilter, filters.VlPalmListFilter)
    actions = (eacs.AreaTransfer,)
    form = eacs.DeviceEmployeeChangeForm
    action_sets = (ActionTuple(_('deviceEmployee.actions.dataTransfer'), (eacs.ReSync2Device, eacs.ReUpload, eacs.DeleteBioData)), ActionTuple(_('deviceEmployee.actions.dataEnrollment'), (eacs.EnrollFingerprint, eacs.EnrollPalm, eacs.EnrollFacePhoto)))
    def company_code(self, obj):
        if obj.employee and obj.employee.company:
            return obj.employee.company.company_code
        else:
            return ''
    company_code.short_description = _('company.field.code')
    def fingerprint_qty(self, obj):
        return obj.bios.get(const.bioFinger, '-')
    fingerprint_qty.short_description = _('emp_field_fingerprint')
    def face_qty(self, obj):
        return obj.bios.get(const.bioFace, '-')
    face_qty.short_description = _('emp_field_face')
    def palm_qty(self, obj):
        return obj.bios.get(const.bioHand, '-')
    palm_qty.short_description = _('emp_field_palm')
    def vl_palm_qty(self, obj):
        return obj.bios.get(const.bioPalmVL, '-')
    vl_palm_qty.short_description = _('emp_field_vlPalm')
    def vl_face_qty(self, obj):
        return obj.bios.get(const.bioFaceVL, '-')
    vl_face_qty.short_description = _('emp_field_vlFace')
    def vl_face_photo_qty(self, obj):
        photos = obj.biophoto_set.filter(approval_state__in=(1, 3)).count()
        if not photos:
            return '-'
        else:
            return photos
    vl_face_photo_qty.short_description = _('emp.fields.vlFace')
    def employee_area(self, obj):
        return obj.area_alias
    employee_area.short_description = _('emp_field_area')
    def update_result(self, obj):
        bios = obj.biodata_set.filter(bio_type__in=(const.bioFinger, const.bioFace, const.bioHand, const.bioFaceVL, const.bioPalmVL)).values('bio_type', 'major_ver').annotate(Count('id'))
        payload = {key: ','.join(['Ver {major_ver}:{id__count}'.format(**bio) for bio in items]) for key, items in itertools.groupby(bios, operator.itemgetter('bio_type'))}
        areas = obj.area.all().values('area_code', 'area_name')
        setattr(obj, 'area_codes', ','.join([area['area_code'] for area in areas]))
        setattr(obj, 'area_alias', ','.join([area['area_name'] for area in areas]))
        setattr(obj, 'bios', payload)
        return obj
    def get_ordering(self, request):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            return ('emp_code_digit', 'emp_code')
        else:
            return ('emp_code',)
    def get_queryset(self, request):
        qs = self.model.objects.all()
        qs = qs.select_related('department')
        if not request.user.is_superuser:
            if request.user.auth_dept.all():
                qs = qs.filter(department__in=request.user.auth_dept.all())
            if request.user.auth_area.all():
                qs = qs.filter(area__in=request.user.auth_area.all()).distinct()
            if request.user.assign_company:
                qs = qs.filter(company=request.user.assign_company)
        qs = qs.filter(Q(status=STATUS_VALID) | Q(status=None))
        return qs
    @staticmethod
    def initial_data():
        from django.contrib.auth.models import Permission
        from mysite._utils import cprint
        content_type = ContentType.objects.get_for_model(DeviceEmployee, for_concrete_model=False)
        _, model_name = content_type.natural_key()
        for perm in ['change']:
            codename = '%s_%s' % (perm, model_name)
            if not Permission.objects.filter(content_type=content_type, codename=codename).exists():
                p = Permission()
                p.name = 'Can %s model_%s' % (perm, model_name)
                p.content_type = content_type
                p.codename = codename
                p.save()
                cprint('+ Successful to insert permission %s' % codename, 'green')