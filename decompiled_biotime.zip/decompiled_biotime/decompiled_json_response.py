# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\admin\\json_response.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:53 UTC (1750672973)

"""\nDjango\'s JsonResponse and JsonpResponse\nclass JsonResponse(data, encoder=DjangoJSONEncoder, safe=True, **kwargs) is New in Django 1.7\nRef: https://docs.djangoproject.com/en/1.11/ref/request-response/#jsonresponse-objects\n"""
import json
from django.core.serializers.json import DjangoJSONEncoder
from django.http import HttpResponse, JsonResponse
class JsonpResponse(HttpResponse):
    """ Docstring for JsonpHttpResponse """
    def __init__(self, callback, data, encoder=DjangoJSONEncoder, *args, **kwargs):
        try:
            content = '{0}({1});'.format(callback, json.dumps(data, *args, cals=encoder))
        except (ValueError, TypeError) as err:
            content = '{0} can\'t be jsonlized, due to {1}'.format(data, err)
        kwargs.setdefault('content_type', 'application/json')
        super(JsonpResponse, self).__init__(content=content, **kwargs)
def json_response(safe=False):
    def json_wrapper(func):
        """\n        A decorator that takes a view response and turns it into json.\n        """
        def decorator(request, *args, **kwargs):
            objects = func(request, *args, **kwargs)
            if isinstance(objects, (HttpResponse, JsonResponse, JsonpResponse)):
                return objects
            else:
                return JsonResponse(objects, safe=safe)
        return decorator
    return json_wrapper
def jsonp_response(func):
    """\n    A decorator thats takes a view response and turns it into jsonp.\n    """
    def decorator(request, *args, **kwargs):
        objects = func(request, *args, **kwargs)
        if isinstance(objects, (HttpResponse, JsonResponse, JsonpResponse)):
            return objects
        else:
            return JsonpResponse(request.GET.get('callback', ''), objects)
    return decorator
def auto_response(func):
    """\n    A decorator thats takes a view response and turns it into json.\n    If a callback is added through GET or POST the response is JSONP.\n    """
    def decorator(request, *args, **kwargs):
        objects = func(request, *args, **kwargs)
        if isinstance(objects, (HttpResponse, JsonResponse, JsonpResponse)):
            return objects
        else:
            return JsonpResponse(request.GET.get('callback', ''), objects) if 'callback' in request.GET else JsonResponse(objects)
    return decorator
LazableJSONEncoder = DjangoJSONEncoder