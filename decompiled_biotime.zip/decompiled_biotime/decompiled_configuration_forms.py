# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\forms\\configuration_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

from django.utils.text import format_lazy
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.admin.forms import ZKPasswordInput
class PersonnelConfigurationForm(forms.ZKActionForm):
    num_emp_code = forms.BooleanField(label=_('num_emp_code'), initial=False, required=False)
    order_by_num_emp_code = forms.BooleanField(label=_('order_by_num_emp_code'), initial=False, required=False)
    verify_by_fingerprinter = forms.BooleanField(label=_('personnel.config.verifyByFingerPrinter'), initial=True, required=False)
    take_capture = forms.BooleanField(label=_('personnel.config.needTakeCapture'), initial=False, required=False)
    check_ip_address = forms.BooleanField(label=_('personnel.config.checkIPAddress'), initial=False, required=False, disabled=True)
    emp_default_password = forms.CharField(label=_('personnel_config_defaultPassword'), widget=ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    def __init__(self, *args, **kwargs):
        super(PersonnelConfigurationForm, self).__init__(*args, **kwargs)