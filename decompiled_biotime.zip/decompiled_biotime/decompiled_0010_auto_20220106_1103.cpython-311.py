# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0010_auto_20220106_1103.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0009_reporttemplate_employee')]
    operations = [migrations.CreateModel(name='CalculateLastDate', fields=[('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('last_date', fields=[('id', models.DateTimeField(db_index=True)), ('end_date', fields=[('id', models.DateTimeField(db_index=True)), ('event', 'CharField'), ('128', 'max_length'), ('null', 'AlterModelOptions'), ('manuallog', 'delete'), ('change', 'view'), ('att_model_manualLog', 'default_permissions'), ('ordering', 'verbose_name_plural'), ('options', 'training'), ('att_model_training', 'AddField'), ('attemployee', 'enable_compensatory'), ('BooleanField', 'globalRule.fields.enableCompensatory'), ('model_name', 'field'), ('field', '