# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\generate_captcha.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:13 UTC (1750672993)

import os
import random
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
from django.conf import settings
class ValidCodeImg:
    pass
    def __init__(self, token, width=150, height=46, code_count=5, font_size=32, point_count=180, line_count=5, img_format='png', font_path=''):
        """\n        可以生成一个经过降噪后的随机验证码的图片\n        :param width: 图片宽度 单位px\n        :param height: 图片高度 单位px\n        :param code_count: 验证码个数\n        :param font_size: 字体大小\n        :param point_count: 噪点个数\n        :param line_count: 划线个数\n        :param img_format: 图片格式\n        :param font_path: 验证码字体\n        :return 生成的图片的bytes类型的data\n        """
        self.token = token
        self.width = width
        self.height = height
        self.code_count = code_count
        self.font_size = font_size
        self.point_count = point_count
        self.line_count = line_count
        self.img_format = img_format
        self.font_path = font_path
    @staticmethod
    def getRandomColor():
        """获取一个随机颜色(r,g,b)格式的"""
        c1 = random.randint(0, 255)
        c2 = random.randint(0, 255)
        c3 = random.randint(0, 255)
        return (c1, c2, c3)
    @staticmethod
    def getRandomStr():
        """获取一个随机字符串"""
        random_num = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3'
        random_char = random.choice(random_num)
        return random_char
    def getValidCodeImg(self):
        import base64
        from io import BytesIO as StringIO
        image = Image.new('RGB', (self.width, self.height), '#fff')
        out_buffer = StringIO()
        draw = ImageDraw.Draw(image)
        if not self.font_path:
            self.font_path = settings.FILEPATH + '/mysite/static/bootstrap/fonts/arial.ttf'
        font = ImageFont.truetype(self.font_path, size=self.font_size)
        temp = []
        margin = (self.width - 20) / self.code_count
        margin_left = 10
        for i in range(self.code_count):
            random_char = self.getRandomStr()
            draw.text((margin_left + i * margin, 0), random_char, 'Blue', font=font)
            temp.append(random_char)
        valid_str = ''.join(temp)
        for i in range(self.line_count):
            x1 = random.randint(0, self.width)
            x2 = random.randint(0, self.width)
            y1 = random.randint(0, self.height)
            y2 = random.randint(0, self.height)
            draw.line((x1, y1, x2, y2), fill=self.getRandomColor())
        for i in range(self.point_count):
            draw.point([random.randint(0, self.width), random.randint(0, self.height)], fill=self.getRandomColor())
            x = random.randint(0, self.width)
            y = random.randint(0, self.height)
            draw.arc((x, y, x + 4, y + 4), 0, 90, fill=self.getRandomColor())
        image.save(out_buffer, format='JPEG')
        byte_data = out_buffer.getvalue()
        base64_str = base64.b64encode(byte_data)
        return (valid_str, base64_str)
def get_captcha(token):
    from mysite.base.models import SecurityPolicy
    policy = SecurityPolicy.default()
    img = ValidCodeImg(token, code_count=policy.code_length)
    valid_str, base64_str = img.getValidCodeImg()
    cache_security_code(valid_str, token)
    return base64_str
def cache_security_code(code, token):
    from django.core.cache import cache
    from mysite.base.models import SecurityPolicy
    policy = SecurityPolicy.default()
    key = 'security_code_{token}'.format(token=token)
    cache.set(key, code, policy.valid_duration * 60)