# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff_meeting\\admin\\approval_meetingmanuallog_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:34 UTC (1750673074)

from django.forms import ModelForm, ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.admin import forms
from mysite.meeting.widgets import MeetingRadioSelect
from mysite.staff_meeting.models import ApprovalMeetingEntity, ApprovalMeetingManualLog
from mysite.utils import get_staff_workflow_instance
from mysite.workflow.actions import Approve, Reject
class StaffMeetingManualLogChangeForm(ModelForm):
    emp = forms.CharField(label=_('workflowInstance.fields.employee'), disabled=True)
    apply_reason = forms.TextField(label=_('meetingManualLog.fields.applyReason'), max_length=200, required=False)
    punch_state = forms.ChoiceField(label=_('meetingManualLog.fields.punchState'), choices=((0, 'Check In'), (1, 'Check Out')))
    meeting = ModelChoiceField(queryset=ApprovalMeetingEntity.objects.get_queryset(), label=_('meetingManualLog.fields.meeting'), widget=MeetingRadioSelect, required=True)
    def __init__(self, *args, **kwargs):
        super(StaffMeetingManualLogChangeForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['emp'].initial = str(self.instance.employee)
    class Meta:
        model = ApprovalMeetingManualLog
        fields = ('punch_time', 'punch_state', 'apply_reason')
@admin.register(ApprovalMeetingManualLog)
class ApprovalMeetingManualLogAdmin(admin.ZKModelAdmin):
    list_display = ('meeting', 'emp_code', 'emp_photo', 'first_name', 'punch_time', 'punch_state', 'apply_reason', 'apply_time', 'approval_status', 'approver', 'approval_remark', 'approval_time', 'last_approver')
    list_filter = ('employee__emp_code', 'employee__first_name', 'punch_time', 'punch_state', 'approval_status')
    hidden_fields = ('approval_remark', 'approval_time', 'last_approver')
    actions = (Approve, Reject)
    form = StaffMeetingManualLogChangeForm
    non_display_fields = ('color',)
    ordering = ('-id',)
    def get_queryset(self, request):
        queryset = super(ApprovalMeetingManualLogAdmin, self).get_queryset(request)
        queryset = queryset.select_related('employee')
        queryset = get_staff_workflow_instance(request, queryset)
        return queryset
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False