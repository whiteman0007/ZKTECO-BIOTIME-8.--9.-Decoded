# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\db_migrate.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from mysite.base.views.intergration import test_conn
from mysite.tools.encryption_utils import aes_encrypt, aes_decrypt
class DbMigrateSettingUpdateSerializer(serializers.Serializer):
    migrate_software_type = serializers.CharField(required=False, allow_blank=True)
    migrate_database_type = serializers.CharField(required=False, allow_blank=True)
    migrate_database_address = serializers.CharField(required=False, allow_blank=True)
    migrate_database_port = serializers.CharField(required=False, allow_blank=True)
    migrate_database_name = serializers.CharField(required=False, allow_blank=True)
    migrate_database_user = serializers.CharField(required=False, allow_blank=True)
    migrate_database_password = serializers.CharField(required=False, allow_blank=True)
    migrate_database_tables = serializers.ListField(child=serializers.CharField(), required=False)
    migrate_transaction_start = serializers.CharField(required=False, allow_blank=True)
    migrate_transaction_end = serializers.CharField(required=False, allow_blank=True)
    migrate_sqlite_database = serializers.CharField(required=False, allow_blank=True)
    migrate_attendance_data = serializers.DictField(required=False, allow_null=True)
    def validate_migrate_database_password(self, value):
        if value:
            try:
                de_password = aes_decrypt(value)
                if de_password:
                    value = de_password
            except Exception as e:
                print(e)
        return value
    def validate(self, data):
        if data.get('migrate_database_type') == 'sqlite':
            required_field = ['migrate_software_type', 'migrate_database_type', 'migrate_sqlite_database', 'migrate_database_name']
        else:
            required_field = ['migrate_software_type', 'migrate_database_type', 'migrate_database_address', 'migrate_database_port', 'migrate_database_name', 'migrate_database_user', 'migrate_database_password']
        required_errors = []
        for field in required_field:
            if not data.get(field):
                required_errors.append(field)
        if required_errors:
            error_dict = {i: _('This field is required.') for i in required_errors}
            raise ValidationError(error_dict)
        try:
            msg = test_conn(data, test=True)
            if msg:
                raise ValidationError(detail=_('dbMigrate_testConnection_fail'))
        except Exception:
            import traceback
            traceback.print_exc()
            raise ValidationError({'detail': _('dbMigrate_testConnection_exception')})
        else:
            if data['migrate_database_password']:
                data['migrate_database_password'] = aes_encrypt(str(data['migrate_database_password']))
            return data