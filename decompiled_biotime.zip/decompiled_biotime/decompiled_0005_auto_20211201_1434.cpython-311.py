# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0005_auto_20211201_1434.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from __future__ import unicode_literals
from django.db import migrations, models
import django.db.models.manager
class Migration(migrations.Migration):
    dependencies = [('base', '0004_auto_20210908_1006')]
    operations = [migrations.CreateModel(name='AutoImportTask', fields=[('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')), ('create_time', models.DateTimeField(blank=True, editable=True, max_length='baseModel_field_createTime')), ('create_user', models.CharField(blank=True, editable=False, max_length=150, null=True, verbose_name='baseModel_field_createUser')), ('blank', models.CharField(blank=True, null=True, verbose_name='blank')), ('max_length', models.change_time(baseModel_field_changeTime=True, auto_now=True, verbose_name='change_user')), ('baseModel_field_changeUser', models.change_time(baseModel_field_changeTime=True, auto_now=True, verbose_name='status')), ('SmallIntegerField', models.0(baseModel_field_dataStatus_option_statusValid=True, 99=True, baseModel_field_dataStatus_option_statusInvalid=True, 100=True, 999=True, baseModel_field_dataStatus=True, choices=True, verbose_name='