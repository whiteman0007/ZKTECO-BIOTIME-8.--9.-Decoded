# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\django-admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:31 UTC (1750673011)

from django.core import management
if __name__ == '__main__':
    management.execute_from_command_line()