# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\models\\bookmark.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:25 UTC (1750673005)

from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from mysite.base.db_const import APP_LABEL
User = get_user_model()
class Bookmark(models.Model):
    title = models.CharField(_('bookmark_field_title'), max_length=128)
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name=_('bookmark_field_user'), blank=True, null=True)
    content_type = models.ForeignKey(ContentType, verbose_name=_('bookmark_field_contentType'), on_delete=models.CASCADE)
    filters = models.CharField(_('bookmark_field_filtersString'), max_length=1000, blank=True)
    is_share = models.BooleanField(_('bookmark_field_isShared'), default=False)
    time_saved = models.DateTimeField(_('bookmark_field_savedTime'), default=timezone.now)
    def __str__(self):
        return self.title
    def save(self, force_insert=False, force_update=False, using=None, update_fields=None):
        from mysite.admin.exceptions import AdminRuntimeWarning
        if Bookmark.objects.filter(title=self.title, content_type=self.content_type).exclude(id=self.id).exists():
            raise AdminRuntimeWarning(_('bookmark_saveError_duplicateTitle'))
        else:
            super(Bookmark, self).save(force_insert, force_update, using, update_fields)
    class Meta:
        ordering = ['time_saved', '-pk']
        default_permissions = ('delete', 'change')
        app_label = APP_LABEL
        verbose_name = _('base_model_bookmark')
        verbose_name_plural = verbose_name