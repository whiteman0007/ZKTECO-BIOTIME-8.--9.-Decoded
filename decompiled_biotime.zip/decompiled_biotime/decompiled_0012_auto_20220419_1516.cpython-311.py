# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0012_auto_20220419_1516.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0011_auto_20220118_1536')]
    operations = [migrations.AddField(model_name='attreportsetting', name='auto_calculate', field=models.BooleanField(default=False)), migrations.AddField(model_name='payloadtimecard', name='payload', field=models.TextField(blank=True, null=True))]