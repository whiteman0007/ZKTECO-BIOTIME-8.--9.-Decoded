# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\admin\\forms\\auth_group_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from django import forms
from django.conf import settings
from django.contrib.auth.models import Group
class GroupChangeForm(forms.ModelForm):
    class Meta:
        model = Group
        fields = '__all__'
    def __init__(self, *args, **kwargs):
        super(GroupChangeForm, self).__init__(*args, **kwargs)