# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\filters.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import django_filters
from django.db.models import Q
from django_filters.rest_framework import FilterSet
from mysite.admin.models import STATUS_VALID, STATUS_RESIGN_PENDING
from mysite.att import models
from mysite.att.models import PayloadPayCode
from mysite.personnel.models import Employee
from mysite.base.threadlocals import get_current_user
class AttRuleListFilter(django_filters.rest_framework.FilterSet):
    """\n    AttRule Filter Class\n    """
    class Meta:
        model = models.AttRule
        fields = ['param_name']
class AttScheduleListFilter(django_filters.rest_framework.FilterSet):
    """\n    AttSchedule Filter Class\n    """
    class Meta:
        model = models.AttSchedule
        fields = ['employee']
class AttShiftListFilter(django_filters.rest_framework.FilterSet):
    """\n    AttShift Filter Class\n    """
    alias__icontains = django_filters.CharFilter(field_name='alias', lookup_expr='icontains')
    class Meta:
        model = models.AttShift
        fields = ['alias', 'alias__icontains', 'company']
class BreakTimeListFilter(django_filters.rest_framework.FilterSet):
    """\n    BreakTime Filter Class\n    """
    class Meta:
        model = models.BreakTime
        fields = ['alias', 'company']
class DeptAttRuleListFilter(django_filters.rest_framework.FilterSet):
    """\n    DeptAttRule Filter Class\n    """
    class Meta:
        model = models.DeptAttRule
        fields = ['alias', 'department']
class HolidayListFilter(django_filters.rest_framework.FilterSet):
    """\n    Holiday Filter Class\n    """
    class Meta:
        model = models.Holiday
        fields = ['alias', 'department']
class LeaveListFilter(django_filters.rest_framework.FilterSet):
    """\n    Leave Filter Class\n    """
    class Meta:
        model = models.Leave
        fields = ['employee']
class ManualLogListFilter(django_filters.rest_framework.FilterSet):
    """\n    ManualLog Filter Class\n    """
    class Meta:
        model = models.ManualLog
        fields = ['employee']
class OvertimeListFilter(django_filters.rest_framework.FilterSet):
    """\n    Overtime Filter Class\n    """
    class Meta:
        model = models.Overtime
        fields = ['employee']
class ReportParamListFilter(django_filters.rest_framework.FilterSet):
    """\n    ReportParam Filter Class\n    """
    class Meta:
        model = models.ReportParam
        fields = ['param_name']
class ShiftDetailListFilter(django_filters.rest_framework.FilterSet):
    """\n    ShiftDetail Filter Class\n    """
    class Meta:
        model = models.ShiftDetail
        fields = ['shift']
class TempScheduleListFilter(django_filters.rest_framework.FilterSet):
    """\n    TempSchedule Filter Class\n    """
    class Meta:
        model = models.TempSchedule
        fields = ['employee']
class TimeIntervalListFilter(django_filters.rest_framework.FilterSet):
    """\n    TimeInterval Filter Class\n    """
    alias__icontains = django_filters.CharFilter(field_name='alias', lookup_expr='icontains')
    class Meta:
        model = models.TimeInterval
        fields = ['alias', 'alias__icontains', 'company']
class TrainingListFilter(django_filters.rest_framework.FilterSet):
    """\n    Training Filter Class\n    """
    class Meta:
        model = models.Training
        fields = ['employee']
class LeaveGroupListFilter(django_filters.rest_framework.FilterSet):
    """\n    Training Filter Class\n    """
    class Meta:
        model = models.LeaveGroup
        fields = ['code', 'name']
class LeaveGroupDetailListFilter(django_filters.rest_framework.FilterSet):
    """\n    Training Filter Class\n    """
    class Meta:
        model = models.LeaveGroupDetail
        fields = ['leave_type', 'pay_code', 'leave_group']
class LeaveYearBalanceListFilter(django_filters.rest_framework.FilterSet):
    """\n    Training Filter Class\n    """
    class Meta:
        model = models.LeaveYearBalance
        fields = ['pay_code', 'employee']
class StaffReportListFilter(FilterSet):
    """\n    Staff Report Filter Class\n    """
    start_date = django_filters.DateFilter(field_name='att_date', lookup_expr='gte')
    end_date = django_filters.DateFilter(field_name='att_date', lookup_expr='lte')
    @property
    def qs(self):
        queryset = super(StaffReportListFilter, self).qs
        queryset = queryset.filter(emp=self.request.user)
        return queryset
class ReportGenericFilter(FilterSet):
    employees = django_filters.CharFilter(method='employee_filter')
    departments = django_filters.CharFilter(method='department_filter')
    areas = django_filters.CharFilter(method='area_filter')
    groups = django_filters.CharFilter(method='group_filter')
    start_date = django_filters.DateFilter(field_name='att_date', lookup_expr='gte')
    end_date = django_filters.DateFilter(field_name='att_date', lookup_expr='lte')
    def employee_filter(self, queryset, name, value):
        if not value or str(value) == '-1':
            return queryset
        else:
            objs = value.split(',')
            try:
                objs = [int(i) for i in objs if i]
            except ValueError:
                objs = []
            queryset = queryset.filter(emp_id__in=objs)
            return queryset
    def department_filter(self, queryset, name, value):
        if not value or str(value) == '-1':
            return queryset
        else:
            objs = value.split(',')
            try:
                objs = [int(i) for i in objs if i]
            except ValueError:
                objs = []
            queryset = queryset.filter(emp__department_id__in=objs)
            from mysite.att.global_cache import C_ATT_RULE
            C_ATT_RULE.action_init()
            resign_emp = str(C_ATT_RULE.value.get('resign_emp'))
            if resign_emp == '0':
                queryset = queryset.filter(Q(emp__status=STATUS_VALID) | Q(emp__status=None) | Q(emp__status=STATUS_RESIGN_PENDING))
            try:
                if not self.request.user.is_superuser and self.request.user.auth_area.all():
                        employees = Employee.objects.filter(area__in=self.request.user.auth_area.all())
                        queryset = queryset.filter(emp__in=employees)
            except:
                pass
            return queryset
    def area_filter(self, queryset, name, value):
        if not value or str(value) == '-1':
            return queryset
        else:
            objs = value.split(',')
            try:
                objs = [int(i) for i in objs if i]
            except ValueError:
                objs = []
            employees = Employee.objects.filter(area__in=objs)
            queryset = queryset.filter(emp__in=employees)
            from mysite.att.global_cache import C_ATT_RULE
            C_ATT_RULE.action_init()
            resign_emp = str(C_ATT_RULE.value.get('resign_emp'))
            if resign_emp == '0':
                queryset = queryset.filter(Q(emp__status=STATUS_VALID) | Q(emp__status=None) | Q(emp__status=STATUS_RESIGN_PENDING))
            if not self.request.user.is_superuser and self.request.user.auth_dept.all():
                    employees = Employee.objects.filter(department__in=self.request.user.auth_dept.all())
                    queryset = queryset.filter(emp__in=employees)
            return queryset
    def group_filter(self, queryset, name, value):
        if not value or str(value) == '-1':
            return queryset
        else:
            objs = value.split(',')
            try:
                objs = [i for i in objs if i]
            except ValueError:
                objs = []
            queryset = queryset.filter(emp__attemployee__group_id__in=objs)
            from mysite.att.global_cache import C_ATT_RULE
            C_ATT_RULE.action_init()
            resign_emp = str(C_ATT_RULE.value.get('resign_emp'))
            if resign_emp == '0':
                queryset = queryset.filter(Q(emp__status=STATUS_VALID) | Q(emp__status=None) | Q(emp__status=STATUS_RESIGN_PENDING))
            if not self.request.user.is_superuser:
                if self.request.user.auth_dept.all():
                    employees = Employee.objects.filter(department__in=self.request.user.auth_dept.all())
                    queryset = queryset.filter(emp__in=employees)
                if self.request.user.auth_area.all():
                    employees = Employee.objects.filter(area__in=self.request.user.auth_area.all())
                    queryset = queryset.filter(emp__in=employees)
            return queryset
    @property
    def qs(self):
        queryset = super(ReportGenericFilter, self).qs
        employees = self.data.get('employees') or '-1'
        departments = self.data.get('departments') or '-1'
        areas = self.data.get('areas') or '-1'
        groups = self.data.get('groups') or '-1'
        if employees == '-1' and departments == '-1' and (areas == '-1') and (groups == '-1'):
            return queryset.none()
        else:
            return queryset
    class Meta:
        model = PayloadPayCode
        fields = ['employees', 'departments', 'areas', 'groups', 'start_date', 'end_date']