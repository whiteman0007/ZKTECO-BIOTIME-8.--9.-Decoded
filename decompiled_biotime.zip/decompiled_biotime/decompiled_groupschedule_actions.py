# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\groupschedule_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.utils.translation import gettext_lazy as _
from django.forms import ModelForm, ValidationError, ModelMultipleChoiceField
from mysite.admin import forms, ZKModelAction
from mysite.att.models import AttGroup, GroupSchedule, AttShift
from mysite.att.company_form import CompanyField4ActionForm
class AddGroupScheduleForm(CompanyField4ActionForm):
    schd_group = ModelMultipleChoiceField(queryset=AttGroup.objects.get_queryset(), required=False)
    start_date = forms.DateField(label=_('groupSchedule.fields.startDate'))
    end_date = forms.DateField(label=_('groupSchedule.fields.endDate'))
    shift = forms.ModelChoiceField(queryset=AttShift.objects.get_queryset(), required=False)
    class Meta:
        model = GroupSchedule
        fields = '__all__'
        exclude = ('group',)
    def clean(self):
        cleaned_data = super(AddGroupScheduleForm, self).clean()
        group = cleaned_data.get('schd_group', None)
        shift = cleaned_data.get('shift', None)
        start_date = cleaned_data.get('start_date', None)
        end_date = cleaned_data.get('end_date', None)
        if not group:
            raise ValidationError(_('scheduledAssign_error_groupNotFound'), code='-1')
        else:
            if not shift:
                raise ValidationError(_('scheduledAssign_error_shiftNotFound'), code='-1')
            else:
                if not start_date or not end_date:
                    raise ValidationError(_('scheduledAssign_error_datePeriodError'), code='-1')
                else:
                    if start_date >= end_date:
                        raise ValidationError(_('scheduledAssign_error_datePeriodError'), code='-1')
                    else:
                        overlaps = GroupSchedule.objects.filter(group__in=group, start_date__lte=end_date, end_date__gte=start_date)
                        if overlaps.exists():
                            overlap = overlaps.first()
                            raise ValidationError(_('scheduledAssign_error_schdOverlap_%(obj)s_%(start_date)s_%(end_date)s'), code='-1', params={'obj': overlap.group.name, 'start_date': overlap.start_date.strftime('%Y-%m-%d'), 'end_date': overlap.end_date.strftime('%Y-%m-%d')})
                        else:
                            return cleaned_data
    def save(self, commit=True):
        start_date = self.cleaned_data['start_date']
        end_date = self.cleaned_data['end_date']
        shift = self.cleaned_data['shift']
        schd_groups = self.cleaned_data['schd_group']
        for schd_group in schd_groups:
            GroupSchedule(group=schd_group, start_date=start_date, end_date=end_date, shift=shift).save(force_insert=True)
class AddGroupSchedule(ZKModelAction):
    verbose_name = _('groupSchedule.actions.add')
    short_description = _('groupSchedule.actions.add')
    help_txt = _('groupSchedule.actions.add')
    action_form = AddGroupScheduleForm
    def action(self, *args, **kwargs):
        form = AddGroupScheduleForm(self.request.POST)
        if form.is_valid():
            form.save()