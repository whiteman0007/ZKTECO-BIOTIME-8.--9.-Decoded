# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\forms\\configration_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:36 UTC (1750673016)

from django.utils.translation import gettext_lazy as _
from django.conf import settings
from mysite.admin import forms
from mysite.iclock import const, choices
from mysite.authorized import auth_settings
from django.forms.widgets import HiddenInput
APPROVAL_CHOICE = ((const.APPROVAL_PENDING, _('approve_pending')), (const.APPROVAL_AUTO_APPROVED, _('approve_auto_approved')))
class DeviceConfigurationForm(forms.ZKActionForm):
    enable_registration = forms.BooleanField(label=_('deviceConfig_field_enableRegistration'), initial=False, required=False, help_text=_('deviceConfig_field_enableRegistration'))
    enable_resigned_filter = forms.BooleanField(label=_('deviceConfig_field_enableResignedFilter'), initial=False, required=False, help_text=_('deviceConfig_field_enableResignedFilterHelpText'))
    enable_auto_add = forms.BooleanField(label=_('deviceConfig_field_autoAdd'), initial=True, required=False, help_text=_('deviceConfig_field_autoAdd'))
    enable_name_upload = forms.BooleanField(label=_('deviceConfig_field_enableNameUpload'), initial=True, required=False, help_text=_('deviceConfig_field_enableNameUploadHelpTxt'))
    enable_name_download = forms.BooleanField(label=_('deviceConfig.fields.enableNameDownload'), initial=True, required=False)
    enable_card_upload = forms.BooleanField(label=_('deviceConfig_field_enableCardUpload'), initial=False, required=False, help_text=_('deviceConfig_field_enableCardUploadHelpTxt'))
    encryption = forms.BooleanField(label=_('deviceConfig.fields.transmissionEncryption'), initial=False, required=False)
    timezone = forms.ChoiceField(label=_('deviceConfig.fields.timezone'), choices=choices.TIMEZONE_CHOICES, initial=settings.DEVICE_TIME_ZONE)
    global_setup = forms.BooleanField(label=_('deviceConfig.fields.globalSetup'), initial=False, required=False)
    heartbeat = forms.IntegerField(label=_('deviceConfig.fields.heartBeat'), initial=10, unit=_('time.units.second'))
    transfer_mode = forms.ChoiceField(label=_('deviceConfig.fields.transferMode'), choices=choices.TRANSFER_MODE, initial=choices.REAL_TIME)
    transfer_interval = forms.IntegerField(label=_('deviceConfig.fields.transferInterval'), initial=1, unit=_('time.units.minute'))
    transfer_time = forms.CharField(label=_('deviceConfig.fields.transferTime'), initial='00:00;14:05')
    sync_mode = forms.ChoiceField(label=_('deviceConfig.fields.syncMode'), choices=choices.SYNC_MODE, initial=choices.REAL_TIME)
    sync_time = forms.CharField(label=_('deviceConfig.fields.syncTime'), initial='00:00;12:00')
    transaction_retention = forms.IntegerField(label=_('deviceConfig_field_transactionRetention'), initial=9999, min_value=90, max_value=9999, unit=_('time.units.day'), help_text=_('deviceConfig_field_transactionRetentionHelpTxt'))
    command_retention = forms.IntegerField(label=_('deviceConfig_field_commandRetention'), initial=90, min_value=15, max_value=9999, unit=_('time.units.day'), help_text=_('deviceConfig_field_commandRetentionHelpTxt'))
    dev_log_retention = forms.IntegerField(label=_('deviceConfig_field_devLogRetention'), initial=90, min_value=15, max_value=9999, unit=_('time.units.day'), help_text=_('deviceConfig_field_devLogRetentionHelpTxt'))
    upload_log_retention = forms.IntegerField(label=_('deviceConfig_field_uploadLogRetention'), initial=90, min_value=15, max_value=9999, unit=_('time.units.day'), help_text=_('deviceConfig_field_devLogRetentionHelpTxt'))
    edit_policy = forms.ChoiceField(label=_('deviceConfig_field_editBioPhotoPolicy'), initial=const.APPROVAL_AUTO_APPROVED, choices=APPROVAL_CHOICE)
    import_policy = forms.ChoiceField(label=_('deviceConfig_field_importBioPhotoPolicy'), initial=const.APPROVAL_AUTO_APPROVED, choices=APPROVAL_CHOICE)
    mobile_policy = forms.ChoiceField(label=_('deviceConfig_field_mobileBioPhotoPolicy'), initial=const.APPROVAL_PENDING, choices=APPROVAL_CHOICE)
    device_policy = forms.ChoiceField(label=_('deviceConfig_field_deviceBioPhotoPolicy'), initial=const.APPROVAL_AUTO_APPROVED, choices=APPROVAL_CHOICE)
    api_policy = forms.ChoiceField(label=_('deviceConfig_field_apiBioPhotoPolicy'), initial=const.APPROVAL_AUTO_APPROVED, choices=APPROVAL_CHOICE)
    visitor_policy = forms.ChoiceField(label=_('deviceConfig.field.visitorBioPhotoPolicy'), initial=const.APPROVAL_PENDING, choices=APPROVAL_CHOICE)
    def __init__(self, *args, **kwargs):
        super(DeviceConfigurationForm, self).__init__(*args, **kwargs)
        if not auth_settings.ENABLE_VISITOR:
            self.fields['visitor_policy'].widget = HiddenInput()
        if settings.ENABLE_WDMS:
            self.fields['mobile_policy'].widget = HiddenInput()