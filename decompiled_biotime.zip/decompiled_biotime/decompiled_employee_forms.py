# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\forms\\employee_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

import datetime
import json
from django.apps import apps
from django.conf import settings
from django.contrib.auth import password_validation
from django.core.cache import cache
from django.forms import ModelForm, Form
from django.utils.translation import gettext_lazy as _
from django.utils.text import format_lazy
from mysite._utils import getattr_ex
from mysite.admin import forms
from mysite.att.widgets import LeaveGroupRadioSelect
from mysite.admin.forms import widgets as admin_widgets, ZKPasswordInput
from mysite.payroll import db_const as payroll_db_const
from mysite.personnel import db_const
from mysite.personnel.models.model_employee import Employee, flush_cache_data
from mysite.personnel.forms.fields import EmployeeSearchChoiceField
from mysite.personnel.models import Department, Area, Position, Company
from mysite.personnel.admin.company_admin import CompanyField4ModelForm
from mysite.personnel.utils import get_default_company, get_default_company_id, get_current_user_company
from mysite.personnel import widgets
from mysite.tools.access_utils import get_access_token, decode_access_token
custom_attr_field_type = [forms.CharField]
class EmployeeAttendanceForm(Form):
    group = forms.ModelChoiceField(label=_('employee.fields.attGroup'), queryset=apps.get_model('att', 'AttGroup').objects.all(), required=False, widget=widgets.AttGroupRadioSelect)
    enable_attendance = forms.BooleanField(label=_('attEmployee.fields.enableAttendance'), initial=True, required=False)
    enable_schedule = forms.BooleanField(label=_('attEmployee.fields.enableSchedule'), initial=True, required=False)
    enable_holiday = forms.BooleanField(label=_('attEmployee.fields.enableHoliday'), initial=True, required=False)
    enable_overtime = forms.BooleanField(label=_('attEmployee.fields.enableOvertime'), initial=True, required=False)
    enable_compensatory = forms.BooleanField(label=_('globalRule.fields.enableCompensatory'), initial=False, required=False)
    ip_address = forms.GenericIPAddressField(label=_('employee.fields.ipAddress'), required=False)
    def clean(self):
        cleaned_data = super(EmployeeAttendanceForm, self).clean()
        cleaned_data['group'] = self.data['group']
        return cleaned_data
class EmployeePayrollForm(Form):
    payment_mode = forms.ChoiceField(choices=payroll_db_const.PAYROLL_MODE, label=_('empPayrollProfile_field_payment_mode'), initial=1)
    payment_type = forms.ChoiceField(choices=payroll_db_const.PAYROLL_TYPE, label=_('empPayrollProfile_field_payment_type'), initial=1)
    bank_name = forms.CharField(required=False, max_length=30, label=_('empPayrollProfile_field_bank_name'))
    bank_account = forms.CharField(required=False, max_length=30, label=_('empPayrollProfile_field_bank_account'))
    agent_id = forms.CharField(required=False, max_length=30, label=_('empPayrollProfile_field_agent_id'))
    agent_account = forms.CharField(required=False, max_length=30, label=_('empPayrollProfile_field_agent_account'))
    national_num = forms.CharField(required=False, max_length=50, label=_('emp_field_nationalNumber'))
    payroll_num = forms.CharField(required=False, max_length=50, label=_('emp_field_payrollNumber'))
    internal_emp_num = forms.CharField(required=False, max_length=50, label=_('emp_field_InternalNum'))
class EmployeeForm(CompanyField4ModelForm):
    enroll_sn = forms.CharField(label=_('emp_field_enrollSN'), required=False, disabled=True)
    superior = EmployeeSearchChoiceField(label=_('employee.field.superior'), tips=_('department.field.deptManager'), required=False)
    bio_photo = forms.FileField(required=False, initial='')
    fpCount = forms.IntegerField(label=_('employee.fields.registeredFPQuantity'), required=False, initial=0, disabled=True, prefix='', suffix=format_lazy('<a id=\"fpRegister\" href=\"javascript:void(0);\" onclick=\"submitRegister()\">{btn}</a>', btn=_('employee.fieldBtn.enroll')))
    fp_type = forms.CharField(required=False, initial='')
    fps = forms.CharField(required=False, initial='')
    templates = forms.CharField(required=False, initial='')
    dur_fps = forms.CharField(required=False, initial='')
    del_fps = forms.CharField(required=False, initial='')
    effective_start = forms.DateField(label=_('employee.fields.effectiveStart'), initial=datetime.datetime.now)
    effective_end = forms.DateField(label=_('employee.fields.effectiveEnd'), initial=datetime.datetime.now)
    enable_att_related = False
    enable_payroll_related = False
    user_defined_fields = None
    day_leave = forms.CharField(required=False)
    is_probation = False
    is_admin = forms.BooleanField(required=False)
    palmCount = forms.IntegerField(label=_('employee.fields.registeredPalmQuantity'), required=False, initial=0, disabled=True, suffix=format_lazy('<a id=\"palmRegister\" href=\"javascript:void(0);\" onclick=\"submitPalmRegister()\">{btn}</a>', btn=_('employee.fieldBtn.enroll')))
    palms = forms.CharField(required=False, initial='')
    palm_template = forms.CharField(required=False, initial='')
    del_palm = forms.CharField(required=False, initial='')
    faceCount = forms.IntegerField(label=_('emp.fields.vlFace'), required=False, initial=0, disabled=True, suffix=format_lazy('<a id=\"faceRegister\" href=\"javascript:void(0);\" onclick=\"submitFaceRegister()\">{btn}</a>', btn=_('employee.fieldBtn.enroll')))
    face = forms.CharField(required=False, initial='')
    leave_group = forms.IntegerField(label=_('employee.fields.leaveGroup'), widget=LeaveGroupRadioSelect(), required=False)
    nickname = forms.CharField(label=_('emp_field_localizedName'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    contact_tel = forms.CharField(label=_('emp_field_contactTel'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    mobile = forms.CharField(label=_('emp_field_mobile'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    national = forms.CharField(label=_('emp_field_national'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    religion = forms.CharField(label=_('emp_field_religion'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    city = forms.CharField(label=_('emp_field_city'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    address = forms.CharField(label=_('emp_field_address'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    postcode = forms.CharField(label=_('emp_field_postcode'), widget=admin_widgets.ZKPasswordInput(), required=False, suffix=format_lazy('<a href=\"javascript:void(0);\" onclick=\"showText(this)\">{btn}</a>', btn=_('Show')))
    email = forms.EmailField(label=_('emp_field_email'), max_length=db_const.MAX_EMP_EMAIL, required=False)
    photo_url = forms.CharField(label='Photo url', required=False)
    biophoto_url = forms.CharField(label='BioPhoto url', required=False)
    self_password = forms.CharField(label=_('emp_field_selfPassword'), strip=False, widget=ZKPasswordInput, help_text=password_validation.password_validators_help_text_html(), required=False)
    def __init__(self, *args, **kwargs):
        import os
        from rest_framework import serializers
        from mysite.authorized import auth_settings
        from mysite.personnel.api.serializers import EmployeeExtraInfoSerializer
        self.enable_att_related = auth_settings.enable_att
        self.enable_payroll_related = auth_settings.enable_payroll
        super(EmployeeForm, self).__init__(*args, **kwargs)
        extra_info = EmployeeExtraInfoSerializer(employee=self.instance)
        self.user_defined_fields = []
        if extra_info.fields:
            for field_name, field in extra_info.fields.items():
                if type(field) is serializers.ChoiceField:
                    choices = ((key, value) for key, value in field.choices.items())
                    self.fields[field_name] = forms.ChoiceField(label=field.label, choices=choices, required=False)
                else:
                    self.fields[field_name] = forms.CharField(label=field.label, required=False)
                self.user_defined_fields.append(field_name)
            if extra_info.data:
                self.initial.update(extra_info.data)
        if settings.EMPLOYEE_AUTO_NUMBER:
            objs = Employee.all_objects.values('emp_code')
            codes = [int(i['emp_code']) for i in objs if i['emp_code'].isdigit()]
            self.fields['emp_code'].initial = str(max(codes) + 1 if codes else 1)
        if self.enable_att_related:
            self.fields.update(EmployeeAttendanceForm().fields)
        if self.enable_payroll_related:
            self.fields.update(EmployeePayrollForm().fields)
        self.fields['effective_start'].initial = datetime.datetime.now().date()
        self.fields['effective_end'].initial = datetime.datetime.now().date()
        if getattr_ex(settings, 'MULTI_COMPANY_EXT', False) and auth_settings.AUTHORIZED_FIRM > 1:
                self.fields['email'].required = True
        if self.instance:
            self.fields['photo_url'].initial = self.instance.photo_url
            self.fields['biophoto_url'].initial = self.instance.biophoto_url
        else:
            default_photo = '/files/nophoto.gif'
            self.fields['photo_url'].initial = default_photo
            self.fields['biophoto_url'].initial = default_photo
        if getattr_ex(settings, 'MULTI_COMPANY', False) and self.user and (not self.user.is_superuser) and self.user.assign_company:
                        if settings.ENABLE_WDMS:
                            for model_name in ['department', 'area', 'position']:
                                self.fields[model_name].company_belong = self.user.assign_company
                        else:
                            if getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
                                for model_name in ['department', 'area', 'position', 'group', 'flow_role']:
                                    self.fields[model_name].company_belong = self.user.assign_company
        if settings.ENABLE_WDMS:
            self.fields['superior'].widget = forms.ZKHiddenInput()
    def save_newinfo(self, emp):
        # irreducible cflow, using cdg fallback
        from rest_framework.exceptions import ValidationError
        from mysite.personnel.api.serializers import EmployeeExtraInfoSerializer
        change_field = set(self.changed_data) & set(self.user_defined_fields)
        if not change_field:
            return
        else:
            serializer = EmployeeExtraInfoSerializer(data=self.cleaned_data, employee=emp)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
                except ValidationError as e:
                        from mysite.admin.exceptions import AdminRuntimeWarning
                        field = list(e.detail.keys())[0]
                        message = e.detail[field][field]
                        raise AdminRuntimeWarning(message)
    def save_bio_photo(self):
        from mysite.utils import save_bio_photo
        if 'bio_photo' in self.changed_data:
            from mysite.iclock.comm.utils import get_comm_setting
            photo = self.files.get('bio_photo', None)
            if not photo:
                return
            else:
                approval_state = get_comm_setting('edit_policy')
                save_bio_photo(self.instance, photo, approval_state)
    def save_fingerprint(self):
        # irreducible cflow, using cdg fallback
        import re
        if 'templates' in self.changed_data:
            templates = self.data.get('templates', None)
            templates = json.loads(templates)
            if templates:
                cls = self.instance.biodata_set.model
                for tem in templates:
                    pass
            if not tem or not tem['template']:
                continue
            fid = tem['no']
            ftmp = tem['template']
            version = tem['version']
            rex = re.search('(?P<major_ver>\\d+).?(?P<minor_ver>\\d*)', version)
            if rex and int(rex.group('major_ver')) > 0:
                major_ver, minor_ver = (rex.group('major_ver'), rex.group('minor_ver') or '0')
                fp = self.instance.biodata_set.filter(bio_no__exact=fid, major_ver=major_ver, minor_ver=minor_ver, bio_type=1).first()
                if not fp:
                    fp = cls(employee=self.instance, bio_no=fid, major_ver=major_ver, minor_ver=minor_ver, bio_type=1, bio_tmp=ftmp, update_time=datetime.datetime.now()).save()
                    fp.bio_tmp = ftmp
                    fp.upload_time = datetime.datetime.now()
                    fp.save()
    def remove_from_device(self, fps):
        from mysite.utils import saveCmd, DevIdentity_ex
        from mysite.iclock.models import Terminal
        devs = Terminal.objects.filter(area__in=self.instance.area.filter(is_default=False))
        pin = self.instance.pin()
        for dev in devs:
            if DevIdentity_ex(dev.push_protocol, '2.2.14'):
                _cmd = 'DATA DELETE FINGERTMP PIN={pin}\tFID={fid}'
            else:
                _cmd = 'DATA DEL_FP PIN={pin}\tFID={fid}'
            for fp in fps:
                cmd = _cmd.format(pin=pin, fid=fp)
                saveCmd(dev.id, cmd)
    def remove_fingerprint(self):
        if 'del_fps' in self.changed_data:
            fps = self.data.get('del_fps', '')
            fps = fps.split(',')
            if fps:
                _fps = self.instance.biodata_set.filter(bio_type=1, bio_no__in=fps)
                _fps.delete()
                self.remove_from_device(fps)
    def clean_self_password(self):
        from mysite.base.models import SecurityPolicy
        from mysite.base.db_const import PASSWORD_EXPS, PASSWORD_EXPS_HIGH, PASSWORD_EXPS_LOWER
        from mysite.base.const import PASSWORD_LEVEL_HIGHER, PASSWORD_LEVEL_LOWER, PASSWORD_LEVEL_MEDIUM
        import re
        password = self.cleaned_data.get('self_password')
        if 'self_password' not in self.changed_data:
            return password
        else:
            policy = SecurityPolicy.default()
            if policy.password_level:
                re_exp = PASSWORD_EXPS
                if policy.password_level == PASSWORD_LEVEL_HIGHER:
                    re_exp = PASSWORD_EXPS_HIGH
                else:
                    if policy.password_level == PASSWORD_LEVEL_LOWER:
                        re_exp = PASSWORD_EXPS_LOWER
                if not re.match(re_exp, password):
                    if policy.password_level == PASSWORD_LEVEL_HIGHER:
                        raise forms.ValidationError(_('password.strength.higher.requirements'), code='password_not_safe_higher')
                    else:
                        if policy.password_level == PASSWORD_LEVEL_MEDIUM:
                            raise forms.ValidationError(_('password_need_meet_strength_requirements'), code='password_not_safe')
                        else:
                            raise forms.ValidationError(_('password.strength.lower.requirements'), code='password_not_safe_lower')
            password_validation.validate_password(password, self.instance)
            return password
    def set_self_password(self):
        if 'self_password' in self.changed_data:
            self.instance.set_password(self.cleaned_data['self_password'])
        else:
            self.cleaned_data.pop('self_password')
    def set_device_password(self):
        if 'device_password' in self.changed_data:
            self.instance.set_devicepassword(self.cleaned_data['device_password'])
    def save_m2m(self):
        self._save_m2m()
    def clean(self):
        import os
        import base64
        from PIL import Image
        from mysite.utils import get_or_create_photo_folder, get_or_create_folder
        from mysite.tools.image_utils import encrypt_image
        if 'camera_photo' in self.data and self.data['camera_photo']:
                photo = self.data['camera_photo']
                tmp_file_path = get_or_create_folder('photo/{company}'.format(company=str(self.instance.company.id)))
                tmp_file_name = os.path.join(tmp_file_path, '{code}.jpg'.format(code=self.data['emp_code']))
                with open(tmp_file_name, 'wb') as orf:
                    orf.write(base64.b64decode(photo.replace('data:image/png;base64,', '')))
                im = Image.open(tmp_file_name)
                if im.mode!= 'RGB':
                    im = im.convert('RGB')
                im.save(tmp_file_name)
                if settings.ENABLE_ENCRYPT_PHOTO:
                    file_path = get_or_create_photo_folder('photo', str(self.instance.company.id))
                    file_name = os.path.join(file_path, '{code}.jpg'.format(code=self.data['emp_code']))
                    with open(file_name, 'wb') as f:
                        f.write(encrypt_image(tmp_file_name, is_path=True))
                    os.remove(tmp_file_name)
        clean_data = super(EmployeeForm, self).clean()
        if 'self_password' in clean_data:
            if 'self_password' in self.changed_data:
                self.instance.set_password(clean_data['self_password'])
                clean_data['self_password'] = self.instance.self_password
            else:
                clean_data.pop('self_password')
        return clean_data
    def clean_biophoto_url(self):
        """"""
        url = self.cleaned_data.get('biophoto_url', '')
        if settings.ACCESS_AES_PREFIX and '/{0}'.format(settings.ACCESS_AES_PREFIX) in url:
            parts = url.split(settings.ACCESS_AES_PREFIX, 2)
            valid, res = decode_access_token(settings.ACCESS_AES_PREFIX + parts[1])
            file_path = res.get('p', '')
            return '{0}{1}'.format(parts[0], file_path)
        else:
            return url
    def clean_photo_url(self):
        """"""
        url = self.cleaned_data.get('photo_url', '')
        if settings.ACCESS_AES_PREFIX and '/{0}'.format(settings.ACCESS_AES_PREFIX) in url:
            parts = url.split(settings.ACCESS_AES_PREFIX, 2)
            valid, res = decode_access_token(settings.ACCESS_AES_PREFIX + parts[1])
            file_path = res.get('p', '')
            return '{0}{1}'.format(parts[0], file_path)
        else:
            return url
    def clean_email(self):
        email = self.cleaned_data.get('email')
        return email
    def clean_effective_start(self):
        effective_start = self.cleaned_data.get('effective_start')
        hire_date = self.cleaned_data.get('hire_date')
        employment_type = self.cleaned_data.get('emp_type')
        if employment_type in (db_const.TEMPORARY, db_const.PROBATION) and effective_start < hire_date:
            raise forms.ValidationError(_('employeeForm.error.effectiveStartTimeLessHireDate'))
        else:
            return effective_start
    def save_employment_period(self, emp):
        from mysite.personnel.models import Employment
        employment = Employment.objects.filter(employee=emp).first()
        employment_type = self.cleaned_data['emp_type']
        now = datetime.datetime.now()
        active = True
        active_time = None
        inactive_time = None
        if employment_type in (db_const.TEMPORARY, db_const.PROBATION):
            start_date = self.cleaned_data['effective_start']
            end_date = self.cleaned_data['effective_end']
            if not employment:
                employment = Employment(employee=emp, employment_type=employment_type, start_date=start_date, end_date=end_date)
                employment.save(force_insert=True)
            if start_date > now.date() or end_date < now.date():
                emp.delete_emp_dev('user')
                active = False
                if end_date < now.date() and (not employment.inactive_time):
                        active_time = None
                        inactive_time = now
            else:
                if not employment.active_time:
                    active_time = now
                    inactive_time = None
            employment.employment_type = employment_type
            employment.active_time = active_time
            employment.inactive_time = inactive_time
            employment.start_date = start_date
            employment.end_date = end_date
            employment.save(force_update=True)
        else:
            if employment:
                employment.inactive_time = None
                employment.active_time = None
                employment.save(force_update=True)
        return active
    def save_att_profile(self, emp):
        from mysite.att.models import AttEmployee
        form = EmployeeAttendanceForm(data=self.cleaned_data)
        form.is_valid()
        obj, created = AttEmployee.objects.update_or_create(emp=emp, defaults=form.cleaned_data)
        emp.attemployee = obj
        return emp
    def save_payroll_profile(self, emp):
        from mysite.payroll.models import EmpPayrollProfile
        form = EmployeePayrollForm(data=self.cleaned_data)
        form.is_valid()
        obj, created = EmpPayrollProfile.objects.update_or_create(employee=emp, defaults=form.cleaned_data)
    def save_palm(self):
        if 'palm_template' in self.changed_data:
            palm_template = self.data.get('palm_template', None)
            palm_id = self.data.get('palms', None)
            if palm_template and palm_id:
                    cls = self.instance.biodata_set.model
                    palm = self.instance.biodata_set.filter(bio_type=8, major_ver='12', bio_no__exact=palm_id).first()
                    if not palm:
                        palm = cls(employee=self.instance, bio_no=palm_id, major_ver='12', bio_type=8, bio_tmp=palm_template, update_time=datetime.datetime.now()).save()
                    else:
                        palm.bio_tmp = palm_template
                        palm.upload_time = datetime.datetime.now()
                        palm.save()
    def remove_palm(self):
        if 'del_palm' in self.changed_data:
            palm = self.data.get('del_palm', '')
            if palm:
                _palms = self.instance.biodata_set.filter(bio_type=8, bio_no=palm)
                _palms.delete()
                self.remove_palm_from_device(palm)
    def remove_palm_from_device(self, palm):
        from mysite.utils import saveCmd, DevIdentity_ex
        from mysite.iclock.models import Terminal
        devs = Terminal.objects.filter(area__in=self.instance.area.filter(is_default=False))
        pin = self.instance.pin()
        for dev in devs:
            if DevIdentity_ex(dev.push_protocol, '2.2.14'):
                _cmd = 'DATA DELETE PALMTMP PIN={pin}\tPID={palmid}'
            else:
                _cmd = 'DATA DEL_PALM PIN={pin}\tPID={palmid}'
            cmd = _cmd.format(pin=pin, palmid=palm)
            saveCmd(dev.id, cmd)
    def save_face(self):
        from mysite.utils import save_bio_photo
        face = self.data.get('face', None)
        if not face:
            return
        else:
            try:
                save_bio_photo(self.instance, face, approval_state=1, overwrite=True)
            except:
                from mysite.admin.exceptions import AdminRuntimeWarning
                raise AdminRuntimeWarning(_('face.register.error.no.face.found'))
    def save_hireday_or_leave_group(self):
        # irreducible cflow, using cdg fallback
        if 'hire_date' in self.changed_data or 'leave_group' in self.changed_data:
            from mysite.att import tasks
            tasks.restore_leaveyearbalance.delay(self.instance)
                    return None
    def save(self, commit=True):
        emp = super(EmployeeForm, self).save(commit=True)
        self.save_newinfo(emp)
        self.save_bio_photo()
        self.set_device_password()
        self.remove_fingerprint()
        self.save_fingerprint()
        self.remove_palm()
        self.save_palm()
        self.save_face()
        active = self.save_employment_period(emp)
        if settings.ACTIVE_APP_LOCATION and 'app_status' in self.changed_data:
                from mysite.mobile.tasks import update_personnel_gps
                update_personnel_gps.delay(emp)
        if self.enable_att_related:
            emp = self.save_att_profile(emp)
            flush_cache_data(emp)
        if self.enable_payroll_related:
            self.save_payroll_profile(emp)
        attrs = ('emp_code', 'status', 'first_name', 'card_no', 'device_password', 'dev_privilege', 'verify_mode', 'bio_photo')
        if active or set(self.changed_data) & set(attrs):
            emp.update_time = datetime.datetime.now()
            emp.enroll_sn = ''
            cache.set('emp_change_flag', 1)
        self.save_hireday_or_leave_group()
        return emp
    class Meta:
        model = Employee
        exclude = ['enable_payroll', 'photo_url', 'biophoto_url']
        if settings.ENABLE_WDMS:
            exclude.extend(['flow_role'])
        fields = '__all__'
class EmployeeAddForm(EmployeeForm):
    def clean_emp_code(self):
        from mysite.utils import get_system_setting
        emp_code = self.cleaned_data.get('emp_code')
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('num_emp_code') is True and (not emp_code.isdigit()):
            raise forms.ValidationError(_('emp_code_should_be_digit'))
        else:
            return emp_code
class EmployeeChangeForm(EmployeeForm):
    emp_code = forms.CharField(label=_('emp_field_employeeCode'), disabled=True)
    is_probation = False
    def __init__(self, *args, **kwargs):
        super(EmployeeChangeForm, self).__init__(*args, **kwargs)
        if self.instance:
            fps = self.instance.biodata_set.filter(bio_type=1).values_list('bio_no', 'bio_tmp', 'valid', 'duress', 'major_ver')
            palms = self.instance.biodata_set.filter(bio_type__in=(8, 10)).values_list('bio_no', 'bio_tmp', 'valid')
            initial_data = {'fpCount': len(fps), 'fps': ','.join(map(str, [fp[0] for fp in fps if fp[3]])), 'dur_fps': len(palms), 'palmCount': ','.join(map(str, [palm[0] for palm in palms])), 'palms': ','.join(map(str, [palm[1] for palm in palms])), 'faceCount': self.instance.biophoto_set.count()}
            if fps:
                templates = []
                for fp in fps:
                    template = {'no': fp[0], 'version': fp[4], 'template': fp[1]}
                    templates.append(template)
                initial_data['templates'] = json.dumps(templates)
            self.fields['leave_group'].widget.value = self.instance.leave_group
            if self.instance.emp_type in (db_const.TEMPORARY, db_const.PROBATION):
                self.is_probation = True
            if hasattr(self.instance, 'employment'):
                initial_data.update({'effective_start': self.instance.employment.start_date, 'effective_end': self.instance.employment.end_date})
            if self.enable_att_related:
                from mysite.att.models import AttEmployee
                att_emp = AttEmployee.objects.filter(emp=self.instance).values('group', 'enable_attendance', 'enable_schedule', 'enable_holiday', 'enable_overtime', 'enable_compensatory', 'ip_address').first()
                if att_emp:
                    initial_data.update(att_emp)
            if self.enable_payroll_related:
                from mysite.payroll.models import EmpPayrollProfile
                emp_payroll = EmpPayrollProfile.objects.filter(employee=self.instance).values('payment_mode', 'payment_type', 'bank_name', 'bank_account', 'agent_id', 'agent_account').first()
                if emp_payroll:
                    for key, value in emp_payroll.items():
                        emp_payroll[key] = str(value)
                    initial_data.update(emp_payroll)
            self.initial.update(initial_data)
            self.initial['department'] = self.instance.department
            if getattr_ex(settings, 'MULTI_COMPANY', False) and (not isinstance(self.fields['company'].widget, forms.ZKHiddenInput)):
                    self.fields['company'].widget.widget.attrs['first_click'] = 0
            if settings.ENABLE_WDMS:
                for model_name in ['department', 'area', 'position']:
                    self.fields[model_name].company_belong = self.instance.company.id
            else:
                if getattr_ex(settings, 'MULTI_COMPANY_EXT', False):
                    for model_name in ['department', 'area', 'position', 'group', 'flow_role']:
                        self.fields[model_name].company_belong = self.instance.company.id
class EmployeeEditSelfInfoForm(ModelForm):
    emp_code = forms.CharField(disabled=True, required=False)
    first_name = forms.CharField(disabled=True, required=False)
    last_name = forms.CharField(disabled=True, required=False)
    department = forms.CharField(disabled=True, required=False)
    position = forms.CharField(disabled=True, required=False)
    emp_type = forms.CharField(disabled=True, required=False)
    hire_date = forms.DateTimeField(disabled=True, required=False)
    email = forms.CharField(required=False)
    mobile = forms.CharField(required=False)
    verify_mode = forms.CharField(required=False, disabled=True)
    dev_privilege = forms.CharField(required=False, disabled=True)
    card_no = forms.CharField(required=False, disabled=True)
    device_password = forms.CharField(required=False)
    bio_photo = forms.FileField(required=False, initial='')
    def __init__(self, *args, **kwargs):
        super(EmployeeEditSelfInfoForm, self).__init__(*args, **kwargs)
        initial_data = {'department': self.instance.department.dept_name, 'position': self.instance.position.position_name if self.instance.position else '', 'emp_type': self.instance.get_emp_type_display(), 'verify_mode': self.instance.get_verify_mode_display(), 'dev_privilege': self.instance.get_dev_privilege_display()}
        self.initial.update(initial_data)
    def save_bio_photo(self):
        from mysite.utils import save_bio_photo
        if 'bio_photo' in self.changed_data:
            from mysite.iclock.comm.utils import get_comm_setting
            photo = self.files.get('bio_photo', None)
            if not photo:
                return
            else:
                approval_state = get_comm_setting('edit_policy')
                save_bio_photo(self.instance, photo, approval_state)
    def set_device_password(self):
        if 'device_password' in self.changed_data:
            self.instance.set_devicepassword(self.cleaned_data['device_password'])
    def save(self, commit=True):
        emp = super(EmployeeEditSelfInfoForm, self).save(commit=True)
        self.save_bio_photo()
        self.set_device_password()
        attrs = ('emp_code', 'first_name', 'card_no', 'device_password', 'dev_privilege', 'verify_mode', 'photo', 'bio_photo')
        if set(self.changed_data) & set(attrs):
            emp.update_time = datetime.datetime.now()
            emp.enroll_sn = ''
            cache.set('emp_change_flag', 1)
        return emp
    class Meta:
        model = Employee
        fields = ['emp_code', 'first_name', 'last_name', 'hire_date', 'email', 'mobile', 'photo', 'card_no', 'device_password', 'bio_photo', 'superior']