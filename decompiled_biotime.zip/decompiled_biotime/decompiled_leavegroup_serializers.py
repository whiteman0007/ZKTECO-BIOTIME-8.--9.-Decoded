# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\leavegroup_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models import LeaveGroup
class LeaveGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveGroup
        fields = ['id', 'code', 'name']