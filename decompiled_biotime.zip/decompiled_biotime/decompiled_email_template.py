# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\email_template.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from mysite.base.api.utils_class import UserLayUIGenericViewSet, BasicUserModelViewSet
from mysite.base.models import EmailTemplate
EMPLOYEE, ADMIN, APPROVER, NOTIFIER, OTHER = (1, 2, 3, 4, 5)
EMPLOYEE_MACRO = [{'macro': '{emp_code}', 'name': _('emp_field_employeeCode')}, {'macro': '{first_name}', 'name': _('emp_field_firstName')}, {'macro': '{last_name}', 'name': _('emp_field_lastName')}, {'macro': '{e_department}', 'name': _('department_filed_name')}, {'macro': '{e_position}', 'name': _('position_field_name')}]
EMPLOYEE_SCHEDULE = [{'macro': '{emp_code}', 'name': _('emp_field_employeeCode')}, {'macro': '{first_name}', 'name': _('emp_field_firstName')}, {'macro': '{last_name}', 'name': _('emp_field_lastName')}, {'macro': '{department}', 'name': _('department_filed_name')}, {'macro': '{schedule_name}', 'name': _('emp_field_schedule_name')}, {'macro': '{schedule_time}', 'name': _('emp_field_schedule_time')}, {'macro': '{break_time}', 'name': _('emp_field_break_time')}]
TEMPORARY_SCHEDULE = [{'macro': '{emp_code}', 'name': _('emp_field_employeeCode')}, {'macro': '{first_name}', 'name': _('emp_field_firstName')}, {'macro': '{last_name}', 'name': _('emp_field_lastName')}, {'macro': '{department}', 'name': _('department_filed_name')}, {'macro': '{att_date}', 'name': _('emp_filed_att_date')}, {'macro': '{table_name}', 'name': _('emp_field_table_name')}, {'macro': '{table_time}', 'name': _('emp_field_table_time')}, {'macro': '{break_time}', 'name': _('emp_field_break_time')}]
APPROVER_AND_NOTIFIER_MACRO = [{'macro': '{r_emp_code}', 'name': _('emp_field_employeeCode')}, {'macro': '{r_first_name}', 'name': _('emp_field_firstName')}, {'macro': '{r_last_name}', 'name': _('emp_field_lastName')}, {'macro': '{r_department}', 'name': _('department_filed_name')}, {'macro': '{r_position}', 'name': _('position_field_name')}]
ADMIN_MACRO = [{'macro': '{admin_first_name}', 'name': _('user_field_firstName')}, {'macro': '{admin_last_name}', 'name': _('user_field_lastName')}]
VISITOR_MACRO = [{'macro': '{vis_first_name}', 'name': _('visitor.field.firstName')}, {'macro': '{vis_last_name}', 'name': _('visitor.field.lastName')}]
EXCEPTION_EMPLOYEE_MACRO = [{'macro': '{late_in}', 'name': _('emailTemplate.macros.lateInQty')}, {'macro': '{early_out}', 'name': _('emailTemplate.macros.earlyOutQty')}, {'macro': '{absence}', 'name': _('emailTemplate.macros.absenceQty')}, {'macro': '{start_time}', 'name': _('emailTemplate.macros.startTime')}, {'macro': '{end_time}', 'name': _('emailTemplate.macros.endTime')}]
PUNCH_EMPLOYEE_MACRO = [{'macro': '{punch_time}', 'name': _('transaction_field_punchTime')}, {'macro': '{punch_state}', 'name': _('transaction_field_punchState')}, {'macro': '{verify_type}', 'name': _('transaction_field_verifyType')}, {'macro': '{work_code}', 'name': _('transaction_field_workCode')}, {'macro': '{terminal_sn}', 'name': _('transaction_field_terminalSN')}]
EXCEPTION_ADMIN_MACRO = [{'macro': '{start_time}', 'name': _('emailTemplate.macros.startTime')}, {'macro': '{end_time}', 'name': _('emailTemplate.macros.endTime')}, {'macro': '{body_detail}', 'name': _('emailTemplate.macros.bodyDetail')}]
WORKFLOW_MACRO = [{'macro': '{apply_reason}', 'name': _('manualLog_field_applyReason')}, {'macro': '{apply_time}', 'name': _('manualLog_field_applyTime')}, {'macro': '{approver}', 'name': _('common_field_approver')}, {'macro': '{approval_status}', 'name': _('common_field_approvalStatus')}, {'macro': '{approval_time}', 'name': _('common_field_approvalTime')}, {'macro': '{approval_remark}', 'name': _('common_field_approvalRemark')}]
MANUAL_LOG_MACRO = [{'macro': '{punch_time}', 'name': _('manualLog_field_punchTime')}, {'macro': '{punch_state}', 'name': _('manualLog_field_punchState')}, {'macro': '{work_code}', 'name': _('manualLog_field_workCode')}]
LEAVE_MACRO = [{'macro': '{pay_code}', 'name': _('leave.fields.payCode')}, {'macro': '{start_time}', 'name': _('leave_field_startTime')}, {'macro': '{end_time}', 'name': _('leave_field_endTime')}]
OVERTIME_MACRO = [{'macro': '{pay_code}', 'name': _('overtime.fields.payCode')}, {'macro': '{start_time}', 'name': _('overtime_field_startTime')}, {'macro': '{end_time}', 'name': _('overtime_field_endTime')}]
TRAINING_MACRO = [{'macro': '{pay_code}', 'name': _('training.fields.payCode')}, {'macro': '{start_time}', 'name': _('training_field_startTime')}, {'macro': '{end_time}', 'name': _('training_field_endTime')}]
SCHEDULE_MACRO = [{'macro': '{att_date}', 'name': _('changeSchedule_field_attDate')}, {'macro': '{previous_timeinterval}', 'name': _('changeSchedule_field_previousTimeInterval')}, {'macro': '{timeinterval}', 'name': _('changeSchedule_field_adjustTimeInterval')}]
MEETING_MACRO = [{'macro': '{alias}', 'name': _('meetingEntity.fields.alias')}, {'macro': '{start_time}', 'name': _('meetingEntity.fields.startTime')}, {'macro': '{end_time}', 'name': _('meetingEntity.fields.endTime')}, {'macro': '{content}', 'name': _('meetingEntity.fields.content')}, {'macro': '{zoom_link}', 'name': _('meetingEntity.fields.zoomInvitation')}, {'macro': '{meeting_room_alias}', 'name': _('meetingRoom.fields.alias')}, {'macro': '{meeting_room_location}', 'name': _('meetingRoom.fields.location')}]
MEETING_MANUAL_LOG_MACRO = [{'macro': '{punch_time}', 'name': _('manualLog_field_punchTime')}, {'macro': '{punch_state}', 'name': _('manualLog_field_punchState')}, {'macro': '{meeting}', 'name': _('meetingManualLog.fields.meeting')}]
RESERVATION_MACRO = [{'macro': '{vis_first_name}', 'name': _('visitor.field.firstName')}, {'macro': '{vis_last_name}', 'name': _('visitor.field.lastName')}, {'macro': '{company}', 'name': _('visitor.field.company')}, {'macro': '{cert_type}', 'name': _('visitor.field.certification')}, {'macro': '{cert_no}', 'name': _('visitor.field.certNo')}, {'macro': '{gender}', 'name': _('visitor.field.gender')}, {'macro': '{visit_quantity}', 'name': _('visitor.field.quantity')}, {'macro': '{visit_date}', 'name': _('visitor.field.visitDate')}, {'macro': '{visit_reason}', 'name': _('visitor.field.reason')}]
MTD_EMPLOYEE_MACRO = [{'macro': '{check_date}', 'name': _('epTransaction.fields.checkDate')}, {'macro': '{check_time}', 'name': _('epTransaction.fields.checkTime')}, {'macro': '{temperature}', 'name': _('epTransaction.fields.temperature')}, {'macro': '{is_mask}', 'name': _('epTransaction.fields.isMask')}, {'macro': '{capture}', 'name': _('epTransaction.fields.capture')}, {'macro': '{area}', 'name': _('epTransaction.fields.area')}]
MANUAL_LOG_MACRO.extend(WORKFLOW_MACRO)
LEAVE_MACRO.extend(WORKFLOW_MACRO)
OVERTIME_MACRO.extend(WORKFLOW_MACRO)
TRAINING_MACRO.extend(WORKFLOW_MACRO)
SCHEDULE_MACRO.extend(WORKFLOW_MACRO)
MEETING_MACRO.extend(WORKFLOW_MACRO)
MEETING_MANUAL_LOG_MACRO.extend(WORKFLOW_MACRO)
RESERVATION_MACRO.extend(WORKFLOW_MACRO)
EVENT_WORKFLOW_MACRO = {(121, 321, 421): MANUAL_LOG_MACRO, (122, 322, 422): LEAVE_MACRO, (123, 323, 423): OVERTIME_MACRO, (124, 324, 424): TRAINING_MACRO, (125, 325, 425): SCHEDULE_MACRO, (1310, 3310, 4310): MEETING_MACRO, (1311, 3311, 4311): MEETING_MANUAL_LOG_MACRO, (149, 349, 449): RESERVATION_MACRO}
EVENT_OTHER_MACRO = {101: (MEETING_MACRO, APPROVER_AND_NOTIFIER_MACRO), 102: (RESERVATION_MACRO, VISITOR_MACRO)}
class EmailTemplateSerializer(serializers.ModelSerializer):
    macro = serializers.SerializerMethodField()
    template = serializers.CharField(allow_blank=True)
    def get_macro(self, obj):
        fields = {'involver': EMPLOYEE_MACRO}
        if obj.receiver in [ADMIN]:
            fields['receiver'] = ADMIN_MACRO
        else:
            fields['receiver'] = APPROVER_AND_NOTIFIER_MACRO
        if obj.category in [11, 21]:
            fields['involver'] = []
            fields['event'] = EXCEPTION_EMPLOYEE_MACRO
            if obj.receiver in [ADMIN]:
                fields['event'] = EXCEPTION_ADMIN_MACRO
        else:
            if obj.category in [15, 22]:
                fields['event'] = MTD_EMPLOYEE_MACRO
                if obj.category == 15:
                    fields['receiver'] = []
            else:
                if obj.event in [101, 102]:
                    fields['event'] = EVENT_OTHER_MACRO[obj.event][0]
                    fields['receiver'] = EVENT_OTHER_MACRO[obj.event][1]
                else:
                    if obj.category in [16]:
                        fields['involver'] = []
                        fields['receiver'] = []
                        fields['event'] = EMPLOYEE_SCHEDULE
                    else:
                        if obj.category in [17]:
                            fields['involver'] = []
                            fields['receiver'] = []
                            fields['event'] = TEMPORARY_SCHEDULE
                        else:
                            if obj.category in [18]:
                                fields['involver'] = []
                                fields['event'] = PUNCH_EMPLOYEE_MACRO
                            else:
                                for category_range in EVENT_WORKFLOW_MACRO:
                                    if obj.sub_category in category_range:
                                        fields['event'] = EVENT_WORKFLOW_MACRO[category_range]
                                        break
        return fields
    class Meta:
        model = EmailTemplate
        fields = '__all__'
class EmailTemplateViewSet(BasicUserModelViewSet):
    model = EmailTemplate
    queryset = EmailTemplate.objects.all()
    serializer_class = EmailTemplateSerializer
    @action(methods=['get'], detail=False)
    def receivers(self, request, *args, **kwargs):
        from mysite.base import const
        from mysite.base.models import EmailTemplate
        from mysite.authorized import auth_settings
        emailTemplates = EmailTemplate.objects.all()
        if not auth_settings.ENABLE_VISITOR:
            emailTemplates = emailTemplates.exclude(category__in=[14, 34, 44]).exclude(event=102)
        if not auth_settings.ENABLE_MEETING:
            emailTemplates = emailTemplates.exclude(category__in=[13, 33, 43]).exclude(event=101)
        if not auth_settings.ENABLE_EP:
            emailTemplates = emailTemplates.exclude(category__in=[15, 22])
        templates = emailTemplates.values('id', 'category', 'sub_category', 'event', 'receiver').order_by('id')
        categories = {}
        receiver_tree = []
        for t in templates:
            parent = 0
            for val, symbol in [(t['receiver'], 'r'), (t['category'], 'c'), (t['sub_category'], 's')]:
                if val > 0:
                    category = '{0}{1}'.format(symbol, val)
                    categories[category] = {'parent': parent, 'name': str(const.EMAIL_TEMPLATE_CATEGORIES[category])}
                    parent = category
            event = 'e{0}'.format(t['event'])
            receiver_tree.append({'id': t['id'], 'name': str(const.EMAIL_TEMPLATE_EVENTS[event]), 'pId': parent})
        for key, val in categories.items():
            receiver_tree.append({'id': key, 'name': val['name'], 'pId': val['parent'], 'nocheck': True})
        return Response(receiver_tree)