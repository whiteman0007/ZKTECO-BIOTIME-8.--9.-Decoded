# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\viewsets\\celery_task.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:10 UTC (1750672990)

from rest_framework.response import Response
from mysite.api.utils_class import LayUIGenericViewSet
from mysite.tools.redis_utils import celery_worker_redis
class CeleryTaskViewSet(LayUIGenericViewSet):
    def list(self, request):
        detail = request.query_params.get('detail')
        detail = True if detail == 'true' else False
        return_data = celery_worker_redis.get_info(detail=detail)
        return Response(return_data)