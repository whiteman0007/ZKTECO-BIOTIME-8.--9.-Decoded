# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\report\\admin\\department_overtime_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:00 UTC (1750672980)

from mysite.att import const
from mysite.att.report.base import ReportAdminBase
from mysite.att.report.decorators import report_register
from mysite.att.api.report_views import DepartmentOvertimeViewSet
from mysite.att.api.report_views.department_overtime import DepartmentOvertimeSerializer
@report_register()
class DepartmentOvertimeAdmin(ReportAdminBase):
    model_name = 'departmentOvertimeReport'
    view_name = 'department_overtime'
    template = 'att/report_new/department_overtime.html'
    api_view = DepartmentOvertimeViewSet
    serializer = DepartmentOvertimeSerializer
    data_source = '/att/api/departmentOvertimeReport/'
    required_dept_wise = True
    list_display = ('company_code', 'company_name', 'dept_code', 'dept_name', 'total_emp')
    hidden_fields = ('company_code',)
    sort_fields = 'dept_code'
    add_paycode_column = True
    paycode_type = const.OVERTIME