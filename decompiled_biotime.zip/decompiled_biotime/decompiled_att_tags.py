# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\templatetags\\att_tags.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:03 UTC (1750672983)

from django import template
from django import forms
from django.utils.translation import gettext_lazy as _
register = template.Library()
def label_tag(field, has_suffix=True):
    is_checkbox = isinstance(field.field.widget, forms.CheckboxInput)
    classes = ['layui-form-label']
    if field.field.required:
        classes.append('required')
    attrs = {'class': ' '.join(classes)}
    if has_suffix:
        label_tag = field.label_tag(attrs=attrs)
    else:
        label_tag = field.label_tag(attrs=attrs, label_suffix=' ')
    return label_tag
@register.filter
def layui_label_tag(field):
    return label_tag(field, has_suffix=False)
@register.filter
def layui_item_field(field):
    field_html = '<div class=\"layui-form-item\">{0}<div class=\"layui-input-inline\">{1}</div></div>'
    return field_html.format(layui_label_tag(field), field.as_widget())
@register.filter
def layui_item_field_ignore(field, ignore_tag=None):
    import re
    field_html = '<div class=\"layui-form-item\" style=\"display: none;\">{0}<div class=\"layui-input-inline\">{1}</div></div>'
    result = field_html.format(layui_label_tag(field), field.as_widget())
    if ignore_tag is None:
        return result
    else:
        return result.replace('<{}'.format(ignore_tag), '<{} lay-ignore'.format(ignore_tag))
@register.filter
def layui_inline_field(field):
    if field:
        field_html = '<div class=\"layui-inline\">{0}<div class=\"layui-input-inline\">{1}</div></div>'
        return field_html.format(layui_label_tag(field), field.as_widget())
    else:
        return ''
@register.filter
def layui_inline_no_label_field(field):
    field_html = '<div class=\"layui-inline\"><div class=\"layui-input-inline\">{0}</div></div>'
    return field_html.format(field.as_widget())
@register.filter
def field_as_label_tag_no_asterisk(field):
    result = label_tag(field, has_suffix=False)
    if result.__contains__('required'):
        result = result.replace('required', '')
    return '%s' % result
@register.filter
def HasLeaveApprovalPrivilege(user):
    from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
    permission = APPROVAL_APPROVE_PERMISSION.get('leave')
    return user.has_perm(permission)