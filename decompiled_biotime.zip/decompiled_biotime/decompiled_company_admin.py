# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\personnel\\admin\\company_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:19 UTC (1750673059)

from django.conf import settings
from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from mysite.authorized import auth_settings
from mysite import admin
from mysite.admin import forms
from mysite.admin.kernel import ZKModelAdmin
from mysite.base.threadlocals import get_current_user
from mysite.personnel import db_const
from mysite.personnel.models import Company
from mysite.personnel.utils import get_default_company, get_default_company_id
from .company_admin_mixin import CompanyAdminMixin
from ..._utils import getattr_ex
class CompanyField4ModelChangeForm(ModelForm):
    company_name = forms.CharField(label=_('company.field.name'), disabled=True, required=False)
    def __init__(self, *args, **kwargs):
        super(CompanyField4ModelChangeForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['company_name'].initial = str(self.instance.company)
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            try:
                req = kwargs.pop('initial').pop('request')
                self.user = req.user
            except:
                self.user = get_current_user()
            if self.user and (not self.user.is_superuser) and self.user.assign_company:
                        self.fields['company_name'].widget = forms.ZKHiddenInput()
        else:
            self.fields['company_name'].widget = forms.ZKHiddenInput()
class CompanyField4ModelForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(CompanyField4ModelForm, self).__init__(*args, **kwargs)
        self.fields['company'].initial = get_default_company()
        if getattr_ex(settings, 'MULTI_COMPANY', False):
            parent_field = ''
            try:
                req = kwargs.pop('initial').pop('request')
                self.user = req.user
                parent_field = list(filter(lambda x: 'parent_' in x, self.Meta.fields))[0]
            except:
                self.user = get_current_user()
            if self.user and (not self.user.is_superuser) and self.user.assign_company:
                        self.fields['company'].initial = Company.objects.filter(id=self.user.assign_company).first()
                        self.fields['company'].widget = forms.ZKHiddenInput()
            if parent_field:
                self.fields[parent_field].company_belong = self.user.assign_company or get_default_company_id()
        else:
            self.fields['company'].widget = forms.ZKHiddenInput()
class CompanyCreationForm(ModelForm):
    company_code = forms.CharField(label=_('company.field.code'), max_length=db_const.MAX_COMPANY_CODE)
    company_name = forms.CharField(label=_('company.field.name'), max_length=db_const.MAX_COMPANY_NAME)
    def __init__(self, *args, **kwargs):
        super(CompanyCreationForm, self).__init__(*args, **kwargs)
        try:
            objs = Company.objects.values('company_code')
            codes = [int(i['company_code']) for i in objs if i['company_code'].isdigit()]
            self.fields['company_code'].initial = str(max(codes) + 1 if codes else 1)
        except Exception:
            return None
    class Meta:
        models = Company
        fields = '__all__'
class CompanyEditForm(ModelForm):
    company_code = forms.CharField(label=_('company.field.code'), max_length=db_const.MAX_COMPANY_CODE)
    company_name = forms.CharField(label=_('company.field.name'), max_length=db_const.MAX_COMPANY_NAME)
    class Meta:
        models = Company
        fields = '__all__'
        exclude = ('is_default',)
@admin.register(Company)
class CompanyAdmin(ZKModelAdmin, CompanyAdminMixin):
    sort_fields = ('company_code', 'company_name')
    add_form = CompanyCreationForm
    form = CompanyEditForm
    list_filter = ('company_code', 'company_name')
    cache_keys = ('company_tree_nodes',)
    def get_form(self, request, obj=None, **kwargs):
        """\n        Use special form during user creation\n        """
        defaults = {}
        if obj is None:
            defaults['form'] = self.add_form
        defaults.update(kwargs)
        return super(CompanyAdmin, self).get_form(request, obj, **defaults)
    @staticmethod
    def initial_data():
        from django.utils.encoding import force_str
        if Company.objects.all().count() == 0:
            Company(company_code='1', company_name=force_str(_('company.default')), is_default=True).save()
    @property
    def list_display(self):
        return self.get_ext_list_display()
    @property
    def hidden_fields(self):
        return self.get_ext_hidden_fields()
    def has_add_permission(self, request):
        if request.user.is_employee:
            return False
        else:
            return request.user.is_superuser and (getattr_ex(settings, 'MULTI_COMPANY_EXT') and auth_settings.AUTHORIZED_FIRM > 1 or settings.ENABLE_WDMS)
    def has_delete_permission(self, request, obj=None):
        if request.user.is_employee:
            return False
        else:
            return request.user.is_superuser and (getattr_ex(settings, 'MULTI_COMPANY_EXT') and auth_settings.AUTHORIZED_FIRM > 1 or settings.ENABLE_WDMS)
    def get_queryset(self, request):
        qs = super(CompanyAdmin, self).get_queryset(request)
        if request.user.is_employee:
            return qs.filter(pk=request.user.company.id)
        else:
            if not request.user.is_superuser and request.user.assign_company:
                    qs = qs.filter(pk=request.user.assign_company)
            return qs