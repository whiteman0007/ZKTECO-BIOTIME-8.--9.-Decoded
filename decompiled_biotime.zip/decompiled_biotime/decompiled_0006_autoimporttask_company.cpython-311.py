# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0006_autoimporttask_company.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from __future__ import unicode_literals
from django.db import migrations
import django.db.models.deletion
import mysite.personnel.fields
class Migration(migrations.Migration):
    dependencies = [('personnel', '0005_auto_20211201_1434'), ('base', '0005_auto_20211201_1434')]
    operations = [migrations.AddField(model_name='autoimporttask', name='company', field=mysite.personnel.fields.CompanyForeignKey(default=1, on_delete=django.db.models.deletion.CASCADE, to='personnel.Company', verbose_name='employee.field.company'))]