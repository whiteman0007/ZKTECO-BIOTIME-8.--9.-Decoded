# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\templatetags\\email_tags.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:29 UTC (1750673009)

from django.template import Library, Node
register = Library()
def do_email_tag(parser, token):
    tag = token.contents
    nodelist = parser.parse(('end%s' % tag,))
    parser.delete_first_token()
    return EmailNode(tag, nodelist)
class EmailNode(Node):
    def __init__(self, tag, nodelist):
        self.tag = tag
        self.nodelist = nodelist
    def render(self, context):
        context_var = '_%s' % self.tag
        if not context.get(context_var, False):
            return ''
        else:
            return self.nodelist.render(context)
register.tag('subject', do_email_tag)
register.tag('body', do_email_tag)
register.tag('bodyhtml', do_email_tag)