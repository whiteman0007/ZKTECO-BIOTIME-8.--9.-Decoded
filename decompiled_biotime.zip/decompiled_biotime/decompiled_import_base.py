# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\data_import\\import_base.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

from celery_progress.backend import AbstractProgressRecorder
from django.apps import apps
from django.utils.translation import gettext_lazy as _, activate
from django.contrib.auth import get_user_model
from mysite.utils import progress_record, is_xss_in_dict
from mysite.tools.file_utils import FileReader
User = get_user_model()
class DataImportBase(object):
    """\n    1. Read data from import file.\n    2. Verify data get cleaned data.\n    3. Saving data to database.\n    """
    overwrite = False
    progress_recorder = None
    total = None
    current = None
    def __init__(self, request, app_label, model_name, **kwargs):
        language = kwargs.pop('template_lng', None)
        if language:
            activate(language)
        self.request = request
        self.progress_recorder = kwargs.pop('progress_recorder', None)
        self.model = apps.get_model(app_label=app_label, model_name=model_name)
        self.rows = []
        self.errors = []
        self.required_fields = []
        self.init_required_fields()
        self.cleaned_rows = []
        self.overwrite = kwargs.pop('overwrite', False)
        self.overwrite = True if int(self.overwrite) else False
        self.auto_approve = kwargs.pop('auto_approve', False)
    def init_required_fields(self):
        return
    def process(self):
        self.file_reader()
        if self.errors:
            return self.errors
        else:
            self.clean()
            if self.errors:
                return self.errors
            else:
                self.bulk_save()
                if self.errors:
                    return self.errors
                else:
                    return None
    def file_reader(self):
        import_file = self.request.FILES['import_file']
        try:
            self.rows = FileReader(import_file, must_fields=self.required_fields).dict_read()
        except Exception as e:
            self.errors.append(str(e))
    def clean_row(self, index, row):
        raise NotImplementedError
    def clean(self):
        from django.core.exceptions import ValidationError
        if not self.rows:
            self.errors.append(_('progress.status.empty'))
            return
        else:
            self.total = len(self.rows)
            for index, row in enumerate(self.rows):
                self.current = index + 1
                progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.dataVerification'))
                cleaned_row = self.clean_row(index, row)
                result, message = is_xss_in_dict(row)
                if result:
                    raise ValidationError(message or 'xss content index {0}'.format(index))
                else:
                    if not cleaned_row:
                        return
                    else:
                        self.cleaned_rows.append(cleaned_row)
    def bulk_save(self):
        for index, row in enumerate(self.cleaned_rows):
            self.current = index + 1
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
            instance = self.save(index, row)
            if not instance:
                break
    def save(self, index, row):
        raise NotImplementedError