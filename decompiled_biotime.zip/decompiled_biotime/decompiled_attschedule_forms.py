# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\forms\\attschedule_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
from django.forms import ModelForm, ValidationError
from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att import db_const
from mysite.admin.forms import widgets
from mysite.att.models import AttSchedule
from mysite.att.models_choices import CYCLE_UNITS, SHIFT_OT_TYPE
class AttScheduleCreationForm(ModelForm):
    days = forms.CharField()
    weekend = forms.CharField(label=_('weekend'), max_length=20, required=False, widget=widgets.ZKHiddenInput)
    alias = forms.CharField(label=_('alias'), max_length=db_const.MAX_SHIFT_ALIAS)
    cycle_unit = forms.ChoiceField(label=_('cycle_unit'), initial=1, choices=CYCLE_UNITS)
    shift_cycle = forms.IntegerField(label=_('shift_cycle'), initial=1)
    shift_cover = forms.BooleanField(label=_('replace_existing_shift_even_using'), initial=False, required=False)
    schedule_cover = forms.BooleanField(label=_('remove_overlap_schedule'), initial=False, required=False)
    work_weekend = forms.BooleanField(label=_('enable_work_on_weekend_as'), initial=True, required=False)
    weekend_type = forms.ChoiceField(label=_('work_type'), initial=0, choices=SHIFT_OT_TYPE)
    work_day_off = forms.BooleanField(label=_('enable_work_on_day_off_as'), initial=True, required=False)
    day_off_type = forms.ChoiceField(label=_('work_type'), initial=0, choices=SHIFT_OT_TYPE)
    auto_shift = forms.BooleanField(label=_('auto_shift'), initial=False, required=False)
    class Meta:
        model = AttSchedule
        fields = '__all__'
        exclude = ['weekend']
    def __init__(self, *args, **kwargs):
        super(AttScheduleCreationForm, self).__init__(*args, **kwargs)
        self.fields['weekend'].initial = get_weekend()
        now = datetime.datetime.now()
        self.fields['start_date'].initial = now.strftime('%Y-%m-01')
        next_month_first = (now + datetime.timedelta(days=31)).strftime('%Y-%m-01')
        this_month_last = datetime.datetime.strptime(next_month_first, '%Y-%m-%d') + datetime.timedelta(days=(-1))
        self.fields['end_date'].initial = this_month_last.strftime('%Y-%m-%d')
    def clean(self):
        cleaned_data = super(AttScheduleCreationForm, self).clean()
        data_pre_check(self, cleaned_data)
        return cleaned_data
    def save(self, commit=True):
        save_data = super(AttScheduleCreationForm, self).save(commit=False)
        save_data.save()
        return save_data
def data_pre_check(self, cleaned_data):
    # irreducible cflow, using cdg fallback
    from mysite.att.models import TimeInterval, AttShift, ShiftDetail
    emp_ids = cleaned_data.get('employee', None)
    days = cleaned_data.get('days', None)
    shift_alias = cleaned_data.get('alias')
    shift_start = cleaned_data.get('start_date')
    shift_end = cleaned_data.get('end_date')
    auto_shift = cleaned_data.get('auto_shift', None)
    shift_unit = int(cleaned_data.get('cycle_unit'))
    shift_cycle = cleaned_data.get('shift_cycle')
    count_weekend = cleaned_data.get('work_weekend', None)
    weekend_type = int(cleaned_data.get('weekend_type'))
    count_day_off = cleaned_data.get('work_day_off', None)
    day_off_type = int(cleaned_data.get('day_off_type'))
    shift_cover = cleaned_data.get('shift_cover', None)
    schedule_cover = cleaned_data.get('schedule_cover', None)
    break_times = cleaned_data.get('break_time', None)
    if not emp_ids:
        raise ValidationError(_('please_select_employee'), code='-1')
    else:
        if not shift_alias:
            raise ValidationError(_('please_input_shift_alias'), code='-1')
        else:
            if shift_start > shift_end:
                raise ValidationError(_('end_date_can_not_less_than_start_date'), code='-1')
            else:
                if days:
                    days = days.split(';')[:(-1)]
                else:
                    raise ValidationError(_('please_select_time_intervals'), code='-1')
                emp_ids = [emp_ids.id]
                emp_len = len(emp_ids)
                start_time = datetime.date(shift_start.year, shift_start.month, shift_start.day)
                end_time = datetime.date(shift_end.year, shift_end.month, shift_end.day)
                batch = 1000
                times = emp_len / batch
                if emp_len % batch:
                    times += 1
                exist_schedule = []
                for i in range(times):
                    start = i * batch
                    end = (i + 1) * batch
                    tmp_uids = emp_ids[start:end]
                    user_schedules = AttSchedule.objects.filter(start_date__lte=end_time, end_date__gte=start_time, employee__id__in=[int(emp_ids) for emp_ids in tmp_uids])
                    if user_schedules:
                        if schedule_cover:
                            exist_schedule.append(user_schedules)
                        else:
                            emp = user_schedules[0].employee
                            raise ValidationError(_('%(code)s(%(name)s) this_employee_already_has_schedule_in %(start)s - %(end)s'), code='-1', params={'code': emp.emp_code, 'name': emp.first_name, 'start': shift_start.strftime('%Y-%m-%d'), 'end': shift_end.strftime('%Y-%m-%d')})
                all_schs = {}
                result = []
                for day in days:
                    pass
    day_schs = day.split('-', 1)
    _day = day_schs[0]
    _schs = day_schs[1].split(',')
    tmps = []
    _types = set()
    for sch in _schs:
        pass
    if sch not in all_schs:
        sc = TimeInterval.objects.filter(id=sch)[0]
        all_schs[sch] = sc
    else:
        sc = all_schs.get(sch, None)
    if auto_shift:
        pass
    _type = sc.use_mode
    if _types and _type == 1:
        raise ValidationError(_('Can_not_using_multiple_timeinterval_with_flexible_timeinterval'), code='-1')
    else:
        _types.add(_type)
    for tmp in tmps:
        pass
    scs = datetime.datetime.strptime(sc.in_time.strftime('%H:%M:%S'), '%H:%M:%S')
    sce = datetime.datetime.strptime(sc.out_time.strftime('%H:%M:%S'), '%H:%M:%S')
    if scs > sce:
        sce += datetime.timedelta(days=1)
    tmp_s = datetime.datetime.strptime(tmp.in_time.strftime('%H:%M:%S'), '%H:%M:%S')
    tmp_e = datetime.datetime.strptime(tmp.out_time.strftime('%H:%M:%S'), '%H:%M:%S')
    if tmp_s > tmp_e:
        tmp_e += datetime.timedelta(days=1)
    if tmp_s <= scs <= tmp_e or tmp_s <= sce <= tmp_e:
        pass
    raise ValidationError(_('%(t)s and %(ss)s time_period_are_duplicated! In_section %(d)s day'), code='-1', params={'t': sc, 'ss': tmp, 'd': str(int(_day) + 1)})
    tmps.append(sc)
    result.append((_day, tmps))
    if False:
        pass
    shifts = AttShift.objects.filter(alias=shift_alias)
    check = True
    if shifts:
        shift = shifts[0]
        if shift.cycle_unit!= shift_unit:
            check = False
        if shift.shift_cycle!= shift_cycle:
            check = False
        if shift.work_weekend!= count_weekend:
            check = False
        if shift.weekend_type!= weekend_type:
            check = False
        if shift.work_day_off!= count_day_off:
            check = False
        if shift.day_off_type!= day_off_type:
            check = False
        if shift.auto_shift!= auto_shift:
            check = False
        shift_details = ShiftDetail.objects.filter(shift=shift)
        sd_dict = {}
        for sd in shift_details:
            _day = str(sd.day_index)
            if _day not in sd_dict:
                sd_dict[_day] = []
            sd_dict[_day].append(sd.time_interval)
        results = ['%s%s' % (k, sorted([getattr(x, 'pk', '') for x in v])) for k, v in list(sd_dict.items())]
        c_result = ['%s%s' % (item[0], sorted([getattr(x, 'pk', '') for x in item[1]])) for item in result]
        if {}.fromkeys(results, '')!= {}.fromkeys(c_result, ''):
            check = False
        if not shift_cover and (not check) and (shift.attschedule_set.all().count() > 0):
            raise ValidationError(_('the_shift(%(shift)s) was_using_can_not_modify.'), code='-1', params={'shift': shift})
    else:
        check = False
        shift = AttShift()
    if not check:
        shift.alias = shift_alias
        shift.cycle_unit = shift_unit
        shift.shift_cycle = shift_cycle
        shift.work_weekend = count_weekend
        shift.weekend_type = weekend_type
        shift.work_day_off = count_day_off
        shift.day_off_type = day_off_type
        shift.auto_shift = auto_shift
        shift.save()
        AttShift.delete_time_interval(shift)
        for r in result:
            AttShift.add_time_interval(shift, r[0], r[1])
    if exist_schedule:
        for query_set in exist_schedule:
            query_set.delete()
    cleaned_data['shift'] = shift
def get_weekend():
    from mysite.att.global_cache import C_ATT_RULE
    C_ATT_RULE.action_init()
    att_rule = C_ATT_RULE.value
    weekend = att_rule['weekend']
    return weekend