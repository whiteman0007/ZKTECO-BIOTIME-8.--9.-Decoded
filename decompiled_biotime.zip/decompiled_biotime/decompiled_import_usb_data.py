# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\personnel\\import_usb_data.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:20 UTC (1750673060)

import base64
import datetime
import json
import os
import shutil
import struct
import zipfile
from celery_progress.backend import AbstractProgressRecorder
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from mysite.iclock.models import BioData
from mysite.personnel.models import Employee, Department, Area
from mysite.personnel.utils import format_pin, devicePIN, get_default_company_id
from mysite.utils import progress_record
class ImportUSBData(object):
    progress_recorder = None
    total = 0
    current = 0
    fp_version = '10'
    face_version = '7'
    need_update_old_record = False
    def __init__(self, request, **kwargs):
        self.request = request
        self.progress_recorder = kwargs.pop('progress_recorder', None)
        self.error_info = []
        self.company_id = request.POST.get('company', get_default_company_id())
        self.usb_data_path = settings.UDISK_PATH + '/import/' + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + '/'
        self.default_department = Department.objects.filter(is_default=True, company_id=self.company_id).first()
        self.default_area = Area.objects.filter(is_default=True, company_id=self.company_id).first()
        if not os.path.exists(self.usb_data_path):
            os.makedirs(self.usb_data_path)
        if self.request:
            self.need_update_old_record = self.request.POST['import_type']
            if self.need_update_old_record == '0':
                self.need_update_old_record = False
            else:
                self.need_update_old_record = bool(self.need_update_old_record)
            self.fp_version = self.request.POST['fp_version']
            self.face_version = self.request.POST['face_version']
    def usb_data_import(self):
        f = self.request.FILES.get('import_file', None)
        if not f:
            self.error_info.append(_('import.usb_data.error.noFileSelect'))
        else:
            f_format = str(f).split('.')
            format_list = ['zip']
            if str(f_format[(-1)]) not in format_list:
                self.error_info.append(_('import.usb_data.error.invalidFileType'))
                shutil.rmtree(self.usb_data_path)
        if not self.error_info:
            try:
                z_file = zipfile.ZipFile(f, 'r')
                z_file.extractall(self.usb_data_path)
                z_file.close()
            except Exception as e:
                self.error_info.append(_('import.usb_data.error.unzipFileError'))
                shutil.rmtree(self.usb_data_path)
        if not self.error_info:
            self.data_import()
    def import_fp_from_udisk_bio(self, fp_file, uid_emp_code_dict):
        # irreducible cflow, using cdg fallback
        with open(fp_file, 'r') as f:
            pass
        file = json.load(f)
        if 'fptemplate10' in file:
            fps = file['fptemplate10']
            for index, fp in enumerate(fps):
                    self.current += index + 1
                    progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
                    fp_dict = {}
                    upin = fp['pin']
                    if upin in uid_emp_code_dict:
                        emp_code = uid_emp_code_dict[upin]
                        emp = Employee.objects.filter(emp_code=emp_code, company_id=self.company_id).first()
                        if emp:
                            try:
                                fp_dict['employee'] = emp
                                fp_dict['bio_tmp'] = fp['template']
                                fp_dict['bio_no'] = fp['fingerid']
                                fp_dict['duress'] = fp['isDuress']
                                fp_dict['bio_index'] = 0
                                fp_dict['bio_type'] = 1
                                fp_dict['valid'] = 1
                                fp_dict['major_ver'] = self.fp_version
                                exits_fp = BioData.objects.filter(employee=emp, bio_type=1, bio_no=fp['fingerid'])
                                if exits_fp:
                                    if self.need_update_old_record:
                                        exits_fp.update(**fp_dict)
                                else:
                                    BioData(**fp_dict).save()
                            except:
                                import traceback
                                traceback.print_exc()
    def import_fp_from_udisk(self, fp_file, uid_emp_code_dict):
        # irreducible cflow, using cdg fallback
        try:
            fd = open(fp_file, 'rb')
            tds = fd.read()
            fd.close()
        except Exception as e:
            self.error_info.append(str(e))
            print(e)
            return None
        ds = len(tds)
        sizes = []
        tmps = []
        m = 0
        n = ds
        while n > 0:
            t = struct.unpack('H', tds[m:ds][0:2])[0]
            m = m + t
            n = ds - m
            sizes.append(m)
        sizes.insert(0, 0)
        s = len(sizes) - 1
        for k in range(s):
            h = k + 1
            tmp = tds[sizes[k]:sizes[h]]
            tmps.append(tmp)
        for index, tmp in enumerate(tmps):
            self.current += index
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
            fp_dict = {}
            size = struct.unpack('H', tmp[0:2])[0]
            upin = struct.unpack('H', tmp[2:4])[0]
            fid = tmp[4]
            valid = tmp[5]
            temp = struct.unpack(str(size - 6) + 's', tmp[6:])[0]
            fptemp = base64.b64encode(temp).decode('utf-8', 'ignore')
            if upin in uid_emp_code_dict:
                emp_code = uid_emp_code_dict[upin]
                emp = Employee.objects.filter(emp_code=emp_code, company_id=self.company_id).first()
                if emp and fptemp:
                    try:
                        fp_dict['employee'] = emp
                        fp_dict['bio_tmp'] = fptemp
                        fp_dict['bio_no'] = fid
                        fp_dict['bio_index'] = 0
                        fp_dict['bio_type'] = 1
                        fp_dict['valid'] = valid
                        fp_dict['major_ver'] = self.fp_version
                        exits_fp = BioData.objects.filter(employee=emp, bio_type=1, bio_no=fid)
                        if exits_fp:
                            if self.need_update_old_record:
                                exits_fp.update(**fp_dict)
                        else:
                            BioData(**fp_dict).save()
                    except:
                        import traceback
                        traceback.print_exc()
    def import_face_from_udisk(self, face_file, uid_emp_code_dict):
        try:
            fd = open(face_file, 'rb')
            tds = fd.read()
            fd.close()
        except Exception as e:
            self.error_info.append(str(e))
            print(e)
            return None
        count = len(tds) // 2576
        tmp = {}
        for i in range(count):
            self.current += i + 1
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
            face_dict = {}
            fdata = tds[i * 2576:(i + 1) * 2576]
            size = struct.unpack('H', fdata[0:2])[0]
            uPIN = struct.unpack('H', fdata[2:4])[0]
            FaceId = fdata[4]
            Valid = fdata[5]
            major_ver = struct.unpack('H', fdata[6:8])[0]
            temp = fdata
            bio_tmp = base64.b64encode(temp).decode('utf-8', 'ignore')
            index = divmod(i, 12)[1]
            tmp[str(FaceId)] = bio_tmp
            if index == 11:
                if uPIN in uid_emp_code_dict:
                    emp_code = uid_emp_code_dict[uPIN]
                    emp = Employee.objects.filter(emp_code=emp_code, company_id=self.company_id).first()
                    if emp:
                        try:
                            face_dict['employee'] = emp
                            face_dict['bio_tmp'] = json.dumps(tmp).replace('\n', '').replace('\r', '')
                            face_dict['bio_no'] = 0
                            face_dict['bio_index'] = 0
                            face_dict['bio_type'] = 2
                            face_dict['valid'] = Valid
                            face_dict['major_ver'] = major_ver
                            exist_face = BioData.objects.filter(employee=emp, bio_no=0, major_ver=major_ver, bio_type=2).first()
                            if exist_face:
                                if self.need_update_old_record:
                                    exist_face.update(**face_dict)
                            else:
                                BioData(**face_dict).save()
                        except:
                            import traceback
                            traceback.print_exc()
                tmp = {}
    def import_employee_from_udisk_bio(self, user_file, uid_emp_code_dict):
        with open(user_file, 'r') as f:
            file = json.load(f)
            if 'USER_INFO' in file:
                users = file['USER_INFO']
                emp_dict = {}
                for index, user in enumerate(users):
                    self.current += index + 1
                    progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
                    PIN = format_pin(user['PIN2'])
                    emp_dict['emp_code'] = PIN
                    emp_dict['department_id'] = self.default_department.id
                    emp_dict['dev_privilege'] = user['Privilege']
                    emp_dict['device_password'] = user['Password']
                    emp_dict['first_name'] = user['Name']
                    emp_dict['acc_group'] = user['Group']
                    emp_dict['acc_timezone'] = 0
                    emp_dict['card_no'] = user['Card']
                    uid_emp_code_dict[user['PIN']] = PIN
                    exist_emp = Employee.objects.filter(emp_code=PIN, company_id=self.company_id)
                    if exist_emp:
                        if self.need_update_old_record:
                            try:
                                exist_emp.update(**emp_dict)
                            except Exception as e:
                                self.error_info.append(PIN + str(e))
                                print(e)
                    else:
                        try:
                            new_emp = Employee(**emp_dict)
                            new_emp.company_id = self.company_id
                            new_emp.save()
                            new_emp.area.set([self.default_area])
                            new_emp.save()
                        except Exception as e:
                            self.error_info.append(PIN + str(e))
                            print(e)
    def import_employee_from_udisk(self, user_file, uid_emp_code_dict):
        try:
            fd = open(user_file, 'rb')
            ud = fd.read()
            fd.close()
        except Exception as e:
            self.error_info.append(str(e))
            print(e)
            return None
        count = len(ud) // 72
        emp_dict = {}
        for i in range(count):
            self.current += i + 1
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
            udata = ud[i * 72:(i + 1) * 72]
            pin = struct.unpack('H', udata[0:2])[0]
            pri = udata[2]
            pwd = bytes.decode(struct.unpack('8s', udata[3:11])[0], encoding='utf-8').strip('\x00')
            Name = bytes.decode(struct.unpack('24s', udata[11:35])[0], encoding='utf-8').strip('\x00')
            Card = struct.unpack('L', udata[35:39])[0]
            Group = udata[39]
            uPIN = bytes.decode(struct.unpack('24s', udata[48:72])[0], encoding='utf-8').strip('\x00')
            PIN = format_pin(uPIN)
            emp_dict['emp_code'] = PIN
            emp_dict['department_id'] = self.default_department.id
            emp_dict['dev_privilege'] = pri
            emp_dict['device_password'] = pwd
            emp_dict['first_name'] = Name
            emp_dict['acc_group'] = Group
            emp_dict['acc_timezone'] = 0
            emp_dict['card_no'] = Card if Card > 0 else ''
            uid_emp_code_dict[pin] = PIN
            exist_emp = Employee.objects.filter(emp_code=PIN, company_id=self.company_id)
            if exist_emp:
                if self.need_update_old_record:
                    try:
                        exist_emp.update(**emp_dict)
                    except Exception as e:
                        self.error_info.append(PIN + str(e))
                        print(e)
            else:
                try:
                    new_emp = Employee(**emp_dict)
                    new_emp.company_id = self.company_id
                    new_emp.save()
                    new_emp.area.set([self.default_area])
                    new_emp.save()
                except Exception as e:
                    self.error_info.append(PIN + str(e))
                    print(e)
    def save_bio_data(self, pin, **data):
        emp = Employee.objects.filter(emp_code=pin, company_id=self.company_id).first()
        if emp:
            data.update(employee=emp)
            exist_face = BioData.objects.filter(employee=emp, bio_no=0, major_ver=data['major_ver'], bio_type=data['bio_type'])
            if exist_face:
                if self.need_update_old_record:
                    exist_face.update(**data)
            else:
                BioData(**data).save()
    def import_biodata_from_udisk_bio(self, bio_file):
        from mysite.iclock import const
        with open(bio_file, 'r') as f:
            file = json.load(f)
            if 'Pers_Biotemplate' in file:
                biodatas = file['Pers_Biotemplate']
                for index, biodata in enumerate(biodatas):
                    self.current += index + 1
                    progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
                    pin = biodata['user_pin']
                    bio_type = biodata['bio_type']
                    data_dict = {}
                    data_dict['bio_no'] = biodata['template_no']
                    data_dict['bio_index'] = biodata['template_no_index']
                    data_dict['valid'] = biodata['valid_flag']
                    data_dict['duress'] = biodata['is_duress']
                    data_dict['bio_type'] = bio_type
                    data_dict['major_ver'] = biodata['major_ver']
                    data_dict['minor_ver'] = biodata['minor_ver']
                    data_dict['bio_format'] = biodata['data_format']
                    data_dict['bio_tmp'] = biodata['template_data']
                    if bio_type in (const.bioFinger, const.bioFaceVL):
                        self.save_bio_data(pin, **data_dict)
    def import_biodata_from_udisk(self, bio_file):
        # irreducible cflow, using cdg fallback
        from mysite.iclock import const
        try:
            f = open(bio_file, 'r')
            ts = f.read()
            f.close()
            ts = ts.strip().split('\n')
        except Exception as e:
            self.error_info.append(str(e))
            print(e)
            return None
        tmp_dict = {}
        for i, row in enumerate(ts):
            self.current += i + 1
            progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
            cols = row.split('\t')
            if len(cols) < 10:
                continue
            pin = cols[0].replace('Pin=', '')
            bio_type = int(cols[5].replace('Type=', ''))
            bio_index = int(cols[2].replace('Index=', ''))
            bio_tmp = cols[9].replace('Tmp=', '')
            major_ver = cols[6].replace('MajorVer=', '')
            data_dict = {}
            data_dict['bio_no'] = int(cols[1].replace('No=', ''))
            data_dict['bio_index'] = bio_index
            data_dict['valid'] = int(cols[3].replace('Valid=', ''))
            data_dict['duress'] = int(cols[4].replace('Duress=', ''))
            data_dict['bio_type'] = bio_type
            data_dict['major_ver'] = major_ver
            data_dict['minor_ver'] = cols[7].replace('MinorVer=', '')
            data_dict['bio_format'] = cols[8].replace('Format=', '')
            data_dict['bio_tmp'] = bio_tmp
            if bio_type == const.bioFinger:
                self.save_bio_data(pin, **data_dict)
                if bio_type in (const.bioFace, const.bioHand):
                    if bio_type == const.bioFace and (major_ver == '12' and bio_index == 14 or (major_ver!= '12' and bio_index == 11)):
                        tmp_dict[str(bio_index)] = bio_tmp
                        data_dict['bio_tmp'] = json.dumps(tmp_dict)
                        self.save_bio_data(pin, **data_dict)
                        tmp_dict = {}
                        if bio_type == const.bioHand and bio_index == 4:
                            tmp_dict[str(bio_index)] = bio_tmp
                            data_dict['bio_tmp'] = json.dumps(tmp_dict)
                            self.save_bio_data(pin, **data_dict)
                            tmp_dict = {}
                            tmp_dict[str(bio_index)] = bio_tmp
    def import_biophoto_from_udisk(self, bio_photos):
        from mysite.iclock.comm.utils import get_comm_setting
        from mysite.utils import save_bio_photo
        pins = [devicePIN(photo.rsplit('.', 1)[0]) for photo in bio_photos]
        exists_pins = Employee.objects.filter(emp_code__in=pins, company_id=self.company_id).values_list('emp_code', flat=True)
        extra_pins = set(pins) - set(list(exists_pins))
        if extra_pins:
            self.error_info.append(_('bioPhotoImport_error_userNoFound_{pin}').format(pin=','.join(extra_pins)))
            return
        else:
            approval_state = get_comm_setting('import_policy')
            overwrite = self.need_update_old_record
            ignore_error = False
            bio_photo_path = self.usb_data_path + 'biophoto/face/'
            for index, photo in enumerate(bio_photos):
                self.current += index + 1
                progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.uploading'))
                pin = devicePIN(photo.rsplit('.', 1)[0])
                if pin in extra_pins:
                    continue
                else:
                    emp = Employee.objects.filter(emp_code=format_pin(pin), company_id=self.company_id).first()
                    if not emp.biophoto_set.filter(approval_state__in=(1, 3)):
                        overwrite = True
                    try:
                        with open(bio_photo_path + photo, 'rb') as pf:
                            save_bio_photo(emp, pf, approval_state, overwrite=overwrite, ignore_error=ignore_error)
                    except Exception as e:
                        return str(e)
    def get_records_total(self, user_file, file_names, bio_ufile, bio_files):
        if user_file:
            fd = open(user_file, 'rb')
            ud = fd.read()
            fd.close()
            self.total += len(ud) // 72
        for file_name in file_names:
            fs = 'face' in file_name.lower()
            fp = 'template.fp10' in file_name.lower()
            f = self.usb_data_path + file_name
            if fs:
                fd = open(f, 'rb')
                tds = fd.read()
                fd.close()
                self.total += len(tds) // 2576
            else:
                if fp:
                    fd = open(f, 'rb')
                    tds = fd.read()
                    fd.close()
                    ds = len(tds)
                    sizes = []
                    m = 0
                    n = ds
                    while n > 0:
                        t = struct.unpack('H', tds[m:ds][0:2])[0]
                        m = m + t
                        n = ds - m
                        sizes.append(m)
                    self.total += len(sizes)
        if bio_ufile:
            with open(bio_ufile, 'r') as f:
                file = json.load(f)
                if 'USER_INFO' in file:
                    users = file['USER_INFO']
                    self.total += len(users)
        for file_name in bio_files:
            fp = 'fpTemplate10' in file_name
            biodata = 'persBiotemplate' in file_name
            if fp:
                with open(file_name, 'r') as f:
                    file = json.load(f)
                    if 'fptemplate10' in file:
                        fps = file['fptemplate10']
                        self.total += len(fps)
            if biodata:
                with open(file_name, 'r') as f:
                    file = json.load(f)
                    if 'Pers_Biotemplate' in file:
                        biodatas = file['Pers_Biotemplate']
                        self.total += len(biodatas)
    def get_sub_file(self, path):
        # irreducible cflow, using cdg fallback
        user_file = None
        file_names = []
        files = os.listdir(path)
        for file_name in files:
            if os.path.isfile(path + file_name):
                is_user_file = 'userInfo' in file_name
                if not is_user_file:
                    file_names.append(path + file_name)
                    user_file = path + file_name
        return (user_file, file_names)
    def data_import(self):
        files = os.listdir(self.usb_data_path)
        file_names = []
        fp_file = []
        user_file = None
        bio_ufile = None
        bio_files = []
        bio_photos = []
        for file_name in files:
            if os.path.isdir(self.usb_data_path + file_name):
                if 'userData' in file_name:
                    bio_ufile, bio_files = self.get_sub_file(self.usb_data_path + file_name + '/')
                else:
                    if 'biophoto' in file_name:
                        bio_photos = os.listdir(self.usb_data_path + file_name + '/face/')
                    else:
                        continue
            else:
                is_user_file = 'user' in file_name
                fp = 'template.fp10' in file_name
                if not is_user_file:
                    if fp:
                        fp_file.append(file_name)
                    else:
                        file_names.append(file_name)
                else:
                    user_file = file_name
        if not user_file and (not bio_ufile):
                return
        if fp_file:
            file_names.append(fp_file[0])
        uf = self.usb_data_path + user_file if user_file else None
        uid_emp_code_dict = {}
        self.get_records_total(uf, file_names, bio_ufile, bio_files)
        self.total += len(bio_photos)
        progress_record(self.progress_recorder, self.current, self.total, _('importProgress.status.dataVerification'))
        if uf:
            self.import_employee_from_udisk(uf, uid_emp_code_dict)
        if bio_ufile:
            self.import_employee_from_udisk_bio(bio_ufile, uid_emp_code_dict)
        for file_name in file_names:
            fs = 'face' in file_name.lower()
            fp = 'template.fp10' in file_name.lower()
            bio = 'biotemplate' in file_name.lower()
            f = self.usb_data_path + file_name
            if fs:
                self.import_face_from_udisk(f, uid_emp_code_dict)
            else:
                if fp:
                    self.import_fp_from_udisk(f, uid_emp_code_dict)
                else:
                    if bio:
                        self.import_biodata_from_udisk(f)
        for file_name in bio_files:
            fp = 'fpTemplate10' in file_name
            bio = 'persBiotemplate' in file_name
            if fp:
                self.import_fp_from_udisk_bio(file_name, uid_emp_code_dict)
            else:
                if bio:
                    self.import_biodata_from_udisk_bio(file_name)
        if bio_photos:
            self.import_biophoto_from_udisk(bio_photos)
        try:
            shutil.rmtree(self.usb_data_path)
        except Exception as e:
            print(e)