# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\forms\\leave_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

from django.utils.translation import gettext_lazy as _
from django.forms.widgets import HiddenInput
from mysite.admin import forms
from mysite.att.models import PayCode
from mysite.personnel.models import Employee
class EmployeeLeaveGetForm(forms.ZKActionForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset(), disabled=True)
    pay_code = forms.ModelChoiceField(label=_('leave.fields.payCode'), queryset=PayCode.objects.get_leave_queryset())
    start_time = forms.DateTimeField(label=_('leave_field_startTime'))
    end_time = forms.DateTimeField(label=_('leave_field_endTime'))
    auto_approve = forms.BooleanField(label=_('leave.fields.autoApproved'), initial=True, required=False)
    apply_reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    leave_day = forms.FloatField(label=_('leave.fields.leaveDay'), initial=0, suffix=_('time.units.day'))
    permission = None
    def __init__(self, request, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        from mysite.att.models import PayloadTimeCard
        import datetime
        self.permission = APPROVAL_APPROVE_PERMISSION.get('leave')
        super(EmployeeLeaveGetForm, self).__init__(*args, **kwargs)
        emp_id = request.GET.get('emp_id', None)
        att_date = request.GET.get('att_date', None)
        timetable_id = request.GET.get('timetable_id', None)
        if not timetable_id:
            timetable_id = None
        if att_date:
            att_date = datetime.datetime.strptime(att_date, '%Y-%m-%d')
        if not emp_id:
            return
        else:
            obj = PayloadTimeCard.objects.filter(emp_id=emp_id, att_date=att_date, time_table_id=timetable_id).first()
            if not obj:
                return
            else:
                self.fields['employee'].queryset = Employee.objects.filter(id=emp_id)
                self.fields['employee'].initial = obj.emp
                self.fields['start_time'].initial = obj.check_in
                self.fields['end_time'].initial = obj.check_out
                if not request.user.has_perm(self.permission) or isinstance(request.user, Employee):
                    self.fields['auto_approve'].widget = HiddenInput()
                    self.fields['auto_approve'].initial = False
class EmployeeLeavePostForm(EmployeeLeaveGetForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset())