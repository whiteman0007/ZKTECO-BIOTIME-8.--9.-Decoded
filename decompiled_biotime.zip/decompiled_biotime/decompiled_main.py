# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\calc_new\\main.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
import logging
import redis_lock
from django.conf import settings
from django.core.cache import cache
from mysite.att.calc_new.calc_interval import calc_no_interval, calc_interval
from mysite.att.calc_new.calc_interval_detail import auto_shift_interval
from mysite.att.calc_new.calc_prepare import get_transaction_dict, get_employee_policy, get_employee_overtime, get_employee_leave, get_employee_schedule, get_employee_training, get_leave_group_detail
from mysite.att.calc_new.calc_save import save_payload
from mysite.att.calc_new.utils import get_punch_states, cache_data, sche_pprint, payload_pprint
from mysite.att.calc_new.week_calendar import CustomizedCalendar
from mysite.att.models import TimeInterval, PayCode, AttCode, PayloadTimeCard
from mysite.base.models import SystemSetting
from mysite.personnel.models import Employee
from mysite.utils import get_dt4mssql
REGULAR, FLEXIBLE = (0, 1)
REGULAR_SCHEDULE, TEMPORARY_SCHEDULE = (1, 2)
logger = logging.getLogger('att_calc')
def personnel_att_calculate(emp, start_date, end_date, interval_cache=None, break_cache=None, otp_cache=None, pc_cache=None, ac_cache=None, punch_state_cache=None, pc_id_cache=None, wc_cache=None, raise_exception=False):
    # irreducible cflow, using cdg fallback
    from mysite.iclock.models import TerminalWorkCode
    if not isinstance(emp, Employee):
        emp = Employee.objects.filter(id=emp).select_related('attemployee', 'resign', 'department').first()
        if not emp:
            return
    if not hasattr(emp, 'attemployee'):
        logger.exception('calc employee: %s error, no attemployee' % emp.emp_code)
        return
    else:
        if not emp.attemployee or not emp.attemployee.enable_attendance:
            return None
        else:
            logger.info('start calc employee: %s, %s --> %s' % (emp.emp_code, start_date, end_date))
            interval_dict = interval_cache if interval_cache else {}
            break_dict = break_cache if break_cache else {}
            otp_dict = otp_cache if otp_cache else {}
            if pc_cache:
                pc_dict = pc_cache
            else:
                pc_dict = {i.id: i for i in PayCode.objects.all()}
            if ac_cache:
                ac_dict = ac_cache
            else:
                ac_dict = {i.code: i for i in AttCode.objects.all()}
            if pc_id_cache:
                pc = pc_id_cache
            else:
                pc = {'regular': PayCode.regular().id, 'late_in': PayCode.late_in().id, 'early_out': PayCode.early_out().id, 'absent': PayCode.absent().id}
            if punch_state_cache:
                punch_state_dict = punch_state_cache
            else:
                punch_state_dict = get_punch_states()
            if wc_cache:
                wc_dict = wc_cache
            else:
                wc_dict = {wc.code: wc for wc in TerminalWorkCode.objects.all()}
            if emp.hire_date:
                start_date = start_date if start_date > get_dt4mssql(emp.hire_date, 1) else get_dt4mssql(emp.hire_date, 1)
            if emp.resign_date:
                end_date = end_date if end_date < get_dt4mssql(emp.resign_date, 1) else get_dt4mssql(emp.resign_date, 1)
            transaction = get_transaction_dict(emp, start_date, end_date, punch_state_dict)
            policy = get_employee_policy(emp)
            if hasattr(emp, 'attemployee'):
                policy.enable_compensatory = policy.enable_compensatory and emp.attemployee.enable_compensatory
            schedule = get_employee_schedule(emp, start_date, end_date)
            overtime = get_employee_overtime(emp, start_date, end_date)
            leave = get_employee_leave(emp, start_date, end_date)
            training = get_employee_training(emp, start_date, end_date)
            leave_group_detail = get_leave_group_detail(emp)
            start_of_week = policy.start_of_week
            if start_of_week == 7:
                start_of_week = SystemSetting.cache_data('week_setting', _dict=True).get('start_of_week', 0)
            customized_calendar = CustomizedCalendar(start_weekday=start_of_week + 1)
            cur_date = start_date - datetime.timedelta(days=1)
    while cur_date < end_date:
        pass
    cur_date += datetime.timedelta(days=1)
    next_date = cur_date + datetime.timedelta(days=1)
    emp_att_calc_lock = redis_lock.Lock(cache.client.get_client(write=True), 'ATT_CALC_LOCK:%s_%s' % (emp.id, cur_date), expire=60)
    if not emp_att_calc_lock.acquire(blocking=False):
        pass
    logging.getLogger('task').debug('%s_%s lock.acquire: False' % (emp.id, cur_date))
    break
    try:
        day_sche = schedule.get(cur_date)
        year, week, week_day = customized_calendar.calc_y_m_d(cur_date)
        base_data = {'emp': emp, 'att_date': cur_date, 'weekday': cur_date.weekday(), 'week': week, 'year': year}
        intervals = day_sche.get('intervals')
        if not intervals:
            transactions = transaction[cur_date]
            transactions.extend(transaction[cur_date + datetime.timedelta(days=1)])
            leaves = leave[cur_date]
            trainings = training[cur_date]
            overtimes = overtime[cur_date]
            if settings.LOGGING_ATT_CALC:
                sche_pprint(base_data, day_sche, transactions, leaves, overtimes, policy, interval_dict)
            payload = calc_no_interval(emp, cur_date, base_data, policy, transactions, overtimes, leaves, otp_dict, pc_dict, ac_dict, punch_state_dict, pc, trainings, wc_dict, leave_group_detail)
            if settings.LOGGING_ATT_CALC:
                payload_pprint(payload)
            PayloadTimeCard.objects.filter(emp=emp, att_date=cur_date).delete()
            save_payload(payload, policy)
        else:
            is_temp_sche = True if day_sche['sche_type'] == 'temp_sche' else False
            holiday = day_sche.get('holiday')
            shift = day_sche.get('shift_obj')
            if shift and shift.auto_shift:
                    transactions = []
                    leaves = []
                    last_leave_id = None
                    _temp_date = cur_date - datetime.timedelta(days=3)
                    out_date = cur_date + datetime.timedelta(days=3)
                    while _temp_date < out_date:
                        _temp_date += datetime.timedelta(days=1)
                        if transaction[_temp_date]:
                            transactions += transaction[_temp_date]
                        if leave[_temp_date]:
                            if last_leave_id == leave[_temp_date][0]['id']:
                                leaves += leave[_temp_date][1:]
                            else:
                                leaves += leave[_temp_date]
                            if leaves:
                                last_leave_id = leaves[(-1)]['id']
                    intervals = auto_shift_interval(cur_date, transactions, intervals, interval_dict, leaves)
            payload_list = []
            for _id in intervals:
                interval = cache_data(interval_dict, _id, TimeInterval)
                in_time = datetime.datetime.combine(cur_date, get_dt4mssql(interval.in_time, 2))
                out_time = in_time + datetime.timedelta(minutes=interval.duration)
                in_date = (in_time - datetime.timedelta(minutes=interval.in_ahead_margin)).date()
                out_date = (out_time + datetime.timedelta(minutes=interval.out_above_margin)).date()
                transactions = []
                leaves = []
                trainings = []
                overtimes = []
                last_leave_id = None
                last_overtime_id = None
                last_training_id = None
                _temp_date = in_date - datetime.timedelta(days=1)
                while _temp_date < out_date:
                    _temp_date += datetime.timedelta(days=1)
                    if transaction[_temp_date]:
                        transactions += transaction[_temp_date]
                    if leave[_temp_date]:
                        if last_leave_id == leave[_temp_date][0]['id']:
                            leaves += leave[_temp_date][1:]
                        else:
                            leaves += leave[_temp_date]
                        if leaves:
                            last_leave_id = leaves[(-1)]['id']
                    if training[_temp_date]:
                        if last_training_id == training[_temp_date][0]['id']:
                            trainings += training[_temp_date][1:]
                        else:
                            trainings += training[_temp_date]
                        if trainings:
                            last_training_id = trainings[(-1)]['id']
                    if overtime[_temp_date]:
                        if last_overtime_id == overtime[_temp_date][0]['id']:
                            overtimes += overtime[_temp_date][1:]
                        else:
                            overtimes += overtime[_temp_date]
                        if overtimes:
                            last_overtime_id = overtimes[(-1)]['id']
                if settings.LOGGING_ATT_CALC:
                    sche_pprint(base_data, day_sche, transactions, leaves, overtimes, policy, interval_dict)
                data = base_data.copy()
                payload = calc_interval(emp, cur_date, data, policy, interval, holiday, is_temp_sche, transactions, overtimes, leaves, break_dict, otp_dict, pc_dict, ac_dict, punch_state_dict, pc, trainings, wc_dict)
                if settings.LOGGING_ATT_CALC:
                    payload_pprint(payload)
                payload_list.append(payload)
            PayloadTimeCard.objects.filter(emp=emp, att_date=cur_date).delete()
            for payload in payload_list:
                save_payload(payload, policy)
    except Exception as e:
        logger.exception('calc: %s_%s error' % (emp.id, cur_date))
        if raise_exception:
            raise e
    emp_att_calc_lock.release()