# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\admin\\applist_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from mysite import admin
from mysite.mobile import actions
from mysite.mobile.models import AppList
@admin.register(AppList)
class AppListAdmin(admin.ZKModelAdmin):
    list_display = ('username', 'login_time', 'last_active', 'client_id', 'device_token', 'client_category', 'active', 'enable')
    sort_fields = ('username', 'enable')
    list_filter = ('username', 'active', 'enable', 'login_time')
    actions = [actions.force_offline, actions.disable, actions.enable]
    @staticmethod
    def initial_data():
        from django.db.models import Count
        accounts = AppList.objects.values('username').annotate(num=Count('id'))
        for account in accounts:
            if account['num'] == 1:
                continue
            else:
                apps = AppList.objects.filter(username=account['username'])
                apps.delete()
    def get_queryset(self, request):
        from mysite.personnel.models.model_employee import Employee
        qs = super(AppListAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                emp = Employee.objects.filter(department__in=request.user.auth_dept.all())
                name_list = [e.emp_code for e in emp] if emp else []
                qs = qs.filter(username__in=name_list)
            if request.user.auth_area.exists():
                emp = Employee.objects.filter(area__in=request.user.auth_area.all()).distinct()
                name_list = [e.emp_code for e in emp] if emp else []
                qs = qs.filter(username__in=name_list)
        return qs