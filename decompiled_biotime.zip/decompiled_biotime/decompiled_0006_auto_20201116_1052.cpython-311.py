# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0006_auto_20201116_1052.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0005_auto_20201106_1538')]
    operations = [migrations.AlterField(model_name='attcode', name='round_off', field=models.SmallIntegerField(choices=[(1, 'attCode.roundOffOpts.roundOff'), (2, 'attCode.roundOffOpts.roundUp'), (3, 'attCode.roundOffOpts.roundDown')], default=1, verbose_name='attCode.fields.roundOff'))]