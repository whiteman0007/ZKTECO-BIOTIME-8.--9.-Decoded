# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\deptschedule_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

import datetime
from django.utils.translation import gettext_lazy as _
from django.forms import ModelForm, ValidationError, ModelMultipleChoiceField
from mysite.admin import forms, ZKModelAction
from mysite.personnel.models import Department
from mysite.att.models import DepartmentSchedule, TimeInterval, AttShift, ShiftDetail
from mysite.att.company_form import CompanyField4ActionForm
class AddDepartmentScheduleForm(CompanyField4ActionForm):
    schd_department = ModelMultipleChoiceField(queryset=Department.objects.get_queryset(), required=False)
    start_date = forms.DateField(label=_('deptSchedule_field_startDate'))
    end_date = forms.DateField(label=_('deptSchedule_field_endDate'))
    shift = forms.ModelChoiceField(queryset=AttShift.objects.get_queryset(), required=False)
    class Meta:
        model = DepartmentSchedule
        fields = '__all__'
        exclude = ['department']
    def clean(self):
        cleaned_data = super(AddDepartmentScheduleForm, self).clean()
        department = cleaned_data.get('schd_department', None)
        shift = cleaned_data.get('shift', None)
        start_date = cleaned_data.get('start_date', None)
        end_date = cleaned_data.get('end_date', None)
        if not department:
            raise ValidationError(_('scheduledAssign_error_deptNotFound'), code='-1')
        else:
            if not shift:
                raise ValidationError(_('scheduledAssign_error_shiftNotFound'), code='-1')
            else:
                if not start_date or not end_date:
                    raise ValidationError(_('scheduledAssign_error_datePeriodError'), code='-1')
                else:
                    if start_date >= end_date:
                        raise ValidationError(_('scheduledAssign_error_datePeriodError'), code='-1')
                    else:
                        overlaps = DepartmentSchedule.objects.filter(department__in=department, start_date__lte=end_date, end_date__gte=start_date)
                        if overlaps.exists():
                            overlap = overlaps.first()
                            raise ValidationError(_('scheduledAssign_error_schdOverlap_%(obj)s_%(start_date)s_%(end_date)s'), code='-1', params={'obj': overlap.department.dept_name, 'start_date': overlap.start_date.strftime('%Y-%m-%d'), 'end_date': overlap.end_date.strftime('%Y-%m-%d')})
                        else:
                            return cleaned_data
    def save(self, commit=True):
        start_date = self.cleaned_data['start_date']
        end_date = self.cleaned_data['end_date']
        shift = self.cleaned_data['shift']
        department = self.cleaned_data['schd_department']
        for dept in department:
            DepartmentSchedule(department=dept, start_date=start_date, end_date=end_date, shift=shift).save(force_insert=True)
class AddDepartmentSchedule(ZKModelAction):
    verbose_name = _('deptSchedule_action_add')
    short_description = _('deptSchedule_action_addDescription')
    help_txt = _('deptSchedule_action_addHelpTxt')
    action_form = AddDepartmentScheduleForm
    def action(self, *args, **kwargs):
        form = AddDepartmentScheduleForm(self.request.POST)
        if form.is_valid():
            form.save()