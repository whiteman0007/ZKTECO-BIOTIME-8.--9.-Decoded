# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\basic_setting.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

from rest_framework import serializers
class BasicSettingSerializer(serializers.Serializer):
    host = serializers.CharField(default='')
    def validate_host(self, host: str):
        if host.startswith('https://'):
            host = host.lstrip('https://')
        if host.startswith('http://'):
            host = host.lstrip('http://')
        return host.rstrip('/')