# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\base\\migrations\\0012_linenotifysetting_send_photo_linenotifyforemployee.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:24 UTC (1750702704)

from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies = [('personnel', '0012_901_attr_type_change'), ('base', '0011_901_backup_db_encrypt')]
    operations = [migrations.AddField(model_name='linenotifysetting', name='send_photo', field=models.BooleanField(default=True, verbose_name='lineNotify_field_sendPhoto')), migrations.CreateModel(name='LineNotifyForEmployee', model_name='id', field=models.AutoField(help_text=True, max_length=True, null=False, verbose_name='ID')), ('send_photo', models.CharField(blank=True, max_length=200, null=True, verbose_name='lineNotify_field_pushTime')), ('message_head', models.CharField(blank=True, max_length=100, null=True, verbose_name='lineNotify_field_messageTail')), ('employee', models.OneToOneField(0=django.db.models.deletion.CASCADE, enableStatus_option_disable=True, lineNotify_field_isValid=True, choices=True, remark=True, lineNotify_field_remark=True, message_type=True, 100=True, Attendance record=True, lineNotify_field_messageType=True, message_head=True, lineNotify_field_messageHead=True, message_tail=True, lineNotify_field_messageTail=True, employee=True, OneToOneField=True, django