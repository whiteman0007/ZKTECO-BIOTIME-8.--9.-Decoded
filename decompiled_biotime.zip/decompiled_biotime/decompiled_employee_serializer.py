# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\employee_serializer.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from django.conf import settings
from mysite.personnel.models import Employee
class EmployeeSerializer(serializers.ModelSerializer):
    photo = serializers.SerializerMethodField()
    first_name = serializers.SerializerMethodField()
    def get_first_name(self, obj):
        return obj.first_name or obj.emp_code
    def get_photo(self, obj):
        if not obj.photo:
            return ''
        else:
            import os
            from mysite.tools.access_utils import get_access_token
            file_path = str(obj.photo.name)
            filename = os.path.basename(file_path)
            access_token = get_access_token({'n': filename, 'p': file_path})
            if settings.ENABLE_ENCRYPT_PHOTO:
                return '/auth_files/{path}'.format(path=access_token)
            else:
                return '/files/{path}'.format(path=access_token)
    class Meta:
        model = Employee
        fields = ('id', 'emp_code', 'first_name', 'email', 'mobile', 'photo')