# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\_utils\\log_filter\\log.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

import logging
class LoggingSqlQueryConsole(logging.Filter):
    def filter(self, record):
        from mysite import settings
        return settings.LOGGING_SQL_QUERY_CONSOLE
class LoggingSqlQueryFIle(logging.Filter):
    def filter(self, record):
        from mysite import settings
        return settings.LOGGING_SQL_QUERY_FILE
class Skip404File(logging.Filter):
    def filter(self, record):
        if record.status_code == 404:
            return False
        else:
            return True