# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\forms\\feedback_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:12 UTC (1750672992)

from django.conf import settings
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
FEEDBACK_TYPE = (('Suggestion', _('feedback.typeOpts.suggestion')), ('Bug', _('feedback.typeOpts.bug')), ('Others', _('feedback.typeOpts.others')))
FEEDBACK_MODULE = (('Personnel', _('menu_personnel')), ('Device', _('menu_terminal')), ('Attendance', _('menu_attendance')), ('Access control', _('menu_access')), ('Payroll', _('menu_payroll')), ('Visitor', _('menu.visitor')), ('Meeting', _('app.menus.meeting')), ('System', _('menu_system')), ('Staff Attendance', _('menu_payroll')), ('Staff Payroll', _('menu_payroll')), ('Staff Visitor', _('menu.visitor')), ('Staff Meeting', _('app.menus.meeting')), ('Others', _('feedback.typeOpts.others')))
class FeedbackForm(forms.ZKActionForm):
    name = forms.CharField(label=_('feedback.fields.name'), required=True)
    country = forms.CharField(label=_('license_active_customerInfoForm_country'), required=True)
    email = forms.EmailField(label=_('feedback.fields.email'))
    type = forms.ChoiceField(label=_('feedback.fields.type'), choices=FEEDBACK_TYPE)
    module = forms.ChoiceField(label=_('feedback.fields.module'), choices=FEEDBACK_MODULE)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    description = forms.TextField(label=_('feedback.fields.description'))
    emp_count = forms.CharField(label=_('feedback.emp.count'), required=False)
    device_count = forms.CharField(label=_('feedback.device.count'), required=False)
    company_name = forms.CharField(label=_('feedback_fields_companyName'))
    phone_number = forms.CharField(label=_('feedback_fields_phoneNumber'), required=False)
    address = forms.TextField(label=_('feedback_fields_address'), widget=forms.ZKTextInput)
    def __init__(self, *args, **kwargs):
        from mysite.personnel.models import Employee
        from mysite.iclock.models import Terminal
        super(FeedbackForm, self).__init__(*args, **kwargs)
        self.fields['emp_count'].initial = Employee.objects.count()
        self.fields['device_count'].initial = Terminal.objects.count()