# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\iclock\\admin\\errorcmd_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:34 UTC (1750673014)

from django.utils.translation import gettext_lazy as _
from mysite import admin
from mysite.iclock.models import ErrorCommandLog
@admin.register(ErrorCommandLog)
class ErrorCommandLogAdmin(admin.ZKModelAdmin):
    def terminal_sn(self, obj):
        return obj.terminal.sn
    terminal_sn.short_description = _('terminal_field_sn')
    def terminal_alias(self, obj):
        return obj.terminal.alias
    terminal_alias.short_description = _('terminal_field_alias')
    list_display = ('terminal_sn', 'terminal_alias', 'error_code', 'error_msg', 'data_origin', 'cmd', 'additional', 'upload_time')
    sort_fields = ('upload_time',)
    ordering = ('-upload_time',)
    list_filter = ('terminal__sn', 'terminal__alias', 'error_code', 'upload_time')
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        qs = super(ErrorCommandLogAdmin, self).get_queryset(request)
        if not request.user.is_superuser and request.user.auth_area.exists():
                qs = qs.filter(terminal__area__in=request.user.auth_area.all())
        if not request.user.is_superuser and request.user.assign_company:
                qs = qs.filter(terminal__area__company=request.user.assign_company)
        return qs