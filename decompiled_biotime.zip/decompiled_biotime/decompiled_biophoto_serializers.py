# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\iclock\\api\\serializers\\biophoto_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:35 UTC (1750673015)

from rest_framework import serializers
from mysite.iclock.models.model_biophoto import BioPhoto
class BioPhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = BioPhoto
        fields = '__all__'
class BioPhotoCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = BioPhoto
        fields = '__all__'
class BioPhotoEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = BioPhoto
        fields = '__all__'
        extra_kwargs = {'emp_code': {'required': False, 'allow_null': False}}
class BioPhotoUploadSerializer(serializers.ModelSerializer):
    employee = serializers.CharField()
    photo = serializers.CharField()
    class Meta:
        model = BioPhoto
        fields = ['employee', 'photo']