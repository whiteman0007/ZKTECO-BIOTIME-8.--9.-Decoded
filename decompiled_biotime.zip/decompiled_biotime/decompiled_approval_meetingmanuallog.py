# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff_meeting\\models\\approval_meetingmanuallog.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:35 UTC (1750673075)

from mysite.meeting.models import MeetingManualLog
class ApprovalMeetingManualLog(MeetingManualLog):
    def get_template_base_root(self):
        return 'meeting/meetingmanuallog'
    class Meta:
        default_permissions = ()
        app_label = 'staff_meeting'
        proxy = True