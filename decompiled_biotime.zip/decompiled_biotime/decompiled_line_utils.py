# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\line\\line_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:13 UTC (1750672993)

import os
import time
import datetime
import json
import glob
import ntpath
import os.path
import logging
import requests
from PIL import Image
from django.conf import settings
from django.db.models import IntegerField, TimeField, Value, Q
from django.db.models.functions import Cast
from django.core.cache import cache
from django.utils.translation import override, gettext_lazy as _
from mysite.base.tasks import send_message2line_notify, send_message2line_notify_error_handler
from mysite.base.line.line_notify import LineNotify
from mysite.personnel.models import Employee, Department
from mysite.iclock.choices import VERIFY_TYPE, PUNCH_STATE
from mysite.accounts.models.user_profile import UserProfile
from mysite.base.models.line_notify_setting import get_line_notify_send_flag
from mysite.base.admin.line_notify_setting_admin import LINE_NOTIFY_SERVICE
from mysite.base.models import SystemSetting, LineNotifyForEmployee
from mysite.att.models import TemporarySchedule, ShiftDetail, AttPolicy, DepartmentSchedule, GroupSchedule, AttSchedule
from mysite.tools.image_utils import decrypt_image, encrypt_image
from mysite.utils import createDir
LINE_NOTIFY_TRANSACTION_FILE = settings.ADDITION_FILE_ROOT + 'line/line_notify_transaction/'
LINE_NOTIFY_TRANSACTION_ALERT_FILE = settings.ADDITION_FILE_ROOT + 'line/line_notify_transaction_alert/'
LINE_LATEIN_EARLYOUT_MESSAGE = settings.ADDITION_FILE_ROOT + 'line/latein_earlyout_messages/'
SEND_LINE_NOTIFY_FAIL_HANDLED = 'write_transaction_{emp_code}'
LN_EMP_IMAGE_CACHE_KEY = 'emp_im_{emp_code}_{token}'
LN_TOKEN_IMAGE_REMAIN_CACHE_KEY = 'im_remain_{token}'
logger = logging.getLogger('lineapp')
MATCHED_DAYS = {0: 6, 1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5}
def get_tuple_value(index, BASE_TUPLE):
    """\n    根据index获取元组定义的值\n    tupel eg: tuple=(\n        (\'0\',_(\"check in\")),\n        (\'1\',_(\"check out\")),\n    )\n    无匹配时返回index\n    """
    for t in BASE_TUPLE:
        if isinstance(t, tuple) and index == t[0]:
            return t[(-1)]
    return index
def line_notify_transaction_dir():
    ret = LINE_NOTIFY_TRANSACTION_FILE
    try:
        if not os.path.isdir(ret):
            os.makedirs(ret)
    except:
        pass
    return ret
def line_notify_transaction_alert_dir():
    ret_alert = LINE_NOTIFY_TRANSACTION_ALERT_FILE
    try:
        if not os.path.isdir(ret_alert):
            os.makedirs(ret_alert)
    except:
        pass
    return ret_alert
def write_line_notify_transaction(recordDict):
    """\n    把考勤机和App端上传的考勤记录暂时存放在文件中\n    :param recordDict: {\n        \'emp_code\': emp.emp_code, \'punch_time\': log_time(datetime), \'punch_state\': normalState(flds[2]),\n        \'verify_type\': normalVerify(flds[3]), \'terminal_sn\': device.sn, \'terminal_alias\': device.alias,\n        \'area_alias\': device.area.area_name, \'work_code\': flds[4], \'crc\': crc_code, \'upload_time\': nt,\n        \'purpose\': purpose, \'emp_id\': emp.pk, \'terminal_id\': device.pk\n    }\n    :return:\n    """
    line_notify_send_flag = get_line_notify_send_flag()
    line_notify_for_emp = LineNotifyForEmployee.get_obj(recordDict['emp_code'])
    if line_notify_send_flag or line_notify_for_emp:
        time_stamp = time.time()
        name = '%s_%s_%s.txt' % (recordDict['terminal_sn'], recordDict['emp_code'], int(time_stamp))
        fn = '%s/%s' % (line_notify_transaction_dir(), name)
        if str(recordDict['verify_type']) == '101' and 'location' in recordDict:
            location = recordDict['location']
        else:
            location = ''
        if 'is_mask' in recordDict:
            is_mask = recordDict['is_mask']
        else:
            is_mask = ''
        if 'temperature' in recordDict:
            temperature = recordDict['temperature']
        else:
            temperature = ''
        text = '{emp_code}\t{punch_time}\t{punch_state}\t{verify_type}\t{terminal_sn}\t{terminal_alias}\t{location}\t{is_mask}\t{temperature}'.format(emp_code=recordDict['emp_code'], punch_time=recordDict['punch_time'], punch_state=recordDict['punch_state'], verify_type=recordDict['verify_type'], terminal_sn=recordDict['terminal_sn'], terminal_alias=recordDict['terminal_alias'], location=location, is_mask=is_mask, temperature=temperature)
        with open(fn, 'w+', encoding='utf-8') as f:
            f.write(text)
        cache.set(SEND_LINE_NOTIFY_FAIL_HANDLED.format(emp_code=recordDict['emp_code']), 1, 120)
def write_line_notify_transaction_alert(kwargs):
    line_notify_send_flag = get_line_notify_send_flag()
    line_notify_for_emp = LineNotifyForEmployee.get_obj(kwargs['emp_code'])
    if line_notify_send_flag or line_notify_for_emp:
        time_stamp = time.time()
        name = 'alert_%s_%s.txt' % (kwargs['emp_code'], int(time_stamp))
        fn = '%s/%s' % (line_notify_transaction_alert_dir(), name)
        result = json.dumps(kwargs)
        with open(fn, 'w+', encoding='utf-8') as f:
            f.write(result)
        cache.set(SEND_LINE_NOTIFY_FAIL_HANDLED.format(emp_code=kwargs['emp_code']), 1, 120)
def read_line_notify_transaction_file():
    """\n    读取新上传的考勤记录文件\n    """
    ret_path = LINE_NOTIFY_TRANSACTION_FILE
    ret_file = None
    for root, dirs, files in os.walk(LINE_NOTIFY_TRANSACTION_FILE, topdown=True):
        if files and root == LINE_NOTIFY_TRANSACTION_FILE:
                ret_file = files
                break
    return (ret_path, ret_file)
def read_line_notify_transaction_file_alert():
    files = []
    folder_path = LINE_NOTIFY_TRANSACTION_ALERT_FILE
    if len(glob.glob(folder_path + 'alert_*.txt')) > 0:
        for path in glob.glob(folder_path + 'alert_*.txt'):
            files.append(ntpath.basename(path))
    return (folder_path, files)
def convert_image_format(img_path, new_image_name=None, new_format='jpeg', thumbnail=None, new_dir=None):
    # irreducible cflow, using cdg fallback
    """\n    转换图片的格式\n    :param img_path: 被转换的图片路径\n    :param new_image_name: 新图片的名称 类型是string 默认是原图片名称\n    :param new_format: 把图片转换成什么格式 类型是string\n    :param thumbnail: 把图片缩略的倍数 类型是int\n    :param new_dir: 转换后的图片存放的路径（提供的路径要提前创建好），默认存放在原图片所在的路径下\n    :return: 转换成功时返回新图片的路径，转换失败返回None\n    """
    try:
        Image.open(img_path).verify()
    except Exception:
        return None
    base_path, image_name = os.path.split(img_path)
    if new_image_name is not None:
        image_name = new_image_name
    if new_dir is not None and os.path.isdir(new_dir):
        new_img_path = os.path.join(new_dir, image_name.rsplit('.', 1)[0] + '.' + new_format)
    else:
        new_img_path = os.path.join(base_path, image_name.rsplit('.', 1)[0] + '.' + new_format)
    im = Image.open(img_path)
    if thumbnail is not None and thumbnail!= 0:
            width, height = im.size
            im.thumbnail((width // thumbnail, height // thumbnail))
    width, height = im.size
    if width > 1024 or height > 1024:
        basewidth = 500
        wpercent = basewidth / float(width)
        hsize = int(float(height) * float(wpercent))
        im = im.resize((basewidth, hsize), Image.ANTIALIAS)
        im.save(new_img_path)
        return new_img_path
        im.save(new_img_path)
        return new_img_path
            except Exception:
                    return None
def get_line_notify_service():
    """ 获取配置的line notify service信息 """
    line_sys = SystemSetting.objects.filter(name=LINE_NOTIFY_SERVICE).first()
    if line_sys:
        return json.loads(line_sys.value)
    else:
        return {}
def line_notify_authorize(authorize_code):
    """\n    文档地址：https://notify-bot.line.me/doc/en/\n    line notify api authorize: https: //notify-bot.line.me/oauth/authorize\n    line notify api token: https://notify-bot.line.me/oauth/token\n    使用line notify api authorize返回的code 请求line notify api token获取access_token\n    """
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    data = dict(grant_type='authorization_code', code=authorize_code)
    line_sys_service = get_line_notify_service()
    data['redirect_uri'] = line_sys_service['callback_url']
    data['client_id'] = line_sys_service['client_id']
    data['client_secret'] = line_sys_service['client_secret']
    r = requests.post('https://notify-bot.line.me/oauth/token', headers=headers, data=data, timeout=5)
    return json.loads(r.text)
def get_user_lang():
    try:
        user_lang = UserProfile.objects.first()
        if user_lang.preferences:
            try:
                lang = json.loads(user_lang.preferences)['language']
            except KeyError as e:
                lang = 'en'
        else:
            lang = 'en'
    except Exception as e:
        lang = 'en'
    return lang
def get_hour_minute_seconds(time_str, minute):
    h, m, s = time_str.split(':')
    result = int(h) * 3600 + (int(m) + minute) * 60 + int(s)
    return str(datetime.timedelta(seconds=result))
def get_late_early_out(check_in_out, minute):
    return get_hour_minute_seconds(check_in_out, minute)
def get_check_out_start_end_time(check_in, duration, out_ahead_margin, out_above_margin):
    cur = datetime.datetime(2019, 1, 1).date()
    check_in = datetime.datetime.combine(cur, check_in)
    check_out = check_in + datetime.timedelta(minutes=duration)
    begin_out = check_out - datetime.timedelta(minutes=out_ahead_margin)
    end_out = check_out + datetime.timedelta(minutes=out_above_margin)
    return (begin_out.strftime('%H:%M:%S'), end_out.strftime('%H:%M:%S'))
def get_check_in_start_end_time(check_in, in_ahead_margin, in_above_margin):
    cur = datetime.datetime(2019, 1, 1).date()
    check_in = datetime.datetime.combine(cur, check_in)
    begin_in = check_in - datetime.timedelta(minutes=in_ahead_margin)
    result = check_in + datetime.timedelta(minutes=in_above_margin)
    return (begin_in.strftime('%H:%M:%S'), result.strftime('%H:%M:%S'))
def get_check_in_time(emp, start_date, end_date):
    def get_check_in_start_end_time_result(result):
        if result.get('allow_late'):
            check_in_time = result.get('check_in')
            in_above_margin = result.get('in_above')
            in_ahead_margin = result.get('in_ahead')
            check_in_start_end_time = get_check_in_start_end_time(check_in_time, in_ahead_margin, in_above_margin)
            check_in = str(check_in_time)
            check_in_result = get_late_early_out(check_in, result.get('allow_late'))
            return (check_in_result, check_in_start_end_time[0], check_in_start_end_time[1])
        else:
            check_in = result.get('check_in')
            in_above_margin = result.get('in_above')
            in_ahead_margin = result.get('in_ahead')
            check_in_start_end_time = get_check_in_start_end_time(check_in, in_ahead_margin, in_above_margin)
            return (str(check_in), check_in_start_end_time[0], check_in_start_end_time[1])
    employee_schedule = get_employee_schedule(emp, start_date, end_date)
    if employee_schedule:
        return get_check_in_start_end_time_result(employee_schedule)
    else:
        employee_department_schedule = get_employee_department_schedule(emp, start_date, end_date)
        if employee_department_schedule:
            return get_check_in_start_end_time_result(employee_department_schedule)
        else:
            employee_group_schedule = get_employee_group_schedule(emp, start_date, end_date)
            if employee_group_schedule:
                return get_check_in_start_end_time_result(employee_group_schedule)
            else:
                employee_temporary_schedule = get_employee_temporary_schedule(emp, start_date)
                if employee_temporary_schedule:
                    return get_check_in_start_end_time_result(employee_temporary_schedule)
def get_check_out(in_time, duration):
    check_in = datetime.datetime.strptime('2000-01-01 {time}'.format(time=in_time), '%Y-%m-%d %H:%M:%S')
    check_out = check_in + datetime.timedelta(minutes=duration)
    return '{out}'.format(out=check_out.strftime('%H:%M:%S'))
def get_check_out_time(emp, start_date, end_date):
    def get_check_out_start_end_time_result(result):
        if result.get('allow_early'):
            check_out_time = get_check_out(result.get('check_in'), result.get('duration'))
            check_out_result = get_late_early_out(check_out_time, result.get('allow_early'))
            check_out_start_end_time = get_check_out_start_end_time(result.get('check_in'), result.get('duration'), result.get('out_ahead'), result.get('out_above'))
            return (check_out_result, check_out_start_end_time[0], check_out_start_end_time[1])
        else:
            check_out = get_check_out(result.get('check_in'), result.get('duration'))
            check_out_start_end_time = get_check_out_start_end_time(result.get('check_in'), result.get('duration'), result.get('out_ahead'), result.get('out_above'))
            return (str(check_out), check_out_start_end_time[0], check_out_start_end_time[1])
    employee_schedule = get_employee_schedule(emp, start_date, end_date)
    if employee_schedule:
        return get_check_out_start_end_time_result(employee_schedule)
    else:
        employee_department_schedule = get_employee_department_schedule(emp, start_date, end_date)
        if employee_department_schedule:
            return get_check_out_start_end_time_result(employee_department_schedule)
        else:
            employee_group_schedule = get_employee_group_schedule(emp, start_date, end_date)
            if employee_group_schedule:
                return get_check_out_start_end_time_result(employee_group_schedule)
            else:
                employee_temporary_schedule = get_employee_temporary_schedule(emp, start_date)
                if employee_temporary_schedule:
                    return get_check_out_start_end_time_result(employee_temporary_schedule)
def get_hour_minute(time1, time2, clock_in=True):
    time1 = datetime.datetime.strptime(time1, '%H:%M:%S')
    time2 = datetime.datetime.strptime(time2, '%H:%M:%S')
    if clock_in and time2 > time1:
        difference = time2 - time1
        if difference.seconds // 60 <= 59:
            return (True, False, difference.seconds // 60)
        else:
            min, sec = divmod(difference.seconds, 60)
            hour, min = divmod(min, 60)
            return (True, hour, min)
    else:
        if not clock_in and (not time1 > time2):
            difference = time2 - time1
            if difference.seconds // 60 <= 59:
                return (True, False, difference.seconds // 60)
            else:
                min, sec = divmod(difference.seconds, 60)
                hour, min = divmod(min, 60)
                return (True, hour, min)
        else:
            return (False, False, False)
def get_late_messages(emp_id, punch_state, punch_time, line_token):
    message_alert = ''
    if punch_state == 'I' or punch_state == '0' or punch_state == 'Check In':
        start_date = end_date = datetime.datetime.strptime(punch_time, '%Y-%m-%d %H:%M:%S').date()
        if not get_check_in_time(emp_id, start_date, end_date):
            check_in_time = None
        else:
            check_in_time, check_in_start_time, check_in_end_time = get_check_in_time(emp_id, start_date, end_date)
        if not check_in_time:
            return (True, message_alert)
        else:
            clock_in_time = ':'.join(punch_time.split(' ')[1].split(':'))
            if check_in_time:
                val_1, val_2, val_3 = get_hour_minute(check_in_time, clock_in_time, clock_in=True)
                if val_1:
                    if not os.path.isdir(LINE_LATEIN_EARLYOUT_MESSAGE):
                        createDir(LINE_LATEIN_EARLYOUT_MESSAGE)
                    now = datetime.datetime.now()
                    cur_date = str(now.date()) + '.txt'
                    cur_date_file = LINE_LATEIN_EARLYOUT_MESSAGE + '/' + cur_date
                    already_sent = False
                    late_in_emp_id = str(emp_id) + ':late_in:' + line_token
                    if os.path.isfile(cur_date_file):
                        data = [f.strip('\n') for f in open(cur_date_file)]
                        if str(late_in_emp_id) in data:
                            already_sent = True
                        else:
                            with open(cur_date_file, 'a+') as f:
                                f.write(str(late_in_emp_id))
                                f.write('\n')
                    else:
                        with open(cur_date_file, 'a+') as f:
                            f.write(str(late_in_emp_id))
                            f.write('\n')
                    if already_sent:
                        return (True, '')
                    if val_1 and val_2:
                        return (False, {'hourminute': [val_2, val_3]})
                    else:
                        if val_3:
                            return (False, {'minute': val_3})
    return (True, message_alert)
def get_late_messages_depatment(emp_id, punch_state, punch_time, line_token):
    message_alert = ''
    if punch_state == 'I' or punch_state == '0' or punch_state == 'Check In':
        start_date = end_date = datetime.datetime.strptime(punch_time, '%Y-%m-%d %H:%M:%S').date()
        if not get_check_in_time(emp_id, start_date, end_date):
            check_in_time = None
        else:
            check_in_time, check_in_start_time, check_in_end_time = get_check_in_time(emp_id, start_date, end_date)
        if not check_in_time:
            return (True, message_alert)
        else:
            clock_in_time = ':'.join(punch_time.split(' ')[1].split(':'))
            if check_in_time:
                val_1, val_2, val_3 = get_hour_minute(check_in_time, clock_in_time, clock_in=True)
                if val_1:
                    if not os.path.isdir(LINE_LATEIN_EARLYOUT_MESSAGE):
                        createDir(LINE_LATEIN_EARLYOUT_MESSAGE)
                    now = datetime.datetime.now()
                    cur_date = str(now.date()) + '.txt'
                    cur_date_file = LINE_LATEIN_EARLYOUT_MESSAGE + '/' + cur_date
                    already_sent = False
                    late_in_emp_id = str(emp_id) + ':late_in:' + line_token
                    if os.path.isfile(cur_date_file):
                        data = [f.strip('\n') for f in open(cur_date_file)]
                        if str(late_in_emp_id) in data:
                            already_sent = True
                        else:
                            with open(cur_date_file, 'a+') as f:
                                f.write(str(late_in_emp_id))
                                f.write('\n')
                    else:
                        with open(cur_date_file, 'a+') as f:
                            f.write(str(late_in_emp_id))
                            f.write('\n')
                    if already_sent:
                        return (True, '')
                    if val_1 and val_2:
                        return (False, {'hourminute': [val_2, val_3]})
                    else:
                        if val_3:
                            return (False, {'minute': val_3})
    return (True, message_alert)
def get_early_out_messages(emp_id, punch_state, punch_time, line_token):
    message_alert = ''
    if punch_state == 'O' or punch_state == '1' or punch_state == 'Check Out':
        start_date = end_date = datetime.datetime.strptime(punch_time, '%Y-%m-%d %H:%M:%S').date()
        if not get_check_out_time(emp_id, start_date, end_date):
            check_out_time = None
        else:
            check_out_time, check_out_start_time, check_out_end_time = get_check_out_time(emp_id, start_date, end_date)
        if not check_out_time:
            return (True, message_alert)
        else:
            clock_out_time = ':'.join(punch_time.split(' ')[1].split(':'))
            if check_out_time:
                val_1, val_2, val_3 = get_hour_minute(clock_out_time, check_out_time, clock_in=False)
                if val_1:
                    if not os.path.isdir(LINE_LATEIN_EARLYOUT_MESSAGE):
                        createDir(LINE_LATEIN_EARLYOUT_MESSAGE)
                    now = datetime.datetime.now()
                    cur_date = str(now.date()) + '.txt'
                    cur_date_file = LINE_LATEIN_EARLYOUT_MESSAGE + cur_date
                    already_sent = False
                    early_out_emp_id = str(emp_id) + ':early_out:' + line_token
                    if os.path.isfile(cur_date_file):
                        data = [f.strip('\n') for f in open(cur_date_file)]
                        if str(early_out_emp_id) in data:
                            already_sent = True
                        else:
                            with open(cur_date_file, 'a+') as f:
                                f.write(str(early_out_emp_id))
                                f.write('\n')
                    else:
                        with open(cur_date_file, 'a+') as f:
                            f.write(str(early_out_emp_id))
                            f.write('\n')
                    if already_sent:
                        return (True, '')
                    if val_1 and val_2:
                        return (False, {'hourminute': [val_2, val_3]})
                    else:
                        if val_3:
                            return (False, {'minute': val_3})
    return (True, message_alert)
def get_early_out_messages_depatment(emp_id, punch_state, punch_time, line_token):
    message_alert = ''
    if punch_state == 'O' or punch_state == '1' or punch_state == 'Check Out':
        start_date = end_date = datetime.datetime.strptime(punch_time, '%Y-%m-%d %H:%M:%S').date()
        if not get_check_out_time(emp_id, start_date, end_date):
            check_out_time = None
        else:
            check_out_time, check_out_start_time, check_out_end_time = get_check_out_time(emp_id, start_date, end_date)
        if not check_out_time:
            return (True, message_alert)
        else:
            clock_out_time = ':'.join(punch_time.split(' ')[1].split(':'))
            if check_out_time:
                val_1, val_2, val_3 = get_hour_minute(clock_out_time, check_out_time, clock_in=False)
                if val_1:
                    if not os.path.isdir(LINE_LATEIN_EARLYOUT_MESSAGE):
                        createDir(LINE_LATEIN_EARLYOUT_MESSAGE)
                    now = datetime.datetime.now()
                    cur_date = str(now.date()) + '.txt'
                    cur_date_file = LINE_LATEIN_EARLYOUT_MESSAGE + cur_date
                    already_sent = False
                    early_out_emp_id = str(emp_id) + ':early_out:' + line_token
                    if os.path.isfile(cur_date_file):
                        data = [f.strip('\n') for f in open(cur_date_file)]
                        if str(early_out_emp_id) in data:
                            already_sent = True
                        else:
                            with open(cur_date_file, 'a+') as f:
                                f.write(str(early_out_emp_id))
                                f.write('\n')
                    else:
                        with open(cur_date_file, 'a+') as f:
                            f.write(str(early_out_emp_id))
                            f.write('\n')
                    if already_sent:
                        return (True, '')
                    if val_1 and val_2:
                        return (False, {'hourminute': [val_2, val_3]})
                    else:
                        if val_3:
                            return (False, {'minute': val_3})
    return (True, message_alert)
def get_employee_id(emp_code):
    try:
        return Employee.objects.filter(emp_code=emp_code).get().id
    except Employee.DoesNotExist:
        return None
def get_employee_department_schedule(emp, start_date, end_date):
    departmentschedule_qs = DepartmentSchedule.objects.filter(department__employee=emp).exclude(Q(end_date__lt=start_date) | Q(start_date__gt=end_date)).order_by('start_date').distinct().annotate(auto_shift=Cast('shift__auto_shift', output_field=IntegerField()), unit=Cast('shift__cycle_unit', output_field=IntegerField()), cycle=Cast('shift__shift_cycle', output_field=IntegerField())).values('start_date', 'end_date', 'shift_id', 'auto_shift', 'unit', 'cycle', 'id')
    new_shiftdetail_lst = []
    if departmentschedule_qs:
        schedule_data = list(departmentschedule_qs)[(-1)]
        return get_shift_detail(schedule_data, start_date)
    else:
        return new_shiftdetail_lst
def get_employee_group_schedule(emp, start_date, end_date):
    groupschedule_qs = GroupSchedule.objects.filter(group__attemployee__emp=emp).exclude(Q(end_date__lt=start_date) | Q(start_date__gt=end_date)).order_by('start_date').distinct().annotate(auto_shift=Cast('shift__auto_shift', output_field=IntegerField()), unit=Cast('shift__cycle_unit', output_field=IntegerField()), cycle=Cast('shift__shift_cycle', output_field=IntegerField())).values('start_date', 'end_date', 'shift_id', 'auto_shift', 'unit', 'cycle', 'id')
    new_shiftdetail_lst = []
    if groupschedule_qs:
        schedule_data = list(groupschedule_qs)[(-1)]
        return get_shift_detail(schedule_data, start_date)
    else:
        return new_shiftdetail_lst
def get_employee_schedule(emp, start_date, end_date):
    attschedule_qs = AttSchedule.objects.filter(employee=emp).exclude(Q(end_date__lt=start_date) | Q(start_date__gt=end_date)).order_by('start_date').annotate(department_id=Cast('employee__department_id', output_field=IntegerField()), auto_shift=Cast('shift__auto_shift', output_field=IntegerField()), unit=Cast('shift__cycle_unit', output_field=IntegerField()), cycle=Cast('shift__shift_cycle', output_field=IntegerField())).values('department_id', 'start_date', 'end_date', 'shift_id', 'auto_shift', 'unit', 'cycle', 'id')
    new_shiftdetail_lst = []
    if attschedule_qs:
        schedule_data = list(attschedule_qs)[(-1)]
        return get_shift_detail(schedule_data, start_date)
    else:
        return new_shiftdetail_lst
def get_employee_temporary_schedule(emp, start_date):
    temporaryschedule_qs = TemporarySchedule.objects.filter(employee=emp, att_date=start_date, time_interval__isnull=False).select_related('time_interval').annotate(check_in=Cast('time_interval__in_time', output_field=TimeField()), duration=Cast('time_interval__duration', output_field=IntegerField()), in_ahead=Cast('time_interval__in_ahead_margin', output_field=IntegerField()), in_above=Cast('time_interval__in_above_margin', output_field=IntegerField()), out_ahead=Cast('time_interval__out_ahead_margin', output_field=IntegerField()), out_above=Cast('time_interval__out_above_margin', output_field=IntegerField()), allow_late=Cast('time_interval__allow_late', output_field=IntegerField()), allow_early=Cast('time_interval__allow_leave_early', output_field=IntegerField())).values('id', 'check_in', 'duration', 'in_ahead', 'in_above', 'out_ahead', 'out_above', 'allow_late', 'allow_early')
    if temporaryschedule_qs:
        return temporaryschedule_qs[0]
    else:
        return []
def get_shift_detail(queryset, start_date):
    current_week_day = start_date.weekday()
    new_shiftdetail_lst = []
    shiftdetail_qs = ShiftDetail.objects.filter(shift_id=queryset['shift_id']).select_related('time_interval').values('day_index', 'time_interval_id').annotate(check_in=Cast('time_interval__in_time', output_field=TimeField()), duration=Cast('time_interval__duration', output_field=IntegerField()), in_ahead=Cast('time_interval__in_ahead_margin', output_field=IntegerField()), in_above=Cast('time_interval__in_above_margin', output_field=IntegerField()), out_ahead=Cast('time_interval__out_ahead_margin', output_field=IntegerField()), out_above=Cast('time_interval__out_above_margin', output_field=IntegerField()), allow_late=Cast('time_interval__allow_late', output_field=IntegerField()), allow_early=Cast('time_interval__allow_leave_early', output_field=IntegerField())).order_by('day_index', 'time_interval__in_time').values('day_index', 'time_interval_id', 'check_in', 'duration', 'in_ahead', 'in_above', 'out_ahead', 'out_above', 'allow_late', 'allow_early')
    for tmp in shiftdetail_qs:
        tmp['week_day'] = MATCHED_DAYS.get(tmp['day_index'], 0)
        new_shiftdetail_lst.append(tmp)
    if new_shiftdetail_lst:
        for data in new_shiftdetail_lst:
            if data['week_day'] == current_week_day:
                return data
def check_weekend():
    """\n    Weekday  where 0 is Monday through 6 is Saturday.\n    """
    att_policy = AttPolicy()
    result = att_policy.cache_data()
    now = datetime.datetime.now()
    day = now.weekday()
    if day == result.weekend1 or day == result.weekend2:
        return True
    else:
        return False
def line_encrypt_image(emp_image_path):
    result = encrypt_image(emp_image_path, emp_image_path)
    with open(emp_image_path, 'wb') as f:
        f.write(result)
def line_decrypt_image(emp_image_path, emp_code):
    line_photo_tmp_dir = '{0}{1}'.format(settings.ADDITION_FILE_ROOT, 'line/photo/tmp')
    if not os.path.isdir(line_photo_tmp_dir):
        createDir(line_photo_tmp_dir)
    line_photo = '{0}line/photo/tmp/{1}_decrypt.png'.format(settings.ADDITION_FILE_ROOT, emp_code)
    decrypt_data = b''
    with open(emp_image_path, 'rb') as f:
        decrypt_data = decrypt_image(f.read())
    if decrypt_data:
        with open(line_photo, 'wb') as f:
            f.write(decrypt_data)
        return line_photo
    else:
        return None
def delete_line_tmp_files():
    line_photo_tmp_dir = '{0}{1}'.format(settings.ADDITION_FILE_ROOT, 'line/photo/tmp/*.png')
    for line_png in glob.glob(line_photo_tmp_dir):
        try:
            os.remove(line_png)
        except Exception as e:
            pass
def _get_line_image_path(emp_code, sn, punch_time, token):
    image_path = None
    emp_token_image_cache_key = LN_EMP_IMAGE_CACHE_KEY.format(emp_code=emp_code, token=token)
    emp_token_image_push_flag = cache.get(emp_token_image_cache_key)
    token_im_remain_cache_key = LN_TOKEN_IMAGE_REMAIN_CACHE_KEY.format(token=token)
    token_im_remain = cache.get(token_im_remain_cache_key, 50)
    att_photo_path = os.path.join('{0}{1}/{2}/{3}'.format(settings.ADDITION_FILE_ROOT, 'upload', datetime.datetime.now().strftime('%Y%m'), sn), '{0}-{1}.jpg'.format(''.join(filter(str.isdigit, punch_time)), emp_code))
    if os.path.isfile(att_photo_path) and (not emp_token_image_push_flag) and (token_im_remain > 0):
                line_photo_dir = '{0}{1}'.format(settings.ADDITION_FILE_ROOT, 'line/photo')
                createDir(line_photo_dir)
                image_path = convert_image_format(att_photo_path, new_image_name=emp_code, new_format='png', new_dir=line_photo_dir)
                line_encrypt_image(image_path)
                emp_line_photo = '{0}line/photo/{1}.png'.format(settings.ADDITION_FILE_ROOT, emp_code)
                image_path = line_decrypt_image(emp_line_photo, emp_code)
    return image_path
def delete_unused_keys(**kwargs):
    popup_keys = ['send_for', 'line_notify_obj', 'message_type']
    for key in popup_keys:
        try:
            kwargs.pop(key)
        except Exception as e:
            pass
    return kwargs
def _real_time_message_format(token, first_name, recover, nickname=None, image_path=None, message_head=None, message_tail=None, cached_image=True, **kwargs):
    """ 推送每条考勤记录详细信息 """
    emp_code = kwargs.pop('emp_code')
    punch_time = kwargs.pop('punch_time')
    terminal_sn = kwargs.pop('terminal_sn')
    terminal_alias = kwargs.pop('terminal_alias')
    punch_state = kwargs.pop('punch_state')
    punch_state = _get_punch_state_value(punch_state)
    verify_type = kwargs.pop('verify_type')
    verify_type = _get_verify_type_value(verify_type)
    if kwargs['send_for'] == 'employee':
        clock_in_late_already_sent, result_late_message = get_late_messages(get_employee_id(emp_code), punch_state, punch_time, token)
        clock_out_early_already_sent, result_early_out_message = get_early_out_messages(get_employee_id(emp_code), punch_state, punch_time, token)
    else:
        clock_in_late_already_sent, result_late_message = get_late_messages_depatment(get_employee_id(emp_code), punch_state, punch_time, token)
        clock_out_early_already_sent, result_early_out_message = get_early_out_messages_depatment(get_employee_id(emp_code), punch_state, punch_time, token)
    kwargs = delete_unused_keys(**kwargs)
    lang = get_user_lang()
    with override(lang):
        if token:
            sticker_id = None
            package_id = None
            message = ''
            if message_head:
                message += message_head
            if nickname:
                message += '\n' + _('Hello') + ' %s' % nickname
            else:
                message += '\n' + _('Hello') + ' %s' % first_name or ''
            if terminal_sn and terminal_sn == 'App':
                terminal_sn = '%s' % terminal_sn if terminal_alias else terminal_sn
            else:
                terminal_sn = '%s(%s)' % (terminal_sn, terminal_alias) if terminal_alias else terminal_sn
            if 'is_mask' in kwargs:
                is_mask = kwargs.pop('is_mask')
                if is_mask:
                    if is_mask in [1, '1']:
                        is_mask = _('epTransaction.opts.withMask')
                    else:
                        if is_mask in [0, '0']:
                            is_mask = _('epTransaction.opts.withoutMask')
                        else:
                            is_mask = _('Unknown')
                    message += '\n' + _('epTransaction.fields.isMask') + ': ' + '{is_mask}'.format(is_mask=is_mask)
            if 'temperature' in kwargs:
                temperature = str(kwargs.pop('temperature'))
                if temperature:
                    from mysite.ep.utils import temperature_converted_with_unit
                    message += '\n' + _('epTransaction.fields.temperature') + ': ' + '{temperature}'.format(temperature=temperature_converted_with_unit(temperature))
            message += '\n' + _('employee code') + ': ' + '{emp_code}'.format(emp_code=emp_code)
            message += '\n' + _('punch time') + ': ' + '{punch_time}'.format(punch_time=punch_time)
            message += '\n' + _('verity_type') + ': ' + '{verify_type}'.format(verify_type=verify_type)
            message += '\n' + _('punch state') + ': ' + '{punch_state}'.format(punch_state=punch_state)
            message += '\n' + _('attendance is checked on machine number {terminal_sn}').format(terminal_sn=terminal_sn)
            if str(verify_type) == '101':
                if 'location' in kwargs:
                    location = kwargs.pop('location')
                    if location:
                        message += '\n' + _('location') + ': ' + '{location}'.format(location=location)
            if kwargs:
                if 'sticker_id' in kwargs:
                    sticker_id = int(kwargs.pop('sticker_id'))
                if 'package_id' in kwargs:
                    package_id = int(kwargs.pop('package_id'))
                for k, v in kwargs.items():
                    if not k == 'company_code':
                        message += '\n{0}:{1}'.format(k, v)
            if not clock_in_late_already_sent:
                if result_late_message and result_late_message.get('hourminute'):
                    result = result_late_message.get('hourminute')
                    message += '\n' + _('late for %(hour)s hours and %(minute)s minutes.') % {'hour': result[0], 'minute': result[1]}
                else:
                    if result_late_message and result_late_message.get('minute'):
                            message += '\n' + _('late for {minute} minutes.').format(minute=result_late_message.get('minute'))
            if not clock_out_early_already_sent:
                if result_early_out_message and result_early_out_message.get('hourminute'):
                    result = result_early_out_message.get('hourminute')
                    message += '\n' + _('early out for %(hour)s hours and %(minute)s minutes.') % {'hour': result[0], 'minute': result[1]}
                else:
                    if result_early_out_message and result_early_out_message.get('minute'):
                            message += '\n' + _('early out for {minute} minutes.').format(minute=result_early_out_message.get('minute'))
            if settings.ACTIVE_CELERY:
                sent_status = '{},{},{}'.format(emp_code, punch_time, punch_state)
                send_message2line_notify.apply_async(args=(token, message), kwargs={'company': message_tail, 'image_path': image_path, 'sticker_id': sticker_id, 'package_id': package_id, 'sent_status': sent_status}, link_error=send_message2line_notify_error_handler.s(recover))
            else:
                notify = LineNotify(token, company=message_tail)
                ret = notify.send(message, image_path=image_path, sticker_id=sticker_id, package_id=package_id)
                ret_text = json.loads(ret.text)
                ret_status = ret_text.get('status')
                if ret_status!= 200:
                    raise ValueError('Send Failure')
            if image_path and cached_image:
                    emp_token_image_cache_key = LN_EMP_IMAGE_CACHE_KEY.format(emp_code=emp_code, token=token)
                    cache.set(emp_token_image_cache_key, 1, 900)
def get_absent_count(emps):
    # irreducible cflow, using cdg fallback
    from collections import defaultdict
    from operator import itemgetter
    from mysite.iclock.models import Transaction
    from mysite.att.calc_new.calc_prepare import get_employee_leave, get_employee_holiday, get_employee_schedule
    now = datetime.datetime.now()
    next_day = now + datetime.timedelta(days=1)
    start_date = now.today().date()
    end_date = next_day.date()
    leave_emp_id = set()
    emp_not_scheduled = []
    for emp in emps:
        emp_obj = Employee.objects.get(id=emp)
        schedule_result = get_employee_schedule(emp_obj, start_date, end_date)
        if schedule_result and schedule_result[start_date]:
            if schedule_result[start_date].get('intervals'):
                result_holiday = get_employee_holiday(emp_obj, start_date, end_date)
                try:
                    if result_holiday and result_holiday[start_date]:
                            leave_emp_id.add(emp)
                except KeyError as e:
                    pass
                result = get_employee_leave(emp, start_date, end_date)
                if result and result[start_date]:
                        leave_emp_id.add(emp)
                emp_not_scheduled.append(emp)
    absent_data = defaultdict(list)
    if not len(emp_not_scheduled) >= len(emps):
        emps = list(set(emps) - set(emp_not_scheduled))
        ABSENT_KEY = int('0001', 2)
        ATTENDANCE_COUNT = 2
        absent_data[ABSENT_KEY] = 0
        absent_data[ATTENDANCE_COUNT] = 0
        on_duty_emps = list(set(emps) - set(leave_emp_id))
        if not on_duty_emps:
            absent_data['schedule'] = True
            absent_data[ABSENT_KEY] = 0
            absent_data[ATTENDANCE_COUNT] = len(leave_emp_id)
            absent_data['emp_ids'] = leave_emp_id
            return absent_data
        else:
            queryset = Transaction.objects.all().filter(punch_time__range=[now.date(), next_day.date()])
            queryset = queryset.filter(emp__in=on_duty_emps)
            queryset = queryset.values('emp_code', 'emp_id').distinct().order_by('emp_code')
            present = queryset.count()
            total = len(on_duty_emps)
            getcount = itemgetter('emp_id')
            present_emps = list(map(getcount, queryset))
            if total:
                absent_data['schedule'] = True
                absent_data[ABSENT_KEY] = total - present
                absent_data[ATTENDANCE_COUNT] = present + len(leave_emp_id)
                absent_data['emp_ids'] = list(set(on_duty_emps) - set(present_emps))
            return absent_data
    else:
        absent_data['schedule'] = False
        return absent_data
def _intraday_attendance_summary_message_format(token, deptid, include_sub_department=True, message_head=None, message_tail=None):
    """ 推送当天考勤概要 """
    from mysite.personnel.models.model_department import get_all_childrens_by_deptid
    if token:
        deptids = [deptid]
        if include_sub_department:
            deptids.extend(get_all_childrens_by_deptid(deptid).values_list('id', flat=True))
        dept_obj = Department.objects.get(pk=deptid)
        emps = Employee.objects.filter(department_id__in=deptids).values_list('id', flat=True)
        result = get_absent_count(emps)
        if result['schedule']:
            ABSENT_EMPLOYEE = result['emp_ids']
            attendance = result[2]
            quantity = len(emps)
            absent = result[1]
            if quantity!= 0:
                percentage = attendance / quantity
            else:
                percentage = 0
            message = ''
            if message_head:
                message += message_head
            message += '\n' + _('The current attendance situation of the {dept_name} is shown below:'.format(dept_name=dept_obj.dept_name))
            message += '\n\n' + _('attendance: {attendance} people'.format(attendance=attendance))
            message += '\n' + _('absent: {absent} people'.format(absent=absent))
            message += '\n' + _('attendance rate: {percentage:.2%}'.format(percentage=percentage))
            message += '\n\n' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            notify = LineNotify(token, company=message_tail)
            notify.send(message)
            if absent > 0:
                message = 'Employee Absences List:\n'
                tail_length = message_tail.__len__() + 1 if message_tail is not None else 0
                absent_emps = Employee.objects.filter(id__in=ABSENT_EMPLOYEE).values('emp_code', 'first_name')
                for emp in absent_emps:
                    next_emp = '{emp_code}({first_name})\n'.format(emp_code=emp['emp_code'], first_name=emp['first_name'])
                    if message.__len__() + tail_length + next_emp.__len__() < 1000:
                        message += next_emp
                    else:
                        notify.send(message)
                        message = next_emp
                notify.send(message)
def _get_verify_type_value(verify_type):
    return get_tuple_value(int(verify_type), VERIFY_TYPE)
def _get_punch_state_value(punch_state):
    return '' if punch_state == '255' else get_tuple_value(punch_state, PUNCH_STATE)
def _real_time_message_format_alert(token, recover, message_head=None, message_tail=None, **kwargs):
    """ 推送每条考勤记录详细信息 """
    from mysite.base.tasks import send_message2line_notify_alert_error_handler, send_message2line_notify_alert
    lang = get_user_lang()
    with override(lang):
        if token:
            sticker_id = None
            package_id = None
            message = ''
            field_1 = ''
            field_2 = ''
            field_3 = ''
            if message_head:
                message += message_head
            if 'manual_log' in kwargs.keys():
                message += '\n' + '{manual_log}'.format(manual_log='Manual Log')
            if 'leave' in kwargs.keys():
                message += '\n' + '{pay_code_desc}'.format(pay_code_desc=kwargs.get('leave').get('pay_code_desc'))
            if 'overtime' in kwargs.keys():
                message += '\n' + '{pay_code_desc}'.format(pay_code_desc=kwargs.get('overtime').get('pay_code_desc'))
            if 'training' in kwargs.keys():
                message += '\n' + '{pay_code_desc}'.format(pay_code_desc=kwargs.get('training').get('pay_code_desc'))
            if 'schedule_adjustment' in kwargs.keys():
                message += '\n' + _('change_schedule')
            if kwargs.get('emp_obj').nickname:
                message += '\n' + _('Hello') + ' %s' % kwargs.get('emp_obj').nickname
            else:
                message += '\n' + _('Hello') + ' %s' % kwargs.get('emp_obj').first_name or ''
            message += '\n' + _('employee code') + ': ' + '{emp_code}'.format(emp_code=kwargs.get('emp_obj').emp_code)
            message += '\n' + _('default_department') + ': ' + '{department}'.format(department=kwargs.get('emp_obj').department.dept_name)
            if 'manual_log' in kwargs.keys():
                message += '\n' + _('manualLog_field_punchTime') + ': ' + '{punch_time}'.format(punch_time=kwargs.get('manual_log').get('punch_time'))
                message += '\n' + _('manualLog_field_punchState') + ': ' + '{punch_state}'.format(punch_state=kwargs.get('manual_log').get('punch_state'))
                field_2 = 'Punch Time: {}'.format(kwargs.get('manual_log').get('punch_time'))
                field_3 = 'Punch state: {}'.format(kwargs.get('manual_log').get('punch_state'))
            if 'leave' in kwargs.keys():
                message += '\n' + _('leave_field_startTime') + ': ' + '{start_time}'.format(start_time=kwargs.get('leave').get('start_time'))
                message += '\n' + _('leave_field_endTime') + ': ' + '{end_time}'.format(end_time=kwargs.get('leave').get('end_time'))
                field_2 = 'Leave Start Time: {}'.format(kwargs.get('leave').get('start_time'))
                field_3 = 'Leave End Time: {}'.format(kwargs.get('leave').get('end_time'))
            if 'overtime' in kwargs.keys():
                message += '\n' + _('leave_field_startTime') + ': ' + '{start_time}'.format(start_time=kwargs.get('overtime').get('start_time'))
                message += '\n' + _('leave_field_endTime') + ': ' + '{end_time}'.format(end_time=kwargs.get('overtime').get('end_time'))
                field_2 = 'Over Time start time: {}'.format(kwargs.get('overtime').get('start_time'))
                field_3 = 'Over Time end time: {}'.format(kwargs.get('overtime').get('end_time'))
            if 'training' in kwargs.keys():
                message += '\n' + _('leave_field_startTime') + ': ' + '{start_time}'.format(start_time=kwargs.get('training').get('start_time'))
                message += '\n' + _('leave_field_endTime') + ': ' + '{end_time}'.format(end_time=kwargs.get('training').get('end_time'))
                field_2 = 'Training start time: {}'.format(kwargs.get('training').get('start_time'))
                field_3 = 'Training end time: {}'.format(kwargs.get('training').get('end_time'))
            if 'schedule_adjustment' in kwargs.keys():
                message += '\n' + _('changeSchedule_field_attDate') + ': ' + '{att_date_stamp}'.format(att_date_stamp=kwargs.get('schedule_adjustment').get('att_date_stamp'))
                message += '\n' + _('changeSchedule_field_previousTimeInterval') + ': ' + '{pre_timetable}'.format(pre_timetable=kwargs.get('schedule_adjustment').get('pre_timetable'))
                message += '\n' + _('changeSchedule_field_adjustTimeInterval') + ': ' + '{cur_timetable}'.format(cur_timetable=kwargs.get('schedule_adjustment').get('cur_timetable'))
                field_2 = 'Schedule Adjustment Pre Timetable: {}'.format(kwargs.get('schedule_adjustment').get('pre_timetable'))
                field_3 = 'Schedule Adjustment Cur Timetable: {}'.format(kwargs.get('schedule_adjustment').get('cur_timetable'))
            message += '\n' + _('common_field_approvalStatus') + ': ' + '{approval_status}'.format(approval_status=kwargs.get('approval_status'))
            message += '\n' + _('common_field_applyReason') + ': ' + '{apply_reason}'.format(apply_reason=kwargs.get('apply_reason'))
            message += '\n' + _('leave_field_applyTime') + ': ' + '{apply_time}'.format(apply_time=kwargs.get('apply_time'))
            message += '\n' + _('common_field_approvalTime') + ': ' + '{approval_time}'.format(approval_time=kwargs.get('approval_time'))
            if kwargs:
                if 'sticker_id' in kwargs:
                    sticker_id = int(kwargs.pop('sticker_id'))
                if 'package_id' in kwargs:
                    package_id = int(kwargs.pop('package_id'))
            image_path = None
            if settings.ACTIVE_CELERY:
                field_1 = 'Employee Code: {}'.format(kwargs.get('emp_obj').emp_code)
                sent_status = '{},{},{}'.format(field_1, field_2, field_3)
                send_message2line_notify_alert.apply_async(args=(token, message), kwargs={'company': message_tail, 'image_path': image_path, 'sticker_id': sticker_id, 'package_id': package_id, 'sent_status': sent_status}, link_error=send_message2line_notify_alert_error_handler.s(recover))
            else:
                notify = LineNotify(token, company=message_tail)
                ret = notify.send(message, image_path=image_path, sticker_id=sticker_id, package_id=package_id)
                ret_text = json.loads(ret.text)
                ret_status = ret_text.get('status')
                if ret_status!= 200:
                    raise ValueError('Send Failure')
def real_time_line_notify():
    # irreducible cflow, using cdg fallback
    from mysite.base.line.send_line_notify import SendLineNotify
    path, files = read_line_notify_transaction_file()
    if files:
        now = datetime.datetime.now()
        for file in files:
            pass
    timestamp = file.split('.')[0].split('_')[(-1)]
    record_upload_time = datetime.datetime.fromtimestamp(float(timestamp[:10]))
    if record_upload_time.date() < now.date():
        pass
    os.remove(os.path.join(path, file))
    continue
    if (now - record_upload_time).seconds < 5:
        continue
    with open(os.path.join(path, file), encoding='utf-8') as f:
        transaction = f.read()
    if transaction:
        pass
    transaction = transaction.split('\t')
    punch_time_datetime = datetime.datetime.strptime(transaction[1], '%Y-%m-%d %H:%M:%S')
    if punch_time_datetime.date() < now.date():
        pass
    os.remove(os.path.join(path, file))
    continue
    kwargs = {}
    if transaction[3] == '101' and transaction.__len__() >= 7:
            kwargs['location'] = transaction[6]
    if transaction.__len__() >= 8:
        kwargs['is_mask'] = transaction[7]
    if transaction.__len__() >= 9:
        kwargs['temperature'] = transaction[8]
    if get_line_notify_send_flag():
        kwargs['punch_time'] = transaction[1]
        kwargs['verify_type'] = transaction[3]
        kwargs['punch_state'] = transaction[2]
        kwargs['terminal_sn'] = transaction[4]
        kwargs['emp_code'] = transaction[0]
        kwargs['terminal_alias'] = transaction[5]
        kwargs['message_type'] = 100
        kwargs['send_for'] = 'department'
        SendLineNotify(**kwargs)
    try:
        line_notify_for_emp = LineNotifyForEmployee.get_obj(transaction[0])
        if isinstance(line_notify_for_emp, LineNotifyForEmployee):
            kwargs['punch_time'] = transaction[1]
            kwargs['verify_type'] = transaction[3]
            kwargs['punch_state'] = transaction[2]
            kwargs['terminal_sn'] = transaction[4]
            kwargs['terminal_alias'] = transaction[5]
            kwargs['message_type'] = 100
            kwargs['line_notify_obj'] = line_notify_for_emp
            kwargs['send_for'] = 'employee'
            SendLineNotify(**kwargs)
    except ValueError:
        import traceback
        logger.exception(str(traceback.print_exc()))
    os.remove(os.path.join(path, file))
    except Exception:
        pass
    import traceback
    logger.exception(str(traceback.print_exc()))
def real_time_line_notify_alert():
    # irreducible cflow, using cdg fallback
    from mysite.base.line.send_line_notify import SendLineNotify
    path, files = read_line_notify_transaction_file_alert()
    if len(files) > 0:
        now = datetime.datetime.now()
        for file in files:
            timestamp = file.split('.')[0].split('_')[(-1)]
            record_upload_time = datetime.datetime.fromtimestamp(float(timestamp[:10]))
            if record_upload_time.date() < now.date():
                os.remove(os.path.join(path, file))
                    continue
                if (now - record_upload_time).seconds < 5:
                    continue
                else:
                    with open(os.path.join(path, file), encoding='utf-8') as f:
                        transaction = f.read()
                    if transaction:
                        kwargs = json.loads(transaction)
                        if get_line_notify_send_flag():
                            kwargs['send_for'] = 'department_alert'
                            SendLineNotify(**kwargs)
                        try:
                            line_notify_for_emp = LineNotifyForEmployee.get_obj(kwargs.get('emp_code'))
                            if isinstance(line_notify_for_emp, LineNotifyForEmployee):
                                kwargs['line_notify_obj'] = line_notify_for_emp
                                kwargs['send_for'] = 'employee_alert'
                                SendLineNotify(**kwargs)
                        except ValueError:
                            import traceback
                            logger.exception(str(traceback.print_exc()))
                        os.remove(os.path.join(path, file))
                    except Exception:
                        import traceback
                        logger.exception(str(traceback.print_exc()))