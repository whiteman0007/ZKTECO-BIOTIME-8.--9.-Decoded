# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\models\\alert_event.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:25 UTC (1750673005)

from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.admin.models import BaseModel
class EventAlertSetting(BaseModel):
    event_id = models.IntegerField(_('eventAlertSetting.fields.eventID'))
    event = models.CharField(_('eventAlertSetting.fields.event'), max_length=50)
    module = models.CharField(_('eventAlertSetting.fields.module'), max_length=50)
    sub_module = models.CharField(_('eventAlertSetting.fields.subModule'), max_length=50)
    email_alert = models.BooleanField(_('eventAlertSetting.fields.emailAlert'), default=True)
    app_alert = models.BooleanField(_('eventAlertSetting.fields.appAlert'), default=True)
    sms_alert = models.BooleanField(_('eventAlertSetting.fields.smsAlert'), default=False)
    whatapp_alert = models.BooleanField(_('eventAlertSetting.fields.whatAppAlert'), default=False)
    facebook_alert = models.BooleanField(_('eventAlertSetting.fields.facebookAlert'), default=False)
    lineapp_alert = models.BooleanField(_('eventAlertSetting.fields.lineAppAlert'), default=False)
    class Meta:
        ordering = ['event_id']
        app_label = 'base'
        verbose_name = _('base.models.eventAlertSetting')
        default_permissions = ('view', 'change')