# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\forms\\manual_log_forms.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
from django.forms import ModelChoiceField
from django.forms.widgets import HiddenInput
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.iclock.models import TerminalWorkCode
from mysite.personnel.models import Employee
class EmployeeManualLogGetForm(forms.ZKActionForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset(), disabled=True)
    punch_time = forms.DateTimeField(label=_('manualLog_field_punchTime'))
    punch_state = forms.ChoiceField(label=_('manualLog_field_punchState'), choices=(('255', '255'),))
    work_code = ModelChoiceField(queryset=TerminalWorkCode.objects.get_queryset(), required=False)
    auto_approve = forms.BooleanField(label=_('leave.fields.autoApproved'), initial=True, required=False)
    apply_reason = forms.TextField(label=_('common_field_applyReason'), required=False)
    permission = None
    def __init__(self, request, *args, **kwargs):
        from mysite.att.actions.common_actions import APPROVAL_APPROVE_PERMISSION
        from mysite.base.utils import get_punch_states
        from mysite.att.models import PayloadTimeCard
        from mysite.personnel.models import Employee
        self.permission = APPROVAL_APPROVE_PERMISSION.get('manuallog')
        super(EmployeeManualLogGetForm, self).__init__(*args, **kwargs)
        self.fields['punch_state'].choices = get_punch_states()
        emp_id = request.GET.get('emp_id', None)
        att_date = request.GET.get('att_date', None)
        timetable_id = request.GET.get('timetable_id', None)
        if not timetable_id:
            timetable_id = None
        if att_date:
            att_date = datetime.datetime.strptime(att_date, '%Y-%m-%d')
        if not emp_id:
            return
        else:
            obj = PayloadTimeCard.objects.filter(emp_id=emp_id, att_date=att_date, time_table_id=timetable_id).first()
            if not obj:
                return
            else:
                self.fields['employee'].queryset = Employee.objects.filter(id=emp_id)
                self.fields['employee'].initial = obj.emp
                self.fields['punch_time'].initial = obj.check_in
                if not request.user.has_perm(self.permission) or isinstance(request.user, Employee):
                    self.fields['auto_approve'].widget = HiddenInput()
                    self.fields['auto_approve'].initial = False
class EmployeeManualLogPostForm(EmployeeManualLogGetForm):
    employee = forms.ModelChoiceField(queryset=Employee.objects.get_queryset())