# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\meeting\\api_request_utils.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:05 UTC (1750673045)

import os
import datetime
import json
import requests
from requests.exceptions import RequestException, Timeout, TooManyRedirects, HTTPError
from .utils import get_logger
API_DEFAULT_HEADER = {'Content-type': 'application/json', 'Accept': 'application/json'}
logger = get_logger('API_request')
class RequestBase(object):
    """Base class that all get/post/delete methods implementations derive from"""
    def __init__(self, api_url='', headers=API_DEFAULT_HEADER, payload={}, params={}, files={}):
        self.api_url = api_url
        self.headers = headers
        self.payload = payload
        self.params = params
        self.files = files
        self.status_code = 200
        self.convert_suc_response = True
        self.set_authorization()
    def set_authorization(self):
        raise NotImplementedError('Authorization headers should be added')
    def get_request_url(self):
        return self.api_url
    def get_response(self):
        try:
            request_url = self.get_request_url()
            resp = self.request_method(request_url, headers=self.headers, data=self.payload, params=self.params, files=self.files)
            resp.raise_for_status()
            status_code = resp.status_code
        except Timeout as e:
            message = 'Timeout Error: {0}'.format(e.response.text)
            return (False, message)
        except HTTPError as e:
            message = 'HTTPError Error: {0}'.format(e.response.text)
            return (False, message)
        except TooManyRedirects as e:
            message = 'TooManyRedirects Error: {0}'.format(e.response.text)
            return (False, message)
        except RequestException as e:
            message = 'Other RequestException Error: {0}'.format(e)
            return (False, message)
        if status_code == requests.codes.ok:
            try:
                resp_json = resp.json()
            except Exception as e:
                message = 'API response cannot convert to JSON'
                return (False, message)
            resp_code = str(resp_json['code'])
            resp_msg = resp_json['message']
            if resp_code == '0':
                return (True, resp_json)
            else:
                message = 'Return Code {0}: {1}'.format(resp_code, resp_msg)
                return (False, message)
        else:
            status_msg = requests.status_codes._codes.get(status_code)[0]
            message = 'Status Code {0}: {1}'.format(status_code, status_msg)
            return (False, message)
    def parse_response(self):
        successful_flag, data = self.get_response()
        if successful_flag:
            message = data
        else:
            message = data
            logger.error('\n URL: {url}\n Method: {method}\n Headers: {headers}\n                         Payload: {payload}\n Query String: {params}\n Msg: {msg}'.format(url=self.api_url, method=self.request_method.__name__, headers=self.headers, payload=self.payload, params=self.params, msg=message))
        return (successful_flag, message)
class ZoomRequestBase(RequestBase):
    def __init__(self, zoom=None, api_url='', *args, **kwargs):
        self.zoom = zoom
        super(ZoomRequestBase, self).__init__(*args, api_url=api_url, **kwargs)
    def set_authorization(self):
        from mysite.tools.encryption_utils import aes_decrypt
        if not self.zoom or not self.zoom.zoom_enable:
            raise NotImplementedError('Zoom credentials not configure or enable.')
        else:
            self.headers['Authorization'] = 'Bearer {token}'.format(token=aes_decrypt(self.zoom.jwt_token))
    def get_response(self):
        try:
            request_url = self.get_request_url()
            resp = self.request_method(request_url, headers=self.headers, data=json.dumps(self.payload), params=self.params, files=self.files)
            resp.raise_for_status()
            status_code = resp.status_code
        except Timeout as e:
            message = 'Timeout Error: {0}'.format(e.response.text)
            return (False, message)
        except HTTPError as e:
            message = 'HTTPError Error: {0}'.format(e.response.text)
            return (False, message)
        except TooManyRedirects as e:
            message = 'TooManyRedirects Error: {0}'.format(e.response.text)
            return (False, message)
        except RequestException as e:
            message = 'Other RequestException Error: {0}'.format(e)
            return (False, message)
        if status_code == self.success_code:
            if self.convert_suc_response:
                try:
                    resp_json = resp.json()
                except Exception as e:
                    message = 'API response cannot convert to JSON'
                    return (False, message)
                return (True, resp_json)
            else:
                return (True, '')
        else:
            try:
                resp_json = resp.json()
                resp_code = str(resp_json['code'])
                resp_msg = resp_json['message']
                message = 'Return Code {0}: {1}'.format(resp_code, resp_msg)
                return (False, message)
            except Exception as e:
                status_msg = requests.status_codes._codes.get(status_code)[0]
                message = 'Status Code {0}: {1}'.format(status_code, status_msg)
                return (False, message)
class ZoomGetRequestWithToken(ZoomRequestBase):
    def __init__(self, api_url='', *args, **kwargs):
        super(ZoomGetRequestWithToken, self).__init__(*args, api_url=api_url, **kwargs)
        self.request_method = getattr(requests, 'get')
        self.success_code = 200
    def set_authorization(self, token=None):
        if token:
            self.headers['Authorization'] = 'Bearer {token}'.format(token=token)
class ZoomGetRequest(ZoomRequestBase):
    def __init__(self, *args, **kwargs):
        super(ZoomGetRequest, self).__init__(*args, **kwargs)
        self.request_method = getattr(requests, 'get')
        self.success_code = 200
class ZoomPostRequest(ZoomRequestBase):
    def __init__(self, *args, **kwargs):
        super(ZoomPostRequest, self).__init__(*args, **kwargs)
        self.request_method = getattr(requests, 'post')
        self.success_code = 201
class ZoomPatchRequest(ZoomRequestBase):
    def __init__(self, *args, **kwargs):
        super(ZoomPatchRequest, self).__init__(*args, **kwargs)
        self.request_method = getattr(requests, 'patch')
        self.success_code = 204
        self.convert_suc_response = False
class ZoomDeleteRequest(ZoomRequestBase):
    def __init__(self, *args, **kwargs):
        super(ZoomDeleteRequest, self).__init__(*args, **kwargs)
        self.request_method = getattr(requests, 'delete')
        self.success_code = 204
        self.convert_suc_response = False