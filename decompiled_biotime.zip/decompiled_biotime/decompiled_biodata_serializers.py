# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\iclock\\api\\serializers\\biodata_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:35 UTC (1750673015)

from rest_framework import serializers
from mysite.iclock.models.model_biodata import BioData
class BioDataSerializer(serializers.ModelSerializer):
    bio_type = serializers.CharField(source='get_bio_type_display')
    employee = serializers.SerializerMethodField()
    def get_employee(self, obj):
        emp = obj.employee
        if emp:
            name_list = []
            if emp.emp_code:
                name_list.append(str(emp.emp_code))
            if emp.first_name:
                name_list.append(str(emp.first_name))
            return ' '.join(name_list)
        else:
            return ''
    class Meta:
        model = BioData
        fields = ['id', 'employee', 'bio_type', 'bio_no', 'bio_index', 'major_ver', 'update_time']
class BioDataCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = BioData
        fields = ['employee', 'bio_type', 'bio_no', 'bio_index', 'major_ver']
class BioDataEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = BioData
        fields = ['employee', 'bio_type', 'bio_no', 'bio_index', 'major_ver']
        extra_kwargs = {'employee': {'read_only': True}, 'bio_type': {'read_only': True}, 'major_ver': {'read_only': True}, 'bio_tmp': {'required': False, 'allow_null': False}}