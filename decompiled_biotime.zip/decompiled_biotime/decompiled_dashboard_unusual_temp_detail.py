# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\ep\\api\\serializers\\dashboard_unusual_temp_detail.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:32 UTC (1750673012)

from django.utils.translation import gettext_lazy as _
from django.utils.html import format_html
from rest_framework import serializers
from mysite.ep.models import EPTransaction
class DashboardUnusualTemperatureDetailSerializer(serializers.ModelSerializer):
    emp_code = serializers.CharField(source='emp.emp_code')
    first_name = serializers.CharField(source='emp.first_name', allow_null=True)
    last_name = serializers.CharField(source='emp.last_name', allow_null=True)
    dept_name = serializers.CharField(source='emp.department.dept_name', allow_null=True)
    position_name = serializers.CharField(source='emp.position.position_name', allow_null=True)
    temperature = serializers.SerializerMethodField(label=_('epTransaction.fields.temperature'))
    is_mask = serializers.SerializerMethodField(label=_('epTransaction.fields.isMask'))
    def get_temperature(self, obj):
        from mysite.ep.utils import temperature_converted_with_unit, check_abnormal_temperature
        t_converted = temperature_converted_with_unit(obj.temperature)
        if not check_abnormal_temperature(obj.temperature):
            return t_converted
        else:
            return format_html('<span style=\"color: #ff0000;\">{0}</span>', t_converted)
    def get_is_mask(self, obj):
        if not obj.is_mask:
            return format_html('<span style=\"color: #ffa500;\">{0}</span>', obj.get_is_mask_display())
        else:
            return obj.get_is_mask_display()
    class Meta:
        model = EPTransaction
        fields = ('emp_code', 'first_name', 'last_name', 'dept_name', 'position_name', 'check_date', 'check_time', 'temperature', 'is_mask')