# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\actions\\grouppolicy_actions.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from django.forms import ModelForm, ModelMultipleChoiceField
from django.utils.translation import gettext_lazy as _
from mysite.admin import forms, ZKModelAction
from mysite.admin.action import ActionHandleError
from mysite.att import models_choices as mc
from mysite.att.fields import PayCodeModelChoiceField
from mysite.att.models import AttGroup, GroupPolicy
from mysite.att.models_choices import EMAIL_FREQUENCY, SENDING_DAY, SELECT_DAY, BOOLEANS
from django.conf import settings
OT_RULE = ((0, _('attRule_overtimeRule_disableOvertime')), (1, _('attRule_overtimeRule_calculationOvertime')), (2, _('attRule_overtimeRule_approvalOvertime')), (3, _('attRule_overtimeRule_approvalOvertimePriority')))
class AddGroupPolicyForm(ModelForm):
    group = ModelMultipleChoiceField(queryset=AttGroup.objects.get_queryset(), required=False)
    use_ot = forms.ChoiceField(label=_('attRule_globalRule_overtimeRule'), choices=OT_RULE, initial=1)
    enable_compensatory = forms.BooleanField(label=_('globalRule.fields.enableCompensatory'), initial=False, required=False)
    max_hrs = forms.DecimalField(label=_('globalRule.fields.maxHrs'), max_digits=4, decimal_places=1, initial=12.0, min_value=0.0, unit=_('time.units.hour'))
    day_change = forms.TimeField(label=_('globalRule.fields.dayChange'), initial='00:00:00')
    punch_period = forms.IntegerField(label=_('attRule_globalRule_duplicatePunchPeriod'), min_value=0, initial=1, unit=_('time.units.minute'))
    d1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d1_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    d1_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    d2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d2_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    d2_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    d3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    d3_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    d3_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    w11_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w11_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    w11_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    w12_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w12_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    w12_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    w13_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    w13_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    w13_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    h1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h1_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    h1_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    h2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h2_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    h2_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    h3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    h3_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    h3_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, unit=_('time.units.hour'))
    t1_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t1_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t1_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t2_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t2_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t2_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t3_pay_code = PayCodeModelChoiceField(label=_('groupPolicy.fields.payCode'), required=False)
    t3_hrs_from = forms.DecimalField(label=_('groupPolicy.fields.hrsFrom'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    t3_hrs_to = forms.DecimalField(label=_('groupPolicy.fields.hrsTo'), max_digits=3, decimal_places=1, initial=0.0, min_value=0.0, unit=_('time.units.hour'))
    late_in2absence = forms.IntegerField(label=_('attRule_globalRule_missIn'), min_value=0, initial=100, unit=_('time.units.minute'))
    early_out2absence = forms.IntegerField(label=_('attRule_globalRule_missIn'), min_value=0, initial=100, unit=_('time.units.minute'))
    miss_in = forms.ChoiceField(label=_('attRule_globalRule_missIn'), choices=mc.MISS_IN_RULE, initial=1)
    late_in_hrs = forms.IntegerField(label=_('attRule_globalRule_missIn'), initial=60, unit=_('time.units.minute'))
    miss_out = forms.ChoiceField(label=_('attRule_globalRule_missOut'), choices=mc.MISS_OUT_RULE, initial=1)
    early_out_hrs = forms.IntegerField(label=_('attRule_globalRule_missOut'), initial=60, unit=_('time.units.minute'))
    max_late_in = forms.IntegerField(label=_('alertSettingPage_label_lateExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    max_early_out = forms.IntegerField(label=_('alertSettingPage_label_earlyLeaveExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    max_absent = forms.IntegerField(label=_('alertSettingPage_label_absentExceed'), min_value=0, initial=0, unit=_('alertSettingPage_exceedUnit_times'))
    group_frequency = forms.ChoiceField(label=_('alertSettingPage_label_emailSendingFrequency'), initial=0, choices=EMAIL_FREQUENCY)
    group_send_day = forms.ChoiceField(label=_('alertSettingPage_label_emailSendingDay'), initial=0, choices=SELECT_DAY)
    email_send_time = forms.TimeField(label=_('alertSettingPage_label_emailSendingTime'), initial='00:00:00')
    sending_day = forms.ChoiceField(label=_('alertSettingPage_label_sendingDay'), initial=0, choices=SENDING_DAY)
    weekend1_color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    weekend2_color_setting = forms.CharField(label=_('holiday.fields.colorSetting'), max_length=30, required=False)
    ot_pay_code = PayCodeModelChoiceField(label=_('timeInterval.fields.overtimePayCode'), required=False)
    bot_uid = forms.CharField(label=_('timeInterval.fields.botUid'), required=False)
    facebook_enable = forms.CharField(label=_(''), required=False, initial=settings.FACEBOOK_ENABLE)
    work_code_enable = forms.CharField(label=_(''), required=False, initial=settings.WORKCODE_SETTING)
    enable_workcode_calculation = forms.BooleanField(label=_('attPolicy.fields.workcodeCalculation'), initial=False, required=False)
    enable_workcode_punch_state = forms.ChoiceField(label=_('timeInterval_field_baseOnPunchType'), initial=0, choices=BOOLEANS, required=False)
    class Meta:
        model = GroupPolicy
        fields = ('weekend1', 'weekend2', 'max_hrs', 'day_change', 'paring_rule', 'punch_period', 'daily_ot', 'd1_pay_code', 'd1_hrs_from', 'd1_hrs_to', 'd2_pay_code', 'd2_hrs_from', 'd2_hrs_to', 'd3_pay_code', 'd3_hrs_from', 'd3_hrs_to', 'weekend_ot', 'w11_pay_code', 'w11_hrs_from', 'w11_hrs_to', 'w12_pay_code', 'w12_hrs_from', 'w12_hrs_to', 'w13_pay_code', 'w13_hrs_from', 'w13_hrs_to', 'holiday_ot', 'h1_pay_code', 'h1_hrs_from', 'h1_hrs_to', 'h2_pay_code', 'h2_hrs_from', 'h2_hrs_to', 'h3_pay_code', 'h3_hrs_from', 'h3_hrs_to', 'weekly_ot', 't1_pay_code', 't1_hrs_from', 't1_hrs_to', 't2_pay_code', 't2_hrs_from', 't2_hrs_to', 't3_pay_code', 't3_hrs_from', 't3_hrs_to', 'late_in2absence', 'early_out2absence', 'miss_in', 'late_in_hrs', 'miss_out'
    def save(self, commit=True):
        import uuid
        from mysite.att.models.model_overtime_policy import OvertimePolicy, OT_LV1, OT_LV2, OT_LV3
        from mysite.att.models.model_payload import group_policy_change
        cleaned_data = self.cleaned_data
        kwargs = {'use_ot': int(cleaned_data.get('use_ot', 0)), 'weekend1': cleaned_data['weekend1'], 'weekend2': cleaned_data['weekend2'], 'max_hrs': cleaned_data['max_hrs'], 'day_change': cleaned_data['day_change'], 'paring_rule': cleaned_data['paring_rule'], 'punch_period': cleaned_data['punch_period'], 'late_in2absence': cleaned_data['late_in2absence'], 'early_out2absence': cleaned_data['early_out2absence'], 'miss_in': cleaned_data['miss_in'], 'late_in_hrs': cleaned_data['late_in_hrs'], 'miss_out': cleaned_data['miss_out'], 'early_out_hrs': cleaned_data['early_out_hrs'], 'require_capture': cleaned_data['require_capture'], 'require_work_code': cleaned_data['require_work_code'], 'require_punch_state': cleaned_data['require_punch_state'], 'daily_ot': cleaned_data['daily_ot'], 'weekend_ot': cleaned_data['weekend_ot'], 'holiday_ot': cleaned_data['holiday_ot'
        groups = cleaned_data['group']
        if not groups:
            raise ActionHandleError(_('groupPolicy.actions.errorNoneGroup'))
        else:
            for group in groups:
                gps = GroupPolicy.objects.filter(group=group)
                if not gps:
                    _gp = GroupPolicy(**kwargs)
                    _gp.group = group
                    _gp.daily_ot_rule = uuid.uuid4().hex
                    _gp.weekend_ot_rule = uuid.uuid4().hex
                    _gp.holiday_ot_rule = uuid.uuid4().hex
                    _gp.weekly_ot_rule = uuid.uuid4().hex
                    polices = []
                    for prefix, master in [('d', _gp.daily_ot_rule), ('w1', _gp.weekend_ot_rule), ('h', _gp.holiday_ot_rule), ('t', _gp.weekly_ot_rule)]:
                        for ot in [OT_LV1, OT_LV2, OT_LV3]:
                            ot_pay_code = '{prefix}{lv}_pay_code'.format(prefix=prefix, lv=ot)
                            ot_hrs_from = '{prefix}{lv}_hrs_from'.format(prefix=prefix, lv=ot)
                            ot_hrs_to = '{prefix}{lv}_hrs_to'.format(prefix=prefix, lv=ot)
                            polices.append(OvertimePolicy(master=master, mode=ot, pay_code=cleaned_data[ot_pay_code], hrs_from=cleaned_data[ot_hrs_from], hrs_to=cleaned_data[ot_hrs_to]))
                    from django.conf import settings
                    if settings.DATABASE_ENGINE == 'oracle':
                        for r in polices:
                            r.save()
                    else:
                        OvertimePolicy.objects.bulk_create(polices)
                    _gp.save(force_insert=True)
                    group_policy_change(_gp)
                else:
                    gp = gps.first()
                    gp.daily_ot_rule = gp.daily_ot_rule if gp.daily_ot_rule else uuid.uuid1().hex
                    gp.weekend_ot_rule = gp.weekend_ot_rule if gp.weekend_ot_rule else uuid.uuid1().hex
                    gp.holiday_ot_rule = gp.holiday_ot_rule if gp.holiday_ot_rule else uuid.uuid1().hex
                    gp.weekly_ot_rule = gp.weekly_ot_rule if gp.weekly_ot_rule else uuid.uuid1().hex
                    for prefix, master in [('d', gp.daily_ot_rule), ('w1', gp.weekend_ot_rule), ('h', gp.holiday_ot_rule), ('t', gp.weekly_ot_rule)]:
                        for ot in [OT_LV1, OT_LV2, OT_LV3]:
                            ot_pay_code = '{prefix}{lv}_pay_code'.format(prefix=prefix, lv=ot)
                            ot_hrs_from = '{prefix}{lv}_hrs_from'.format(prefix=prefix, lv=ot)
                            ot_hrs_to = '{prefix}{lv}_hrs_to'.format(prefix=prefix, lv=ot)
                            _changed = [ot_pay_code, ot_hrs_from, ot_hrs_to]
                            if set(self.changed_data).intersection(set(_changed)):
                                otp = OvertimePolicy.objects.filter(master=master, mode=ot).first()
                                if otp:
                                    otp.hrs_from = cleaned_data[ot_hrs_from]
                                    otp.hrs_to = cleaned_data[ot_hrs_to]
                                    otp.pay_code = cleaned_data[ot_pay_code]
                                    otp.save()
                    gps.update(**kwargs)
                    for obj in gps:
                        obj.save()
                    group_policy_change(gp)
class AddGroupPolicy(ZKModelAction):
    verbose_name = _('groupPolicy.actions.add')
    short_description = _('groupPolicy.actions.add')
    help_txt = _('groupPolicy.actions.add')
    action_form = AddGroupPolicyForm
    def action(self, *args, **kwargs):
        form = AddGroupPolicyForm(self.request.POST)
        if form.is_valid():
            form.save()