# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\iclock\\migrations\\0010_901_push_version_width.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:38 UTC (1750702718)

from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('iclock', '0009_auto_20230411_1415')]
    operations = [migrations.AlterField(model_name='terminal', name='push_protocol', field=models.CharField(editable=False, max_length=50, verbose_name='terminal_field_pushProtocolVersion')), migrations.AlterField(model_name='terminal', name='push_ver', field=models.CharField(blank=True, editable=False, max_length=50, null=True, verbose_name='terminal_field_pushVersion'))]