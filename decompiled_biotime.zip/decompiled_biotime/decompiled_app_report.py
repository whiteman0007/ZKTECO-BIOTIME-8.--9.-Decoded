# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\app_report.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.api.serializers.utils import EmployeeExtraInfoSerializer
from mysite.att.api import fields
from mysite.att.api.base_serializers import PayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.api.utils_class import SumPayCodeDuration, SumAttCodeDuration
from mysite.att.models import PayloadTimeCard, PayCode, AttCode
class APPReportSerializer(PayCodeRelatedReportModelSerializer, EmployeeExtraInfoSerializer):
    emp_code = serializers.CharField(label=_('report_column_empCode'), source='emp__emp_code')
    first_name = serializers.CharField(label=_('report_column_firstName'), source='emp__first_name', allow_null=True)
    last_name = serializers.CharField(label=_('report_column_lastName'), source='emp__last_name', allow_null=True)
    nick_name = serializers.CharField(label=_('report_column_nickName'), source='emp__nickname', allow_null=True)
    gender = serializers.CharField(label=_('report_column_gender'), source='emp__gender', allow_null=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='emp__department__dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='emp__department__dept_name', allow_null=True)
    position_code = serializers.CharField(label=_('report_column_positionCode'), source='emp__position__position_code', allow_null=True)
    position_name = serializers.CharField(label=_('report_column_positionName'), source='emp__position__position_name', allow_null=True)
    att_date = fields.DateField(label=_('report_column_attendanceDate'))
    check_in = fields.TimeField(label=_('report.columns.checkIn'))
    check_out = fields.TimeField(label=_('report.columns.checkOut'))
    clock_in = fields.TimeField(label=_('report.columns.clockIn'))
    clock_out = fields.TimeField(label=_('report.columns.clockOut'))
    break_in = fields.TimeField(label=_('report.columns.breakIn'))
    break_out = fields.TimeField(label=_('report.columns.breakOut'))
    weekday = fields.WeekdayField(label=_('report_column_attendanceWeekday'))
    def get_fields(self):
        fields = super(APPReportSerializer, self).get_fields()
        self.add_emp_extra_info_fields(fields)
        return fields
    class Meta:
        model = PayloadTimeCard
        fields = ('id', 'emp_id', 'emp_code', 'first_name', 'last_name', 'nick_name', 'gender', 'dept_code', 'dept_name', 'position_code', 'position_name', 'att_date', 'weekday', 'time_table_alias', 'check_in', 'check_out', 'work_day', 'clock_in', 'clock_out', 'break_out', 'break_in')
class APPReportFilter(ReportGenericFilter):
    def department_filter(self, queryset, name, value):
        if not value or str(value) == '-1':
            return queryset
        else:
            objs = [int(i) for i in value.split(',') if i]
            queryset = queryset.filter(emp__department_id__in=objs)
            return queryset
    class Meta:
        model = PayloadTimeCard
        fields = ['employees', 'departments', 'start_date', 'end_date']
class APPReportViewSet(ReportUserGenericViewSet):
    model = PayloadTimeCard
    queryset = PayloadTimeCard.objects.select_related().order_by('emp', 'att_date', 'clock_in')
    filterset_class = APPReportFilter
    serializer_dict = {'list': APPReportSerializer, 'export': APPReportSerializer}
    @property
    def att_codes(self):
        if not hasattr(self, '_att_codes'):
            self._att_codes = AttCode.objects.filter(symbol_only=False).order_by('order').values('id', 'code', 'alias', 'display_format', 'min_val', 'round_off')
        return self._att_codes
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.filter(is_display=True).order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def annotate_queryset(self, queryset):
        from mysite.utils import get_system_setting
        psnl_config = get_system_setting('psnl_config_setting')
        if psnl_config.get('order_by_num_emp_code') is True:
            ordering = ['emp__emp_code_digit', 'emp__emp_code']
        else:
            ordering = ['emp__emp_code']
        queryset = queryset.values('id', 'emp_id', 'emp__emp_code', 'emp__first_name', 'emp__last_name', 'emp__nickname', 'emp__gender', 'emp__department__dept_code', 'emp__department__dept_name', 'emp__position__position_code', 'emp__position__position_name', 'time_table_alias', 'att_date', 'week', 'weekday', 'check_in', 'check_out', 'clock_in', 'clock_out', 'break_out', 'break_in', 'work_day', 'emp__emp_code_digit').order_by(*ordering, 'att_date')
        values = {}
        if self.att_codes:
            for att_code in self.att_codes:
                values[att_code['code']] = SumAttCodeDuration(att_code, fk='payloadattcode', distinct=True)
        if self.pay_codes:
            for pay_code in self.pay_codes:
                values['paycode_{index}'.format(index=pay_code['id'])] = SumPayCodeDuration(pay_code, fk='payloadpaycode', distinct=True)
        if values:
            queryset = queryset.annotate(**values)
        return queryset
    def get_file_title(self):
        return _('att.menus.reports.totalTimeCard')