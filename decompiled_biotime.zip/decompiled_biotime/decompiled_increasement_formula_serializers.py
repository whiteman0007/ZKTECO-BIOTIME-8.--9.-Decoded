# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\payroll\\api\\serializers\\increasement_formula_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:12 UTC (1750673052)

from rest_framework import serializers
from mysite.payroll.models import IncreasementFormula
class IncreasementFormulaSerializer(serializers.ModelSerializer):
    class Meta:
        model = IncreasementFormula
        fields = ['id', 'name', 'formula', 'remark']
class IncreasementFormulaExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = IncreasementFormula
        fields = ['id', 'name', 'formula', 'remark']