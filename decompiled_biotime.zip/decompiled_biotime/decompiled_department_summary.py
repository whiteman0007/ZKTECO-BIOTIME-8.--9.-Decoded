# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\department_summary.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.db.models import Sum, Count, Case, When, Value, IntegerField
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.api.base_serializers import PayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.api.utils_class import SumPayCodeDuration
from mysite.att.models import PayloadPayCode
from mysite.att.models.model_paycode import PayCode, LATE_IN, EARLY_OUT, ABSENT
class DepartmentSummarySerializer(PayCodeRelatedReportModelSerializer):
    company_code = serializers.CharField(label=_('company.field.code'), source='emp__company__company_code', allow_null=True)
    company_name = serializers.CharField(label=_('company.field.name'), source='emp__company__company_name', allow_null=True)
    dept_code = serializers.CharField(label=_('report_column_departmentCode'), source='emp__department__dept_code', allow_null=True)
    dept_name = serializers.CharField(label=_('report_column_departmentName'), source='emp__department__dept_name', allow_null=True)
    total_emp = serializers.IntegerField(label=_('report_column_employeeCount'), source='emp_count')
    total_late_times = serializers.IntegerField(label=_('report_column_lateDuration'), source='sum_late_times')
    total_early_leave_times = serializers.IntegerField(label=_('report_column_earlyLeaveDuration'), source='sum_early_leave_times')
    total_absent_times = serializers.IntegerField(label=_('report_column_absentDuration'), source='sum_absent_times')
    class Meta:
        model = PayloadPayCode
        fields = ('dept_code', 'dept_name', 'total_emp', 'total_late_times', 'total_early_leave_times', 'total_absent_times', 'company_code', 'company_name')
class DepartmentSummaryViewSet(ReportUserGenericViewSet):
    model = PayloadPayCode
    queryset = PayloadPayCode.objects.all().select_related()
    filterset_class = ReportGenericFilter
    serializer_dict = {'list': DepartmentSummarySerializer, 'export': DepartmentSummarySerializer}
    def __init__(self, *args, **kwargs):
        self.summary_fields = ['total_emp', 'total_late_times', 'total_early_leave_times', 'total_absent_times']
        super(DepartmentSummaryViewSet, self).__init__(*args, **kwargs)
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.all().order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def get_file_title(self):
        return _('menu_att_departmentSummaryReport')
    def annotate_queryset(self, queryset):
        queryset = queryset.values('emp__department_id', 'emp__department__dept_code', 'emp__department__dept_name').order_by('emp__department_id')
        values = {'emp_count': Count('emp', distinct=True), 'sum_late_times': Sum(Case(When(pay_code__fixed_code=LATE_IN, duration__gt=0, then=Value(1))), output_field=IntegerField()), 'sum_early_leave_times': Sum(Case(When(pay_code__fixed_code=EARLY_OUT, duration__gt=0, then=Value(1))), output_field=IntegerField()), 'sum_absent_times': Sum(Case(When(pay_code__fixed_code=ABSENT, duration__gt=0, then=Value(1))), output_field=IntegerField())}
        if self.pay_codes:
            for pay_code in self.pay_codes:
                self.summary_fields.append('paycode_{index}'.format(index=pay_code['id']))
                values['paycode_{index}'.format(index=pay_code['id'])] = SumPayCodeDuration(pay_code)
            queryset = queryset.annotate(**values)
        return queryset