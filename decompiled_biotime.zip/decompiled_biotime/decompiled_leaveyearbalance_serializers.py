# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\leaveyearbalance_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from django.utils.translation import gettext_lazy as _
from mysite.att.models import LeaveYearBalance
from mysite.att.models_choices import LEAVE_TYPE
class LeaveYearBalanceSerializer(serializers.ModelSerializer):
    leave_type_display = serializers.SerializerMethodField(source='get_leave_type_disaplay')
    def get_leave_type_display(self, obj):
        return str(LEAVE_TYPE[obj.leave_type - 1][1])
    class Meta:
        model = LeaveYearBalance
        fields = ['id', 'leave_type_display', 'year', 'entitlement_days', 'leave_day', 'exceed_leave_day', 'pre_balance', 'employee_id']
class LeaveYearBalanceEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveYearBalance
        fields = ['pre_balance']
class LeaveYearBalanceLimitedSerializer(serializers.ModelSerializer):
    pay_code_name = serializers.CharField(label=_('payCode.fields.name'), source='pay_code__name', allow_null=True)
    remain_days = serializers.SerializerMethodField()
    def get_pre_exceed(self, obj):
        """\n        Last year exceed days\n        """
        last_year = LeaveYearBalance.objects.filter(employee_id=obj['employee_id'], year=int(obj['year']) - 1, pay_code_id=obj['pay_code_id'])
        pre_exceed = last_year.exists() and last_year.first().exceed_leave_day or 0
        return pre_exceed
    def get_remain_days(self, obj):
        """\n        If remain days < 0 means exist exceed leave days\n        """
        pre_exceed = self.get_pre_exceed(obj)
        _days = obj['entitlement_days'] + obj['pre_balance'] - obj['leave_day'] - pre_exceed
        return _days
    class Meta:
        model = LeaveYearBalance
        fields = ['id', 'pay_code_id', 'pay_code_name', 'year', 'entitlement_days', 'remain_days', 'pre_balance']