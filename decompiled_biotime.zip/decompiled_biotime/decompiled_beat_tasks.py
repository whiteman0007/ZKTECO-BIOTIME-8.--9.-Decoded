# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\beat_tasks.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import datetime
from django.db.models import Sum, When, Case, Value, IntegerField, Q
from django.utils.translation import gettext_lazy as _
from mysite.att.models import PayloadPayCode
from mysite.att.models.model_paycode import LATE_IN, EARLY_OUT, ABSENT
from mysite.base.const import ATT_LATE_IN, ATT_EARLY_LEAVE, ATT_ABSENT, EMPLOYEE, SUCCESS, ATT_EXCEPTION_ALERT
from mysite.base.models import EventAlertSetting
from mysite.base.tasks import asyn_send_one_mail
from mysite.base.utils import process_att_exception_email, save_system_log
from mysite.beat_tasks import BaseMinuteTask, minute_task_register
from mysite.mobile.choices import SUB_CATEGORY_ABSENT, SUB_CATEGORY_LATE, SUB_CATEGORY_EARLY_LEAVE
from mysite.mobile.models import AppList
from mysite.mobile.tasks import save_attendance_message
from mysite.personnel.models import Employee
from mysite.utils import get_start_end_by_frequency
from .models import DepartmentPolicy, AttEmployee, GroupPolicy, AttPolicy
from mysite.base import const
DAILY, WEEKLY, MONTHLY = (3, 2, 1)
@minute_task_register()
class AttExceptionAlertTask(BaseMinuteTask):
    name = 'att.beat_tasks.AttExceptionAlertTask'
    def need_run_task(self, dt_now):
        group_policy = GroupPolicy.objects.filter(group_frequency__in=(DAILY, WEEKLY, MONTHLY), email_send_time__hour=dt_now.hour, email_send_time__minute=dt_now.minute)
        dept_policy = DepartmentPolicy.objects.filter(dept_frequency__in=(DAILY, WEEKLY, MONTHLY), email_send_time__hour=dt_now.hour, email_send_time__minute=dt_now.minute)
        global_policy = AttPolicy.objects.filter(global_frequency__in=(DAILY, WEEKLY, MONTHLY), email_send_time__hour=dt_now.hour, email_send_time__minute=dt_now.minute)
        if group_policy.exists() or dept_policy.exists() or global_policy.exists():
            return True
        else:
            return False
    def get_policy_emps_list(self, dt_now):
        data_list = []
        all_emp_qs = AttEmployee.objects.all()
        g_qs = GroupPolicy.objects.filter(group_frequency__in=(DAILY, WEEKLY, MONTHLY), email_send_time__hour=dt_now.hour, email_send_time__minute=dt_now.minute)
        for policy in g_qs:
            emp_qs = all_emp_qs.filter(group_id=policy.group_id)
            data_list.append((emp_qs, policy))
        dept_emp_qs = all_emp_qs.filter(group__isnull=True)
        d_qs = DepartmentPolicy.objects.filter(dept_frequency__in=(DAILY, WEEKLY, MONTHLY), email_send_time__hour=dt_now.hour, email_send_time__minute=dt_now.minute)
        for policy in d_qs:
            emp_qs = dept_emp_qs.filter(emp__department_id=policy.department_id)
            data_list.append((emp_qs, policy))
        dept_p_qs = DepartmentPolicy.objects.values('department_id')
        group_qs = GroupPolicy.objects.values('group_id')
        global_emp_qs = all_emp_qs.exclude(group_id__in=group_qs).exclude(emp__department_id__in=dept_p_qs)
        global_qs = AttPolicy.objects.filter(global_frequency__in=(DAILY, WEEKLY, MONTHLY), email_send_time__hour=dt_now.hour, email_send_time__minute=dt_now.minute)
        global_policy = global_qs.first()
        if global_policy:
            data_list.append((global_emp_qs, global_policy))
        return data_list
    def delivery_exception_email_to_department_manage(self, manager, items, start_date, end_date, params):
        """\n        Delivery email after attendance calculation(it depends on alert setting)\n        :param dept: Department\n        :param items: [{\'emp_code\':\'***\', late_times\': 0, \'early_leave_times\': 0, \'absent_times\': 0 ...}]\n        :param start_date: Calculation Start Date\n        :param end_date: Calculation End Date\n        :return:\n        """
        from mysite.personnel.models import Employee
        email_alert = EventAlertSetting.objects.filter(event_id__in=(const.ATT_LATE_IN, const.ATT_EARLY_LEAVE, const.ATT_ABSENT)).values_list('email_alert', flat=True)
        email_alert_late_in_to, email_alert_early_out_to, email_alert_absent_to = email_alert
        if manager.email:
            to = [manager.email]
            body_detail_list = []
            body_detail = '\n                        <table border=\"1\" cellspacing=\"0\" cellpadding=\"10\"><thead><tr>\n                            <th>Name</th>\n                            <th>First Name</th>\n                            <th>Late</th>\n                            <th>Early Leave</th>\n                            <th>Absent</th>\n                        </tr></thead><tbody>\n                    '
            body_detail_list.append(body_detail)
            body_detail2 = ''
            for item in items:
                emp = Employee.get_emp_by_pk(item['emp_id'])
                late_in = item.get('late_in')
                early_out = item.get('early_out')
                absence = item.get('absence')
                if email_alert_late_in_to and late_in > params['late_in'] or (email_alert_early_out_to and early_out > params['early_out']) or (email_alert_absent_to and absence > params['absence']):
                    body_detail2 = '\n                                <tr>\n                                <td>{emp}</td>\n                                <td>{first_name}</td>\n                                <td>{late}</td>\n                                <td>{early_leave}</td>\n                                <td>{absent}</td>\n                                </tr>\n                            '.format(emp=emp.emp_code, first_name=emp.first_name, late=item['late_in'], early_leave=item['early_out'], absent=item['absence'])
                    body_detail_list.append(body_detail2)
            if process_att_exception_email(const.ADMIN, None, receiver=manager, email_alert=email_alert, body_detail_list=body_detail_list, start_time=start_date, end_time=end_date):
                return
            else:
                subject = 'Attendance Exception Of Exception'
                body = '\n                Dear {manager},<br>\n                    There are some attendance exceptions from {start_date} to {end_date}:\n                        {body_detail}\n            '.format(manager=manager.username, start_date=start_date.strftime('%Y-%m-%d %H:%M:%S'), end_date=end_date.strftime('%Y-%m-%d %H:%M:%S'), body_detail=''.join(body_detail_list) + '</tbody></table>')
                if body_detail2:
                    asyn_send_one_mail(subject, body, to)
    def process_notify(self, start_date, end_date, params, emp_ids):
        import itertools
        import operator
        from mysite.personnel.models import Department
        queryset = PayloadPayCode.objects.filter(emp_id__in=emp_ids, time_card__check_out__gt=start_date, time_card__check_out__lte=end_date, pay_code__fixed_code__in=(LATE_IN, EARLY_OUT, ABSENT), is_exception__gt=0).select_related('emp')
        queryset = queryset.values('emp_id', 'emp__department_id')
        queryset = queryset.annotate(late_in=Sum(Case(When(pay_code__fixed_code=LATE_IN, then=Value(1)), default=0), output_field=IntegerField()), early_out=Sum(Case(When(pay_code__fixed_code=EARLY_OUT, then=Value(1)), default=0), output_field=IntegerField()), absence=Sum(Case(When(pay_code__fixed_code=ABSENT, then=Value(1)), default=0), output_field=IntegerField()))
        queryset = queryset.filter(Q(late_in__gt=params['late_in']) | Q(early_out__gt=params['early_out']) | Q(absence__gt=params['absence']))
        email_alert = EventAlertSetting.objects.filter(event_id__in=(ATT_LATE_IN, ATT_EARLY_LEAVE, ATT_ABSENT)).values_list('email_alert', flat=True)
        app_alert = EventAlertSetting.objects.filter(event_id__in=(ATT_LATE_IN, ATT_EARLY_LEAVE, ATT_ABSENT)).values_list('app_alert', flat=True)
        app_alert_late_in, app_alert_early_out, app_alert_absent = app_alert
        facebook_alert = EventAlertSetting.objects.filter(event_id__in=(ATT_LATE_IN, ATT_EARLY_LEAVE, ATT_ABSENT)).values_list('facebook_alert', flat=True)
        for payload in queryset:
            emp = Employee.get_emp_by_pk(payload['emp_id'])
            if not emp:
                continue
            else:
                if not emp.email and (not emp.app_status):
                        continue
                late_in = payload.get('late_in', 0)
                early_out = payload.get('early_out', 0)
                absence = payload.get('absence', 0)
                exception_value = {const.LATE_IN: (late_in, params['late_in']), const.EARLY_OUT: (early_out, params['early_out']), const.ABSENCE: (absence, params['absence'])}
                if emp.email and (not process_att_exception_email(EMPLOYEE, payload, receiver=emp, email_alert=email_alert, start_time=start_date, end_time=end_date, exception_value=exception_value)):
                        to = [emp.email]
                        subject = 'Attendance Exception Of Exception'
                        body = '\n                                Dear {emp}，\n                                    There are some attendance exceptions from {start_date} to {end_date}:\n                                        Late: {late}\n                                        Early Leave: {early_leave}\n                                        Absent: {absent}\n                                '
                        body = body.format(emp=emp.first_name or emp.emp_code, start_date=start_date.strftime('%Y-%m-%d %H:%M:%S'), end_date=end_date.strftime('%Y-%m-%d %H:%M:%S'), late=payload['late_in'], early_leave=payload['early_out'], absent=payload['absence'])
                        asyn_send_one_mail(subject, body, to)
                if emp.app_status:
                    payload['emp__first_name'] = emp.first_name
                    payload['emp__emp_code'] = emp.emp_code
                    if late_in > params['late_in'] and app_alert_late_in:
                            message = 'You got {count} times late during {start} to {end}'.format(count=late_in, start=start_date.strftime('%Y-%m-%d'), end=end_date.strftime('%Y-%m-%d'))
                            save_attendance_message(emp, SUB_CATEGORY_LATE, str(_('%(emp__first_name)s(%(emp__emp_code)s) Late In')) % {'emp__first_name': payload['emp__first_name'], 'emp__emp_code': payload['emp__emp_code']}, message, payload)
                    if early_out > params['early_out'] and app_alert_early_out:
                            message = 'You got %(count)s times early leave during %(start)s to %(end)s' % {'count': early_out, 'start': start_date.strftime('%Y-%m-%d'), 'end': end_date.strftime('%Y-%m-%d')}
                            save_attendance_message(emp, SUB_CATEGORY_EARLY_LEAVE, str(_('%(emp__first_name)s(%(emp__emp_code)s) Early Out')) % {'emp__first_name': payload['emp__first_name'], 'emp__emp_code': payload['emp__emp_code']}, message, payload)
                    if absence > params['absence'] and app_alert_absent:
                            message = str(_('You got {count} times absent during {start} to {end}')).format(count=absence, start=start_date.strftime('%Y-%m-%d'), end=end_date.strftime('%Y-%m-%d'))
                            save_attendance_message(emp, SUB_CATEGORY_ABSENT, str(_('%(emp__first_name)s(%(emp__emp_code)s) Absence')) % {'emp__first_name': payload['emp__first_name'], 'emp__emp_code': payload['emp__emp_code']}, message, payload)
                if params['bot_uid'] and any(facebook_alert):
                        late_in_emp = early_out_emp = absent_emp = 0
                        if params['late_in']:
                            late_in_emp += 1
                        if params['early_out']:
                            early_out_emp += 1
                        if params['absent']:
                            absent_emp += 1
                        body = '\n                        There are some attendance exceptions from {start_date} to {end_date}:\n                            Summary Late Employee: {late}\n                            Summary Early Leave Employee: {early_leave}\n                            Summary Absent Employee: {absent}\n                       '
                        body = body.format(start_date=start_date.strftime('%Y-%m-%d %H:%M:%S'), end_date=end_date.strftime('%Y-%m-%d %H:%M:%S'), late=late_in_emp, early_leave=early_out_emp, absent=absent_emp)
                        from mysite.base.messenger import MessengerNotify
                        notify = MessengerNotify()
                        notify.send(params['policy'], body, 6)
        reports = {key: list(queryset) for key, queryset in itertools.groupby(queryset, operator.itemgetter('emp__department_id'))}
        for department, employees in reports.items():
            dept = Department.objects.filter(id=department).first()
            if not dept:
                continue
            else:
                managers = dept.myuser_set.all()
                for manager in managers:
                    self.delivery_exception_email_to_department_manage(manager, employees, start_date, end_date, params)
    def run(self, dt_now=None):
        if not dt_now:
            dt_now = datetime.datetime.now()
        policy_emps_list = self.get_policy_emps_list(dt_now)
        for emp_qs, policy in policy_emps_list:
            if isinstance(policy, GroupPolicy):
                frequency = policy.group_frequency
                send_day = policy.group_send_day
                bot_uid = policy.bot_uid
            else:
                if isinstance(policy, DepartmentPolicy):
                    frequency = policy.dept_frequency
                    send_day = policy.dept_send_day
                    bot_uid = policy.bot_uid
                else:
                    frequency = policy.global_frequency
                    send_day = policy.global_send_day
                    bot_uid = policy.bot_uid
            start_date, end_date = get_start_end_by_frequency(frequency, policy.sending_day, send_day, dt_now, policy.start_of_week)
            if start_date is None or end_date is None:
                continue
            else:
                params = {'late_in': int(policy.max_late_in) or 0, 'early_out': int(policy.max_early_out) or 0, 'absence': int(policy.max_absent) or 0, 'bot_uid': bot_uid or None, 'policy': policy}
                emp_id_qs = emp_qs.values('emp_id')
                self.process_notify(start_date, end_date, params, emp_id_qs)
        if policy_emps_list:
            save_system_log(ATT_EXCEPTION_ALERT, SUCCESS, '')