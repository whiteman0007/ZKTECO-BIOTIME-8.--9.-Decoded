# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\report_views\\group_overtime.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from django.db.models import Count
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from mysite.att.api.base_serializers import PayCodeRelatedReportModelSerializer
from mysite.att.api.filters import ReportGenericFilter
from mysite.att.api.utils_class import ReportUserGenericViewSet
from mysite.att.api.utils_class import SumPayCodeDuration
from mysite.att.models import PayloadPayCode
from mysite.att.models.model_paycode import PayCode, OVERTIME
class GroupOvertimeSerializer(PayCodeRelatedReportModelSerializer):
    group_code = serializers.CharField(label=_('attGroup.fields.code'), source='emp__attemployee__group__code', allow_null=True)
    group_name = serializers.CharField(label=_('attGroup.fields.name'), source='emp__attemployee__group__name', allow_null=True)
    total_emp = serializers.IntegerField(label=_('report_column_employeeCount'), source='emp_count')
    class Meta:
        model = PayloadPayCode
        fields = ('group_code', 'group_name', 'total_emp')
class GroupOvertimeViewSet(ReportUserGenericViewSet):
    model = PayloadPayCode
    queryset = PayloadPayCode.objects.all().select_related()
    filterset_class = ReportGenericFilter
    serializer_dict = {'list': GroupOvertimeSerializer, 'export': GroupOvertimeSerializer}
    @property
    def pay_codes(self):
        if not hasattr(self, '_pay_codes'):
            self._pay_codes = PayCode.objects.filter(code_type=OVERTIME).order_by('display_order').values('id', 'name', 'display_format', 'min_val', 'round_off')
        return self._pay_codes
    def annotate_queryset(self, queryset):
        queryset = queryset.values('emp__attemployee__group_id', 'emp__attemployee__group__code', 'emp__attemployee__group__name').order_by('emp__attemployee__group_id')
        values = {'emp_count': Count('emp', distinct=True)}
        if self.pay_codes:
            for pay_code in self.pay_codes:
                self.summary_fields.append('paycode_{index}'.format(index=pay_code['id']))
                values['paycode_{index}'.format(index=pay_code['id'])] = SumPayCodeDuration(pay_code)
            queryset = queryset.annotate(**values)
        return queryset
    def get_file_title(self):
        return _('att.menus.reports.groupOvertimeSummary')