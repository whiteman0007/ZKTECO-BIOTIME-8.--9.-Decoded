# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\att\\migrations\\0005_auto_20201106_1538.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:18:16 UTC (1750702696)

from __future__ import unicode_literals
from django.db import migrations, models
class Migration(migrations.Migration):
    dependencies = [('att', '0004_auto_20201021_1551')]
    operations = [migrations.AlterField(model_name='manuallog', name='is_mask', field=models.IntegerField(blank=True, choices=[(1, 'epTransaction.opts.withMask'), (0, 'epTransaction.opts.withoutMask'), (255, 'epTransaction.opts.notEnable')], default=255, null=True, verbose_name='epTransaction.fields.isMask'))]