# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\management\\commands\\flush_redis.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:21 UTC (1750673001)

from django.core.management.base import BaseCommand
class Command(BaseCommand):
    help = 'flush redis data'
    def handle(self, *args, **options):
        from django_redis import get_redis_connection
        get_redis_connection('default').flushall()
        print('[*]Flush all')