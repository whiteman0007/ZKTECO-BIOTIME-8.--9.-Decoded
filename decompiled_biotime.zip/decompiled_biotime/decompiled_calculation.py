# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\meeting\\calculation.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:05 UTC (1750673045)

import itertools
import operator
import datetime
from django.db.models import Q, Min, Max
from mysite.meeting.models import MeetingTransaction, MeetingPayloadBase
def employee_calculation(emp, punch_time):
    meetings = emp.attender.filter(start_time__lte=punch_time, end_tiem__gte=punch_time).values_list('id', 'in_start', 'in_end', 'out_start', 'out_end', 'meeting_date', 'duration', 'start_time', 'end_time', 'in_required', 'out_required')
    for meeting in meetings:
        MeetingPayloadBase.objects.filter(emp=emp, meeting=meeting).delete()
        queryset = MeetingTransaction.objects.filter(emp=emp).filter(Q(punch_datetime__gte=meeting['in_start'], punch_datetime__lte=meeting['in_end']) | Q(punch_datetime__gte=meeting['out_start'], punch_datetime__lte=meeting['out_end']))
        queryset = queryset.values('emp')
        detail = queryset.annotate(clock_in=Min('punch_datetime'), clock_out=Max('punch_datetime')).first()
        if detail:
            clock_in, clock_out = (detail['clock_in'], detail['clock_out'])
            if clock_in == clock_out:
                clock_out = None
        else:
            clock_in = clock_out = None
        attended = late_in = early_out = absent = 0
        if meeting['in_required'] and clock_in and (clock_in > meeting['start_time']):
                    late_in = (clock_in - meeting['start_time']).total_seconds()
        if meeting['out_required'] and clock_out and (clock_out < meeting['end_time']):
                    early_out = (meeting['end_time'] - clock_out).total_seconds()
        if meeting['in_required'] and meeting['out_required']:
            if not all((clock_in, clock_out)):
                absent = meeting['duration']
        else:
            if meeting['in_required']:
                if not clock_in:
                    absent = meeting['duration']
            else:
                if meeting['out_required'] and (not clock_out):
                        absent = meeting['duration']
        if absent:
            late_in = early_out = 0
        if clock_in and clock_out:
                attended = (clock_out - clock_in).total_seconds()
        MeetingPayloadBase(emp=emp, meeting=meeting['id'], meeting_date=meeting['meeting_date'], start_time=meeting['start_time'], end_time=meeting['end_time'], duration=meeting['duration'], clock_in=clock_in, clock_out=clock_out, attended_duration=attended, late_in=late_in, early_out=early_out, absent=absent).save(force_insert=True)
def meeting_calculation(meeting):
    from mysite.workflow.models_choices import APPROVED
    now = datetime.datetime.now()
    if not meeting.attender.exists():
        return
    else:
        if meeting.start_time > now:
            return
        else:
            if meeting.approval_status not in [APPROVED]:
                return
            else:
                if not meeting.room:
                    return
                else:
                    mt = list(meeting.room.meetingroomdevice_set.values_list('device_id', flat=True))
                    queryset = MeetingTransaction.objects.filter(emp__attender=meeting).filter(Q(punch_datetime__gte=meeting.in_start, punch_datetime__lte=meeting.in_end) | Q(punch_datetime__gte=meeting.out_start, punch_datetime__lte=meeting.out_end)).filter(Q(terminal_id__in=mt) | Q(meeting=meeting)).distinct()
                    queryset = queryset.values('emp')
                    queryset = queryset.annotate(clock_in=Min('punch_datetime'), clock_out=Max('punch_datetime'))
                    payload = {key: list(items)[0] for key, items in itertools.groupby(queryset, key=operator.itemgetter('emp'))}
                    MeetingPayloadBase.objects.filter(meeting=meeting).delete()
                    for employee in meeting.attender.all().values_list('id', flat=True).order_by('emp_code'):
                        detail = payload.get(employee, None)
                        if detail:
                            clock_in, clock_out = (detail['clock_in'], detail['clock_out'])
                            if clock_in == clock_out:
                                clock_out = None
                        else:
                            clock_in = clock_out = None
                        attended = late_in = early_out = absent = 0
                        if meeting.in_required and clock_in and (clock_in > meeting.start_time):
                                    late_in = (clock_in - meeting.start_time).total_seconds()
                        if meeting.out_required and clock_out and (clock_out < meeting.end_time):
                                    early_out = (meeting.end_time - clock_out).total_seconds()
                        if meeting.in_required and meeting.out_required:
                            if not all((clock_in, clock_out)):
                                absent = meeting.duration
                        else:
                            if meeting.in_required:
                                if not clock_in:
                                    absent = meeting.duration
                            else:
                                if meeting.out_required and (not clock_out):
                                        absent = meeting.duration
                        if absent:
                            late_in = early_out = 0
                        if clock_in and clock_out:
                                attended = (clock_out - clock_in).total_seconds()
                        MeetingPayloadBase(emp_id=employee, meeting=meeting, meeting_date=meeting.meeting_date, start_time=meeting.start_time, end_time=meeting.end_time, duration=meeting.duration, clock_in=clock_in, clock_out=clock_out, attended_duration=attended, late_in=late_in, early_out=early_out, absent=absent).save(force_insert=True)