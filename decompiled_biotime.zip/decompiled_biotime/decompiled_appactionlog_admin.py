# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\mobile\\admin\\appactionlog_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:09 UTC (1750673049)

from mysite import admin
from mysite.mobile.models import AppActionLog
@admin.register(AppActionLog)
class AppActionLogAdmin(admin.ZKModelAdmin):
    list_display = ('user', 'client', 'action', 'action_time', 'request_status', 'describe')
    list_filter = ('user', 'client', 'action', 'action_time', 'request_status', 'describe')
    query_fields = ('user', 'client', 'action')
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj=None):
        return False
    def get_queryset(self, request):
        from mysite.personnel.models.model_employee import Employee
        qs = super(AppActionLogAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                emp = Employee.objects.filter(department__in=request.user.auth_dept.all())
                name_list = [e.emp_code for e in emp] if emp else []
                qs = qs.filter(user__in=name_list)
            if request.user.auth_area.exists():
                emp = Employee.objects.filter(area__in=request.user.auth_area.all()).distinct()
                name_list = [e.emp_code for e in emp] if emp else []
                qs = qs.filter(user__in=name_list)
        return qs