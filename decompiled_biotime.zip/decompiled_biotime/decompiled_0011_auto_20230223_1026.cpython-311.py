# Decompiled with Hussein Amer
# Internal filename: 'C:\\ZKBioTime\\mysite\\personnel\\migrations\\0011_auto_20230223_1026.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 18:19:08 UTC (1750702748)

from django.db import migrations, models
import django.db.models.deletion
import django.db.models.manager
import mysite.personnel.fields
import mysite.personnel.models.company_mixin
import mysite.tools.image_utils
class Migration(migrations.Migration):
    dependencies = [('personnel', '0010_auto_20221202_1852')]
    baseModel_field_changeTime = [migrations.AlterModelManagers('company', name='all_objects', managers=[django.db.models.manager]), migrations.AddField('company', name='address', field=[models.CharField(True, blank=200, null=True, verbose_name='company.field.address'), migrations.AddField('company', name='max_length', null=True, verbose_name='verbose_name'), migrations.AddField('company', name='max_length', null=True, verbose_name='verbose_name'), migrations.AddField('company', name='max_length', null=True, verbose_name='verbose_name'), migrations.AddField('company', name='max_length', null=True, verbose_name='verbose_name'), migrations.AddField('company', name='max_length', null=True, verbose_name='verbose_name'), migrations.AddField('company', name='max_length', null=True, verbose_name='verbose_name'), migrations.AddField('