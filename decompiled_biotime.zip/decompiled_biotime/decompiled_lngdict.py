# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\lngdict.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:40 UTC (1750673020)

from django.utils.translation import gettext_lazy as _
def OpName(op):
    OPNAMES = {0: 'start up', 1: 'shutdown', 2: 'validation failure', 3: 'alarm', 4: 'enter the menu', 5: 'change settings', 6: 'registration fingerprint', 7: 'registration password', 8: 'card registration', 20: 'the data in the card copied to the machine', 21: 'set time', 22: 'restore factory settings', 23: 'Delete Record', 24: 'remove administrator rights', 25: '25', group set up to amend Access: '26', modify user access control settings: '27', access time to amend paragraph: '28', amend unlock Portfolio: '29', unlock: '30', registration of new users: '31', fingerprint attribute changes: '32', stress alarm: 'stress alarm', 34: 'anti-submarine', 35: 'anti-submarine', Delete attendance photos: '35', 36: 'Delete attendance photos', Modify user information: '36', 37: 'Holiday operation', 38: 'Restore data', 39: 'Backup data', 40
    try:
        return '%s(%s)' % (OPNAMES[op], op)
    except Exception:
        return op and '%s' % op or ''
def AlarmName(obj):
    ALARMNAMES = {50: 'Door Close Detected', 51: 'Door Open Detected', 55: 'Machine Been Broken', 53: 'Out Door Button', 54: 'Door Broken Accidentally', 58: 'Try Invalid Verification', 59: 'Force', 60: 'Device offline', 4: 'door open', 5: 'door closed', 65535: 'Alarm Cancelled'}
    try:
        return '%s' % ALARMNAMES[obj]
    except Exception:
        return obj and '%s' % obj or ''
def CMDName(cmd_code):
    CMDNAMES = {0: 'success', (-1): 'Parameter error', (-2): 'Photo data size does not match', (-3): 'Reading and writing error', (-9): 'Template length does not match', (-10): 'User does not exist', (-11): 'Template format error', (-12): 'Illegal template', (-1001): 'Capacity is full', (-1002): 'Device not upgraded BS', (-1003): 'Command timeout', (-1004): 'Data and device configuration are inconsistent', (-1005): 'Device is busy', (-1006): 'The data is too long', (-1007): 'Memory error', (-1008): 'Get server data error'}
    if cmd_code is None:
        return ''
    else:
        if cmd_code >= 0:
            return '%s(%s)' % (cmd_code, CMDNAMES[0])
        else:
            try:
                return '%s(%s)' % (cmd_code, CMDNAMES[cmd_code])
            except Exception:
                return '%s' % cmd_code