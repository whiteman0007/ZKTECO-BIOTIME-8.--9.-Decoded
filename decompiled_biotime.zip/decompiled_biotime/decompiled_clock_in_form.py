# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\staff\\forms\\clock_in_form.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:31 UTC (1750673071)

from django.utils.translation import gettext_lazy as _
from mysite.admin import forms
from mysite.att.models_choices import PUNCH_STATES
from mysite.personnel.forms.fields import EmployeeSearchChoiceField
class ClockInForm(forms.ZKActionForm):
    employee = EmployeeSearchChoiceField(model_name='staff_clock_in')
    punch_state = forms.ChoiceField(label=_('manualLog_field_punchState'), choices=PUNCH_STATES)
    work_code = forms.CharField(label=_('manualLog_field_workCode'), max_length=20, required=False)
    apply_reason = forms.TextField(label=_('manualLog_field_applyReason'), required=False)
    def __init__(self, *args, **kwargs):
        from mysite.base.utils import get_punch_states
        super(ClockInForm, self).__init__(*args, **kwargs)
        self.fields['punch_state'].choices = get_punch_states()