# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\manage.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:44 UTC (1750673024)

import os
import sys
if __name__ == '__main__':
    try:
        from django.core.management import execute_from_command_line
    except ImportError:
        try:
            import django
        except ImportError:
            raise ImportError('Couldn\'t import Django. Are you sure it\'s installed and available on your PYTHONPATH environment variable? Did you forget to activate a virtual environment?')
        raise
    execute_from_command_line(sys.argv)