# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\att\\admin\\manuallog_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

from celery_progress.backend import AbstractProgressRecorder
from django.forms import ModelForm, ModelChoiceField
from django.utils.translation import gettext_lazy as _
from mysite import admin, config
from mysite.admin import forms
from mysite.admin.exceptions import AdminRuntimeWarning
from mysite.att.actions import AddManualLog, BulkAddManualLog, Approve, Reject, Revoke, Import
from mysite.att.models import ManualLog
from mysite.personnel.models.model_employee import Employee
from mysite.workflow.models_choices import PENDING, REVOKE
from mysite.iclock.models import TerminalWorkCode
class ManualLogChangeForm(ModelForm):
    emp = forms.CharField(label=_('manualLog_field_employee'), disabled=True)
    punch_time = forms.DateTimeField(label=_('manualLog_field_punchTime'))
    work_code = ModelChoiceField(queryset=TerminalWorkCode.objects.get_queryset(), required=False)
    apply_reason = forms.TextField(label=_('manualLog_field_applyReason'), required=False)
    attachment = forms.FileField(label=_('common_field_attachment'), required=False)
    def __init__(self, *args, **kwargs):
        super(ManualLogChangeForm, self).__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields['emp'].initial = str(self.instance.employee)
    def save(self, commit=True):
        if self.changed_data:
            if self.instance.approval_status == REVOKE:
                self.instance.reset = True
            else:
                if self.instance.approval_status == PENDING and self.instance.nodeinstance_set.count():
                    raise AdminRuntimeWarning(_('The application is on processing, not allow to modify.'))
        super(ManualLogChangeForm, self).save(commit)
        return self.instance
    class Meta:
        model = ManualLog
        fields = ('punch_time', 'punch_state', 'work_code', 'apply_reason')
@admin.register(ManualLog)
class ManualLogAdmin(admin.ZKModelAdmin):
    list_display = ('id', 'emp_code', 'emp_photo', 'first_name', 'last_name') + config.WDMS_LIST_DISPLAY + ('department', 'position', 'workflow_engine', 'punch_time', 'punch_state', 'work_code', 'apply_reason', 'apply_time', 'attachment_url', 'approval_status', 'approval_remark', 'approval_time', 'last_approver')
    list_filter = config.EMPLOYEE_LIST_FILTER + config.WDMS_LIST_FILTER_EMPLOYEE + ('punch_time', 'punch_state', 'approval_status')
    non_display_fields = ('color',)
    ordering = ('-id',)
    hidden_fields = ('last_name', 'position', 'attachment_url', 'approval_remark', 'workflow_engine', 'approval_time', 'last_approver') + config.WDMS_HIDDEN
    form = ManualLogChangeForm
    actions = [AddManualLog, BulkAddManualLog, Approve, Reject, Revoke, Import]
    def attachment_url(self, obj):
        if obj.attachment:
            return '/files/' + str(obj.attachment)
        else:
            return ''
    attachment_url.short_description = _('common_field_attachment')
    def has_add_permission(self, request):
        return False
    def get_queryset(self, request):
        qs = super(ManualLogAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            if request.user.auth_dept.exists():
                qs = qs.filter(employee__department__in=request.user.auth_dept.all())
            if request.user.auth_area.exists():
                emp_list_by_area = Employee.objects.filter(area__in=request.user.auth_area.all())
                qs = qs.filter(employee__in=emp_list_by_area)
            if request.user.assign_company:
                qs = qs.filter(employee__company=request.user.assign_company)
        return qs
    def dataimport(self, request):
        from mysite.att.data_import import ImportManualLogData
        overwrite = True if int(request.POST['import_type']) else False
        import_file = request.FILES['import_file']
        request_user = request.user
        handle = ImportManualLogData(request, import_file=import_file, overwrite=overwrite, request_user=request_user)
        handle.exe_import_data()
    def data_import(self, request, **kwargs):
        from mysite.att.data_import import ManualLogImport
        progress_recorder = kwargs.get('progress_recorder', None)
        process = ManualLogImport(request, app_label=self.opts.app_label, model_name=self.opts.model_name, **kwargs)
        process.process()
        if process.errors:
            if isinstance(progress_recorder, AbstractProgressRecorder):
                progress_recorder.stop_task(process.current, process.total, _('importProgress.status.failed'))
            else:
                if progress_recorder:
                    import json
                    progress_recorder(**{'event_name': 'result', 'data': json.dumps({'code': (-1), 'message': str(_('importProgress.status.failed')) + ' {0}/{1}'.format(process.current, process.total), 'channel': ''})})
            return process.errors[0]