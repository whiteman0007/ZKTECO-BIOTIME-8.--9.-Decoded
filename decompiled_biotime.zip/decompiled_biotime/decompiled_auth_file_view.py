# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\auth_file_view.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:03 UTC (1750672983)

import functools
import mimetypes
import os
import posixpath
import re
import stat
import io
from pathlib import Path
from django.http import FileResponse, Http404, HttpResponseNotModified
from django.utils._os import safe_join
from django.utils.http import http_date, parse_http_date
from six.moves.urllib.parse import unquote
from django.utils.translation import gettext as _
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.views.static import directory_index
from mysite._utils import getattr_ex
from mysite.tools.image_utils import decrypt_image
def file_access(expire_with_default=False, path_default=[]):
    """"""
    def method(func):
        @functools.wraps(func)
        def wrapper(request, path: str, *args, **kwargs):
            """"""
            from mysite.tools.access_utils import decode_access_token
            kwargs.update({'dynamic_path': path.startswith(settings.ACCESS_AES_PREFIX)})
            if settings.ACCESS_AES_PREFIX and path.startswith(settings.ACCESS_AES_PREFIX):
                valid, res = decode_access_token(path)
                if not valid:
                    if expire_with_default:
                        path_dir = os.path.dirname(res.get('p', ''))
                        if getattr_ex(settings, 'MULTI_COMPANY', False) and bool(re.search('\\d', path_dir)):
                                path_dir = os.path.dirname(path_dir)
                        if path_dir in path_default:
                            fullpath = Path(safe_join(settings.ADDITION_FILE_ROOT, 'nophoto.gif'))
                            content_type, encoding = mimetypes.guess_type(fullpath)
                            content_type = content_type or 'application/octet-stream'
                            response = FileResponse(open(fullpath, 'rb'), content_type=content_type, filename=res.get('n', ''))
                            statobj = fullpath.stat()
                            response['Last-Modified'] = http_date(statobj.st_mtime)
                            if stat.S_ISREG(statobj.st_mode) and 'Content-Length' not in response:
                                    response['Content-Length'] = statobj.st_size
                            if encoding:
                                response['Content-Encoding'] = encoding
                            return response
                    raise Http404('invalid access')
                else:
                    path = res.get('p', '')
                    if path and (not res.get('n', '')):
                            res.update({'n': os.path.basename(path)})
                    kwargs.update(res)
            return func(request, path, *args, **kwargs)
        return wrapper
    return method
def login_check(users_only=False, users_scope=[]):
    """"""
    def method(func):
        @functools.wraps(func)
        def wrapper(request, path: str, *args, **kwargs):
            """"""
            from django.contrib.auth import get_user_model
            UserModel = get_user_model()
            if users_only and (not isinstance(request.user, UserModel)):
                raise Http404('invalid access')
            else:
                path = posixpath.normpath(path).lstrip('/')
                if users_scope and (not isinstance(request.user, UserModel)):
                    match = [scope for scope in users_scope if path.startswith(scope)]
                    if match:
                        raise Http404('invalid access')
                return func(request, path, *args, **kwargs)
        return wrapper
    return method
@file_access()
def no_auth_file_serve(request, path, document_root=None, show_indexes=False, *args, **kwargs):
    """\n    Serve static files below a given point in the directory structure.\n\n    To use, put a URL pattern such as::\n\n        from django.views.static import serve\n\n        path(\'<path:path>\', serve, {\'document_root\': \'/path/to/my/files/\'})\n\n    in your URLconf. You must provide the ``document_root`` param. You may\n    also set ``show_indexes`` to ``True`` if you\'d like to serve a basic index\n    of the directory.  This index view will use the template hardcoded below,\n    but if you\'d like to override it, you can create a template called\n    ``static/directory_index.html``.\n    """
    path = posixpath.normpath(path).lstrip('/')
    fullpath = Path(safe_join(document_root, path))
    if fullpath.is_dir():
        if show_indexes:
            return directory_index(path, fullpath)
        else:
            raise Http404(_('Directory indexes are not allowed here.'))
    else:
        if not fullpath.exists():
            raise Http404(_('“%(path)s” does not exist') % {'path': fullpath})
        else:
            statobj = fullpath.stat()
            if not was_modified_since(request.META.get('HTTP_IF_MODIFIED_SINCE'), statobj.st_mtime):
                return HttpResponseNotModified()
            else:
                content_type, encoding = mimetypes.guess_type(str(fullpath))
                content_type = content_type or 'application/octet-stream'
                if content_type == 'image/svg':
                    content_type = 'image/svg+xml'
                response = FileResponse(fullpath.open('rb'), content_type=content_type, filename=kwargs.get('filename', ''))
                response.headers['Last-Modified'] = http_date(statobj.st_mtime)
                if encoding:
                    response.headers['Content-Encoding'] = encoding
                return response
@login_required
@file_access()
@login_check(users_scope=['api-docs/', 'card_template/', 'import_template/', 'license/', 'logs/', 'backup/'])
def file_serve(request, path, document_root=None, show_indexes=False, *args, **kwargs):
    """\n    Serve static files below a given point in the directory structure.\n\n    To use, put a URL pattern such as::\n\n        from django.views.static import serve\n\n        path(\'<path:path>\', serve, {\'document_root\': \'/path/to/my/files/\'})\n\n    in your URLconf. You must provide the ``document_root`` param. You may\n    also set ``show_indexes`` to ``True`` if you\'d like to serve a basic index\n    of the directory.  This index view will use the template hardcoded below,\n    but if you\'d like to override it, you can create a template called\n    ``static/directory_index.html``.\n    """
    path = posixpath.normpath(path).lstrip('/')
    fullpath = Path(safe_join(document_root, path))
    if fullpath.is_dir():
        if show_indexes:
            return directory_index(path, fullpath)
        else:
            raise Http404(_('Directory indexes are not allowed here.'))
    else:
        if not fullpath.exists():
            raise Http404(_('“%(path)s” does not exist') % {'path': fullpath})
        else:
            statobj = fullpath.stat()
            if not was_modified_since(request.META.get('HTTP_IF_MODIFIED_SINCE'), statobj.st_mtime):
                return HttpResponseNotModified()
            else:
                content_type, encoding = mimetypes.guess_type(str(fullpath))
                content_type = content_type or 'application/octet-stream'
                if content_type == 'image/svg':
                    content_type = 'image/svg+xml'
                response = FileResponse(fullpath.open('rb'), content_type=content_type, filename=kwargs.get('filename', ''))
                response.headers['Last-Modified'] = http_date(statobj.st_mtime)
                if encoding:
                    response.headers['Content-Encoding'] = encoding
                return response
@login_required
@file_access(expire_with_default=True, path_default=['photo', 'register', 'visitor/photo'])
def auth_file_serve(request, path, document_root=None, *args, **kwargs):
    path_dir = os.path.dirname(path)
    if getattr_ex(settings, 'MULTI_COMPANY', False) and bool(re.search('\\d', path_dir)):
            path_dir = os.path.dirname(path_dir)
    path = posixpath.normpath(unquote(path)).lstrip('/')
    fullpath = safe_join(document_root, path)
    if os.path.isdir(fullpath):
        raise Http404(_('\"%(path)s\" does not exist') % {'path': fullpath})
    else:
        if not os.path.exists(fullpath):
            raise Http404(_('\"%(path)s\" does not exist') % {'path': fullpath})
        else:
            statobj = os.stat(fullpath)
            if not was_modified_since(request.META.get('HTTP_IF_MODIFIED_SINCE'), statobj.st_mtime, statobj.st_size):
                return HttpResponseNotModified()
            else:
                content_type, encoding = mimetypes.guess_type(fullpath)
                content_type = content_type or 'application/octet-stream'
                if content_type == 'image/svg':
                    content_type = 'image/svg+xml'
                if path_dir in ['photo', 'biophoto', 'register', 'visitor/photo', 'visitor/biophoto', 'visitor/register', 'visitor/reservation', 'company_logo']:
                    with open(fullpath, 'rb') as f:
                        decrypt_data = decrypt_image(f.read())
                        de_file = io.BytesIO(decrypt_data)
                    response = FileResponse(de_file, content_type=content_type, filename=kwargs.get('filename', ''))
                    response['Content-Length'] = len(decrypt_data)
                else:
                    response = FileResponse(open(fullpath, 'rb'), content_type=content_type, filename=kwargs.get('filename', ''))
                response['Last-Modified'] = http_date(statobj.st_mtime)
                if stat.S_ISREG(statobj.st_mode) and 'Content-Length' not in response:
                        response['Content-Length'] = statobj.st_size
                if encoding:
                    response['Content-Encoding'] = encoding
                return response
@file_access()
def iclock_doc(request, path, *args, **kwargs):
    """\n    path: 通过encrypt判断返回的信息是加密或解密的图片， 如果不是获取图片信息则直接返回文件\n    """
    dynamic_path = kwargs.get('dynamic_path', False)
    if not dynamic_path:
        raise Http404('Invalid access')
    else:
        path_dir = os.path.dirname(path)
        if getattr_ex(settings, 'MULTI_COMPANY', False) and bool(re.search('\\d', path_dir)):
                path_dir = os.path.dirname(path_dir)
        GET_ENCRYPT_PHOTO = False
        GET_PHOTO = False
        if settings.ENABLE_ENCRYPT_PHOTO:
            if path_dir in ['photo', 'biophoto', 'register', 'visitor/photo', 'visitor/biophoto', 'visitor/register', 'biophoto/palm']:
                document_root = settings.AUTH_FILE_ROOT
                GET_PHOTO = True
            else:
                if path_dir in ['encrypt/photo', 'encrypt/biophoto', 'encrypt/register', 'encrypt/visitor/photo', 'encrypt/visitor/biophoto', 'encrypt/visitor/register', 'encrypt/biophoto/palm']:
                    document_root = settings.AUTH_FILE_ROOT
                    path = path[8:]
                    GET_PHOTO = True
                    GET_ENCRYPT_PHOTO = True
                else:
                    document_root = settings.ADDITION_FILE_ROOT
        else:
            document_root = settings.ADDITION_FILE_ROOT
        path = posixpath.normpath(unquote(path)).lstrip('/')
        fullpath = safe_join(document_root, path)
        if os.path.isdir(fullpath):
            raise Http404(_('\"%(path)s\" does not exist') % {'path': fullpath})
        else:
            if not os.path.exists(fullpath):
                raise Http404(_('\"%(path)s\" does not exist') % {'path': fullpath})
            else:
                statobj = os.stat(fullpath)
                if not was_modified_since(request.META.get('HTTP_IF_MODIFIED_SINCE'), statobj.st_mtime, statobj.st_size):
                    return HttpResponseNotModified()
                else:
                    content_type, encoding = mimetypes.guess_type(fullpath)
                    content_type = content_type or 'application/octet-stream'
                    if GET_PHOTO:
                        with open(fullpath, 'rb') as f:
                            if GET_ENCRYPT_PHOTO:
                                bytes_image = f.read()
                                if b'$' in bytes_image[:10]:
                                    prefix = bytes_image[:10].split(b'$')[0]
                                    bytes_image = bytes_image[len(prefix) + 1:]
                                image_data = io.BytesIO(bytes_image)
                            else:
                                bytes_image = decrypt_image(f.read())
                                image_data = io.BytesIO(bytes_image)
                        response = FileResponse(image_data, content_type=content_type, filename=kwargs.get('filename', ''))
                        response['Content-Length'] = len(bytes_image)
                    else:
                        response = FileResponse(open(fullpath, 'rb'), content_type=content_type, filename=kwargs.get('filename', ''))
                    response['Last-Modified'] = http_date(statobj.st_mtime)
                    if stat.S_ISREG(statobj.st_mode) and 'Content-Length' not in response:
                            response['Content-Length'] = statobj.st_size
                    if encoding:
                        response['Content-Encoding'] = encoding
                    return response
def was_modified_since(header=None, mtime=0, size=0):
    try:
        if header is None:
            raise ValueError
        else:
            matches = re.match('^([^;]+)(; length=([0-9]+))?$', header, re.IGNORECASE)
            header_mtime = parse_http_date(matches.group(1))
            header_len = matches.group(3)
            if header_len and int(header_len)!= size:
                raise ValueError
            else:
                if int(mtime) > header_mtime:
                    raise ValueError
    except (AttributeError, ValueError, OverflowError):
        return True
    else:
        return False