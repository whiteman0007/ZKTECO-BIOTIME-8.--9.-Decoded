# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\base\\models\\auto_export.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:25 UTC (1750673005)

import json
import re
from django.db import models
from django.utils.translation import gettext_lazy as _
from mysite.admin.models import BaseModel
from mysite.base.db_const import MAX_AUTO_EXPORT_CODE, MAX_AUTO_EXPORT_NAME
class AutoExportTask(BaseModel):
    task_code = models.CharField(_('autoExportTask_field_code'), unique=True, max_length=MAX_AUTO_EXPORT_CODE)
    task_name = models.CharField(_('autoExportTask_field_name'), max_length=MAX_AUTO_EXPORT_NAME)
    params = models.TextField(_('autoExportTask_field_params'), null=True, blank=True)
    enable = models.BooleanField(_('autoExport.fields.enable'), default=True)
    process_time = models.DateTimeField(_('autoExport.fields.processTime'), null=True, blank=True)
    def __str__(self):
        return '{code} {name}'.format(code=self.task_code, name=self.task_name)
    def __init__(self, *args, **kwargs):
        super(AutoExportTask, self).__init__(*args, **kwargs)
        if not self.params:
            self.options = {}
        else:
            from mysite.base.api.serializers import AutoExportTaskOptionReadableSerializer
            serializer = AutoExportTaskOptionReadableSerializer(data=self.get_options())
            serializer.is_valid(raise_exception=True)
            self.options = serializer.validated_data
    @classmethod
    def options_handler(cls, options):
        import six
        departments = options.get('departments', None)
        if not departments:
            options['departments'] = []
        else:
            if isinstance(departments, six.text_type):
                departments = list(map(int, filter(lambda x: x.strip(), departments.split(','))))
                options['departments'] = departments
        areas = options.get('areas', None)
        if not areas:
            options['areas'] = []
        else:
            if isinstance(areas, six.text_type):
                areas = list(map(int, filter(lambda x: x.strip(), areas.split(','))))
                options['areas'] = areas
        if 'export_encryption_type' not in options:
            options['export_encryption_type'] = 0
            options['export_encryption_password'] = ''
        return options
    def get_options(self):
        from mysite.personnel.models import Department, Area
        from mysite.personnel.utils import get_default_company
        if not self.params:
            return {}
        else:
            options = json.loads(self.params)
            options = self.options_handler(options)
            if not options.get('company', None):
                options['company'] = get_default_company().id
                if options['departments']:
                    department = Department.objects.filter(id=options['departments'][0]).first()
                    if department:
                        options['company'] = department.company.id
                else:
                    if options['areas']:
                        area = Area.objects.filter(id=options['areas'][0]).first()
                        if area:
                            options['company'] = area.company.id
            return options
    def data_template(self):
        return self.options.get('data_template', '')
    data_template.short_description = _('autoExport_task_dataTemplate')
    def query_field(self):
        return self.options.get('query_field', '')
    query_field.short_description = _('autoExport_task_queryField')
    def export_file(self):
        return self.options.get('file_prefix', '')
    export_file.short_description = _('autoExport_task_filePrefix')
    def export_format(self):
        return self.options.get('export_format', '')
    export_format.short_description = _('autoExport_task_exportFormat')
    def export_path(self):
        return self.options.get('export_path', '')
    export_path.short_description = _('autoExport_task_exportPath')
    def export_by(self):
        return self.options.get('export_policy', '')
    export_by.short_description = _('autoExport_task_export_by')
    def export_time(self):
        return self.options.get('export_time', '')
    export_time.short_description = _('autoExport_task_exportTime')
    class Meta:
        app_label = 'base'
        verbose_name = _('base_model_autoExportTask')
        verbose_name_plural = verbose_name