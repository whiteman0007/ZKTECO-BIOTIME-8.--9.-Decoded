# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\asgi.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:54 UTC (1750672974)

"""\nASGI config for HelloWord project.\n\nIt exposes the ASGI callable as a module-level variable named ``application``.\n\nFor more information on this file, see\nhttps://docs.djangoproject.com/en/4.2/howto/deployment/asgi/\n"""
from django.urls import re_path
import mysite.base.websocket.urls
from mysite import asgi_urls
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')
import django
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter, get_default_application
from channels.auth import AuthMiddlewareStack
application = ProtocolTypeRouter({'http': AuthMiddlewareStack(URLRouter(asgi_urls.urlpatterns + [re_path('', get_asgi_application())])), 'websocket': AuthMiddlewareStack(URLRouter(mysite.base.websocket.urls.urlpatterns))})