# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\payroll\\admin\\leave_formula_admin.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:11 UTC (1750673051)

from mysite import admin
from mysite.payroll.models import LeaveFormula
from mysite.admin.kernel import ZKModelAdmin
from mysite.payroll.forms import AddLeaveFormulaForm
@admin.register(LeaveFormula)
class LeaveFormulaAdmin(ZKModelAdmin):
    actions = []
    list_display = ('id', 'name', 'pay_code', 'formula', 'remark')
    list_filter = ('name', 'pay_code', 'formula', 'remark')
    sort_fields = ()
    cache_keys = ()
    form = AddLeaveFormulaForm