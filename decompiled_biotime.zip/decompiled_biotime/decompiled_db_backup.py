# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\base\\api\\serializers\\db_backup.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:03:09 UTC (1750672989)

import os
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
class DBBackupUpdateSerializer(serializers.Serializer):
    db_type = serializers.CharField()
    db_name = serializers.CharField()
    file_path = serializers.CharField()
    frequency = serializers.CharField()
    point_day = serializers.CharField()
    point_time = serializers.CharField()
    is_backup_photo = serializers.CharField()
    def validate_file_path(self, value):
        if not value:
            raise ValidationError(detail=_('store_path_is_required'))
        try:
            if not os.path.exists(value):
                os.makedirs(value)
            if not os.path.exists(value):
                raise ValidationError(detail=_('store_path_is_wrong'))
        except Exception:
            raise ValidationError(detail=_('store_path_is_wrong'))
        else:
            return value