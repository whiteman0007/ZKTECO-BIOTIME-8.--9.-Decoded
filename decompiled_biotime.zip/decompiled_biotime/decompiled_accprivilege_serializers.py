# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\acc\\api\\serializers\\accprivilege_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:48 UTC (1750672968)

from rest_framework import serializers
from mysite.acc.models.model_acc_privilege import AccPrivilege
from mysite.att.api.serializers import util_serializers
class AccPrivilegeSerializer(serializers.ModelSerializer):
    area_name = serializers.CharField(source='area.area_name')
    group_no = serializers.CharField(source='group.group_no')
    verify_mode = serializers.CharField(source='get_verify_mode_display')
    is_group_timezone = serializers.CharField(source='get_is_group_timezone_display')
    class Meta:
        model = AccPrivilege
        fields = ['id', 'area_name', 'emp_code', 'emp_first_name', 'emp_last_name', 'group_no', 'is_group_timezone', 'timezone1', 'timezone2', 'timezone3', 'verify_mode']
class AccPrivilegeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccPrivilege
        fields = '__all__'
class AccPrivilegeEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccPrivilege
        fields = '__all__'
class AccPrivilegeActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = AccPrivilege
        action_type_choices = (('delete', 'delete'),)