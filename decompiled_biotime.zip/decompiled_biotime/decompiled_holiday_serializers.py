# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\api\\serializers\\holiday_serializers.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:55 UTC (1750672975)

from rest_framework import serializers
from mysite.att.models.model_holiday import Holiday
from mysite.att.api.serializers import util_serializers
from mysite.utils import get_dt4mssql
class HolidaySerializer(serializers.ModelSerializer):
    work_type = serializers.CharField(source='get_work_type_display', allow_null=True)
    department = serializers.CharField(source='department.dept_name', allow_null=True)
    start_date = serializers.SerializerMethodField()
    def get_start_date(self, obj):
        return get_dt4mssql(obj.start_date, 1)
    class Meta:
        model = Holiday
        fields = ['id', 'alias', 'department', 'start_date', 'duration_day', 'work_type']
class HolidayCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Holiday
        fields = '__all__'
class HolidayEditSerializer(serializers.ModelSerializer):
    class Meta:
        model = Holiday
        fields = '__all__'
class HolidayActionSerializer(util_serializers.ObjectActionSerializer):
    class Meta:
        model = Holiday
        action_type_choices = (('delete', 'delete'),)