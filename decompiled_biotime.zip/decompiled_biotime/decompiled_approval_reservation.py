# Decompiled with Hussein Amer
# Internal filename: 'E:\\Python\\ZKBioTime 8\\tags\\9.0.4\\mysite\\staff_visitor\\models\\approval_reservation.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:04:37 UTC (1750673077)

from mysite.visitor.models import Reservation
class ApprovalReservation(Reservation):
    def get_template_base_root(self):
        return 'visitor/reservation'
    class Meta:
        default_permissions = ()
        app_label = 'staff_visitor'
        proxy = True