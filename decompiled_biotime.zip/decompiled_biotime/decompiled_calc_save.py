# Decompiled with Hussein Amer
# Internal filename: '.\\mysite\\att\\calc_new\\calc_save.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 2025-06-23 10:02:57 UTC (1750672977)

import logging
import json
import decimal
from mysite.att.calc_new.utils import to_workday, to_hour, pay_code_set_exception
from mysite.att.calc_new.utils import get_workday, get_hours, get_minutes
from mysite.att.models import Overtime
from mysite.att.models.model_payload import PayloadTimeCard, PayloadPayCode, PayloadAttCode, PayloadParing, PayloadEffectPunch, PayloadWorkCodeParing
from mysite.att.models_choices import APPROVAL_IGNORE
from mysite.workflow.models_choices import APPROVED
logger = logging.getLogger('att_calc')
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        else:
            super(DecimalEncoder, self).default(o)
def auto_add_overtime(emp, overtime_punchs, overtimes, pay_code_id, approval_status):
    if not emp.attemployee or not emp.attemployee.enable_overtime:
        return None
    else:
        for pairs in overtime_punchs:
            if approval_status == APPROVAL_IGNORE:
                continue
            else:
                start, end = (pairs[0], pairs[1])
                overtime_obj = Overtime()
                overtime_obj.pay_code_id = pay_code_id
                overtime_obj.start_time = start
                overtime_obj.end_time = end
                overtime_obj.employee = emp
                overtime_obj.approval_status = approval_status
                if not Overtime.objects.filter(employee=emp, start_time=start, end_time=end).first():
                    try:
                        overtime_obj.save()
                        if approval_status == APPROVED:
                            overtimes.append({'start_time': start, 'end_time': end, 'pay_code_id': pay_code_id})
                    except Exception:
                        logger.exception('auto_add_overtime error.')
def get_payload_pay_code(cur_date, paycode, base_time_card_data, interval_work_time, pc_dict, work_day):
    payload_pay_code_list = []
    for k, v in paycode.items():
        if v <= 0:
            continue
        else:
            payload_pay_code = {'is_weekly': False, 'pay_code': pc_dict[k], 'pay_code_alias': pc_dict[k].name, 'pay_code_symbol': pc_dict[k].symbol, 'duration': v * 60, 'workday': get_workday(v, interval_work_time, work_day, pc_dict[k]), 'hours': get_hours(v * 60, pc_dict[k]), 'minutes': get_minutes(v * 60, pc_dict[k])}
            payload_pay_code.update(base_time_card_data)
            pay_code_set_exception(payload_pay_code)
            payload_pay_code_list.append(payload_pay_code)
    return payload_pay_code_list
def get_payload_att_code(attcode, base_time_card_data, interval_work_time, ac_dict, work_day):
    payload_att_code_list = []
    for k, v in attcode.items():
        if v <= 0:
            continue
        else:
            payload_att_code = {'is_weekly': False, 'att_code': ac_dict[k], 'att_code_alias': ac_dict[k].alias, 'att_code_symbol': ac_dict[k].symbol, 'duration': v * 60, 'workday': get_workday(v, interval_work_time, work_day, ac_dict[k]), 'hours': get_hours(v * 60, ac_dict[k]), 'minutes': get_minutes(v * 60, ac_dict[k])}
            payload_att_code.update(base_time_card_data)
            payload_att_code_list.append(payload_att_code)
    return payload_att_code_list
def get_payload_paring(data_type, data_index, pay_code, work_day, base_time_card_data, paring):
    if paring.get('clock_out', None) and paring.get('clock_in', None):
        duration = (paring['clock_out'] - paring['clock_in']).total_seconds()
    else:
        duration = 0
    paring_data = {'data_type': data_type, 'duration': duration, 'worked_duration': 0, 'pay_code_id': pay_code, 'stamp': 0, 'data_index': data_index, 'workday': work_day}
    paring_data.update(paring)
    paring_data.update(base_time_card_data)
    return paring_data
def save_payload(payload, policy):
    from django.conf import settings
    payload['time_card'].pop('year')
    time_card = PayloadTimeCard(**payload['time_card'])
    time_card.save(force_insert=True)
    pay_codes = []
    time_card_payload = {}
    for pay_code in payload['pay_code']:
        if pay_code['pay_code'].is_cp() and (not policy.enable_compensatory):
                continue
        pay_codes.append(PayloadPayCode(**pay_code))
        payload_key = 'paycode_%s' % pay_code['pay_code'].id
        time_card_payload[payload_key] = {'duration': pay_code['duration'], 'workday': pay_code['workday'], 'hours': pay_code['hours'], 'minutes': pay_code['minutes']}
    PayloadPayCode.objects.bulk_create(pay_codes)
    att_codes = []
    for att_code in payload['att_code']:
        att_code.pop('year')
        att_codes.append(PayloadAttCode(**att_code))
        time_card_payload[att_code['att_code'].code] = {'duration': att_code['duration'], 'workday': att_code['workday'], 'hours': att_code['hours'], 'minutes': att_code['minutes']}
    PayloadAttCode.objects.bulk_create(att_codes)
    time_card.payload = json.dumps(time_card_payload, cls=DecimalEncoder)
    time_card.save(force_update=True)
    parings = []
    with_paycode_parings = []
    for paring in payload['paring']:
        paring.pop('year')
        if paring['pay_code_id'] is None:
            parings.append(PayloadParing(**paring))
        else:
            with_paycode_parings.append(PayloadParing(**paring))
    if 'oracle' in settings.DATABASES['default']['ENGINE'].lower():
        PayloadParing.objects.bulk_create(parings)
        PayloadParing.objects.bulk_create(with_paycode_parings)
    else:
        parings.extend(with_paycode_parings)
        PayloadParing.objects.bulk_create(parings)
    effect_punchs = []
    for effect_punch in payload['effect_punch']:
        effect_punch.pop('year')
        effect_punchs.append(PayloadEffectPunch(**effect_punch))
    PayloadEffectPunch.objects.bulk_create(effect_punchs)
    work_code_parings = []
    for work_code_paring in payload['work_code_paring']:
        work_code_paring.pop('year')
        work_code_parings.append(PayloadWorkCodeParing(**work_code_paring))
    PayloadWorkCodeParing.objects.bulk_create(work_code_parings)